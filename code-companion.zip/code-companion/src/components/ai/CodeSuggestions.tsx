import { useState } from 'react';
import { Sparkles, Check, X, ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import type { CodeSuggestion } from '@/types';

const mockSuggestions: CodeSuggestion[] = [
  {
    id: '1',
    code: 'const handleSubmit = async (data: FormData) => {\n  try {\n    await submitForm(data);\n    toast.success("Form submitted!");\n  } catch (error) {\n    toast.error("Submission failed");\n  }\n};',
    description: 'Complete the form submission handler with error handling',
    confidence: 95,
  },
  {
    id: '2',
    code: 'useEffect(() => {\n  const controller = new AbortController();\n  fetchData(controller.signal);\n  return () => controller.abort();\n}, []);',
    description: 'Add cleanup for async operations in useEffect',
    confidence: 88,
  },
];

interface CodeSuggestionsProps {
  isVisible: boolean;
  onAccept: (suggestion: CodeSuggestion) => void;
  onDismiss: (suggestionId: string) => void;
}

export function CodeSuggestions({ isVisible, onAccept, onDismiss }: CodeSuggestionsProps) {
  const [suggestions, setSuggestions] = useState<CodeSuggestion[]>(mockSuggestions);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  if (!isVisible || suggestions.length === 0) return null;

  const handleAccept = (suggestion: CodeSuggestion) => {
    onAccept(suggestion);
    setSuggestions((prev) => prev.filter((s) => s.id !== suggestion.id));
  };

  const handleDismiss = (id: string) => {
    onDismiss(id);
    setSuggestions((prev) => prev.filter((s) => s.id !== id));
  };

  return (
    <div className="absolute bottom-20 left-1/2 -translate-x-1/2 w-[500px] z-50">
      <div className="bg-card border border-border rounded-lg shadow-xl glow-ai overflow-hidden animate-fade-in">
        <div className="flex items-center gap-2 px-4 py-2 border-b border-border bg-secondary/50">
          <Sparkles className="h-4 w-4 text-primary animate-pulse" />
          <span className="text-sm font-medium">AI Suggestions</span>
          <span className="text-xs text-muted-foreground ml-auto">
            {suggestions.length} available
          </span>
        </div>

        <div className="max-h-64 overflow-y-auto">
          {suggestions.map((suggestion) => (
            <div
              key={suggestion.id}
              className="border-b border-border last:border-0"
            >
              <div className="flex items-start gap-3 p-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm font-medium truncate">
                      {suggestion.description}
                    </span>
                    <span className={cn(
                      "text-xs px-1.5 py-0.5 rounded-full",
                      suggestion.confidence >= 90 
                        ? "bg-syntax-string/20 text-syntax-string"
                        : "bg-syntax-type/20 text-syntax-type"
                    )}>
                      {suggestion.confidence}%
                    </span>
                  </div>
                  
                  <button
                    onClick={() => setExpandedId(expandedId === suggestion.id ? null : suggestion.id)}
                    className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1"
                  >
                    {expandedId === suggestion.id ? (
                      <>
                        <ChevronUp className="h-3 w-3" />
                        Hide code
                      </>
                    ) : (
                      <>
                        <ChevronDown className="h-3 w-3" />
                        Show code
                      </>
                    )}
                  </button>

                  {expandedId === suggestion.id && (
                    <pre className="mt-2 p-2 bg-terminal rounded text-xs overflow-x-auto">
                      <code className="text-terminal-text">{suggestion.code}</code>
                    </pre>
                  )}
                </div>

                <div className="flex gap-1 flex-shrink-0">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7 text-syntax-string hover:bg-syntax-string/20"
                    onClick={() => handleAccept(suggestion)}
                  >
                    <Check className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7 text-destructive hover:bg-destructive/20"
                    onClick={() => handleDismiss(suggestion.id)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="px-4 py-2 bg-secondary/30 text-xs text-muted-foreground">
          Press <kbd className="px-1 py-0.5 bg-secondary rounded text-foreground">Tab</kbd> to accept, <kbd className="px-1 py-0.5 bg-secondary rounded text-foreground">Esc</kbd> to dismiss
        </div>
      </div>
    </div>
  );
}
