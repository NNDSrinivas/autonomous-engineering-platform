import { useState } from 'react';
import { X, Circle } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { EditorTab } from '@/types';

interface CodeEditorProps {
  tabs: EditorTab[];
  activeTabId: string | null;
  onTabChange: (tabId: string) => void;
  onTabClose: (tabId: string) => void;
}

const sampleCode = `import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { fetchUserData } from '@/api/users';

interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
}

export function UserProfile({ userId }: { userId: string }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function loadUser() {
      try {
        const data = await fetchUserData(userId);
        setUser(data);
      } catch (error) {
        console.error('Failed to fetch user:', error);
      } finally {
        setIsLoading(false);
      }
    }

    loadUser();
  }, [userId]);

  if (isLoading) {
    return <div className="animate-pulse">Loading...</div>;
  }

  if (!user) {
    return <div>User not found</div>;
  }

  return (
    <div className="p-6 rounded-lg bg-card">
      <div className="flex items-center gap-4">
        <img 
          src={user.avatar || '/default-avatar.png'} 
          alt={user.name}
          className="w-16 h-16 rounded-full"
        />
        <div>
          <h2 className="text-xl font-bold">{user.name}</h2>
          <p className="text-muted-foreground">{user.email}</p>
        </div>
      </div>
      <Button className="mt-4">Edit Profile</Button>
    </div>
  );
}`;

function tokenizeLine(line: string): JSX.Element[] {
  const tokens: JSX.Element[] = [];
  let remaining = line;
  let key = 0;

  const patterns: [RegExp, string][] = [
    [/^(\/\/.*|\/\*[\s\S]*?\*\/)/, 'text-syntax-comment'],
    [/^(['"`].*?['"`])/, 'text-syntax-string'],
    [/^(\b(import|export|from|const|let|var|function|return|if|else|try|catch|finally|async|await|interface|type|extends|implements|class|new|this|null|undefined|true|false)\b)/, 'text-syntax-keyword'],
    [/^(\b\d+\.?\d*\b)/, 'text-syntax-number'],
    [/^(\b[A-Z][a-zA-Z0-9]*\b)/, 'text-syntax-type'],
    [/^(\b[a-z][a-zA-Z0-9]*\s*(?=\())/, 'text-syntax-function'],
    [/^([{}[\]().,;:?<>=!+\-*/&|^~%@#])/, 'text-muted-foreground'],
  ];

  while (remaining.length > 0) {
    let matched = false;

    for (const [pattern, className] of patterns) {
      const match = remaining.match(pattern);
      if (match) {
        tokens.push(
          <span key={key++} className={className}>
            {match[0]}
          </span>
        );
        remaining = remaining.slice(match[0].length);
        matched = true;
        break;
      }
    }

    if (!matched) {
      const nextSpecial = remaining.slice(1).search(/['"`]|\b(import|export|const|let|var|function|return|if|else|interface|type)\b|\d|\s[A-Z]/);
      const end = nextSpecial === -1 ? remaining.length : nextSpecial + 1;
      tokens.push(
        <span key={key++} className="text-syntax-variable">
          {remaining.slice(0, end)}
        </span>
      );
      remaining = remaining.slice(end);
    }
  }

  return tokens;
}

export function CodeEditor({ tabs, activeTabId, onTabChange, onTabClose }: CodeEditorProps) {
  const [cursorLine, setCursorLine] = useState(15);
  const activeTab = tabs.find(t => t.id === activeTabId);
  const lines = sampleCode.split('\n');

  return (
    <div className="flex-1 flex flex-col bg-editor overflow-hidden">
      {/* Tabs */}
      <div className="flex bg-background border-b border-border overflow-x-auto">
        {tabs.map((tab) => (
          <div
            key={tab.id}
            className={cn(
              "flex items-center gap-2 px-4 py-2 border-r border-border cursor-pointer group min-w-0",
              tab.id === activeTabId 
                ? "bg-editor text-foreground border-t-2 border-t-primary" 
                : "bg-background text-muted-foreground hover:bg-secondary"
            )}
            onClick={() => onTabChange(tab.id)}
          >
            <span className="truncate text-sm">{tab.name}</span>
            {tab.isModified && (
              <Circle className="h-2 w-2 fill-current text-primary" />
            )}
            <button
              onClick={(e) => {
                e.stopPropagation();
                onTabClose(tab.id);
              }}
              className="opacity-0 group-hover:opacity-100 hover:bg-secondary rounded p-0.5 transition-opacity"
            >
              <X className="h-3 w-3" />
            </button>
          </div>
        ))}
      </div>

      {/* Breadcrumb */}
      {activeTab && (
        <div className="px-4 py-1 text-xs text-muted-foreground bg-editor border-b border-border">
          src › components › {activeTab.name}
        </div>
      )}

      {/* Editor content */}
      <div className="flex-1 overflow-auto font-mono text-sm">
        <div className="min-w-max">
          {lines.map((line, index) => (
            <div
              key={index}
              className={cn(
                "flex code-line",
                cursorLine === index + 1 && "bg-editor-line"
              )}
              onClick={() => setCursorLine(index + 1)}
            >
              <div className="w-14 px-4 text-right text-editor-gutter select-none flex-shrink-0">
                {index + 1}
              </div>
              <pre className="px-4 py-0">
                <code>{tokenizeLine(line)}</code>
              </pre>
            </div>
          ))}
        </div>
      </div>

      {/* Status bar */}
      <div className="flex items-center justify-between px-4 py-1 bg-primary text-primary-foreground text-xs">
        <div className="flex items-center gap-4">
          <span>Ln {cursorLine}, Col 1</span>
          <span>Spaces: 2</span>
          <span>UTF-8</span>
        </div>
        <div className="flex items-center gap-4">
          <span>TypeScript React</span>
          <span>Prettier</span>
        </div>
      </div>
    </div>
  );
}
