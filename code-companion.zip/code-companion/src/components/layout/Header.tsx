import { 
  Menu, 
  Search, 
  Play, 
  Bug, 
  MoreHorizontal,
  Sparkles,
  MessageSquare
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

interface HeaderProps {
  isChatOpen: boolean;
  onToggleChat: () => void;
}

const menuItems = ['File', 'Edit', 'Selection', 'View', 'Go', 'Run', 'Terminal', 'Help'];

export function Header({ isChatOpen, onToggleChat }: HeaderProps) {
  return (
    <header className="h-9 bg-background border-b border-border flex items-center px-2 gap-2">
      {/* Window controls placeholder */}
      <div className="flex items-center gap-1.5 px-2">
        <div className="w-3 h-3 rounded-full bg-destructive/60" />
        <div className="w-3 h-3 rounded-full bg-syntax-type/60" />
        <div className="w-3 h-3 rounded-full bg-syntax-string/60" />
      </div>

      {/* Menu items */}
      <nav className="flex items-center">
        {menuItems.map((item) => (
          <button
            key={item}
            className="px-2 py-0.5 text-xs text-muted-foreground hover:text-foreground hover:bg-secondary rounded transition-colors"
          >
            {item}
          </button>
        ))}
      </nav>

      {/* Search bar */}
      <div className="flex-1 flex justify-center max-w-md mx-auto">
        <div className="relative w-full">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search files, symbols..."
            className="h-6 pl-7 pr-3 text-xs bg-secondary border-none"
          />
          <div className="absolute right-2 top-1/2 -translate-y-1/2 flex gap-1">
            <kbd className="px-1 text-[10px] text-muted-foreground bg-background rounded">⌘</kbd>
            <kbd className="px-1 text-[10px] text-muted-foreground bg-background rounded">P</kbd>
          </div>
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-1">
        <Button variant="ghost" size="icon" className="h-7 w-7">
          <Play className="h-3.5 w-3.5" />
        </Button>
        <Button variant="ghost" size="icon" className="h-7 w-7">
          <Bug className="h-3.5 w-3.5" />
        </Button>
        <div className="w-px h-4 bg-border mx-1" />
        <Button
          variant={isChatOpen ? "ai" : "ghost"}
          size="sm"
          onClick={onToggleChat}
          className={cn(
            "h-7 gap-1.5 px-2",
            isChatOpen && "glow-ai"
          )}
        >
          <Sparkles className="h-3.5 w-3.5" />
          <span className="text-xs">AI</span>
        </Button>
      </div>
    </header>
  );
}
