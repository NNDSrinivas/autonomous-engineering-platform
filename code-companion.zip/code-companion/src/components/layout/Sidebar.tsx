import { useState } from 'react';
import { 
  Files, 
  Search, 
  GitBranch, 
  Bug, 
  Puzzle, 
  Settings,
  ChevronRight,
  ChevronDown,
  FileCode,
  FileJson,
  FileText,
  Folder,
  FolderOpen
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import type { FileItem } from '@/types';

const sidebarIcons = [
  { icon: Files, label: 'Explorer', id: 'explorer' },
  { icon: Search, label: 'Search', id: 'search' },
  { icon: GitBranch, label: 'Source Control', id: 'git' },
  { icon: Bug, label: 'Debug', id: 'debug' },
  { icon: Puzzle, label: 'Extensions', id: 'extensions' },
];

const mockFiles: FileItem[] = [
  {
    id: '1',
    name: 'src',
    type: 'folder',
    children: [
      {
        id: '2',
        name: 'components',
        type: 'folder',
        children: [
          { id: '3', name: 'Button.tsx', type: 'file', language: 'typescript' },
          { id: '4', name: 'Input.tsx', type: 'file', language: 'typescript' },
          { id: '5', name: 'Card.tsx', type: 'file', language: 'typescript' },
        ],
      },
      {
        id: '6',
        name: 'hooks',
        type: 'folder',
        children: [
          { id: '7', name: 'useAuth.ts', type: 'file', language: 'typescript' },
          { id: '8', name: 'useApi.ts', type: 'file', language: 'typescript' },
        ],
      },
      { id: '9', name: 'App.tsx', type: 'file', language: 'typescript' },
      { id: '10', name: 'main.tsx', type: 'file', language: 'typescript' },
      { id: '11', name: 'index.css', type: 'file', language: 'css' },
    ],
  },
  { id: '12', name: 'package.json', type: 'file', language: 'json' },
  { id: '13', name: 'tsconfig.json', type: 'file', language: 'json' },
  { id: '14', name: 'README.md', type: 'file', language: 'markdown' },
];

interface FileTreeItemProps {
  item: FileItem;
  depth: number;
  onSelect: (item: FileItem) => void;
  selectedId: string | null;
}

const getFileIcon = (item: FileItem) => {
  if (item.type === 'folder') return null;
  
  switch (item.language) {
    case 'typescript':
    case 'javascript':
      return <FileCode className="h-4 w-4 text-syntax-function" />;
    case 'json':
      return <FileJson className="h-4 w-4 text-syntax-type" />;
    default:
      return <FileText className="h-4 w-4 text-muted-foreground" />;
  }
};

function FileTreeItem({ item, depth, onSelect, selectedId }: FileTreeItemProps) {
  const [isOpen, setIsOpen] = useState(depth < 1);
  const isSelected = selectedId === item.id;

  const handleClick = () => {
    if (item.type === 'folder') {
      setIsOpen(!isOpen);
    } else {
      onSelect(item);
    }
  };

  return (
    <div>
      <button
        onClick={handleClick}
        className={cn(
          "flex items-center w-full py-1 px-2 text-sm hover:bg-sidebar-hover transition-colors rounded-sm group",
          isSelected && "bg-sidebar-hover text-primary"
        )}
        style={{ paddingLeft: `${depth * 12 + 8}px` }}
      >
        {item.type === 'folder' ? (
          <>
            {isOpen ? (
              <ChevronDown className="h-4 w-4 mr-1 text-muted-foreground" />
            ) : (
              <ChevronRight className="h-4 w-4 mr-1 text-muted-foreground" />
            )}
            {isOpen ? (
              <FolderOpen className="h-4 w-4 mr-2 text-syntax-type" />
            ) : (
              <Folder className="h-4 w-4 mr-2 text-syntax-type" />
            )}
          </>
        ) : (
          <>
            <span className="w-4 mr-1" />
            <span className="mr-2">{getFileIcon(item)}</span>
          </>
        )}
        <span className={cn(
          "truncate",
          item.type === 'file' && "text-foreground",
          item.type === 'folder' && "text-foreground font-medium"
        )}>
          {item.name}
        </span>
      </button>
      {item.type === 'folder' && isOpen && item.children && (
        <div>
          {item.children.map((child) => (
            <FileTreeItem
              key={child.id}
              item={child}
              depth={depth + 1}
              onSelect={onSelect}
              selectedId={selectedId}
            />
          ))}
        </div>
      )}
    </div>
  );
}

interface SidebarProps {
  onFileSelect: (file: FileItem) => void;
  selectedFileId: string | null;
}

export function Sidebar({ onFileSelect, selectedFileId }: SidebarProps) {
  const [activeTab, setActiveTab] = useState('explorer');

  return (
    <div className="flex h-full">
      {/* Icon bar */}
      <div className="w-12 bg-background border-r border-border flex flex-col items-center py-2 gap-1">
        {sidebarIcons.map(({ icon: Icon, label, id }) => (
          <Button
            key={id}
            variant={activeTab === id ? 'sidebarActive' : 'sidebar'}
            size="icon"
            onClick={() => setActiveTab(id)}
            title={label}
            className={cn(
              "h-10 w-10 rounded-none border-l-2 border-transparent",
              activeTab === id && "border-primary bg-transparent"
            )}
          >
            <Icon className="h-5 w-5" />
          </Button>
        ))}
        <div className="flex-1" />
        <Button variant="sidebar" size="icon" title="Settings" className="h-10 w-10">
          <Settings className="h-5 w-5" />
        </Button>
      </div>

      {/* File explorer */}
      <div className="w-56 bg-sidebar border-r border-border flex flex-col">
        <div className="px-4 py-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
          Explorer
        </div>
        <div className="flex-1 overflow-y-auto px-1">
          {mockFiles.map((item) => (
            <FileTreeItem
              key={item.id}
              item={item}
              depth={0}
              onSelect={onFileSelect}
              selectedId={selectedFileId}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
