import { useState } from 'react';
import { Terminal as TerminalIcon, X, Plus, ChevronUp, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface TerminalProps {
  isOpen: boolean;
  onToggle: () => void;
}

const terminalOutput = [
  { type: 'command', content: '$ npm run dev' },
  { type: 'info', content: '' },
  { type: 'info', content: '  VITE v5.0.0  ready in 342 ms' },
  { type: 'info', content: '' },
  { type: 'success', content: '  ➜  Local:   http://localhost:5173/' },
  { type: 'info', content: '  ➜  Network: http://192.168.1.100:5173/' },
  { type: 'info', content: '  ➜  press h + enter to show help' },
  { type: 'info', content: '' },
  { type: 'info', content: '[TypeScript] Found 0 errors. Watching for file changes.' },
];

export function Terminal({ isOpen, onToggle }: TerminalProps) {
  const [activeTab, setActiveTab] = useState('terminal');
  const tabs = ['Terminal', 'Problems', 'Output', 'Debug Console'];

  if (!isOpen) {
    return (
      <button
        onClick={onToggle}
        className="fixed bottom-4 right-96 bg-card border border-border rounded-lg px-3 py-1.5 flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors shadow-lg"
      >
        <TerminalIcon className="h-4 w-4" />
        Terminal
        <ChevronUp className="h-3 w-3" />
      </button>
    );
  }

  return (
    <div className="h-48 bg-terminal border-t border-border flex flex-col">
      {/* Tabs */}
      <div className="flex items-center justify-between bg-background border-b border-border">
        <div className="flex">
          {tabs.map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab.toLowerCase().replace(' ', '-'))}
              className={cn(
                "px-3 py-1.5 text-xs border-b-2 transition-colors",
                activeTab === tab.toLowerCase().replace(' ', '-')
                  ? "border-primary text-foreground"
                  : "border-transparent text-muted-foreground hover:text-foreground"
              )}
            >
              {tab}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-1 px-2">
          <Button variant="ghost" size="icon" className="h-6 w-6">
            <Plus className="h-3.5 w-3.5" />
          </Button>
          <Button variant="ghost" size="icon" className="h-6 w-6" onClick={onToggle}>
            <ChevronDown className="h-3.5 w-3.5" />
          </Button>
          <Button variant="ghost" size="icon" className="h-6 w-6" onClick={onToggle}>
            <X className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>

      {/* Terminal content */}
      <div className="flex-1 overflow-auto p-2 font-mono text-xs">
        {terminalOutput.map((line, index) => (
          <div
            key={index}
            className={cn(
              line.type === 'command' && 'text-foreground',
              line.type === 'success' && 'text-syntax-string',
              line.type === 'error' && 'text-destructive',
              line.type === 'info' && 'text-muted-foreground'
            )}
          >
            {line.content || '\u00A0'}
          </div>
        ))}
        <div className="flex items-center text-foreground">
          <span className="text-syntax-string">$</span>
          <span className="ml-2 w-2 h-4 bg-foreground animate-pulse" />
        </div>
      </div>
    </div>
  );
}
