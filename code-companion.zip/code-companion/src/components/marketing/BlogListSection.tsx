import { useState, useRef } from 'react';
import { useInView } from 'framer-motion';
import { Search, Calendar, Clock, User, Tag, ArrowRight } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

const allPosts = [
  {
    id: 1,
    title: 'Introducing NAVI: The Future of Autonomous Engineering',
    excerpt: 'Today we are launching NAVI, the most advanced autonomous engineering AI ever built.',
    category: 'Product',
    author: 'NAVI Team',
    date: '2024-01-15',
    readTime: '5 min',
    gradient: 'from-primary via-accent to-purple-500',
    featured: true,
  },
  {
    id: 2,
    title: 'How NAVI Understands Your Entire Engineering Context',
    excerpt: 'Deep dive into NAVI universal context awareness and how it connects to your tools.',
    category: 'Engineering',
    author: 'Sarah Chen',
    date: '2024-01-12',
    readTime: '8 min',
    gradient: 'from-blue-500 via-cyan-500 to-teal-500',
    featured: true,
  },
  {
    id: 3,
    title: 'The Approval-First Architecture: Why Control Matters',
    excerpt: 'Exploring the design philosophy behind NAVI approval-first system.',
    category: 'Security',
    author: 'Michael Rodriguez',
    date: '2024-01-10',
    readTime: '6 min',
    gradient: 'from-green-500 via-emerald-500 to-teal-500',
    featured: false,
  },
  {
    id: 4,
    title: 'Building Workflow Templates for Your Team',
    excerpt: 'Learn how to create and share custom workflow templates.',
    category: 'Tutorial',
    author: 'Emily Watson',
    date: '2024-01-08',
    readTime: '10 min',
    gradient: 'from-orange-500 via-red-500 to-pink-500',
    featured: false,
  },
  {
    id: 5,
    title: 'NAVI Memory System: How AI Learns Your Preferences',
    excerpt: 'Understanding how NAVI builds and uses its memory system.',
    category: 'Engineering',
    author: 'David Kim',
    date: '2024-01-05',
    readTime: '7 min',
    gradient: 'from-violet-500 via-purple-500 to-fuchsia-500',
    featured: false,
  },
  {
    id: 6,
    title: 'Enterprise Security Best Practices with NAVI',
    excerpt: 'A comprehensive guide to deploying NAVI in enterprise environments.',
    category: 'Security',
    author: 'Alex Johnson',
    date: '2024-01-03',
    readTime: '12 min',
    gradient: 'from-slate-500 via-gray-500 to-zinc-500',
    featured: false,
  },
];

const categories = ['All', 'Product', 'Engineering', 'Security', 'Tutorial'];

const categoryColors: Record<string, string> = {
  Product: 'bg-primary/10 text-primary',
  Engineering: 'bg-blue-500/10 text-blue-500',
  Security: 'bg-green-500/10 text-green-500',
  Tutorial: 'bg-orange-500/10 text-orange-500',
};

export function BlogListSection() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  const filteredPosts = allPosts.filter((post) => {
    const matchesSearch = post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || post.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <section ref={ref} id="blog" className="py-32 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div
          className="text-center mb-12"
          style={{
            opacity: isInView ? 1 : 0,
            transform: isInView ? 'translateY(0)' : 'translateY(30px)',
            transition: 'all 0.8s cubic-bezier(0.16, 1, 0.3, 1)',
          }}
        >
          <Badge variant="outline" className="mb-4 px-4 py-2 border-primary/30 bg-primary/5">
            <Tag className="h-3.5 w-3.5 mr-2 text-primary" />
            Blog
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Latest{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
              Updates
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Insights, tutorials, and updates from the NAVI team
          </p>
        </div>

        {/* Search and Filter */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search articles..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </Button>
            ))}
          </div>
        </div>

        {/* Posts Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPosts.map((post, index) => (
            <div
              key={post.id}
              className={cn(
                'group rounded-xl border border-border bg-card/50 overflow-hidden cursor-pointer',
                'transition-all duration-300 hover:border-primary/50 hover:shadow-lg hover:-translate-y-1'
              )}
              style={{
                opacity: isInView ? 1 : 0,
                transform: isInView ? 'translateY(0)' : 'translateY(30px)',
                transition: `all 0.6s cubic-bezier(0.16, 1, 0.3, 1) ${index * 0.1}s`,
              }}
            >
              <div className="relative h-40 overflow-hidden">
                <div className={cn('absolute inset-0 bg-gradient-to-br', post.gradient)} />
                <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />
                <Badge className={cn('absolute top-3 left-3 text-xs', categoryColors[post.category])}>
                  {post.category}
                </Badge>
                {post.featured && (
                  <Badge className="absolute top-3 right-3 bg-primary text-primary-foreground text-xs">
                    Featured
                  </Badge>
                )}
              </div>

              <div className="p-5">
                <h3 className="font-bold mb-2 group-hover:text-primary transition-colors line-clamp-2">
                  {post.title}
                </h3>
                <p className="text-muted-foreground text-sm mb-4 line-clamp-2">{post.excerpt}</p>
                <div className="flex items-center gap-3 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <User className="h-3 w-3" />
                    {post.author}
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    {new Date(post.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {post.readTime}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredPosts.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No articles found matching your criteria.</p>
          </div>
        )}
      </div>
    </section>
  );
}
