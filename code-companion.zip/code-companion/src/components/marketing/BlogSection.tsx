import { useRef } from 'react';
import { useInView } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowRight, Calendar, Clock, User } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

const blogPosts = [
  {
    id: 1,
    title: 'Introducing NAVI: The Future of Autonomous Engineering',
    excerpt: 'Today we are launching NAVI, the most advanced autonomous engineering AI ever built.',
    category: 'Product',
    author: 'NAVI Team',
    date: '2024-01-15',
    readTime: '5 min read',
    gradient: 'from-primary via-accent to-purple-500',
    featured: true,
  },
  {
    id: 2,
    title: 'How NAVI Understands Your Entire Engineering Context',
    excerpt: 'Deep dive into NAVI universal context awareness and how it connects to your tools.',
    category: 'Engineering',
    author: 'Sarah Chen',
    date: '2024-01-12',
    readTime: '8 min read',
    gradient: 'from-blue-500 via-cyan-500 to-teal-500',
    featured: true,
  },
  {
    id: 3,
    title: 'The Approval-First Architecture: Why Control Matters',
    excerpt: 'Exploring the design philosophy behind NAVI approval-first system.',
    category: 'Security',
    author: 'Michael Rodriguez',
    date: '2024-01-10',
    readTime: '6 min read',
    gradient: 'from-green-500 via-emerald-500 to-teal-500',
    featured: true,
  },
];

const categoryColors: Record<string, string> = {
  Product: 'bg-primary/10 text-primary',
  Engineering: 'bg-blue-500/10 text-blue-500',
  Security: 'bg-green-500/10 text-green-500',
};

interface BlogCardProps {
  post: typeof blogPosts[0];
  index: number;
}

function BlogCard({ post, index }: BlogCardProps) {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-50px' });

  return (
    <div
      ref={ref}
      className={cn(
        'group block rounded-2xl border border-border bg-card/50 overflow-hidden cursor-pointer',
        'transition-all duration-500 hover:border-primary/50 hover:shadow-xl',
        'hover:-translate-y-1'
      )}
      style={{
        opacity: isInView ? 1 : 0,
        transform: isInView ? 'translateY(0)' : 'translateY(30px)',
        transition: `all 0.6s cubic-bezier(0.16, 1, 0.3, 1) ${index * 0.1}s`,
      }}
    >
      <div className="relative h-48 overflow-hidden">
        <div className={cn('absolute inset-0 bg-gradient-to-br', post.gradient)} />
        <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />
        <Badge className={cn('absolute top-4 left-4', categoryColors[post.category])}>
          {post.category}
        </Badge>
      </div>

      <div className="p-6">
        <h3 className="font-bold text-lg mb-3 group-hover:text-primary transition-colors">
          {post.title}
        </h3>
        <p className="text-muted-foreground text-sm mb-4 line-clamp-2">{post.excerpt}</p>
        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <span className="flex items-center gap-1">
            <User className="h-4 w-4" />
            {post.author}
          </span>
          <span className="flex items-center gap-1">
            <Calendar className="h-4 w-4" />
            {new Date(post.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
          </span>
        </div>
      </div>
    </div>
  );
}

export function BlogSection() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section ref={ref} id="blog" className="py-32 relative overflow-hidden bg-muted/30">
      <div className="max-w-7xl mx-auto px-6 relative">
        <div
          className="text-center mb-16"
          style={{
            opacity: isInView ? 1 : 0,
            transform: isInView ? 'translateY(0)' : 'translateY(30px)',
            transition: 'all 0.8s cubic-bezier(0.16, 1, 0.3, 1)',
          }}
        >
          <span className="inline-block px-4 py-1.5 rounded-full text-sm font-medium bg-primary/10 text-primary mb-4">
            Blog
          </span>
          <h2 className="text-4xl md:text-5xl font-bold">
            Latest{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
              Updates
            </span>
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {blogPosts.map((post, index) => (
            <BlogCard key={post.id} post={post} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
