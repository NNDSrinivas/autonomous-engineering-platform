import { motion } from 'framer-motion';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  TrendingUp, 
  Clock, 
  Users, 
  Zap,
  ArrowRight,
  Quote
} from 'lucide-react';

const caseStudies = [
  {
    company: 'TechFlow Inc.',
    logo: '🚀',
    industry: 'SaaS',
    title: 'Reduced development time by 60%',
    description: 'TechFlow transformed their engineering workflow with NAVI, enabling their team to ship features faster than ever.',
    metrics: [
      { label: 'Time Saved', value: '60%', icon: Clock },
      { label: 'PRs/Week', value: '3x', icon: TrendingUp },
      { label: 'Team Size', value: '25', icon: Users },
    ],
    testimonial: {
      quote: "NAVI has fundamentally changed how we approach development. What used to take days now takes hours.",
      author: 'Sarah Chen',
      role: 'VP of Engineering',
    },
    color: 'from-blue-500/20 to-purple-500/20',
  },
  {
    company: 'DataScale AI',
    logo: '🧠',
    industry: 'AI/ML',
    title: 'Automated 80% of routine tasks',
    description: 'DataScale leveraged NAVI to automate their entire Jira-to-PR workflow, freeing engineers for creative work.',
    metrics: [
      { label: 'Automation', value: '80%', icon: Zap },
      { label: 'Bugs Found', value: '-45%', icon: TrendingUp },
      { label: 'Engineers', value: '50+', icon: Users },
    ],
    testimonial: {
      quote: "The autonomous workflow execution is like having an extra senior engineer on every project.",
      author: 'Marcus Johnson',
      role: 'CTO',
    },
    color: 'from-green-500/20 to-teal-500/20',
  },
  {
    company: 'FinSecure',
    logo: '🔒',
    industry: 'FinTech',
    title: 'Enterprise security with 10x velocity',
    description: 'FinSecure needed enterprise-grade security without sacrificing speed. NAVI delivered both.',
    metrics: [
      { label: 'Velocity', value: '10x', icon: TrendingUp },
      { label: 'Security Score', value: '99%', icon: Zap },
      { label: 'Compliance', value: 'SOC2', icon: Clock },
    ],
    testimonial: {
      quote: "We thought we'd have to choose between security and speed. NAVI proved us wrong.",
      author: 'Emily Rodriguez',
      role: 'Head of Security',
    },
    color: 'from-orange-500/20 to-red-500/20',
  },
];

export function CaseStudiesSection() {
  return (
    <section className="py-24 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-primary/5 to-background" />
      
      <div className="relative max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <Badge variant="outline" className="mb-4">
            <TrendingUp className="h-3.5 w-3.5 mr-2" />
            Success Stories
          </Badge>
          <h2 className="text-3xl md:text-5xl font-bold mb-4">
            Trusted by Industry Leaders
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            See how top engineering teams are transforming their workflows with NAVI.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {caseStudies.map((study, index) => (
            <motion.div
              key={study.company}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.15 }}
            >
              <Card className="h-full overflow-hidden group hover:shadow-2xl transition-all duration-500 border-border/50">
                <CardContent className="p-0">
                  {/* Header with gradient */}
                  <div className={`bg-gradient-to-br ${study.color} p-6`}>
                    <div className="flex items-center gap-3 mb-4">
                      <span className="text-4xl">{study.logo}</span>
                      <div>
                        <h3 className="font-bold text-lg">{study.company}</h3>
                        <Badge variant="secondary" className="text-xs">
                          {study.industry}
                        </Badge>
                      </div>
                    </div>
                    <h4 className="text-xl font-semibold">{study.title}</h4>
                  </div>

                  {/* Content */}
                  <div className="p-6">
                    <p className="text-muted-foreground mb-6">{study.description}</p>

                    {/* Metrics */}
                    <div className="grid grid-cols-3 gap-4 mb-6">
                      {study.metrics.map((metric) => (
                        <motion.div
                          key={metric.label}
                          whileHover={{ scale: 1.05 }}
                          className="text-center p-3 rounded-lg bg-muted/50"
                        >
                          <metric.icon className="h-4 w-4 mx-auto mb-1 text-primary" />
                          <div className="text-xl font-bold text-primary">{metric.value}</div>
                          <div className="text-xs text-muted-foreground">{metric.label}</div>
                        </motion.div>
                      ))}
                    </div>

                    {/* Testimonial */}
                    <div className="relative p-4 rounded-lg bg-muted/30 border border-border/50">
                      <Quote className="absolute top-2 left-2 h-4 w-4 text-primary/30" />
                      <p className="text-sm italic mb-3 pl-4">"{study.testimonial.quote}"</p>
                      <div className="flex items-center gap-2 pl-4">
                        <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold">
                          {study.testimonial.author[0]}
                        </div>
                        <div>
                          <div className="text-sm font-medium">{study.testimonial.author}</div>
                          <div className="text-xs text-muted-foreground">{study.testimonial.role}</div>
                        </div>
                      </div>
                    </div>

                    {/* CTA */}
                    <Button variant="ghost" className="w-full mt-4 group-hover:bg-primary/10">
                      Read Full Story
                      <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
