import { useRef } from 'react';
import { useInView, motion } from 'framer-motion';
import { Badge } from '@/components/ui/badge';
import { Rocket, Zap, Shield, Brain, GitBranch, Sparkles, Bug, ArrowUp, Star } from 'lucide-react';

const releases = [
  {
    version: '3.0.0',
    date: 'December 2025',
    type: 'major',
    title: 'NAVI 3.0 - Autonomous Engineering',
    features: [
      { icon: Brain, text: 'Full autonomous task execution' },
      { icon: Shield, text: 'SOC2 compliance' },
    ],
  },
  {
    version: '2.8.0',
    date: 'November 2025',
    type: 'minor',
    title: 'Enhanced Integrations',
    features: [
      { icon: Zap, text: 'Slack real-time notifications' },
      { icon: GitBranch, text: 'GitHub Actions integration' },
    ],
  },
  {
    version: '2.7.0',
    date: 'October 2025',
    type: 'minor',
    title: 'Smart Memory System',
    features: [
      { icon: Brain, text: 'Persistent conversation memory' },
      { icon: Star, text: 'User preference learning' },
    ],
  },
  {
    version: '2.5.2',
    date: 'August 2025',
    type: 'patch',
    title: 'Bug Fixes & Performance',
    features: [
      { icon: Bug, text: 'Fixed memory leak' },
      { icon: ArrowUp, text: '40% faster code generation' },
    ],
  },
  {
    version: '2.0.0',
    date: 'June 2025',
    type: 'major',
    title: 'NAVI 2.0 - Team Collaboration',
    features: [
      { icon: Rocket, text: 'Real-time team collaboration' },
      { icon: Shield, text: 'Role-based access control' },
    ],
  },
  {
    version: '1.0.0',
    date: 'January 2025',
    type: 'major',
    title: 'NAVI 1.0 - Initial Release',
    features: [
      { icon: Brain, text: 'AI-powered code generation' },
      { icon: Sparkles, text: 'Basic workflow automation' },
    ],
  },
];

const getTypeBadge = (type: string) => {
  switch (type) {
    case 'major':
      return <Badge className="bg-primary text-primary-foreground text-xs">Major</Badge>;
    case 'minor':
      return <Badge variant="secondary" className="text-xs">Feature</Badge>;
    case 'patch':
      return <Badge variant="outline" className="text-xs">Patch</Badge>;
    default:
      return null;
  }
};

export function ChangelogSection() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section ref={ref} id="changelog" className="py-32 relative overflow-hidden bg-muted/30">
      <div className="max-w-4xl mx-auto px-6">
        <div
          className="text-center mb-16"
          style={{
            opacity: isInView ? 1 : 0,
            transform: isInView ? 'translateY(0)' : 'translateY(30px)',
            transition: 'all 0.8s cubic-bezier(0.16, 1, 0.3, 1)',
          }}
        >
          <Badge variant="outline" className="mb-4 px-4 py-2 border-primary/30 bg-primary/5">
            <Rocket className="h-3.5 w-3.5 mr-2 text-primary" />
            Product Updates
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold mb-4">Changelog</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Track the evolution of NAVI. See what's new and what's coming next.
          </p>
        </div>

        {/* Timeline */}
        <div className="relative">
          <div className="absolute left-8 top-0 bottom-0 w-px bg-gradient-to-b from-primary via-primary/50 to-transparent" />

          {releases.map((release, index) => (
            <motion.div
              key={release.version}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="relative pl-20 pb-8 last:pb-0"
            >
              <div className={`absolute left-6 w-5 h-5 rounded-full border-4 border-background ${
                release.type === 'major' ? 'bg-primary' : release.type === 'minor' ? 'bg-accent' : 'bg-muted-foreground'
              }`} />

              <div className="bg-card border border-border rounded-xl p-5 hover:shadow-lg transition-all">
                <div className="flex flex-wrap items-center gap-2 mb-2">
                  <span className="text-lg font-bold text-primary">v{release.version}</span>
                  {getTypeBadge(release.type)}
                  <span className="text-xs text-muted-foreground">{release.date}</span>
                </div>

                <h3 className="font-semibold mb-3">{release.title}</h3>

                <div className="grid gap-1.5">
                  {release.features.map((feature, i) => (
                    <div key={i} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <feature.icon className="h-3.5 w-3.5 text-primary flex-shrink-0" />
                      <span>{feature.text}</span>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
