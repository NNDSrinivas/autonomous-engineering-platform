import { useRef } from 'react';
import { useInView } from 'framer-motion';
import { Check, X, Minus, Sparkles, Brain, Shield, Workflow, Plug } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

const competitors = [
  { name: 'NAVI', tagline: 'Autonomous Engineering AI', isMain: true, logo: '✨', color: 'from-primary to-accent' },
  { name: 'GitHub Copilot', tagline: 'AI Pair Programmer', isMain: false, logo: 'GH', color: 'from-gray-600 to-gray-700' },
  { name: 'Cursor', tagline: 'AI Code Editor', isMain: false, logo: 'CU', color: 'from-blue-600 to-blue-700' },
  { name: 'Cline', tagline: 'Open Coding Agent', isMain: false, logo: 'CL', color: 'from-purple-600 to-purple-700' },
];

const features = [
  {
    category: 'Core Capabilities',
    items: [
      { name: 'Code Completion', navi: true, copilot: true, cursor: true, cline: true },
      { name: 'End-to-End Task Execution', navi: true, copilot: false, cursor: 'partial', cline: 'partial' },
      { name: 'Multi-File Refactoring', navi: true, copilot: false, cursor: true, cline: true },
    ],
  },
  {
    category: 'Context & Intelligence',
    items: [
      { name: 'Jira/Slack/Confluence Integration', navi: true, copilot: false, cursor: false, cline: false },
      { name: 'Memory & Learning', navi: true, copilot: false, cursor: 'partial', cline: true },
    ],
  },
  {
    category: 'Workflow Automation',
    items: [
      { name: 'Git Branch & PR Creation', navi: true, copilot: false, cursor: false, cline: true },
      { name: 'CI/CD Monitoring', navi: true, copilot: false, cursor: false, cline: false },
    ],
  },
  {
    category: 'Security & Control',
    items: [
      { name: 'Approval-First Actions', navi: true, copilot: false, cursor: false, cline: true },
      { name: 'Enterprise SSO', navi: true, copilot: true, cursor: true, cline: false },
    ],
  },
];

function FeatureStatus({ value }: { value: boolean | string }) {
  if (value === true) {
    return (
      <div className="flex items-center justify-center">
        <div className="w-6 h-6 rounded-full bg-green-500/20 flex items-center justify-center">
          <Check className="h-4 w-4 text-green-500" />
        </div>
      </div>
    );
  }
  if (value === false) {
    return (
      <div className="flex items-center justify-center">
        <div className="w-6 h-6 rounded-full bg-muted flex items-center justify-center">
          <X className="h-4 w-4 text-muted-foreground" />
        </div>
      </div>
    );
  }
  return (
    <div className="flex items-center justify-center">
      <div className="w-6 h-6 rounded-full bg-yellow-500/20 flex items-center justify-center">
        <Minus className="h-4 w-4 text-yellow-500" />
      </div>
    </div>
  );
}

export function CompareSection() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section ref={ref} id="compare" className="py-32 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-6 relative">
        <div
          className="text-center mb-16"
          style={{
            opacity: isInView ? 1 : 0,
            transform: isInView ? 'translateY(0)' : 'translateY(30px)',
            transition: 'all 0.8s cubic-bezier(0.16, 1, 0.3, 1)',
          }}
        >
          <Badge variant="outline" className="mb-6 px-4 py-2 border-primary/30 bg-primary/5">
            <Sparkles className="h-3.5 w-3.5 mr-2 text-primary" />
            Compare AI Coding Tools
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            NAVI vs{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
              The Competition
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            See how NAVI's autonomous engineering capabilities compare to other AI coding assistants
          </p>
        </div>

        {/* Competitor Cards */}
        <div className="grid md:grid-cols-4 gap-4 mb-12">
          {competitors.map((competitor) => (
            <div
              key={competitor.name}
              className={cn(
                'relative p-4 rounded-xl border transition-all duration-500',
                competitor.isMain
                  ? 'border-primary bg-primary/5 shadow-lg shadow-primary/10'
                  : 'border-border bg-card/50'
              )}
            >
              {competitor.isMain && (
                <div className="absolute -top-2.5 left-1/2 -translate-x-1/2">
                  <Badge className="bg-gradient-to-r from-primary to-accent text-xs">Recommended</Badge>
                </div>
              )}
              <div className={cn('w-10 h-10 rounded-lg flex items-center justify-center text-sm font-bold text-white mb-2 mx-auto bg-gradient-to-br', competitor.color)}>
                {competitor.logo}
              </div>
              <h3 className="text-sm font-bold text-center">{competitor.name}</h3>
              <p className="text-xs text-muted-foreground text-center">{competitor.tagline}</p>
            </div>
          ))}
        </div>

        {/* Comparison Table */}
        <div className="overflow-x-auto rounded-xl border border-border bg-card/50">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4 w-1/3 text-sm">Feature</th>
                {competitors.map((c) => (
                  <th key={c.name} className={cn('text-center py-3 px-4 text-sm', c.isMain && 'bg-primary/5')}>
                    <span className={cn('font-semibold', c.isMain && 'text-primary')}>{c.name}</span>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {features.map((category) => (
                <>
                  <tr key={category.category} className="bg-muted/50">
                    <td colSpan={5} className="py-2 px-4 font-semibold text-xs text-muted-foreground">{category.category}</td>
                  </tr>
                  {category.items.map((item) => (
                    <tr key={item.name} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                      <td className="py-3 px-4 text-sm">{item.name}</td>
                      <td className={cn('py-3 px-4', 'bg-primary/5')}><FeatureStatus value={item.navi} /></td>
                      <td className="py-3 px-4"><FeatureStatus value={item.copilot} /></td>
                      <td className="py-3 px-4"><FeatureStatus value={item.cursor} /></td>
                      <td className="py-3 px-4"><FeatureStatus value={item.cline} /></td>
                    </tr>
                  ))}
                </>
              ))}
            </tbody>
          </table>
        </div>

        {/* Key Differentiators */}
        <div className="grid md:grid-cols-4 gap-4 mt-12">
          {[
            { icon: Brain, title: 'Universal Context', description: 'Connects to Jira, Slack, Confluence, and GitHub' },
            { icon: Workflow, title: 'End-to-End Workflows', description: 'Execute entire tasks from ticket to PR' },
            { icon: Shield, title: 'Approval-First', description: 'Every action requires your explicit approval' },
            { icon: Plug, title: 'Deep Integrations', description: 'Full OAuth integrations with your tool stack' },
          ].map((diff) => (
            <div key={diff.title} className="p-4 rounded-xl border border-border bg-card/50 hover:border-primary/50 transition-all">
              <diff.icon className="h-8 w-8 text-primary mb-3" />
              <h3 className="font-semibold mb-1">{diff.title}</h3>
              <p className="text-muted-foreground text-sm">{diff.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
