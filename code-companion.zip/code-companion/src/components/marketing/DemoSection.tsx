import { useState, useRef } from 'react';
import { useInView } from 'framer-motion';
import { Play, Pause, Volume2, VolumeX, Maximize2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

const demoSteps = [
  {
    time: '0:00',
    title: 'Connect Your Tools',
    description: 'NAVI integrates with Jira, GitHub, Slack, and more in seconds.',
  },
  {
    time: '0:15',
    title: 'Assign a Task',
    description: 'Simply tell NAVI what you want to accomplish in natural language.',
  },
  {
    time: '0:35',
    title: 'Review the Plan',
    description: 'NAVI analyzes the context and proposes a step-by-step execution plan.',
  },
  {
    time: '0:55',
    title: 'Approve & Execute',
    description: 'Approve each action and watch NAVI execute with precision.',
  },
  {
    time: '1:20',
    title: 'Monitor Progress',
    description: 'Track real-time progress as NAVI creates branches, writes code, and opens PRs.',
  },
];

function InteractiveDemo() {
  const [activeStep, setActiveStep] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);

  return (
    <div className="grid lg:grid-cols-2 gap-8 items-center">
      {/* Video/Demo Preview */}
      <div className="relative aspect-video rounded-2xl overflow-hidden bg-card border border-border">
        {/* Mock Terminal/IDE Preview */}
        <div className="absolute inset-0 bg-gradient-to-br from-background via-card to-background">
          {/* Terminal Header */}
          <div className="h-10 bg-muted/50 border-b border-border flex items-center px-4 gap-2">
            <div className="w-3 h-3 rounded-full bg-destructive/50" />
            <div className="w-3 h-3 rounded-full bg-yellow-500/50" />
            <div className="w-3 h-3 rounded-full bg-green-500/50" />
            <span className="ml-4 text-xs text-muted-foreground font-mono">NAVI Terminal</span>
          </div>
          
          {/* Terminal Content */}
          <div className="p-6 font-mono text-sm space-y-3">
            <div className="flex items-start gap-2">
              <span className="text-primary">❯</span>
              <span className="text-foreground">navi connect --jira --github --slack</span>
            </div>
            {activeStep >= 1 && (
              <div className="text-muted-foreground animate-fade-in">
                ✓ Connected to Jira (3 projects found)
              </div>
            )}
            {activeStep >= 1 && (
              <div className="text-muted-foreground animate-fade-in">
                ✓ Connected to GitHub (12 repositories)
              </div>
            )}
            {activeStep >= 2 && (
              <div className="flex items-start gap-2 animate-fade-in">
                <span className="text-primary">❯</span>
                <span className="text-foreground">"Implement user authentication for ticket NAVI-142"</span>
              </div>
            )}
            {activeStep >= 3 && (
              <div className="text-accent animate-fade-in">
                ⚡ Analyzing ticket context...
              </div>
            )}
            {activeStep >= 3 && (
              <div className="bg-primary/10 border border-primary/30 rounded-lg p-4 mt-4 animate-fade-in">
                <div className="text-primary font-semibold mb-2">Proposed Workflow:</div>
                <div className="space-y-1 text-muted-foreground">
                  <div>1. Create branch feature/NAVI-142-auth</div>
                  <div>2. Implement JWT authentication</div>
                  <div>3. Add unit tests</div>
                  <div>4. Open PR with description</div>
                </div>
              </div>
            )}
            {activeStep >= 4 && (
              <div className="flex items-center gap-2 text-green-500 animate-fade-in">
                <span>✓</span>
                <span>PR #247 opened successfully</span>
              </div>
            )}
          </div>
        </div>

        {/* Play Button Overlay */}
        <div 
          className={cn(
            'absolute inset-0 flex items-center justify-center bg-background/50 backdrop-blur-sm transition-opacity duration-300',
            isPlaying && 'opacity-0 pointer-events-none'
          )}
        >
          <Button
            size="lg"
            className="w-20 h-20 rounded-full bg-gradient-to-r from-primary to-accent hover:opacity-90"
            onClick={() => {
              setIsPlaying(true);
              // Auto-progress through steps
              let step = 0;
              const interval = setInterval(() => {
                step++;
                if (step <= 4) {
                  setActiveStep(step);
                } else {
                  clearInterval(interval);
                }
              }, 1500);
            }}
          >
            <Play className="h-8 w-8 ml-1" fill="currentColor" />
          </Button>
        </div>

        {/* Video Controls */}
        <div className="absolute bottom-0 left-0 right-0 h-12 bg-gradient-to-t from-background to-transparent flex items-end pb-3 px-4">
          <div className="flex items-center gap-4 w-full">
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setIsPlaying(!isPlaying)}>
              {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            </Button>
            <div className="flex-1 h-1 bg-muted rounded-full overflow-hidden">
              <div 
                className="h-full bg-primary transition-all duration-300"
                style={{ width: `${(activeStep / 4) * 100}%` }}
              />
            </div>
            <span className="text-xs text-muted-foreground">1:35</span>
          </div>
        </div>
      </div>

      {/* Steps List */}
      <div className="space-y-4">
        {demoSteps.map((step, index) => (
          <div
            key={index}
            className={cn(
              'p-4 rounded-xl border transition-all duration-300 cursor-pointer',
              activeStep === index 
                ? 'border-primary bg-primary/5 shadow-lg shadow-primary/10' 
                : 'border-border/50 bg-card/30 hover:border-primary/30'
            )}
            onClick={() => setActiveStep(index)}
          >
            <div className="flex items-center gap-4">
              <div
                className={cn(
                  'w-10 h-10 rounded-full flex items-center justify-center text-sm font-mono',
                  activeStep === index
                    ? 'bg-gradient-to-r from-primary to-accent text-primary-foreground'
                    : 'bg-muted text-muted-foreground'
                )}
              >
                {step.time}
              </div>
              <div>
                <h4 className="font-semibold">{step.title}</h4>
                <p className="text-sm text-muted-foreground">{step.description}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function DemoSection() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section ref={ref} id="demo" className="py-32 relative overflow-hidden bg-muted/30">
      {/* Background */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute top-0 right-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-6 relative">
        <div
          className="text-center mb-16"
          style={{
            opacity: isInView ? 1 : 0,
            transform: isInView ? 'translateY(0)' : 'translateY(30px)',
            transition: 'all 0.8s cubic-bezier(0.16, 1, 0.3, 1)',
          }}
        >
          <span className="inline-block px-4 py-1.5 rounded-full text-sm font-medium bg-primary/10 text-primary mb-4">
            See It In Action
          </span>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Watch NAVI{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
              transform your workflow
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            From task assignment to PR creation in under 2 minutes
          </p>
        </div>

        <div
          style={{
            opacity: isInView ? 1 : 0,
            transform: isInView ? 'translateY(0)' : 'translateY(50px)',
            transition: 'all 0.8s cubic-bezier(0.16, 1, 0.3, 1) 0.2s',
          }}
        >
          <InteractiveDemo />
        </div>
      </div>
    </section>
  );
}
