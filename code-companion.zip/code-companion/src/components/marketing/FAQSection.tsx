import { useRef, useState } from 'react';
import { useInView } from 'framer-motion';
import { ChevronDown, HelpCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

const faqs = [
  {
    question: 'What is NAVI and how is it different from other AI coding assistants?',
    answer: 'NAVI is an autonomous engineering AI that goes beyond code completion. While tools like Copilot help you write code, NAVI executes complete engineering workflows — from reading Jira tickets to creating pull requests. It connects to your entire tool stack (Jira, GitHub, Slack, Confluence) to understand context and take action with your approval.',
  },
  {
    question: 'Is NAVI safe to use? Will it make changes without my permission?',
    answer: 'NAVI is built with an approval-first architecture. Every action that modifies code, creates branches, opens PRs, or updates tickets requires your explicit approval. NAVI always explains what it plans to do and waits for your confirmation before proceeding. You maintain complete control at all times.',
  },
  {
    question: 'What integrations does NAVI support?',
    answer: 'NAVI integrates with Jira, GitHub, GitLab, Bitbucket, Slack, Microsoft Teams, Confluence, Notion, Linear, CircleCI, Jenkins, and more. All integrations use OAuth for secure authentication, and you can manage permissions granularly.',
  },
  {
    question: 'How does the free trial work?',
    answer: 'Start with a 14-day free trial of NAVI Pro — no credit card required. You get full access to all features including unlimited AI conversations, all integrations, and end-to-end workflows. After the trial, you can continue with our Free tier or upgrade to Pro.',
  },
  {
    question: 'Can NAVI learn my coding style and preferences?',
    answer: 'Yes! NAVI has a sophisticated memory system that learns from your interactions. It remembers your coding preferences, past conversations, project context, and team patterns. The more you use NAVI, the better it understands your workflow.',
  },
  {
    question: 'Is my code and data secure with NAVI?',
    answer: 'Security is our top priority. NAVI is SOC 2 certified and GDPR compliant. Your code is encrypted in transit and at rest. We never train our models on your proprietary code. Enterprise plans include additional security features like SSO, audit logging, and on-premise deployment options.',
  },
  {
    question: 'How does NAVI handle complex, multi-step tasks?',
    answer: 'NAVI breaks down complex tasks into discrete steps and executes them sequentially with approval gates. For example, implementing a feature involves: analyzing the ticket, understanding the codebase, generating code, writing tests, creating a branch, committing changes, and opening a PR. You approve each critical step.',
  },
  {
    question: 'Can I use NAVI with my existing IDE?',
    answer: 'NAVI works alongside your existing development environment. While other tools require IDE plugins, NAVI operates at a higher level — connecting to your repositories and project management tools directly. You can continue using your preferred IDE while NAVI handles the automation.',
  },
  {
    question: 'What happens if NAVI makes a mistake?',
    answer: 'All changes made by NAVI are tracked and reversible. Since NAVI creates branches and PRs, you can review all changes before merging. If something goes wrong, you can simply close the PR or revert the changes. The approval system ensures mistakes are caught before they impact your main branch.',
  },
  {
    question: 'Is NAVI suitable for enterprise teams?',
    answer: 'Absolutely. Our Enterprise plan includes team management, SSO/SAML authentication, advanced security controls, custom integrations, dedicated support, SLA guarantees, and on-premise deployment options. Contact our sales team for a custom quote.',
  },
];

interface FAQItemProps {
  faq: typeof faqs[0];
  isOpen: boolean;
  onToggle: () => void;
  index: number;
}

function FAQItem({ faq, isOpen, onToggle, index }: FAQItemProps) {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-50px' });

  return (
    <div
      ref={ref}
      className={cn(
        'border border-border rounded-xl overflow-hidden transition-all duration-300',
        isOpen ? 'bg-primary/5 border-primary/30' : 'bg-card/50 hover:border-primary/20'
      )}
      style={{
        opacity: isInView ? 1 : 0,
        transform: isInView ? 'translateY(0)' : 'translateY(20px)',
        transition: `all 0.5s cubic-bezier(0.16, 1, 0.3, 1) ${index * 0.05}s`,
      }}
    >
      <button
        onClick={onToggle}
        className="w-full px-6 py-5 flex items-center justify-between text-left"
      >
        <span className="font-medium pr-8">{faq.question}</span>
        <ChevronDown
          className={cn(
            'h-5 w-5 text-muted-foreground transition-transform duration-300 flex-shrink-0',
            isOpen && 'rotate-180 text-primary'
          )}
        />
      </button>
      
      <div
        className={cn(
          'overflow-hidden transition-all duration-300',
          isOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
        )}
      >
        <div className="px-6 pb-5 text-muted-foreground">
          {faq.answer}
        </div>
      </div>
    </div>
  );
}

export function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section ref={ref} id="faq" className="py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 right-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 left-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />
      </div>

      <div className="max-w-4xl mx-auto px-6 relative">
        <div
          className="text-center mb-16"
          style={{
            opacity: isInView ? 1 : 0,
            transform: isInView ? 'translateY(0)' : 'translateY(30px)',
            transition: 'all 0.8s cubic-bezier(0.16, 1, 0.3, 1)',
          }}
        >
          <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-sm font-medium bg-primary/10 text-primary mb-4">
            <HelpCircle className="h-4 w-4" />
            FAQ
          </span>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Frequently Asked{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
              Questions
            </span>
          </h2>
          <p className="text-xl text-muted-foreground">
            Everything you need to know about NAVI
          </p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <FAQItem
              key={index}
              faq={faq}
              isOpen={openIndex === index}
              onToggle={() => setOpenIndex(openIndex === index ? null : index)}
              index={index}
            />
          ))}
        </div>

        {/* Contact CTA */}
        <div
          className="text-center mt-12"
          style={{
            opacity: isInView ? 1 : 0,
            transition: 'opacity 0.8s ease 0.5s',
          }}
        >
          <p className="text-muted-foreground">
            Still have questions?{' '}
            <a href="mailto:support@navi.ai" className="text-primary hover:underline">
              Contact our support team
            </a>
          </p>
        </div>
      </div>
    </section>
  );
}
