import { useState, useRef, useEffect } from 'react';
import { motion, useInView, useScroll, useTransform } from 'framer-motion';
import { 
  Brain, Workflow, Shield, MessageSquare, Plug, Zap, 
  GitBranch, Code2, Terminal, Layers, Database, Lock 
} from 'lucide-react';
import { cn } from '@/lib/utils';

const features = [
  {
    icon: Brain,
    title: 'Universal Context Awareness',
    description: 'NAVI understands your entire engineering environment — Jira tickets, Slack conversations, Confluence docs, GitHub PRs.',
    gradient: 'from-cyan-500 to-blue-500',
    delay: 0,
  },
  {
    icon: Workflow,
    title: 'End-to-End Workflows',
    description: 'Execute complete engineering tasks from start to finish with your approval at each critical step.',
    gradient: 'from-purple-500 to-pink-500',
    delay: 0.1,
  },
  {
    icon: Shield,
    title: 'Approval-First Actions',
    description: 'Every action requires your explicit approval. NAVI explains what it will do and waits for confirmation.',
    gradient: 'from-green-500 to-emerald-500',
    delay: 0.2,
  },
  {
    icon: MessageSquare,
    title: 'Conversation Intelligence',
    description: 'Natural language interface that understands engineering context perfectly.',
    gradient: 'from-orange-500 to-amber-500',
    delay: 0.3,
  },
  {
    icon: Plug,
    title: 'Seamless Integrations',
    description: 'Connect Jira, GitHub, Slack, Confluence, and more with OAuth.',
    gradient: 'from-blue-500 to-indigo-500',
    delay: 0.4,
  },
  {
    icon: Zap,
    title: 'Continuous Learning',
    description: 'NAVI remembers your preferences and gets smarter with every interaction.',
    gradient: 'from-pink-500 to-rose-500',
    delay: 0.5,
  },
];

interface FeatureCardProps {
  feature: typeof features[0];
  index: number;
}

function FeatureCard({ feature, index }: FeatureCardProps) {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });
  const [isHovered, setIsHovered] = useState(false);
  const Icon = feature.icon;

  return (
    <div
      ref={ref}
      className={cn(
        'group relative p-6 rounded-2xl border border-border/50 bg-card/50 backdrop-blur-sm',
        'transition-all duration-500 hover:border-primary/50 hover:shadow-2xl',
        'hover:shadow-primary/10 cursor-pointer overflow-hidden'
      )}
      style={{
        opacity: isInView ? 1 : 0,
        transform: isInView ? 'translateY(0)' : 'translateY(50px)',
        transition: `all 0.6s cubic-bezier(0.16, 1, 0.3, 1) ${feature.delay}s`,
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Gradient background on hover */}
      <div
        className={cn(
          'absolute inset-0 opacity-0 transition-opacity duration-500',
          `bg-gradient-to-br ${feature.gradient}`
        )}
        style={{ opacity: isHovered ? 0.05 : 0 }}
      />
      
      {/* Animated border */}
      <div
        className={cn(
          'absolute inset-0 rounded-2xl opacity-0 transition-opacity duration-500',
          'bg-gradient-to-r from-transparent via-primary/50 to-transparent'
        )}
        style={{
          opacity: isHovered ? 1 : 0,
          mask: 'linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)',
          maskComposite: 'xor',
          WebkitMaskComposite: 'xor',
          padding: '1px',
        }}
      />

      <div className="relative z-10">
        <div
          className={cn(
            'w-14 h-14 rounded-xl flex items-center justify-center mb-4',
            'bg-gradient-to-br transition-transform duration-300',
            feature.gradient,
            isHovered && 'scale-110'
          )}
        >
          <Icon className="h-7 w-7 text-white" />
        </div>

        <h3 className="text-xl font-semibold mb-2 transition-colors duration-300 group-hover:text-primary">
          {feature.title}
        </h3>
        
        <p className="text-muted-foreground leading-relaxed">
          {feature.description}
        </p>

        {/* Floating particles on hover */}
        {isHovered && (
          <>
            {[...Array(5)].map((_, i) => (
              <div
                key={i}
                className="absolute w-1 h-1 rounded-full bg-primary"
                style={{
                  left: `${20 + Math.random() * 60}%`,
                  top: `${20 + Math.random() * 60}%`,
                  animation: `float ${2 + Math.random() * 2}s ease-in-out infinite`,
                  animationDelay: `${Math.random() * 2}s`,
                }}
              />
            ))}
          </>
        )}
      </div>
    </div>
  );
}

export function FeatureShowcase() {
  const containerRef = useRef<HTMLDivElement>(null);
  const isInView = useInView(containerRef, { once: true, margin: '-100px' });

  return (
    <section ref={containerRef} className="py-32 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-0 w-96 h-96 bg-primary/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-0 w-96 h-96 bg-accent/5 rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-6 relative">
        <div
          className="text-center mb-20"
          style={{
            opacity: isInView ? 1 : 0,
            transform: isInView ? 'translateY(0)' : 'translateY(30px)',
            transition: 'all 0.8s cubic-bezier(0.16, 1, 0.3, 1)',
          }}
        >
          <span className="inline-block px-4 py-1.5 rounded-full text-sm font-medium bg-primary/10 text-primary mb-4">
            Features
          </span>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Everything you need for{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
              autonomous engineering
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            NAVI combines the capabilities of a Tech Lead, Staff Engineer, Project Manager, and SRE in one intelligent system.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <FeatureCard key={index} feature={feature} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
