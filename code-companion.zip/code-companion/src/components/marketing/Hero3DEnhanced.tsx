import { useRef, useMemo, useEffect, useState } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Float, Sphere, MeshDistortMaterial, Stars, Trail, useScroll } from '@react-three/drei';
import * as THREE from 'three';

function AnimatedSphere({ position, color, speed, distort, scale = 1 }: { 
  position: [number, number, number]; 
  color: string; 
  speed: number; 
  distort: number;
  scale?: number;
}) {
  const meshRef = useRef<THREE.Mesh>(null);
  
  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.x = state.clock.elapsedTime * speed * 0.3;
      meshRef.current.rotation.y = state.clock.elapsedTime * speed * 0.5;
    }
  });

  return (
    <Float speed={2} rotationIntensity={1} floatIntensity={2}>
      <Sphere ref={meshRef} args={[scale, 64, 64]} position={position}>
        <MeshDistortMaterial
          color={color}
          attach="material"
          distort={distort}
          speed={2}
          roughness={0.2}
          metalness={0.8}
        />
      </Sphere>
    </Float>
  );
}

function ParticleField({ count = 500, scrollY = 0 }: { count?: number; scrollY?: number }) {
  const mesh = useRef<THREE.Points>(null);
  
  const [positions, colors] = useMemo(() => {
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);
    
    for (let i = 0; i < count; i++) {
      positions[i * 3] = (Math.random() - 0.5) * 25;
      positions[i * 3 + 1] = (Math.random() - 0.5) * 25;
      positions[i * 3 + 2] = (Math.random() - 0.5) * 25;
      
      const color = new THREE.Color();
      color.setHSL(0.55 + Math.random() * 0.15, 0.8, 0.6);
      colors[i * 3] = color.r;
      colors[i * 3 + 1] = color.g;
      colors[i * 3 + 2] = color.b;
    }
    
    return [positions, colors];
  }, [count]);

  useFrame((state) => {
    if (mesh.current) {
      mesh.current.rotation.x = state.clock.elapsedTime * 0.02;
      mesh.current.rotation.y = state.clock.elapsedTime * 0.03 + scrollY * 0.001;
    }
  });

  return (
    <points ref={mesh}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          count={count}
          array={positions}
          itemSize={3}
        />
        <bufferAttribute
          attach="attributes-color"
          count={count}
          array={colors}
          itemSize={3}
        />
      </bufferGeometry>
      <pointsMaterial size={0.05} vertexColors transparent opacity={0.8} sizeAttenuation />
    </points>
  );
}

function FloatingRings({ scrollY = 0 }: { scrollY?: number }) {
  const ringRef1 = useRef<THREE.Mesh>(null);
  const ringRef2 = useRef<THREE.Mesh>(null);
  const ringRef3 = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    const scrollOffset = scrollY * 0.0005;
    
    if (ringRef1.current) {
      ringRef1.current.rotation.x = t * 0.2 + scrollOffset;
      ringRef1.current.rotation.y = t * 0.3;
    }
    if (ringRef2.current) {
      ringRef2.current.rotation.x = t * 0.15 + Math.PI / 3;
      ringRef2.current.rotation.z = t * 0.25 + scrollOffset;
    }
    if (ringRef3.current) {
      ringRef3.current.rotation.y = t * 0.2 + scrollOffset;
      ringRef3.current.rotation.z = t * 0.15 + Math.PI / 6;
    }
  });

  return (
    <group>
      <mesh ref={ringRef1}>
        <torusGeometry args={[3, 0.02, 16, 100]} />
        <meshStandardMaterial color="#00d4ff" emissive="#00d4ff" emissiveIntensity={0.5} />
      </mesh>
      <mesh ref={ringRef2}>
        <torusGeometry args={[3.5, 0.015, 16, 100]} />
        <meshStandardMaterial color="#a855f7" emissive="#a855f7" emissiveIntensity={0.5} />
      </mesh>
      <mesh ref={ringRef3}>
        <torusGeometry args={[4, 0.01, 16, 100]} />
        <meshStandardMaterial color="#00d4ff" emissive="#00d4ff" emissiveIntensity={0.3} />
      </mesh>
    </group>
  );
}

function OrbitingCube({ scrollY = 0 }: { scrollY?: number }) {
  const cubeRef = useRef<THREE.Mesh>(null);
  
  useFrame((state) => {
    const t = state.clock.elapsedTime;
    if (cubeRef.current) {
      cubeRef.current.position.x = Math.sin(t * 0.5) * 5;
      cubeRef.current.position.z = Math.cos(t * 0.5) * 5;
      cubeRef.current.position.y = Math.sin(t * 0.3) * 1 - scrollY * 0.002;
      cubeRef.current.rotation.x = t;
      cubeRef.current.rotation.y = t * 1.2;
    }
  });

  return (
    <Trail width={0.5} length={8} color="#00d4ff" attenuation={(t) => t * t}>
      <mesh ref={cubeRef}>
        <boxGeometry args={[0.3, 0.3, 0.3]} />
        <meshStandardMaterial color="#00d4ff" emissive="#00d4ff" emissiveIntensity={0.8} />
      </mesh>
    </Trail>
  );
}

function FloatingGeometries({ scrollY = 0 }: { scrollY?: number }) {
  const group = useRef<THREE.Group>(null);
  const icosahedronRef = useRef<THREE.Mesh>(null);
  const octahedronRef = useRef<THREE.Mesh>(null);
  const dodecahedronRef = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    const t = state.clock.elapsedTime;
    
    if (group.current) {
      group.current.rotation.y = t * 0.05;
      group.current.position.y = -scrollY * 0.003;
    }
    
    if (icosahedronRef.current) {
      icosahedronRef.current.rotation.x = t * 0.3;
      icosahedronRef.current.rotation.z = t * 0.2;
      icosahedronRef.current.position.y = Math.sin(t * 0.5) * 0.5;
    }
    
    if (octahedronRef.current) {
      octahedronRef.current.rotation.y = t * 0.4;
      octahedronRef.current.rotation.x = t * 0.25;
      octahedronRef.current.position.y = Math.sin(t * 0.6 + 1) * 0.5;
    }
    
    if (dodecahedronRef.current) {
      dodecahedronRef.current.rotation.z = t * 0.35;
      dodecahedronRef.current.rotation.y = t * 0.2;
      dodecahedronRef.current.position.y = Math.sin(t * 0.4 + 2) * 0.5;
    }
  });

  return (
    <group ref={group}>
      <mesh ref={icosahedronRef} position={[-6, 2, -3]}>
        <icosahedronGeometry args={[0.8, 0]} />
        <meshStandardMaterial 
          color="#00d4ff" 
          emissive="#00d4ff" 
          emissiveIntensity={0.3}
          wireframe
        />
      </mesh>
      
      <mesh ref={octahedronRef} position={[6, -1, -2]}>
        <octahedronGeometry args={[0.6, 0]} />
        <meshStandardMaterial 
          color="#a855f7" 
          emissive="#a855f7" 
          emissiveIntensity={0.3}
          wireframe
        />
      </mesh>
      
      <mesh ref={dodecahedronRef} position={[0, 4, -5]}>
        <dodecahedronGeometry args={[0.5, 0]} />
        <meshStandardMaterial 
          color="#22d3ee" 
          emissive="#22d3ee" 
          emissiveIntensity={0.3}
          wireframe
        />
      </mesh>
    </group>
  );
}

function Scene({ scrollY }: { scrollY: number }) {
  return (
    <>
      <ambientLight intensity={0.2} />
      <pointLight position={[10, 10, 10]} intensity={1} color="#00d4ff" />
      <pointLight position={[-10, -10, -10]} intensity={0.5} color="#a855f7" />
      <spotLight position={[0, 10, 0]} intensity={0.5} color="#ffffff" />
      
      <AnimatedSphere position={[0, 0, 0]} color="#00d4ff" speed={0.5} distort={0.4} />
      <AnimatedSphere position={[-4, 2, -2]} color="#a855f7" speed={0.3} distort={0.3} scale={0.7} />
      <AnimatedSphere position={[4, -1, -3]} color="#00d4ff" speed={0.4} distort={0.35} scale={0.5} />
      
      <FloatingRings scrollY={scrollY} />
      <OrbitingCube scrollY={scrollY} />
      <FloatingGeometries scrollY={scrollY} />
      <ParticleField scrollY={scrollY} />
      <Stars radius={100} depth={50} count={2000} factor={4} saturation={0} fade speed={1} />
      
      <fog attach="fog" args={['#0a0a0f', 8, 30]} />
    </>
  );
}

export function Hero3DEnhanced() {
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="absolute inset-0 -z-10">
      <Canvas camera={{ position: [0, 0, 8], fov: 60 }}>
        <Scene scrollY={scrollY} />
      </Canvas>
    </div>
  );
}
