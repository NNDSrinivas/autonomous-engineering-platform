import { useState, useRef } from 'react';
import { useInView } from 'framer-motion';
import { cn } from '@/lib/utils';

const integrations = [
  { name: 'Jira', color: '#0052CC', logo: 'J', category: 'Project' },
  { name: 'GitHub', color: '#24292e', logo: 'G', category: 'Code' },
  { name: 'Slack', color: '#4A154B', logo: 'S', category: 'Chat' },
  { name: 'Confluence', color: '#0052CC', logo: 'C', category: 'Docs' },
  { name: 'GitLab', color: '#FC6D26', logo: 'GL', category: 'Code' },
  { name: 'Bitbucket', color: '#0052CC', logo: 'B', category: 'Code' },
  { name: 'Teams', color: '#6264A7', logo: 'T', category: 'Chat' },
  { name: 'Linear', color: '#5E6AD2', logo: 'L', category: 'Project' },
  { name: 'Notion', color: '#000000', logo: 'N', category: 'Docs' },
  { name: 'Discord', color: '#5865F2', logo: 'D', category: 'Chat' },
  { name: 'CircleCI', color: '#343434', logo: 'CI', category: 'CI/CD' },
  { name: 'Jenkins', color: '#D24939', logo: 'JK', category: 'CI/CD' },
];

interface IntegrationCardProps {
  integration: typeof integrations[0];
  index: number;
}

function IntegrationCard({ integration, index }: IntegrationCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className={cn(
        'relative p-6 rounded-2xl border border-border/50 bg-card/30 backdrop-blur-sm',
        'transition-all duration-500 cursor-pointer group',
        'hover:border-primary/50 hover:shadow-xl hover:shadow-primary/5',
        'hover:-translate-y-2'
      )}
      style={{
        animationDelay: `${index * 0.05}s`,
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Gradient glow on hover */}
      <div
        className="absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"
        style={{
          background: `radial-gradient(circle at center, ${integration.color}20, transparent 70%)`,
        }}
      />

      <div className="relative z-10 flex flex-col items-center text-center">
        {/* Logo */}
        <div
          className={cn(
            'w-16 h-16 rounded-xl flex items-center justify-center mb-4',
            'text-2xl font-bold text-white transition-transform duration-300',
            isHovered && 'scale-110'
          )}
          style={{ backgroundColor: integration.color }}
        >
          {integration.logo}
        </div>

        {/* Name */}
        <h4 className="font-semibold mb-1">{integration.name}</h4>
        
        {/* Category */}
        <span className="text-xs text-muted-foreground px-2 py-0.5 rounded-full bg-muted">
          {integration.category}
        </span>
      </div>

      {/* Connection line animation */}
      {isHovered && (
        <div className="absolute inset-x-0 -bottom-4 flex justify-center">
          <div className="w-px h-8 bg-gradient-to-b from-primary to-transparent animate-pulse" />
        </div>
      )}
    </div>
  );
}

export function IntegrationsGrid() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section ref={ref} className="py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_50%_at_50%_-20%,rgba(var(--primary),0.1),transparent)]" />
        
        {/* Grid pattern */}
        <div 
          className="absolute inset-0 opacity-5"
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, hsl(var(--foreground)) 1px, transparent 0)`,
            backgroundSize: '40px 40px',
          }}
        />
      </div>

      <div className="max-w-7xl mx-auto px-6 relative">
        <div
          className="text-center mb-16"
          style={{
            opacity: isInView ? 1 : 0,
            transform: isInView ? 'translateY(0)' : 'translateY(30px)',
            transition: 'all 0.8s cubic-bezier(0.16, 1, 0.3, 1)',
          }}
        >
          <span className="inline-block px-4 py-1.5 rounded-full text-sm font-medium bg-primary/10 text-primary mb-4">
            Integrations
          </span>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Works with your{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
              favorite tools
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Connect your existing workflow in minutes. No complex setup required.
          </p>
        </div>

        <div
          className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6"
          style={{
            opacity: isInView ? 1 : 0,
            transition: 'opacity 0.8s ease 0.3s',
          }}
        >
          {integrations.map((integration, index) => (
            <IntegrationCard key={integration.name} integration={integration} index={index} />
          ))}
        </div>

        {/* More integrations CTA */}
        <div
          className="text-center mt-12"
          style={{
            opacity: isInView ? 1 : 0,
            transition: 'opacity 0.8s ease 0.5s',
          }}
        >
          <p className="text-muted-foreground">
            And many more... Don't see yours?{' '}
            <a href="#" className="text-primary hover:underline">
              Request an integration
            </a>
          </p>
        </div>
      </div>
    </section>
  );
}
