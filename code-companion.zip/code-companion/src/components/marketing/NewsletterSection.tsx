import { useState, useRef, useCallback } from 'react';
import { useInView, motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Mail, Sparkles, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { z } from 'zod';

const emailSchema = z.string().email({ message: "Please enter a valid email address" }).max(255);

export function NewsletterSection() {
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  const sendConfirmationEmail = useCallback(async (subscriberEmail: string) => {
    try {
      const siteUrl = window.location.origin;
      const { error } = await supabase.functions.invoke('send-newsletter-confirmation', {
        body: { email: subscriberEmail, siteUrl }
      });
      
      if (error) {
        console.error('Failed to send confirmation email:', error);
      }
    } catch (err) {
      console.error('Email sending error:', err);
    }
  }, []);

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const validation = emailSchema.safeParse(email);
    if (!validation.success) {
      toast.error(validation.error.errors[0].message);
      return;
    }

    setIsLoading(true);
    
    try {
      const { error } = await supabase
        .from('newsletter_subscribers')
        .insert({ email: email.toLowerCase().trim(), source: 'marketing' });

      if (error) {
        if (error.code === '23505') {
          toast.info("You're already subscribed!");
          navigate('/newsletter/thank-you');
        } else {
          throw error;
        }
      } else {
        // Send confirmation email in background
        sendConfirmationEmail(email.toLowerCase().trim());
        navigate('/newsletter/thank-you');
      }
    } catch (error) {
      console.error('Newsletter subscription error:', error);
      toast.error("Something went wrong. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section ref={ref} className="py-24 relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-accent/10" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/5 rounded-full blur-3xl" />

      <div className="max-w-4xl mx-auto px-6 relative">
        <motion.div
          className="text-center"
          style={{
            opacity: isInView ? 1 : 0,
            transform: isInView ? 'translateY(0)' : 'translateY(30px)',
            transition: 'all 0.8s cubic-bezier(0.16, 1, 0.3, 1)',
          }}
        >
          <Badge variant="outline" className="mb-6 px-4 py-2 border-primary/30 bg-primary/5">
            <Mail className="h-3.5 w-3.5 mr-2 text-primary" />
            Stay Updated
          </Badge>

          <h2 className="text-3xl md:text-5xl font-bold mb-4">
            Get the Latest{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
              NAVI Updates
            </span>
          </h2>

          <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto">
            Join 10,000+ engineers getting weekly insights on AI-powered development, new features, and best practices.
          </p>

          <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
            <div className="flex-1">
              <Input
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="h-12 px-4 bg-background/50 backdrop-blur-sm"
                disabled={isLoading}
                required
              />
            </div>
            <Button 
              type="submit" 
              className="h-12 px-6 bg-gradient-to-r from-primary to-accent hover:opacity-90"
              disabled={isLoading}
            >
              {isLoading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <>
                  <Sparkles className="h-4 w-4 mr-2" />
                  Subscribe
                </>
              )}
            </Button>
          </form>

          <p className="text-xs text-muted-foreground mt-4">
            No spam, ever. Unsubscribe anytime.
          </p>
        </motion.div>
      </div>
    </section>
  );
}
