import { useState, useRef } from 'react';
import { useInView } from 'framer-motion';
import { Check, Sparkles, Building2, Rocket, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { useNavigate } from 'react-router-dom';

const plans = [
  {
    name: 'Free',
    description: 'Perfect for getting started',
    price: '$0',
    period: '/month',
    icon: Zap,
    gradient: 'from-gray-500 to-gray-600',
    features: [
      '5 AI conversations/day',
      '2 integrations',
      'Basic context awareness',
      'Community support',
      'Single user',
    ],
    cta: 'Get Started',
    popular: false,
  },
  {
    name: 'Pro',
    description: 'For professional developers',
    price: '$29',
    period: '/month',
    icon: Rocket,
    gradient: 'from-primary to-cyan-400',
    features: [
      'Unlimited AI conversations',
      'All integrations',
      'Full context awareness',
      'End-to-end workflows',
      'Priority support',
      'Memory & learning',
      'Custom workflows',
      'API access',
    ],
    cta: 'Start Free Trial',
    popular: true,
  },
  {
    name: 'Enterprise',
    description: 'For teams at scale',
    price: 'Custom',
    period: '',
    icon: Building2,
    gradient: 'from-purple-500 to-pink-500',
    features: [
      'Everything in Pro',
      'Unlimited team members',
      'SSO & SAML',
      'Advanced security',
      'Custom integrations',
      'Dedicated support',
      'SLA guarantee',
      'On-premise option',
      'Custom training',
    ],
    cta: 'Contact Sales',
    popular: false,
  },
];

interface PricingCardProps {
  plan: typeof plans[0];
  index: number;
}

function PricingCard({ plan, index }: PricingCardProps) {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-50px' });
  const [isHovered, setIsHovered] = useState(false);
  const navigate = useNavigate();
  const Icon = plan.icon;

  return (
    <div
      ref={ref}
      className={cn(
        'relative rounded-2xl p-8 transition-all duration-500',
        'border bg-card/50 backdrop-blur-sm',
        plan.popular 
          ? 'border-primary/50 shadow-2xl shadow-primary/20 scale-105 z-10' 
          : 'border-border/50 hover:border-primary/30',
        isHovered && !plan.popular && 'shadow-xl shadow-primary/10'
      )}
      style={{
        opacity: isInView ? 1 : 0,
        transform: isInView 
          ? `translateY(0) ${plan.popular ? 'scale(1.05)' : 'scale(1)'}` 
          : 'translateY(50px) scale(0.95)',
        transition: `all 0.6s cubic-bezier(0.16, 1, 0.3, 1) ${index * 0.1}s`,
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Popular badge */}
      {plan.popular && (
        <div className="absolute -top-4 left-1/2 -translate-x-1/2">
          <span className="inline-flex items-center gap-1.5 px-4 py-1 rounded-full text-sm font-medium bg-gradient-to-r from-primary to-accent text-primary-foreground">
            <Sparkles className="h-3.5 w-3.5" />
            Most Popular
          </span>
        </div>
      )}

      {/* Gradient glow for popular */}
      {plan.popular && (
        <div className="absolute inset-0 -z-10 rounded-2xl bg-gradient-to-b from-primary/20 to-transparent blur-xl" />
      )}

      <div className="mb-6">
        <div
          className={cn(
            'w-14 h-14 rounded-xl flex items-center justify-center mb-4',
            'bg-gradient-to-br',
            plan.gradient
          )}
        >
          <Icon className="h-7 w-7 text-white" />
        </div>

        <h3 className="text-2xl font-bold">{plan.name}</h3>
        <p className="text-muted-foreground mt-1">{plan.description}</p>
      </div>

      <div className="mb-8">
        <span className="text-5xl font-bold">{plan.price}</span>
        <span className="text-muted-foreground">{plan.period}</span>
      </div>

      <ul className="space-y-4 mb-8">
        {plan.features.map((feature, i) => (
          <li key={i} className="flex items-center gap-3">
            <div
              className={cn(
                'w-5 h-5 rounded-full flex items-center justify-center',
                'bg-gradient-to-br',
                plan.gradient
              )}
            >
              <Check className="h-3 w-3 text-white" />
            </div>
            <span className="text-sm">{feature}</span>
          </li>
        ))}
      </ul>

      <Button
        className={cn(
          'w-full transition-all duration-300',
          plan.popular 
            ? 'bg-gradient-to-r from-primary to-accent hover:opacity-90' 
            : ''
        )}
        variant={plan.popular ? 'default' : 'outline'}
        size="lg"
        onClick={() => {
          if (plan.name === 'Enterprise') {
            window.location.href = 'mailto:sales@navi.ai';
          } else {
            navigate('/auth');
          }
        }}
      >
        {plan.cta}
      </Button>
    </div>
  );
}

export function PricingSection() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section ref={ref} className="py-32 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-gradient-to-b from-primary/10 to-transparent rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-6 relative">
        <div
          className="text-center mb-20"
          style={{
            opacity: isInView ? 1 : 0,
            transform: isInView ? 'translateY(0)' : 'translateY(30px)',
            transition: 'all 0.8s cubic-bezier(0.16, 1, 0.3, 1)',
          }}
        >
          <span className="inline-block px-4 py-1.5 rounded-full text-sm font-medium bg-primary/10 text-primary mb-4">
            Pricing
          </span>
          <h2 className="text-4xl md:text-5xl font-bold mb-6">
            Simple, transparent{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
              pricing
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Start free and scale as you grow. No hidden fees, cancel anytime.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 items-start">
          {plans.map((plan, index) => (
            <PricingCard key={plan.name} plan={plan} index={index} />
          ))}
        </div>

        {/* Trust badges */}
        <div
          className="mt-16 text-center"
          style={{
            opacity: isInView ? 1 : 0,
            transition: 'opacity 0.8s ease 0.5s',
          }}
        >
          <p className="text-muted-foreground mb-4">Trusted by 10,000+ developers worldwide</p>
          <div className="flex items-center justify-center gap-8 flex-wrap">
            {['SOC 2 Certified', 'GDPR Compliant', '99.9% Uptime', '24/7 Support'].map((badge) => (
              <span key={badge} className="text-sm text-muted-foreground flex items-center gap-2">
                <Check className="h-4 w-4 text-primary" />
                {badge}
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
