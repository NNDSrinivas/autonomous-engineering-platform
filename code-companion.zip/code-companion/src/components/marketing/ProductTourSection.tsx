import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { 
  Play, 
  Pause, 
  RotateCcw,
  ChevronRight,
  ChevronLeft,
  MessageSquare,
  GitBranch,
  Code,
  CheckCircle2,
  Sparkles,
  Zap,
  Brain,
  Rocket
} from 'lucide-react';

const tourSteps = [
  {
    id: 1,
    title: 'Connect Your Tools',
    description: 'Link NAVI to your Jira, GitHub, Slack, and other development tools in seconds.',
    icon: Zap,
    animation: 'connect',
    details: [
      'One-click OAuth integration',
      'Automatic permission scoping',
      'Real-time sync enabled',
    ],
  },
  {
    id: 2,
    title: 'Natural Language Commands',
    description: 'Just tell NAVI what you need. It understands complex engineering requests.',
    icon: MessageSquare,
    animation: 'chat',
    details: [
      '"Pick up JIRA-123 and implement it"',
      '"Review the latest PR and suggest fixes"',
      '"Generate tests for the auth module"',
    ],
  },
  {
    id: 3,
    title: 'Autonomous Execution',
    description: 'Watch as NAVI analyzes your codebase, creates branches, and writes code.',
    icon: Brain,
    animation: 'execute',
    details: [
      'Context-aware code generation',
      'Follows your coding patterns',
      'Automatic branch management',
    ],
  },
  {
    id: 4,
    title: 'Code Review & PR',
    description: 'NAVI creates pull requests with detailed descriptions and requests reviews.',
    icon: GitBranch,
    animation: 'pr',
    details: [
      'Auto-generated PR descriptions',
      'Linked Jira tickets',
      'Reviewer suggestions',
    ],
  },
  {
    id: 5,
    title: 'Continuous Learning',
    description: 'NAVI learns from your feedback and improves with every interaction.',
    icon: Sparkles,
    animation: 'learn',
    details: [
      'Persistent memory across sessions',
      'Team knowledge sharing',
      'Preference learning',
    ],
  },
];

function AnimatedDemo({ step }: { step: typeof tourSteps[0] }) {
  const [animationPhase, setAnimationPhase] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setAnimationPhase((prev) => (prev + 1) % 4);
    }, 1500);
    return () => clearInterval(interval);
  }, [step.id]);

  const renderAnimation = () => {
    switch (step.animation) {
      case 'connect':
        return (
          <div className="relative w-full h-full flex items-center justify-center">
            {['Jira', 'GitHub', 'Slack', 'VS Code'].map((tool, i) => (
              <motion.div
                key={tool}
                className="absolute w-16 h-16 rounded-xl bg-card border border-border flex items-center justify-center text-2xl shadow-lg"
                initial={{ scale: 0, opacity: 0 }}
                animate={{
                  scale: animationPhase >= i ? 1 : 0,
                  opacity: animationPhase >= i ? 1 : 0,
                  x: Math.cos((i * Math.PI) / 2) * 80,
                  y: Math.sin((i * Math.PI) / 2) * 80,
                }}
                transition={{ type: 'spring', delay: i * 0.1 }}
              >
                {tool === 'Jira' && '📋'}
                {tool === 'GitHub' && '🐙'}
                {tool === 'Slack' && '💬'}
                {tool === 'VS Code' && '💻'}
              </motion.div>
            ))}
            <motion.div
              className="w-20 h-20 rounded-full bg-gradient-to-br from-primary to-accent flex items-center justify-center z-10"
              animate={{ rotate: 360 }}
              transition={{ duration: 8, repeat: Infinity, ease: 'linear' }}
            >
              <Sparkles className="h-10 w-10 text-primary-foreground" />
            </motion.div>
            {animationPhase >= 3 && (
              <>
                {[0, 1, 2, 3].map((i) => (
                  <motion.div
                    key={i}
                    className="absolute w-1 h-16 bg-gradient-to-b from-primary to-transparent"
                    initial={{ opacity: 0, scale: 0 }}
                    animate={{ opacity: 0.6, scale: 1 }}
                    style={{
                      rotate: `${i * 90}deg`,
                      transformOrigin: 'center center',
                    }}
                  />
                ))}
              </>
            )}
          </div>
        );

      case 'chat':
        return (
          <div className="w-full h-full p-4 space-y-3">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: animationPhase >= 0 ? 1 : 0, x: animationPhase >= 0 ? 0 : -20 }}
              className="bg-primary/10 rounded-lg p-3 max-w-[80%] border border-primary/20"
            >
              <p className="text-sm">Pick up JIRA-456 and implement the user authentication flow</p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: animationPhase >= 1 ? 1 : 0, x: animationPhase >= 1 ? 0 : 20 }}
              className="bg-muted rounded-lg p-3 max-w-[80%] ml-auto"
            >
              <p className="text-sm flex items-center gap-2">
                <Brain className="h-4 w-4 text-primary" />
                Analyzing JIRA-456...
              </p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: animationPhase >= 2 ? 1 : 0, x: animationPhase >= 2 ? 0 : 20 }}
              className="bg-muted rounded-lg p-3 max-w-[80%] ml-auto"
            >
              <p className="text-sm flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-500" />
                Found related files and patterns
              </p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: animationPhase >= 3 ? 1 : 0, x: animationPhase >= 3 ? 0 : 20 }}
              className="bg-muted rounded-lg p-3 max-w-[80%] ml-auto"
            >
              <p className="text-sm flex items-center gap-2">
                <Rocket className="h-4 w-4 text-primary" />
                Starting implementation...
              </p>
            </motion.div>
          </div>
        );

      case 'execute':
        return (
          <div className="w-full h-full p-4 font-mono text-xs">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-2"
            >
              {[
                { text: '$ git checkout -b feature/JIRA-456', delay: 0 },
                { text: '✓ Branch created', delay: 1, color: 'text-green-500' },
                { text: '$ Analyzing codebase...', delay: 1 },
                { text: '✓ Found 12 related files', delay: 2, color: 'text-green-500' },
                { text: '$ Generating auth module...', delay: 2 },
                { text: '✓ Created src/auth/AuthProvider.tsx', delay: 3, color: 'text-green-500' },
              ].map((line, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ 
                    opacity: animationPhase >= line.delay ? 1 : 0, 
                    x: animationPhase >= line.delay ? 0 : -10 
                  }}
                  className={line.color || 'text-muted-foreground'}
                >
                  {line.text}
                </motion.div>
              ))}
            </motion.div>
          </div>
        );

      case 'pr':
        return (
          <div className="w-full h-full p-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-card rounded-lg border border-border p-4 shadow-lg"
            >
              <div className="flex items-center gap-2 mb-3">
                <GitBranch className="h-5 w-5 text-primary" />
                <span className="font-semibold">Pull Request #142</span>
                <Badge variant="secondary" className="ml-auto">Ready for review</Badge>
              </div>
              <h4 className="font-medium mb-2">feat: Implement user authentication flow</h4>
              <p className="text-sm text-muted-foreground mb-3">
                Implements JIRA-456. Adds OAuth2 authentication with...
              </p>
              <div className="flex gap-4 text-sm">
                <motion.span 
                  className="text-green-500"
                  animate={{ opacity: animationPhase >= 2 ? 1 : 0.3 }}
                >
                  +324 lines
                </motion.span>
                <motion.span 
                  className="text-red-500"
                  animate={{ opacity: animationPhase >= 2 ? 1 : 0.3 }}
                >
                  -12 lines
                </motion.span>
              </div>
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: animationPhase >= 3 ? '100%' : '0%' }}
                className="mt-3 h-1 bg-green-500 rounded"
              />
            </motion.div>
          </div>
        );

      case 'learn':
        return (
          <div className="w-full h-full flex items-center justify-center">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
              className="relative w-40 h-40"
            >
              {[0, 1, 2, 3, 4, 5].map((i) => (
                <motion.div
                  key={i}
                  className="absolute w-8 h-8 rounded-full bg-gradient-to-br from-primary to-accent"
                  style={{
                    left: '50%',
                    top: '50%',
                    marginLeft: -16,
                    marginTop: -16,
                  }}
                  animate={{
                    x: Math.cos((i * Math.PI) / 3 + animationPhase) * 60,
                    y: Math.sin((i * Math.PI) / 3 + animationPhase) * 60,
                    scale: [1, 1.2, 1],
                  }}
                  transition={{ duration: 2, repeat: Infinity, delay: i * 0.2 }}
                />
              ))}
              <div className="absolute inset-0 flex items-center justify-center">
                <Brain className="h-12 w-12 text-primary" />
              </div>
            </motion.div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="w-full h-64 md:h-80 bg-gradient-to-br from-muted/50 to-muted/30 rounded-xl border border-border overflow-hidden">
      {renderAnimation()}
    </div>
  );
}

export function ProductTourSection() {
  const [currentStep, setCurrentStep] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  useEffect(() => {
    if (!isAutoPlaying) return;
    const interval = setInterval(() => {
      setCurrentStep((prev) => (prev + 1) % tourSteps.length);
    }, 6000);
    return () => clearInterval(interval);
  }, [isAutoPlaying]);

  const progress = ((currentStep + 1) / tourSteps.length) * 100;

  return (
    <section className="py-24 relative overflow-hidden" id="demo">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-accent/5 to-background" />

      <div className="relative max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <Badge variant="outline" className="mb-4">
            <Rocket className="h-3.5 w-3.5 mr-2" />
            Interactive Tour
          </Badge>
          <h2 className="text-3xl md:text-5xl font-bold mb-4">
            See NAVI in Action
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Take a guided tour through NAVI's powerful features and see how it transforms your workflow.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Animation Panel */}
          <div className="space-y-6">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentStep}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.3 }}
              >
                <AnimatedDemo step={tourSteps[currentStep]} />
              </motion.div>
            </AnimatePresence>

            {/* Progress and Controls */}
            <div className="space-y-4">
              <Progress value={progress} className="h-2" />
              <div className="flex items-center justify-between">
                <div className="flex gap-2">
                  <Button
                    size="icon"
                    variant="outline"
                    onClick={() => setCurrentStep((prev) => (prev - 1 + tourSteps.length) % tourSteps.length)}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <Button
                    size="icon"
                    variant="outline"
                    onClick={() => setIsAutoPlaying(!isAutoPlaying)}
                  >
                    {isAutoPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                  </Button>
                  <Button
                    size="icon"
                    variant="outline"
                    onClick={() => setCurrentStep((prev) => (prev + 1) % tourSteps.length)}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setCurrentStep(0)}
                >
                  <RotateCcw className="h-4 w-4 mr-2" />
                  Restart
                </Button>
              </div>
            </div>
          </div>

          {/* Steps List */}
          <div className="space-y-4">
            {tourSteps.map((step, index) => {
              const Icon = step.icon;
              const isActive = index === currentStep;
              const isPast = index < currentStep;

              return (
                <motion.div
                  key={step.id}
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  onClick={() => setCurrentStep(index)}
                  className={`p-4 rounded-xl border cursor-pointer transition-all ${
                    isActive
                      ? 'bg-primary/10 border-primary shadow-lg shadow-primary/10'
                      : isPast
                      ? 'bg-muted/50 border-border'
                      : 'bg-card border-border hover:border-primary/50'
                  }`}
                >
                  <div className="flex gap-4">
                    <div
                      className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${
                        isActive
                          ? 'bg-primary text-primary-foreground'
                          : isPast
                          ? 'bg-green-500/20 text-green-500'
                          : 'bg-muted text-muted-foreground'
                      }`}
                    >
                      {isPast ? <CheckCircle2 className="h-6 w-6" /> : <Icon className="h-6 w-6" />}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">Step {index + 1}</span>
                        {isActive && (
                          <Badge className="bg-primary/20 text-primary border-0">Active</Badge>
                        )}
                      </div>
                      <h3 className={`font-semibold ${isActive ? 'text-primary' : ''}`}>
                        {step.title}
                      </h3>
                      <p className="text-sm text-muted-foreground mt-1">{step.description}</p>
                      
                      <AnimatePresence>
                        {isActive && (
                          <motion.ul
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="mt-3 space-y-1"
                          >
                            {step.details.map((detail, i) => (
                              <motion.li
                                key={i}
                                initial={{ opacity: 0, x: -10 }}
                                animate={{ opacity: 1, x: 0 }}
                                transition={{ delay: i * 0.1 }}
                                className="text-sm flex items-center gap-2"
                              >
                                <CheckCircle2 className="h-3 w-3 text-primary" />
                                {detail}
                              </motion.li>
                            ))}
                          </motion.ul>
                        )}
                      </AnimatePresence>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
