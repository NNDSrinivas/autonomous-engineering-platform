import { useRef, useEffect, useState } from 'react';
import { useInView } from 'framer-motion';
import { cn } from '@/lib/utils';

const stats = [
  { value: 10000, suffix: '+', label: 'Active Developers', description: 'Trust NAVI daily' },
  { value: 2, suffix: 'M+', label: 'Tasks Completed', description: 'Autonomously executed' },
  { value: 85, suffix: '%', label: 'Time Saved', description: 'On routine tasks' },
  { value: 99.9, suffix: '%', label: 'Uptime', description: 'Enterprise-grade reliability' },
];

interface AnimatedCounterProps {
  value: number;
  suffix: string;
  duration?: number;
  isInView: boolean;
}

function AnimatedCounter({ value, suffix, duration = 2000, isInView }: AnimatedCounterProps) {
  const [count, setCount] = useState(0);
  const hasAnimated = useRef(false);

  useEffect(() => {
    if (!isInView || hasAnimated.current) return;
    hasAnimated.current = true;

    let startTime: number;
    let animationFrame: number;

    const animate = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      
      // Easing function for smooth animation
      const easeOutExpo = 1 - Math.pow(2, -10 * progress);
      
      setCount(value * easeOutExpo);

      if (progress < 1) {
        animationFrame = requestAnimationFrame(animate);
      }
    };

    animationFrame = requestAnimationFrame(animate);

    return () => cancelAnimationFrame(animationFrame);
  }, [isInView, value, duration]);

  const displayValue = value >= 1000 
    ? Math.floor(count).toLocaleString()
    : Number.isInteger(value) 
      ? Math.floor(count) 
      : count.toFixed(1);

  return (
    <span className="tabular-nums">
      {displayValue}{suffix}
    </span>
  );
}

export function StatsSection() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section 
      ref={ref} 
      className="py-24 relative overflow-hidden bg-gradient-to-b from-background via-muted/30 to-background"
    >
      {/* Animated background */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[400px]">
          <div className="absolute inset-0 bg-gradient-to-r from-primary/20 via-accent/20 to-primary/20 blur-3xl animate-pulse" />
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 relative">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div
              key={stat.label}
              className={cn(
                'text-center p-8 rounded-2xl',
                'bg-card/30 backdrop-blur-sm border border-border/50',
                'transition-all duration-500 hover:border-primary/50 hover:shadow-xl hover:shadow-primary/5',
                'hover:-translate-y-1'
              )}
              style={{
                opacity: isInView ? 1 : 0,
                transform: isInView ? 'translateY(0)' : 'translateY(30px)',
                transition: `all 0.6s cubic-bezier(0.16, 1, 0.3, 1) ${index * 0.1}s`,
              }}
            >
              <div className="text-4xl md:text-5xl font-bold mb-2 text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
                <AnimatedCounter 
                  value={stat.value} 
                  suffix={stat.suffix} 
                  isInView={isInView}
                />
              </div>
              <div className="text-lg font-semibold mb-1">{stat.label}</div>
              <div className="text-sm text-muted-foreground">{stat.description}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
