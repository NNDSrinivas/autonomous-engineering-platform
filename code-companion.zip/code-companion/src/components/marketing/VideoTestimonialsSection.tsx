import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Play, 
  Pause, 
  ChevronLeft, 
  ChevronRight, 
  Quote,
  Volume2,
  VolumeX,
  Star
} from 'lucide-react';

const videoTestimonials = [
  {
    id: 1,
    name: 'Sarah Chen',
    role: 'VP of Engineering',
    company: 'TechFlow Inc.',
    avatar: '👩‍💻',
    quote: "NAVI has completely transformed how our team approaches development. What used to take us days now takes hours. The autonomous workflow execution is like having a senior engineer available 24/7.",
    rating: 5,
    videoThumbnail: '🎬',
    videoDuration: '2:45',
    metrics: { timeSaved: '60%', productivity: '3x' },
  },
  {
    id: 2,
    name: 'Marcus Johnson',
    role: 'CTO',
    company: 'DataScale AI',
    avatar: '👨‍💼',
    quote: "The context-aware memory system is incredible. NAVI remembers everything about our codebase and makes intelligent suggestions. It's like it truly understands our architecture.",
    rating: 5,
    videoThumbnail: '🎥',
    videoDuration: '3:12',
    metrics: { automation: '80%', bugs: '-45%' },
  },
  {
    id: 3,
    name: 'Emily Rodriguez',
    role: 'Head of Security',
    company: 'FinSecure',
    avatar: '👩‍🔬',
    quote: "Security was our top concern. NAVI exceeded our expectations with SOC2 compliance and enterprise-grade security. We ship faster without compromising on safety.",
    rating: 5,
    videoThumbnail: '📹',
    videoDuration: '2:58',
    metrics: { velocity: '10x', security: '99%' },
  },
  {
    id: 4,
    name: 'David Kim',
    role: 'Engineering Manager',
    company: 'CloudNative Labs',
    avatar: '👨‍🔧',
    quote: "Onboarding new developers used to take weeks. With NAVI's documentation sync and code understanding, new team members are productive from day one.",
    rating: 5,
    videoThumbnail: '🎞️',
    videoDuration: '3:30',
    metrics: { onboarding: '-75%', satisfaction: '98%' },
  },
];

export function VideoTestimonialsSection() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(true);

  const nextTestimonial = () => {
    setActiveIndex((prev) => (prev + 1) % videoTestimonials.length);
    setIsPlaying(false);
  };

  const prevTestimonial = () => {
    setActiveIndex((prev) => (prev - 1 + videoTestimonials.length) % videoTestimonials.length);
    setIsPlaying(false);
  };

  const activeTestimonial = videoTestimonials[activeIndex];

  return (
    <section className="py-24 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-background to-background" />
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
      </div>

      <div className="relative max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <Badge variant="outline" className="mb-4">
            <Play className="h-3.5 w-3.5 mr-2" />
            Video Testimonials
          </Badge>
          <h2 className="text-3xl md:text-5xl font-bold mb-4">
            Hear From Our Customers
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Real stories from engineering teams transforming their workflows with NAVI.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Video Player */}
          <motion.div
            key={activeIndex}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4 }}
            className="relative aspect-video rounded-2xl overflow-hidden bg-gradient-to-br from-primary/20 to-accent/20 border border-border shadow-2xl"
          >
            {/* Video Placeholder */}
            <div className="absolute inset-0 flex items-center justify-center">
              <motion.span 
                className="text-9xl"
                animate={{ scale: isPlaying ? [1, 1.1, 1] : 1 }}
                transition={{ repeat: isPlaying ? Infinity : 0, duration: 2 }}
              >
                {activeTestimonial.videoThumbnail}
              </motion.span>
            </div>

            {/* Play/Pause Overlay */}
            <AnimatePresence>
              {!isPlaying && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 bg-black/40 flex items-center justify-center cursor-pointer"
                  onClick={() => setIsPlaying(true)}
                >
                  <motion.div
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                    className="w-20 h-20 rounded-full bg-primary flex items-center justify-center shadow-lg shadow-primary/50"
                  >
                    <Play className="h-8 w-8 text-primary-foreground ml-1" />
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Video Controls */}
            <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Button
                    size="icon"
                    variant="ghost"
                    className="h-8 w-8 text-white hover:bg-white/20"
                    onClick={() => setIsPlaying(!isPlaying)}
                  >
                    {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                  </Button>
                  <span className="text-white text-sm">{activeTestimonial.videoDuration}</span>
                </div>
                <Button
                  size="icon"
                  variant="ghost"
                  className="h-8 w-8 text-white hover:bg-white/20"
                  onClick={() => setIsMuted(!isMuted)}
                >
                  {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                </Button>
              </div>
              {/* Progress Bar */}
              <div className="mt-2 h-1 bg-white/30 rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-primary"
                  initial={{ width: '0%' }}
                  animate={{ width: isPlaying ? '100%' : '0%' }}
                  transition={{ duration: isPlaying ? 165 : 0, ease: 'linear' }}
                />
              </div>
            </div>
          </motion.div>

          {/* Quote and Info */}
          <div className="space-y-6">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeIndex}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
              >
                {/* Rating */}
                <div className="flex gap-1 mb-4">
                  {[...Array(activeTestimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>

                {/* Quote */}
                <div className="relative mb-6">
                  <Quote className="absolute -top-2 -left-2 h-8 w-8 text-primary/20" />
                  <p className="text-xl md:text-2xl font-medium leading-relaxed pl-6">
                    "{activeTestimonial.quote}"
                  </p>
                </div>

                {/* Author */}
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-14 h-14 rounded-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center text-3xl">
                    {activeTestimonial.avatar}
                  </div>
                  <div>
                    <div className="font-semibold text-lg">{activeTestimonial.name}</div>
                    <div className="text-muted-foreground">
                      {activeTestimonial.role} at {activeTestimonial.company}
                    </div>
                  </div>
                </div>

                {/* Metrics */}
                <div className="flex gap-6">
                  {Object.entries(activeTestimonial.metrics).map(([key, value]) => (
                    <div key={key} className="text-center p-4 rounded-lg bg-muted/50">
                      <div className="text-2xl font-bold text-primary">{value}</div>
                      <div className="text-sm text-muted-foreground capitalize">{key}</div>
                    </div>
                  ))}
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Navigation */}
            <div className="flex items-center justify-between pt-6 border-t border-border">
              <div className="flex gap-2">
                {videoTestimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      setActiveIndex(index);
                      setIsPlaying(false);
                    }}
                    className={`w-3 h-3 rounded-full transition-all ${
                      index === activeIndex ? 'bg-primary w-8' : 'bg-muted-foreground/30 hover:bg-muted-foreground/50'
                    }`}
                  />
                ))}
              </div>
              <div className="flex gap-2">
                <Button size="icon" variant="outline" onClick={prevTestimonial}>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button size="icon" variant="outline" onClick={nextTestimonial}>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
