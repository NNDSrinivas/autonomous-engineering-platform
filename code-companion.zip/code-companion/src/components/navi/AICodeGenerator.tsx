import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Sparkles, 
  Code, 
  RefreshCw, 
  Bug, 
  TestTube2,
  Copy,
  Check,
  FileCode,
  Loader2,
  ChevronDown,
  ChevronRight,
  AlertCircle
} from 'lucide-react';
import { useAICodeGeneration } from '@/hooks/useAIFeatures';
import { cn } from '@/lib/utils';
import type { JiraTask } from '@/types';

interface AICodeGeneratorProps {
  selectedTask: JiraTask | null;
  onApplyCode?: (files: Array<{ path: string; content: string }>) => void;
}

export function AICodeGenerator({ selectedTask, onApplyCode }: AICodeGeneratorProps) {
  const task = selectedTask;
  const { isGenerating, generatedCode, generateCode, clearGenerated } = useAICodeGeneration();
  const [expandedFiles, setExpandedFiles] = useState<Set<string>>(new Set());
  const [copiedFile, setCopiedFile] = useState<string | null>(null);

  const handleGenerate = async (action: 'generate' | 'refactor' | 'fix' | 'test') => {
    if (!task) return;
    await generateCode(
      task.key,
      task.title,
      task.description || '',
      { action }
    );
  };

  const toggleFile = (path: string) => {
    const newExpanded = new Set(expandedFiles);
    if (newExpanded.has(path)) {
      newExpanded.delete(path);
    } else {
      newExpanded.add(path);
    }
    setExpandedFiles(newExpanded);
  };

  const copyToClipboard = async (content: string, path: string) => {
    await navigator.clipboard.writeText(content);
    setCopiedFile(path);
    setTimeout(() => setCopiedFile(null), 2000);
  };

  const impactColors = {
    low: 'bg-green-500/20 text-green-400',
    medium: 'bg-yellow-500/20 text-yellow-400',
    high: 'bg-red-500/20 text-red-400'
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-primary" />
          <h3 className="font-medium text-sm">AI Code Generator</h3>
        </div>
        {generatedCode && (
          <Button variant="ghost" size="sm" onClick={clearGenerated}>
            Clear
          </Button>
        )}
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-2 gap-2">
        <Button
          variant="outline"
          size="sm"
          onClick={() => handleGenerate('generate')}
          disabled={isGenerating}
          className="justify-start"
        >
          <Code className="h-4 w-4 mr-2" />
          Generate Code
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => handleGenerate('refactor')}
          disabled={isGenerating}
          className="justify-start"
        >
          <RefreshCw className="h-4 w-4 mr-2" />
          Refactor
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => handleGenerate('fix')}
          disabled={isGenerating}
          className="justify-start"
        >
          <Bug className="h-4 w-4 mr-2" />
          Fix Bug
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => handleGenerate('test')}
          disabled={isGenerating}
          className="justify-start"
        >
          <TestTube2 className="h-4 w-4 mr-2" />
          Generate Tests
        </Button>
      </div>

      {/* Loading State */}
      {isGenerating && (
        <div className="flex items-center justify-center py-8">
          <Loader2 className="h-6 w-6 animate-spin text-primary" />
          <span className="ml-2 text-sm text-muted-foreground">Generating code...</span>
        </div>
      )}

      {/* Generated Code Results */}
      {generatedCode && !isGenerating && (
        <div className="space-y-4">
          {/* Summary */}
          <div className="p-3 bg-primary/5 rounded-lg border border-primary/20">
            <p className="text-sm">{generatedCode.summary}</p>
            <div className="flex items-center gap-2 mt-2">
              <Badge className={impactColors[generatedCode.estimatedImpact]}>
                {generatedCode.estimatedImpact} impact
              </Badge>
              <Badge variant="outline">
                {generatedCode.files?.length || 0} files
              </Badge>
            </div>
          </div>

          {/* Files */}
          <ScrollArea className="h-[400px]">
            <div className="space-y-2">
              {generatedCode.files?.map((file) => (
                <div 
                  key={file.path} 
                  className="border border-border rounded-lg overflow-hidden"
                >
                  <button
                    onClick={() => toggleFile(file.path)}
                    className="w-full flex items-center justify-between p-3 hover:bg-secondary/50 transition-colors"
                  >
                    <div className="flex items-center gap-2">
                      {expandedFiles.has(file.path) ? (
                        <ChevronDown className="h-4 w-4" />
                      ) : (
                        <ChevronRight className="h-4 w-4" />
                      )}
                      <FileCode className="h-4 w-4 text-primary" />
                      <span className="text-sm font-mono">{file.path}</span>
                    </div>
                    <Badge 
                      variant="outline" 
                      className={cn(
                        file.action === 'create' && 'border-green-500 text-green-500',
                        file.action === 'modify' && 'border-yellow-500 text-yellow-500',
                        file.action === 'delete' && 'border-red-500 text-red-500'
                      )}
                    >
                      {file.action}
                    </Badge>
                  </button>
                  
                  {expandedFiles.has(file.path) && (
                    <div className="border-t border-border">
                      <div className="flex items-center justify-between px-3 py-2 bg-secondary/30">
                        <span className="text-xs text-muted-foreground">{file.description}</span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => copyToClipboard(file.content, file.path)}
                        >
                          {copiedFile === file.path ? (
                            <Check className="h-4 w-4 text-green-500" />
                          ) : (
                            <Copy className="h-4 w-4" />
                          )}
                        </Button>
                      </div>
                      <pre className="p-3 text-xs overflow-x-auto bg-background">
                        <code>{file.content}</code>
                      </pre>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </ScrollArea>

          {/* Test Suggestions */}
          {generatedCode.testSuggestions?.length > 0 && (
            <div className="p-3 bg-secondary/30 rounded-lg">
              <h4 className="text-sm font-medium flex items-center gap-2 mb-2">
                <TestTube2 className="h-4 w-4" />
                Suggested Tests
              </h4>
              <ul className="text-xs text-muted-foreground space-y-1">
                {generatedCode.testSuggestions.map((test, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="text-primary">•</span>
                    {test}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Apply Button */}
          {onApplyCode && generatedCode.files?.length > 0 && (
            <Button 
              className="w-full"
              onClick={() => onApplyCode(generatedCode.files.map(f => ({ path: f.path, content: f.content })))}
            >
              <Sparkles className="h-4 w-4 mr-2" />
              Apply Generated Code
            </Button>
          )}
        </div>
      )}

      {/* Empty State */}
      {!generatedCode && !isGenerating && (
        <div className="text-center py-6 text-muted-foreground">
          <Sparkles className="h-8 w-8 mx-auto mb-2 opacity-50" />
          <p className="text-sm">Select an action to generate code based on this task</p>
        </div>
      )}
    </div>
  );
}
