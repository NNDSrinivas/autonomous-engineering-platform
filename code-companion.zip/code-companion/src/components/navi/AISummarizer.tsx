import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Sparkles, 
  MessageSquare, 
  Video, 
  GitPullRequest,
  FileText,
  Loader2,
  Copy,
  Check,
  ChevronDown,
  ChevronRight,
  Users,
  Clock,
  AlertCircle
} from 'lucide-react';
import { useAISummarization } from '@/hooks/useAIFeatures';
import { cn } from '@/lib/utils';

type SummaryType = 'slack' | 'meeting' | 'pr_comments' | 'confluence';

interface AISummarizerProps {
  type?: SummaryType;
  initialContent?: string;
  context?: {
    taskKey?: string;
    channelName?: string;
    participants?: string[];
  };
}

const typeConfig: Record<SummaryType, { icon: any; title: string; placeholder: string; color: string }> = {
  slack: {
    icon: MessageSquare,
    title: 'Slack Conversation',
    placeholder: 'Paste Slack conversation here...',
    color: 'text-purple-400'
  },
  meeting: {
    icon: Video,
    title: 'Meeting Notes',
    placeholder: 'Paste meeting transcript or notes here...',
    color: 'text-blue-400'
  },
  pr_comments: {
    icon: GitPullRequest,
    title: 'PR Comments',
    placeholder: 'Paste PR discussion here...',
    color: 'text-green-400'
  },
  confluence: {
    icon: FileText,
    title: 'Documentation',
    placeholder: 'Paste documentation content here...',
    color: 'text-orange-400'
  }
};

export function AISummarizer({ type = 'slack', initialContent = '', context }: AISummarizerProps) {
  const { isSummarizing, summarize } = useAISummarization();
  const [content, setContent] = useState(initialContent);
  const [summary, setSummary] = useState<any>(null);
  const [copied, setCopied] = useState(false);
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set(['summary']));
  const [selectedType, setSelectedType] = useState<SummaryType>(type);

  const config = typeConfig[selectedType];
  const Icon = config.icon;

  const handleSummarize = async () => {
    if (!content.trim()) return;
    
    const result = await summarize(selectedType, content, context);
    if (result) {
      setSummary(result);
    }
  };

  const copyToClipboard = async () => {
    if (!summary) return;
    await navigator.clipboard.writeText(JSON.stringify(summary, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const toggleSection = (section: string) => {
    const newExpanded = new Set(expandedSections);
    if (newExpanded.has(section)) {
      newExpanded.delete(section);
    } else {
      newExpanded.add(section);
    }
    setExpandedSections(newExpanded);
  };

  const renderSection = (title: string, key: string, items: any[], icon?: React.ReactNode) => {
    if (!items?.length) return null;

    return (
      <div className="border border-border rounded-lg overflow-hidden">
        <button
          onClick={() => toggleSection(key)}
          className="w-full flex items-center justify-between p-3 hover:bg-secondary/50 transition-colors"
        >
          <div className="flex items-center gap-2">
            {expandedSections.has(key) ? (
              <ChevronDown className="h-4 w-4" />
            ) : (
              <ChevronRight className="h-4 w-4" />
            )}
            {icon}
            <span className="text-sm font-medium">{title}</span>
            <Badge variant="outline" className="text-xs">{items.length}</Badge>
          </div>
        </button>
        {expandedSections.has(key) && (
          <div className="p-3 pt-0 space-y-2">
            {items.map((item, i) => (
              <div key={i} className="flex items-start gap-2 text-sm">
                <span className="text-primary mt-1">•</span>
                {typeof item === 'string' ? (
                  <span>{item}</span>
                ) : (
                  <div>
                    <span className="font-medium">{item.item || item.title}</span>
                    {item.owner && <span className="text-muted-foreground"> — {item.owner}</span>}
                    {item.deadline && <span className="text-muted-foreground"> ({item.deadline})</span>}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-primary" />
          <h3 className="font-medium text-sm">AI Summarizer</h3>
          <Badge variant="outline" className={cn("text-xs", config.color)}>
            <Icon className="h-3 w-3 mr-1" />
            {config.title}
          </Badge>
        </div>
        {summary && (
          <Button variant="ghost" size="sm" onClick={copyToClipboard}>
            {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
          </Button>
        )}
      </div>

      {/* Input */}
      {!summary && (
        <div className="space-y-3">
          {/* Type Selector */}
          <div className="flex gap-2">
            {(Object.keys(typeConfig) as SummaryType[]).map((t) => {
              const TypeIcon = typeConfig[t].icon;
              return (
                <Button
                  key={t}
                  variant={selectedType === t ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedType(t)}
                  className="flex-1"
                >
                  <TypeIcon className="h-4 w-4 mr-1" />
                  {typeConfig[t].title.split(' ')[0]}
                </Button>
              );
            })}
          </div>
          <Textarea
            placeholder={config.placeholder}
            value={content}
            onChange={(e) => setContent(e.target.value)}
            rows={8}
            className="font-mono text-xs"
          />
          <Button 
            onClick={handleSummarize} 
            disabled={isSummarizing || !content.trim()}
            className="w-full"
          >
            {isSummarizing ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Summarizing...
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4 mr-2" />
                Generate Summary
              </>
            )}
          </Button>
        </div>
      )}

      {/* Summary Results */}
      {summary && (
        <ScrollArea className="h-[400px]">
          <div className="space-y-3">
            {/* Main Summary */}
            <div className="p-4 bg-primary/5 rounded-lg border border-primary/20">
              <p className="text-sm">{summary.summary}</p>
              {summary.sentiment && (
                <Badge 
                  className={cn(
                    "mt-2",
                    summary.sentiment === 'positive' && 'bg-green-500/20 text-green-400',
                    summary.sentiment === 'neutral' && 'bg-gray-500/20 text-gray-400',
                    summary.sentiment === 'concerned' && 'bg-yellow-500/20 text-yellow-400'
                  )}
                >
                  {summary.sentiment}
                </Badge>
              )}
            </div>

            {/* Type-specific sections */}
            {selectedType === 'slack' && (
              <>
                {renderSection('Decisions', 'decisions', summary.decisions, <Check className="h-4 w-4 text-green-400" />)}
                {renderSection('Action Items', 'actionItems', summary.actionItems, <Clock className="h-4 w-4 text-blue-400" />)}
                {renderSection('Key Points', 'keyPoints', summary.keyPoints)}
                {renderSection('Questions', 'questions', summary.questions, <AlertCircle className="h-4 w-4 text-yellow-400" />)}
                {renderSection('Blockers', 'blockers', summary.blockers, <AlertCircle className="h-4 w-4 text-red-400" />)}
              </>
            )}

            {selectedType === 'meeting' && (
              <>
                {renderSection('Agenda', 'agenda', summary.agenda)}
                {renderSection('Decisions', 'decisions', summary.decisions, <Check className="h-4 w-4 text-green-400" />)}
                {renderSection('Action Items', 'actionItems', summary.actionItems, <Clock className="h-4 w-4 text-blue-400" />)}
                {renderSection('Technical Notes', 'technicalNotes', summary.technicalNotes)}
                {renderSection('Follow-ups', 'followUps', summary.followUps)}
                {summary.nextSteps && (
                  <div className="p-3 bg-secondary/30 rounded-lg">
                    <span className="text-sm font-medium">Next Steps: </span>
                    <span className="text-sm text-muted-foreground">{summary.nextSteps}</span>
                  </div>
                )}
              </>
            )}

            {selectedType === 'pr_comments' && (
              <>
                {renderSection('Required Changes', 'requiredChanges', summary.requiredChanges, <AlertCircle className="h-4 w-4 text-red-400" />)}
                {renderSection('Suggestions', 'suggestions', summary.suggestions)}
                {renderSection('Approved Aspects', 'approvedAspects', summary.approvedAspects, <Check className="h-4 w-4 text-green-400" />)}
                {renderSection('Concerns', 'concerns', summary.concerns, <AlertCircle className="h-4 w-4 text-yellow-400" />)}
              </>
            )}

            {selectedType === 'confluence' && (
              <>
                {summary.purpose && (
                  <div className="p-3 bg-secondary/30 rounded-lg">
                    <span className="text-sm font-medium">Purpose: </span>
                    <span className="text-sm text-muted-foreground">{summary.purpose}</span>
                  </div>
                )}
                {renderSection('Key Requirements', 'keyRequirements', summary.keyRequirements)}
                {renderSection('Technical Details', 'technicalDetails', summary.technicalDetails)}
                {renderSection('Constraints', 'constraints', summary.constraints)}
                {renderSection('Dependencies', 'dependencies', summary.dependencies)}
              </>
            )}

            {/* Reset Button */}
            <Button 
              variant="outline" 
              onClick={() => setSummary(null)}
              className="w-full"
            >
              Summarize New Content
            </Button>
          </div>
        </ScrollArea>
      )}
    </div>
  );
}
