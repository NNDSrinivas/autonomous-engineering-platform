import { useState, useEffect } from 'react';
import { 
  GitBranch, 
  MessageSquare, 
  FileText, 
  Video, 
  Activity,
  AlertCircle,
  CheckCircle2,
  Clock,
  User,
  ExternalLink,
  RefreshCw,
  Bell,
  LayoutGrid,
  XCircle,
  Play,
  Inbox,
  Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';
import { useIntegrations } from '@/hooks/useIntegrations';

interface ActivityItem {
  id: string;
  type: 'pr' | 'build' | 'message' | 'meeting' | 'task' | 'mention' | 'review';
  title: string;
  description: string;
  source: string;
  timestamp: Date;
  status?: 'success' | 'failed' | 'pending' | 'info';
  url?: string;
  user?: string;
  unread?: boolean;
}

const getActivityIcon = (type: string, status?: string) => {
  switch (type) {
    case 'pr':
      return <GitBranch className={cn("h-4 w-4", status === 'success' ? 'text-green-400' : 'text-syntax-function')} />;
    case 'build':
      return status === 'failed' 
        ? <XCircle className="h-4 w-4 text-red-400" />
        : status === 'success'
        ? <CheckCircle2 className="h-4 w-4 text-green-400" />
        : <Play className="h-4 w-4 text-yellow-400 animate-pulse" />;
    case 'message':
    case 'mention':
      return <MessageSquare className="h-4 w-4 text-purple-400" />;
    case 'meeting':
      return <Video className="h-4 w-4 text-sky-400" />;
    case 'task':
      return <LayoutGrid className="h-4 w-4 text-blue-400" />;
    case 'review':
      return <GitBranch className="h-4 w-4 text-yellow-400" />;
    default:
      return <Activity className="h-4 w-4 text-muted-foreground" />;
  }
};

const getSourceBadge = (source: string) => {
  const colors: Record<string, string> = {
    slack: 'bg-purple-500/10 text-purple-400 border-purple-500/30',
    teams: 'bg-violet-500/10 text-violet-400 border-violet-500/30',
    github: 'bg-green-500/10 text-green-400 border-green-500/30',
    jira: 'bg-blue-500/10 text-blue-400 border-blue-500/30',
    confluence: 'bg-blue-500/10 text-blue-300 border-blue-300/30',
    zoom: 'bg-sky-500/10 text-sky-400 border-sky-500/30',
  };
  return colors[source] || 'bg-muted text-muted-foreground';
};

const formatTime = (date: Date) => {
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  
  if (minutes < 60) return `${minutes}m ago`;
  if (hours < 24) return `${hours}h ago`;
  return date.toLocaleDateString();
};

type FilterType = 'all' | 'unread' | 'mentions' | 'builds' | 'prs';

export function ActivityFeed() {
  const [filter, setFilter] = useState<FilterType>('all');
  const [items, setItems] = useState<ActivityItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const { integrations } = useIntegrations();

  const connectedCount = integrations.filter(i => i.status === 'connected').length;

  useEffect(() => {
    // Simulate initial load
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);
    return () => clearTimeout(timer);
  }, []);

  const handleSync = async () => {
    if (connectedCount === 0) return;
    setIsSyncing(true);
    // In real app, would fetch from integration-data edge function
    setTimeout(() => {
      setIsSyncing(false);
    }, 2000);
  };

  const filteredItems = items.filter(item => {
    if (filter === 'unread') return item.unread;
    if (filter === 'mentions') return item.type === 'mention';
    if (filter === 'builds') return item.type === 'build';
    if (filter === 'prs') return item.type === 'pr' || item.type === 'review';
    return true;
  });

  const unreadCount = items.filter(i => i.unread).length;

  if (isLoading) {
    return (
      <div className="flex-1 flex flex-col h-full bg-panel-content">
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">Loading activity...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col h-full bg-panel-content">
      {/* Header */}
      <div className="px-6 py-4 border-b border-border bg-panel-header">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center">
              <Bell className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h2 className="font-semibold">Activity Feed</h2>
              <p className="text-xs text-muted-foreground">
                {connectedCount > 0 
                  ? `Real-time updates from ${connectedCount} connected integrations`
                  : 'Connect integrations to see activity'
                }
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {unreadCount > 0 && (
              <Badge variant="outline" className="text-xs bg-primary/10 text-primary border-primary/30">
                {unreadCount} unread
              </Badge>
            )}
            <Tooltip>
              <TooltipTrigger asChild>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-8 w-8"
                  onClick={handleSync}
                  disabled={connectedCount === 0 || isSyncing}
                >
                  <RefreshCw className={cn("h-4 w-4", isSyncing && "animate-spin")} />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                {connectedCount > 0 ? 'Refresh activity' : 'Connect integrations first'}
              </TooltipContent>
            </Tooltip>
          </div>
        </div>

        {/* Filters */}
        <div className="flex gap-2">
          {(['all', 'unread', 'mentions', 'builds', 'prs'] as FilterType[]).map((f) => (
            <Tooltip key={f}>
              <TooltipTrigger asChild>
                <Button
                  variant={filter === f ? 'default' : 'outline'}
                  size="xs"
                  onClick={() => setFilter(f)}
                  className="capitalize"
                >
                  {f}
                </Button>
              </TooltipTrigger>
              <TooltipContent>Filter by {f}</TooltipContent>
            </Tooltip>
          ))}
        </div>
      </div>

      {/* Activity List or Empty State */}
      <div className="flex-1 overflow-y-auto">
        {connectedCount === 0 ? (
          <div className="flex flex-col items-center justify-center h-full px-6 text-center">
            <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mb-4">
              <Inbox className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-medium mb-2">No Integrations Connected</h3>
            <p className="text-sm text-muted-foreground mb-4 max-w-sm">
              Connect your tools like GitHub, Slack, and Jira to see real-time activity updates here.
            </p>
            <Badge variant="outline" className="text-xs">
              Go to Integrations in the sidebar
            </Badge>
          </div>
        ) : filteredItems.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full px-6 text-center">
            <div className="h-16 w-16 rounded-full bg-muted flex items-center justify-center mb-4">
              <Inbox className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-medium mb-2">No Activity Yet</h3>
            <p className="text-sm text-muted-foreground">
              {filter === 'all' 
                ? 'Activity from your connected integrations will appear here.'
                : `No ${filter} activity to show.`
              }
            </p>
          </div>
        ) : (
          filteredItems.map((item) => (
            <div
              key={item.id}
              className={cn(
                "px-6 py-4 border-b border-border hover:bg-card/50 transition-colors cursor-pointer group",
                item.unread && "bg-primary/5"
              )}
            >
              <div className="flex gap-4">
                <div className="flex-shrink-0 mt-1">
                  {getActivityIcon(item.type, item.status)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-medium">{item.title}</span>
                      {item.unread && (
                        <span className="w-2 h-2 rounded-full bg-primary" />
                      )}
                    </div>
                    <span className="text-xs text-muted-foreground flex-shrink-0">
                      {formatTime(item.timestamp)}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground mb-2 line-clamp-2">
                    {item.description}
                  </p>
                  <div className="flex items-center gap-3">
                    <Badge variant="outline" className={cn("text-[10px]", getSourceBadge(item.source))}>
                      {item.source}
                    </Badge>
                    {item.user && (
                      <span className="text-xs text-muted-foreground flex items-center gap-1">
                        <User className="h-3 w-3" />
                        {item.user}
                      </span>
                    )}
                    {item.status && item.status !== 'info' && (
                      <Badge 
                        variant="outline" 
                        className={cn(
                          "text-[10px]",
                          item.status === 'success' && 'bg-green-500/10 text-green-400 border-green-500/30',
                          item.status === 'failed' && 'bg-red-500/10 text-red-400 border-red-500/30',
                          item.status === 'pending' && 'bg-yellow-500/10 text-yellow-400 border-yellow-500/30'
                        )}
                      >
                        {item.status}
                      </Badge>
                    )}
                  </div>
                </div>
                <ExternalLink className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0" />
              </div>
            </div>
          ))
        )}
      </div>

      {/* Footer */}
      {filteredItems.length > 0 && (
        <div className="px-6 py-3 border-t border-border bg-panel-header">
          <p className="text-xs text-muted-foreground text-center">
            Showing {filteredItems.length} of {items.length} activities
          </p>
        </div>
      )}
    </div>
  );
}
