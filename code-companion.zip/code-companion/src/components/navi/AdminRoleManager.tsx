import { useState, useEffect, useCallback } from 'react';
import { Shield, UserPlus, Trash2, Loader2, Search, AlertTriangle, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { useAdminAnalytics } from '@/hooks/useAdminAnalytics';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

interface AdminUser {
  id: string;
  user_id: string;
  role: string;
  created_at: string;
  email?: string;
}

export function AdminRoleManager() {
  const { isAdmin, isLoading: isCheckingAdmin } = useAdminAnalytics();
  const [admins, setAdmins] = useState<AdminUser[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);
  const [isRemoving, setIsRemoving] = useState<string | null>(null);
  const [newAdminEmail, setNewAdminEmail] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [error, setError] = useState<string | null>(null);

  // Fetch all admin users
  const fetchAdmins = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const { data, error } = await supabase
        .from('user_roles')
        .select('*')
        .eq('role', 'admin')
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Fetch emails for each admin from profiles
      const adminsWithEmails = await Promise.all(
        (data || []).map(async (admin) => {
          // Try to get email from auth (only works for service role)
          // For now, we'll show user_id as identifier
          return {
            ...admin,
            email: admin.user_id.substring(0, 8) + '...',
          };
        })
      );

      setAdmins(adminsWithEmails);
    } catch (err) {
      console.error('Error fetching admins:', err);
      setError('Failed to load admin users');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    if (isAdmin) {
      fetchAdmins();
    }
  }, [isAdmin, fetchAdmins]);

  // Add new admin by email
  const handleAddAdmin = async () => {
    if (!newAdminEmail.trim()) {
      toast.error('Please enter an email address');
      return;
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(newAdminEmail.trim())) {
      toast.error('Please enter a valid email address');
      return;
    }

    setIsAdding(true);
    try {
      // First, find the user by email in profiles
      // Since we can't directly query auth.users, we need to use an edge function or RPC
      // For now, we'll need to create a user lookup function
      
      // Alternative: look up user via a server function
      const { data: functionData, error: functionError } = await supabase.functions.invoke('admin-lookup-user', {
        body: { email: newAdminEmail.trim() }
      });

      if (functionError) {
        // If function doesn't exist, show helpful message
        if (functionError.message.includes('not found') || functionError.message.includes('404')) {
          toast.error('Admin lookup function not configured. Please contact support.');
          setIsAdding(false);
          return;
        }
        throw functionError;
      }

      if (!functionData?.user_id) {
        toast.error('User not found with that email address');
        setIsAdding(false);
        return;
      }

      // Check if already admin
      const existingAdmin = admins.find(a => a.user_id === functionData.user_id);
      if (existingAdmin) {
        toast.error('This user is already an admin');
        setIsAdding(false);
        return;
      }

      // Add admin role
      const { error: insertError } = await supabase
        .from('user_roles')
        .insert({
          user_id: functionData.user_id,
          role: 'admin' as const,
        });

      if (insertError) throw insertError;

      toast.success(`Admin role granted to ${newAdminEmail}`);
      setNewAdminEmail('');
      fetchAdmins();
    } catch (err: any) {
      console.error('Error adding admin:', err);
      toast.error(err.message || 'Failed to add admin');
    } finally {
      setIsAdding(false);
    }
  };

  // Remove admin role
  const handleRemoveAdmin = async (adminId: string, userId: string) => {
    // Check if trying to remove self
    const { data: { user } } = await supabase.auth.getUser();
    if (user?.id === userId) {
      toast.error("You cannot remove your own admin role");
      return;
    }

    setIsRemoving(adminId);
    try {
      const { error } = await supabase
        .from('user_roles')
        .delete()
        .eq('id', adminId);

      if (error) throw error;

      toast.success('Admin role removed');
      setAdmins(prev => prev.filter(a => a.id !== adminId));
    } catch (err) {
      console.error('Error removing admin:', err);
      toast.error('Failed to remove admin role');
    } finally {
      setIsRemoving(null);
    }
  };

  // Filter admins by search
  const filteredAdmins = admins.filter(admin => 
    admin.user_id.toLowerCase().includes(searchQuery.toLowerCase()) ||
    admin.email?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (isCheckingAdmin) {
    return (
      <div className="p-6 space-y-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-32" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-8 text-center">
        <div className="h-16 w-16 rounded-full bg-destructive/10 flex items-center justify-center mb-4">
          <Shield className="h-8 w-8 text-destructive" />
        </div>
        <h2 className="text-xl font-semibold mb-2">Access Denied</h2>
        <p className="text-muted-foreground max-w-md">
          You don't have permission to manage admin roles. 
          This feature is only available to administrators.
        </p>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Users className="h-6 w-6 text-primary" />
          Admin Role Management
        </h1>
        <p className="text-muted-foreground text-sm mt-1">
          View, add, and remove administrator access
        </p>
      </div>

      {/* Add Admin Card */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <UserPlus className="h-4 w-4" />
            Add New Admin
          </CardTitle>
          <CardDescription>
            Grant admin access to a user by their email address
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            <Input
              placeholder="Enter user email address..."
              value={newAdminEmail}
              onChange={(e) => setNewAdminEmail(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleAddAdmin()}
              disabled={isAdding}
              className="flex-1"
            />
            <Button 
              onClick={handleAddAdmin} 
              disabled={isAdding || !newAdminEmail.trim()}
            >
              {isAdding ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <UserPlus className="h-4 w-4 mr-2" />
              )}
              Add Admin
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Admin List */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-base flex items-center gap-2">
                <Shield className="h-4 w-4" />
                Current Admins
              </CardTitle>
              <CardDescription>
                {admins.length} admin{admins.length !== 1 ? 's' : ''} with full access
              </CardDescription>
            </div>
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search admins..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {error ? (
            <div className="flex items-center justify-center py-8 text-destructive">
              <AlertTriangle className="h-5 w-5 mr-2" />
              {error}
            </div>
          ) : isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : filteredAdmins.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-8 text-muted-foreground">
              <Users className="h-12 w-12 mb-3 opacity-50" />
              <p>{searchQuery ? 'No admins match your search' : 'No admin users found'}</p>
            </div>
          ) : (
            <ScrollArea className="max-h-[400px]">
              <div className="space-y-2">
                {filteredAdmins.map((admin) => (
                  <div
                    key={admin.id}
                    className="flex items-center justify-between p-3 rounded-lg bg-secondary/50 border border-border"
                  >
                    <div className="flex items-center gap-3">
                      <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <Shield className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-sm">
                            {admin.email || admin.user_id.substring(0, 16) + '...'}
                          </span>
                          <Badge variant="default" className="text-[10px]">
                            Admin
                          </Badge>
                        </div>
                        <span className="text-xs text-muted-foreground">
                          Added {format(new Date(admin.created_at), 'MMM d, yyyy')}
                        </span>
                      </div>
                    </div>

                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-destructive hover:text-destructive hover:bg-destructive/10"
                          disabled={isRemoving === admin.id}
                        >
                          {isRemoving === admin.id ? (
                            <Loader2 className="h-4 w-4 animate-spin" />
                          ) : (
                            <Trash2 className="h-4 w-4" />
                          )}
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Remove Admin Access?</AlertDialogTitle>
                          <AlertDialogDescription>
                            This will revoke admin privileges from this user. They will no longer
                            be able to access the analytics dashboard or manage admin roles.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => handleRemoveAdmin(admin.id, admin.user_id)}
                            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                          >
                            Remove Admin
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                ))}
              </div>
            </ScrollArea>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
