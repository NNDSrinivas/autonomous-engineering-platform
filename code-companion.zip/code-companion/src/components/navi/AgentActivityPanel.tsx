import { useState, useEffect, useCallback } from 'react';
import { 
  FileCode, 
  FileEdit, 
  FolderSearch, 
  Brain, 
  GitBranch,
  CheckCircle2,
  Loader2,
  FileText,
  Database,
  Globe,
  Sparkles,
  ChevronDown,
  ChevronUp,
  Zap,
  Search,
  Eye,
  Pencil,
  Terminal,
  Play,
  Shield,
  X
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import type { CommandToApprove, CommandApprovalChoice } from './CommandApprovalCard';

export type AgentPhase = 
  | 'idle'
  | 'thinking'
  | 'reading'
  | 'analyzing'
  | 'planning'
  | 'writing'
  | 'reviewing'
  | 'searching'
  | 'executing'
  | 'awaiting_approval'
  | 'complete';

export interface FileActivity {
  id: string;
  path: string;
  action: 'read' | 'write' | 'create' | 'delete' | 'analyze';
  status: 'pending' | 'active' | 'complete';
  changes?: number;
  timestamp: Date;
}

export interface AgentStep {
  id: string;
  label: string;
  description?: string;
  status: 'pending' | 'active' | 'complete' | 'skipped';
  duration?: number;
}

interface AgentActivityPanelProps {
  isActive: boolean;
  phase: AgentPhase;
  currentThought?: string;
  files: FileActivity[];
  steps: AgentStep[];
  totalEdits: number;
  linesChanged: number;
  tokensProcessed: number;
  pendingCommands?: CommandToApprove[];
  onCommandApprove?: (id: string, choice: CommandApprovalChoice) => void;
  onCommandSkip?: (id: string) => void;
  onDismiss?: () => void;
}

const phaseConfig: Record<AgentPhase, { icon: React.ReactNode; label: string; color: string }> = {
  idle: { icon: <Brain className="h-4 w-4" />, label: 'Ready', color: 'text-muted-foreground' },
  thinking: { icon: <Brain className="h-4 w-4 animate-pulse" />, label: 'Thinking...', color: 'text-purple-400' },
  reading: { icon: <Eye className="h-4 w-4" />, label: 'Reading files', color: 'text-blue-400' },
  analyzing: { icon: <Search className="h-4 w-4" />, label: 'Analyzing', color: 'text-cyan-400' },
  planning: { icon: <Sparkles className="h-4 w-4" />, label: 'Planning changes', color: 'text-yellow-400' },
  writing: { icon: <Pencil className="h-4 w-4" />, label: 'Writing code', color: 'text-green-400' },
  reviewing: { icon: <CheckCircle2 className="h-4 w-4" />, label: 'Reviewing', color: 'text-orange-400' },
  searching: { icon: <Globe className="h-4 w-4" />, label: 'Searching', color: 'text-sky-400' },
  executing: { icon: <Terminal className="h-4 w-4" />, label: 'Executing', color: 'text-pink-400' },
  awaiting_approval: { icon: <Shield className="h-4 w-4 animate-pulse" />, label: 'Awaiting approval', color: 'text-yellow-400' },
  complete: { icon: <CheckCircle2 className="h-4 w-4" />, label: 'Complete', color: 'text-status-success' },
};

const actionIcons: Record<FileActivity['action'], React.ReactNode> = {
  read: <Eye className="h-3 w-3" />,
  write: <Pencil className="h-3 w-3" />,
  create: <FileCode className="h-3 w-3" />,
  delete: <FileText className="h-3 w-3" />,
  analyze: <Search className="h-3 w-3" />,
};

const actionColors: Record<FileActivity['action'], string> = {
  read: 'text-blue-400 bg-blue-400/10',
  write: 'text-green-400 bg-green-400/10',
  create: 'text-emerald-400 bg-emerald-400/10',
  delete: 'text-red-400 bg-red-400/10',
  analyze: 'text-purple-400 bg-purple-400/10',
};

const riskColors: Record<string, string> = {
  low: 'bg-status-success/10 text-status-success border-status-success/30',
  medium: 'bg-status-warning/10 text-status-warning border-status-warning/30',
  high: 'bg-status-error/10 text-status-error border-status-error/30',
};

// Animated dots for loading states
function AnimatedDots() {
  return (
    <span className="inline-flex gap-0.5">
      <span className="animate-bounce" style={{ animationDelay: '0ms' }}>.</span>
      <span className="animate-bounce" style={{ animationDelay: '150ms' }}>.</span>
      <span className="animate-bounce" style={{ animationDelay: '300ms' }}>.</span>
    </span>
  );
}

// Typing effect for thoughts
function TypedText({ text, speed = 30 }: { text: string; speed?: number }) {
  const [displayText, setDisplayText] = useState('');
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    setDisplayText('');
    setCurrentIndex(0);
  }, [text]);

  useEffect(() => {
    if (currentIndex < text.length) {
      const timeout = setTimeout(() => {
        setDisplayText(prev => prev + text[currentIndex]);
        setCurrentIndex(prev => prev + 1);
      }, speed);
      return () => clearTimeout(timeout);
    }
  }, [currentIndex, text, speed]);

  return (
    <span>
      {displayText}
      {currentIndex < text.length && <span className="animate-pulse">▌</span>}
    </span>
  );
}

// Pulsing ring animation
function PulsingRing({ color }: { color: string }) {
  return (
    <div className="relative">
      <div className={cn(
        "absolute inset-0 rounded-full animate-ping opacity-75",
        color
      )} />
      <div className={cn(
        "absolute inset-0 rounded-full animate-pulse",
        color
      )} />
    </div>
  );
}

export function AgentActivityPanel({
  isActive,
  phase,
  currentThought,
  files,
  steps,
  totalEdits,
  linesChanged,
  tokensProcessed,
  pendingCommands = [],
  onCommandApprove,
  onCommandSkip,
  onDismiss,
}: AgentActivityPanelProps) {
  const [isExpanded, setIsExpanded] = useState(true);
  const [showAllFiles, setShowAllFiles] = useState(false);

  const config = phaseConfig[phase];
  const activeFiles = files.filter(f => f.status === 'active');
  const completedFiles = files.filter(f => f.status === 'complete');
  const pendingFiles = files.filter(f => f.status === 'pending');
  
  const completedSteps = steps.filter(s => s.status === 'complete').length;
  const progress = steps.length > 0 ? (completedSteps / steps.length) * 100 : 0;

  const displayFiles = showAllFiles ? files : files.slice(0, 5);
  const pendingApprovals = pendingCommands.filter(c => c.status === 'pending');

  if (!isActive && phase === 'idle') return null;

  return (
    <div className={cn(
      "rounded-lg border overflow-hidden transition-all duration-300",
      phase === 'complete' 
        ? "border-status-success/30 bg-status-success/5" 
        : "border-primary/30 bg-primary/5"
    )}>
      {/* Header */}
      <Collapsible open={isExpanded} onOpenChange={setIsExpanded}>
        <CollapsibleTrigger className="w-full">
          <div className="flex items-center justify-between p-3 hover:bg-secondary/50 transition-colors">
            <div className="flex items-center gap-3">
              {/* Animated status indicator */}
              <div className="relative h-8 w-8 flex items-center justify-center">
                {phase !== 'idle' && phase !== 'complete' && (
                  <>
                    <div className="absolute inset-0 rounded-full bg-primary/20 animate-ping" />
                    <div className="absolute inset-1 rounded-full bg-primary/30 animate-pulse" />
                  </>
                )}
                <div className={cn(
                  "relative z-10 h-6 w-6 rounded-full flex items-center justify-center",
                  phase === 'complete' ? "bg-status-success/20" : "bg-primary/20"
                )}>
                  <span className={config.color}>{config.icon}</span>
                </div>
              </div>

              <div className="text-left">
                <div className="flex items-center gap-2">
                  <span className={cn("font-medium text-sm", config.color)}>
                    {config.label}
                  </span>
                  {phase !== 'idle' && phase !== 'complete' && (
                    <Badge variant="outline" className="text-[10px] px-1.5 py-0 h-4 bg-primary/10 border-primary/30">
                      <Loader2 className="h-2.5 w-2.5 mr-1 animate-spin" />
                      Active
                    </Badge>
                  )}
                </div>
                {currentThought && (
                  <p className="text-xs text-muted-foreground max-w-[300px] truncate">
                    {currentThought}
                  </p>
                )}
              </div>
            </div>

            <div className="flex items-center gap-3">
              {/* Stats badges */}
              <div className="hidden sm:flex items-center gap-2">
                {totalEdits > 0 && (
                  <Badge variant="secondary" className="text-[10px] gap-1">
                    <FileEdit className="h-3 w-3" />
                    {totalEdits} edits
                  </Badge>
                )}
                {files.length > 0 && (
                  <Badge variant="secondary" className="text-[10px] gap-1">
                    <FolderSearch className="h-3 w-3" />
                    {files.length} files
                  </Badge>
                )}
              </div>
              
              {isExpanded ? (
                <ChevronUp className="h-4 w-4 text-muted-foreground" />
              ) : (
                <ChevronDown className="h-4 w-4 text-muted-foreground" />
              )}
            </div>
          </div>
        </CollapsibleTrigger>

        <CollapsibleContent>
          <div className="px-3 pb-3 space-y-3">
            {/* Progress bar */}
            {steps.length > 0 && (
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                  <span>Progress</span>
                  <span>{completedSteps}/{steps.length} steps</span>
                </div>
                <Progress value={progress} className="h-1.5" />
              </div>
            )}

            {/* Current thought with typing animation */}
            {currentThought && phase !== 'complete' && (
              <div className="p-2 rounded-md bg-secondary/50 border border-border/50">
                <div className="flex items-start gap-2">
                  <Brain className="h-4 w-4 text-purple-400 mt-0.5 flex-shrink-0" />
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    <TypedText text={currentThought} speed={20} />
                  </p>
                </div>
              </div>
            )}

            {/* Active file operations */}
            {activeFiles.length > 0 && (
              <div className="space-y-1.5">
                <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
                  Currently working on
                </span>
                {activeFiles.map((file) => (
                  <div
                    key={file.id}
                    className={cn(
                      "flex items-center gap-2 p-2 rounded-md border animate-pulse",
                      actionColors[file.action],
                      "border-current/30"
                    )}
                  >
                    <span className="flex-shrink-0">{actionIcons[file.action]}</span>
                    <span className="text-xs font-mono truncate flex-1">{file.path}</span>
                    <Loader2 className="h-3 w-3 animate-spin flex-shrink-0" />
                  </div>
                ))}
              </div>
            )}

            {/* File activity list */}
            {files.length > 0 && (
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
                    File activity
                  </span>
                  {files.length > 5 && (
                    <button
                      onClick={() => setShowAllFiles(!showAllFiles)}
                      className="text-[10px] text-primary hover:underline"
                    >
                      {showAllFiles ? 'Show less' : `+${files.length - 5} more`}
                    </button>
                  )}
                </div>
                <div className="space-y-1 max-h-32 overflow-y-auto">
                  {displayFiles.map((file, index) => (
                    <div
                      key={file.id}
                      className={cn(
                        "flex items-center gap-2 px-2 py-1.5 rounded text-xs transition-all",
                        file.status === 'complete' && "bg-secondary/30",
                        file.status === 'active' && "bg-primary/10",
                        file.status === 'pending' && "opacity-50"
                      )}
                      style={{
                        animationDelay: `${index * 50}ms`,
                      }}
                    >
                      <span className={cn(
                        "flex-shrink-0 p-1 rounded",
                        actionColors[file.action]
                      )}>
                        {actionIcons[file.action]}
                      </span>
                      <span className="font-mono truncate flex-1 text-muted-foreground">
                        {file.path}
                      </span>
                      {file.changes !== undefined && file.changes > 0 && (
                        <Badge variant="outline" className="text-[9px] px-1 py-0 h-4">
                          +{file.changes}
                        </Badge>
                      )}
                      {file.status === 'complete' && (
                        <CheckCircle2 className="h-3 w-3 text-status-success flex-shrink-0" />
                      )}
                      {file.status === 'active' && (
                        <Loader2 className="h-3 w-3 animate-spin text-primary flex-shrink-0" />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Pending Command Approvals - Inline */}
            {pendingApprovals.length > 0 && (
              <div className="space-y-2">
                <span className="text-[10px] uppercase tracking-wider text-yellow-400 flex items-center gap-1">
                  <Shield className="h-3 w-3" />
                  Approval Required
                </span>
                {pendingApprovals.map((cmd) => (
                  <div
                    key={cmd.id}
                    className="p-3 rounded-lg bg-yellow-400/10 border border-yellow-400/30 animate-pulse"
                  >
                    <div className="flex items-start gap-2 mb-2">
                      <Terminal className="h-4 w-4 text-yellow-400 flex-shrink-0 mt-0.5" />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-medium text-yellow-400">
                            {cmd.type.replace('_', ' ').charAt(0).toUpperCase() + cmd.type.slice(1)} Command
                          </span>
                          <Badge 
                            variant="outline" 
                            className={cn("text-[9px] uppercase border", riskColors[cmd.risk])}
                          >
                            {cmd.risk} risk
                          </Badge>
                        </div>
                        <code className="text-xs font-mono text-foreground mt-1 block bg-terminal p-2 rounded truncate">
                          {cmd.command}
                        </code>
                        {cmd.description && (
                          <p className="text-[10px] text-muted-foreground mt-1">{cmd.description}</p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 justify-end">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => onCommandSkip?.(cmd.id)}
                        className="h-7 text-[10px] gap-1 text-muted-foreground"
                      >
                        <X className="h-3 w-3" />
                        Skip
                      </Button>
                      <Button
                        variant="secondary"
                        size="sm"
                        onClick={() => onCommandApprove?.(cmd.id, 'always_allow')}
                        className="h-7 text-[10px] gap-1"
                      >
                        <Shield className="h-3 w-3" />
                        Always Allow
                      </Button>
                      <Button
                        variant="ai"
                        size="sm"
                        onClick={() => onCommandApprove?.(cmd.id, 'allow')}
                        className="h-7 text-[10px] gap-1"
                      >
                        <Play className="h-3 w-3" />
                        Allow
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Steps */}
            {steps.length > 0 && (
              <div className="space-y-1.5">
                <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
                  Steps
                </span>
                <div className="space-y-1">
                  {steps.map((step, index) => (
                    <div
                      key={step.id}
                      className={cn(
                        "flex items-center gap-2 px-2 py-1.5 rounded text-xs",
                        step.status === 'complete' && "text-muted-foreground",
                        step.status === 'active' && "bg-primary/10 text-foreground",
                        step.status === 'pending' && "text-muted-foreground/50",
                        step.status === 'skipped' && "text-muted-foreground/30 line-through"
                      )}
                    >
                      <span className="w-5 h-5 flex items-center justify-center flex-shrink-0">
                        {step.status === 'complete' && (
                          <CheckCircle2 className="h-4 w-4 text-status-success" />
                        )}
                        {step.status === 'active' && (
                          <Loader2 className="h-4 w-4 animate-spin text-primary" />
                        )}
                        {step.status === 'pending' && (
                          <span className="w-2 h-2 rounded-full bg-muted-foreground/30" />
                        )}
                        {step.status === 'skipped' && (
                          <span className="text-muted-foreground/50">—</span>
                        )}
                      </span>
                      <span className="flex-1">{step.label}</span>
                      {step.duration && (
                        <span className="text-[10px] text-muted-foreground">
                          {step.duration}ms
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Stats footer */}
            <div className="flex items-center justify-between pt-2 border-t border-border/50 text-[10px] text-muted-foreground">
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1">
                  <Zap className="h-3 w-3" />
                  {tokensProcessed.toLocaleString()} tokens
                </span>
                {linesChanged > 0 && (
                  <span className="flex items-center gap-1">
                    <FileCode className="h-3 w-3" />
                    {linesChanged} lines
                  </span>
                )}
              </div>
              {phase === 'complete' && (
                <span className="text-status-success flex items-center gap-1">
                  <CheckCircle2 className="h-3 w-3" />
                  Done
                </span>
              )}
            </div>
          </div>
        </CollapsibleContent>
      </Collapsible>
    </div>
  );
}

// Hook to simulate agent activity (for demo/testing)
export function useAgentActivitySimulation() {
  const [isActive, setIsActive] = useState(false);
  const [phase, setPhase] = useState<AgentPhase>('idle');
  const [currentThought, setCurrentThought] = useState('');
  const [files, setFiles] = useState<FileActivity[]>([]);
  const [steps, setSteps] = useState<AgentStep[]>([]);
  const [totalEdits, setTotalEdits] = useState(0);
  const [linesChanged, setLinesChanged] = useState(0);
  const [tokensProcessed, setTokensProcessed] = useState(0);

  const simulateActivity = useCallback((taskDescription: string) => {
    setIsActive(true);
    setPhase('thinking');
    setCurrentThought(`Understanding request: "${taskDescription.substring(0, 50)}..."`);
    setFiles([]);
    setSteps([]);
    setTotalEdits(0);
    setLinesChanged(0);
    setTokensProcessed(0);

    // Simulated file operations
    const mockFiles = [
      'src/components/Button.tsx',
      'src/hooks/useAuth.ts',
      'src/pages/Dashboard.tsx',
      'src/lib/utils.ts',
      'src/types/index.ts',
    ];

    const mockSteps: AgentStep[] = [
      { id: '1', label: 'Analyze request', status: 'pending' },
      { id: '2', label: 'Search codebase', status: 'pending' },
      { id: '3', label: 'Plan changes', status: 'pending' },
      { id: '4', label: 'Implement solution', status: 'pending' },
      { id: '5', label: 'Review & verify', status: 'pending' },
    ];

    setSteps(mockSteps);

    // Simulate progression
    const timeline = [
      { delay: 500, action: () => setPhase('reading') },
      { delay: 1000, action: () => setCurrentThought('Scanning project structure...') },
      { delay: 1500, action: () => {
        setFiles([{ id: '1', path: mockFiles[0], action: 'read', status: 'active', timestamp: new Date() }]);
        setSteps(s => s.map((step, i) => ({ ...step, status: i === 0 ? 'active' : step.status })));
        setTokensProcessed(p => p + 1250);
      }},
      { delay: 2500, action: () => {
        setFiles(f => [
          { ...f[0], status: 'complete' },
          { id: '2', path: mockFiles[1], action: 'read', status: 'active', timestamp: new Date() },
        ]);
        setTokensProcessed(p => p + 890);
      }},
      { delay: 3500, action: () => {
        setPhase('analyzing');
        setCurrentThought('Analyzing code patterns and dependencies...');
        setFiles(f => [
          ...f.map(file => ({ ...file, status: 'complete' as const })),
          { id: '3', path: mockFiles[2], action: 'analyze', status: 'active', timestamp: new Date() },
        ]);
        setSteps(s => s.map((step, i) => ({ ...step, status: i === 0 ? 'complete' : i === 1 ? 'active' : step.status })));
        setTokensProcessed(p => p + 2100);
      }},
      { delay: 4500, action: () => {
        setPhase('planning');
        setCurrentThought('Determining optimal implementation strategy...');
        setFiles(f => f.map(file => ({ ...file, status: 'complete' as const })));
        setSteps(s => s.map((step, i) => ({ ...step, status: i <= 1 ? 'complete' : i === 2 ? 'active' : step.status })));
        setTokensProcessed(p => p + 1500);
      }},
      { delay: 5500, action: () => {
        setPhase('writing');
        setCurrentThought('Implementing changes...');
        setFiles(f => [
          ...f,
          { id: '4', path: mockFiles[0], action: 'write', status: 'active', changes: 12, timestamp: new Date() },
        ]);
        setSteps(s => s.map((step, i) => ({ ...step, status: i <= 2 ? 'complete' : i === 3 ? 'active' : step.status })));
        setTokensProcessed(p => p + 3200);
      }},
      { delay: 7000, action: () => {
        setFiles(f => [
          ...f.map(file => ({ ...file, status: 'complete' as const })),
          { id: '5', path: mockFiles[3], action: 'write', status: 'active', changes: 5, timestamp: new Date() },
        ]);
        setTotalEdits(2);
        setLinesChanged(17);
        setTokensProcessed(p => p + 1800);
      }},
      { delay: 8500, action: () => {
        setPhase('reviewing');
        setCurrentThought('Verifying changes and checking for issues...');
        setFiles(f => f.map(file => ({ ...file, status: 'complete' as const })));
        setSteps(s => s.map((step, i) => ({ ...step, status: i <= 3 ? 'complete' : i === 4 ? 'active' : step.status })));
        setTotalEdits(3);
        setLinesChanged(22);
        setTokensProcessed(p => p + 950);
      }},
      { delay: 10000, action: () => {
        setPhase('complete');
        setCurrentThought('All changes applied successfully');
        setSteps(s => s.map(step => ({ ...step, status: 'complete' })));
        setTokensProcessed(p => p + 200);
      }},
    ];

    timeline.forEach(({ delay, action }) => {
      setTimeout(action, delay);
    });

    // Reset after completion
    setTimeout(() => {
      setIsActive(false);
      setPhase('idle');
    }, 15000);
  }, []);

  const reset = useCallback(() => {
    setIsActive(false);
    setPhase('idle');
    setCurrentThought('');
    setFiles([]);
    setSteps([]);
    setTotalEdits(0);
    setLinesChanged(0);
    setTokensProcessed(0);
  }, []);

  return {
    isActive,
    phase,
    currentThought,
    files,
    steps,
    totalEdits,
    linesChanged,
    tokensProcessed,
    simulateActivity,
    reset,
    // Setters for real integration
    setIsActive,
    setPhase,
    setCurrentThought,
    setFiles,
    setSteps,
    setTotalEdits,
    setLinesChanged,
    setTokensProcessed,
  };
}
