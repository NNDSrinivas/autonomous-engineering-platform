import { useApprovalGate, ApprovalSettings } from '@/hooks/useApprovalGate';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { 
  Shield, 
  GitBranch, 
  Play, 
  MessageSquare, 
  FileText,
  AlertTriangle,
  Info
} from 'lucide-react';
import { cn } from '@/lib/utils';

export function ApprovalSettingsPanel() {
  const { settings, updateSettings } = useApprovalGate();

  const handleGlobalToggle = (checked: boolean) => {
    updateSettings({ requireApprovalForAllWrites: checked });
  };

  const handleGitHubToggle = (key: keyof ApprovalSettings['github'], checked: boolean) => {
    updateSettings({
      github: { ...settings.github, [key]: checked }
    });
  };

  const handleCICDToggle = (key: keyof ApprovalSettings['cicd'], checked: boolean) => {
    updateSettings({
      cicd: { ...settings.cicd, [key]: checked }
    });
  };

  const handleSlackToggle = (key: keyof ApprovalSettings['slack'], checked: boolean) => {
    updateSettings({
      slack: { ...settings.slack, [key]: checked }
    });
  };

  const handleConfluenceToggle = (key: keyof ApprovalSettings['confluence'], checked: boolean) => {
    updateSettings({
      confluence: { ...settings.confluence, [key]: checked }
    });
  };

  const handleJiraToggle = (key: keyof ApprovalSettings['jira'], checked: boolean) => {
    updateSettings({
      jira: { ...settings.jira, [key]: checked }
    });
  };

  return (
    <div className="space-y-6 p-4">
      <div className="space-y-2">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <Shield className="h-5 w-5 text-primary" />
          Write Action Approvals
        </h2>
        <p className="text-sm text-muted-foreground">
          Configure which actions require explicit approval before NAVI can execute them.
        </p>
      </div>

      {/* Global Setting */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <CardTitle className="text-base flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-status-warning" />
                Require Approval for All Writes
              </CardTitle>
              <CardDescription>
                When enabled, all write operations require your explicit approval
              </CardDescription>
            </div>
            <Switch
              checked={settings.requireApprovalForAllWrites}
              onCheckedChange={handleGlobalToggle}
            />
          </div>
        </CardHeader>
      </Card>

      <Separator />

      {/* GitHub Settings */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <GitBranch className="h-4 w-4 text-github-gray" />
            GitHub
          </CardTitle>
          <CardDescription>
            Branch creation, pull requests, and file commits
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <Label htmlFor="github-approval" className="text-sm">
              Require approval for GitHub actions
            </Label>
            <Switch
              id="github-approval"
              checked={settings.github.requireApproval}
              onCheckedChange={(checked) => handleGitHubToggle('requireApproval', checked)}
              disabled={settings.requireApprovalForAllWrites}
            />
          </div>
        </CardContent>
      </Card>

      {/* CI/CD Settings */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <Play className="h-4 w-4 text-cicd-orange" />
            CI/CD Pipelines
          </CardTitle>
          <CardDescription>
            Workflow runs, deployments, and pipeline management
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <Label htmlFor="cicd-approval" className="text-sm">
              Require approval for CI/CD actions
            </Label>
            <Switch
              id="cicd-approval"
              checked={settings.cicd.requireApproval}
              onCheckedChange={(checked) => handleCICDToggle('requireApproval', checked)}
              disabled={settings.requireApprovalForAllWrites}
            />
          </div>
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="cicd-rerun" className="text-sm">
                Auto-approve workflow re-runs
              </Label>
              <p className="text-xs text-muted-foreground">
                Skip approval for re-running failed workflows
              </p>
            </div>
            <Switch
              id="cicd-rerun"
              checked={settings.cicd.autoApproveRerun}
              onCheckedChange={(checked) => handleCICDToggle('autoApproveRerun', checked)}
              disabled={settings.requireApprovalForAllWrites}
            />
          </div>
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="cicd-deploy" className="text-sm flex items-center gap-2">
                Require approval for deployments
                <Badge variant="outline" className="text-[10px] bg-status-error/10 text-status-error">
                  High Risk
                </Badge>
              </Label>
            </div>
            <Switch
              id="cicd-deploy"
              checked={settings.cicd.requireApprovalForDeploy}
              onCheckedChange={(checked) => handleCICDToggle('requireApprovalForDeploy', checked)}
            />
          </div>
        </CardContent>
      </Card>

      {/* Slack Settings */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <MessageSquare className="h-4 w-4 text-slack-purple" />
            Slack
            <Badge variant="outline" className="text-[10px]">Read-Only by Default</Badge>
          </CardTitle>
          <CardDescription>
            Message drafting and channel interactions
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-start gap-2 p-3 rounded-lg bg-muted/50 border">
            <Info className="h-4 w-4 text-muted-foreground flex-shrink-0 mt-0.5" />
            <p className="text-xs text-muted-foreground">
              NAVI can read Slack channels and draft messages, but will not send messages directly. 
              You can copy drafts and send them yourself.
            </p>
          </div>
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="slack-draft" className="text-sm">
                Draft-only mode
              </Label>
              <p className="text-xs text-muted-foreground">
                NAVI drafts messages but never sends them
              </p>
            </div>
            <Switch
              id="slack-draft"
              checked={settings.slack.draftOnly}
              onCheckedChange={(checked) => handleSlackToggle('draftOnly', checked)}
            />
          </div>
          {!settings.slack.draftOnly && (
            <div className="flex items-center justify-between">
              <Label htmlFor="slack-approval" className="text-sm">
                Require approval to send messages
              </Label>
              <Switch
                id="slack-approval"
                checked={settings.slack.requireApproval}
                onCheckedChange={(checked) => handleSlackToggle('requireApproval', checked)}
                disabled={settings.requireApprovalForAllWrites}
              />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Confluence Settings */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <FileText className="h-4 w-4 text-confluence-blue" />
            Confluence
            <Badge variant="outline" className="text-[10px]">Read-Only by Default</Badge>
          </CardTitle>
          <CardDescription>
            Documentation and wiki page management
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-start gap-2 p-3 rounded-lg bg-muted/50 border">
            <Info className="h-4 w-4 text-muted-foreground flex-shrink-0 mt-0.5" />
            <p className="text-xs text-muted-foreground">
              NAVI can read Confluence pages and draft content, but will not create or update pages directly.
            </p>
          </div>
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="confluence-draft" className="text-sm">
                Draft-only mode
              </Label>
              <p className="text-xs text-muted-foreground">
                NAVI drafts content but never creates/updates pages
              </p>
            </div>
            <Switch
              id="confluence-draft"
              checked={settings.confluence.draftOnly}
              onCheckedChange={(checked) => handleConfluenceToggle('draftOnly', checked)}
            />
          </div>
          {!settings.confluence.draftOnly && (
            <div className="flex items-center justify-between">
              <Label htmlFor="confluence-approval" className="text-sm">
                Require approval to create/update pages
              </Label>
              <Switch
                id="confluence-approval"
                checked={settings.confluence.requireApproval}
                onCheckedChange={(checked) => handleConfluenceToggle('requireApproval', checked)}
                disabled={settings.requireApprovalForAllWrites}
              />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Jira Settings */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <svg className="h-4 w-4 text-jira-blue" viewBox="0 0 24 24" fill="currentColor">
              <path d="M11.571 11.429L0 23h11.571V11.429zM11.571 0v11.571H0L11.571 0zM12.429 12.429L24 0H12.429v12.429zM12.429 24V12.429H24L12.429 24z" />
            </svg>
            Jira
          </CardTitle>
          <CardDescription>
            Issue updates, comments, and linking
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <Label htmlFor="jira-approval" className="text-sm">
              Require approval for Jira actions
            </Label>
            <Switch
              id="jira-approval"
              checked={settings.jira.requireApproval}
              onCheckedChange={(checked) => handleJiraToggle('requireApproval', checked)}
              disabled={settings.requireApprovalForAllWrites}
            />
          </div>
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="jira-comments" className="text-sm">
                Auto-approve adding comments
              </Label>
              <p className="text-xs text-muted-foreground">
                Allow NAVI to add comments without approval
              </p>
            </div>
            <Switch
              id="jira-comments"
              checked={settings.jira.autoApproveComments}
              onCheckedChange={(checked) => handleJiraToggle('autoApproveComments', checked)}
              disabled={settings.requireApprovalForAllWrites}
            />
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
