import { useEffect, useRef, useState } from 'react';
import { cn } from '@/lib/utils';

interface AudioWaveformProps {
  isActive: boolean;
  className?: string;
}

export function AudioWaveform({ isActive, className }: AudioWaveformProps) {
  const [audioLevels, setAudioLevels] = useState<number[]>(Array(12).fill(0.2));
  const analyserRef = useRef<AnalyserNode | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    if (isActive) {
      startAudioAnalysis();
    } else {
      stopAudioAnalysis();
    }

    return () => {
      stopAudioAnalysis();
    };
  }, [isActive]);

  const startAudioAnalysis = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      
      const audioContext = new AudioContext();
      audioContextRef.current = audioContext;
      
      const analyser = audioContext.createAnalyser();
      analyser.fftSize = 32;
      analyser.smoothingTimeConstant = 0.8;
      analyserRef.current = analyser;
      
      const source = audioContext.createMediaStreamSource(stream);
      source.connect(analyser);
      
      updateWaveform();
    } catch (error) {
      console.error('Failed to access microphone for visualization:', error);
      // Fallback to simulated animation
      simulateWaveform();
    }
  };

  const stopAudioAnalysis = () => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
    
    analyserRef.current = null;
    setAudioLevels(Array(12).fill(0.2));
  };

  const updateWaveform = () => {
    if (!analyserRef.current || !isActive) return;
    
    const dataArray = new Uint8Array(analyserRef.current.frequencyBinCount);
    analyserRef.current.getByteFrequencyData(dataArray);
    
    // Map frequency data to our 12 bars
    const levels: number[] = [];
    const step = Math.floor(dataArray.length / 12);
    
    for (let i = 0; i < 12; i++) {
      const value = dataArray[i * step] / 255;
      // Add minimum height and smooth the values
      levels.push(Math.max(0.15, value * 0.85 + 0.15));
    }
    
    setAudioLevels(levels);
    animationFrameRef.current = requestAnimationFrame(updateWaveform);
  };

  const simulateWaveform = () => {
    const animate = () => {
      if (!isActive) return;
      
      const levels = Array(12).fill(0).map((_, i) => {
        const time = Date.now() / 150;
        const wave = Math.sin(time + i * 0.5) * 0.3 + 0.5;
        const noise = Math.random() * 0.2;
        return Math.min(1, Math.max(0.15, wave + noise));
      });
      
      setAudioLevels(levels);
      animationFrameRef.current = requestAnimationFrame(animate);
    };
    
    animate();
  };

  if (!isActive) return null;

  return (
    <div className={cn("flex items-center gap-0.5 h-6", className)}>
      {audioLevels.map((level, index) => (
        <div
          key={index}
          className="w-1 rounded-full bg-primary transition-all duration-75"
          style={{
            height: `${level * 100}%`,
            opacity: 0.6 + level * 0.4,
          }}
        />
      ))}
    </div>
  );
}
