import { useState } from 'react';
import {
  Shield,
  ShieldCheck,
  ShieldAlert,
  ShieldOff,
  Play,
  GitBranch,
  Code,
  GitPullRequest,
  Link,
  MessageSquare,
  RotateCcw,
  Bell,
  Pause,
  Timer,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import type { CheckpointConfig, CheckpointLevel } from '@/hooks/useAutonomousWorkflow';
import type { WorkflowPhase } from '@/hooks/useEndToEndWorkflow';

const CHECKPOINT_LEVELS: { value: CheckpointLevel; label: string; icon: React.ReactNode; description: string }[] = [
  { 
    value: 'all', 
    label: 'Maximum Control', 
    icon: <ShieldCheck className="h-4 w-4" />,
    description: 'Approval required for every step'
  },
  { 
    value: 'high_risk', 
    label: 'Balanced (Recommended)', 
    icon: <Shield className="h-4 w-4" />,
    description: 'Approval for high-risk operations only'
  },
  { 
    value: 'critical_only', 
    label: 'Minimal', 
    icon: <ShieldAlert className="h-4 w-4" />,
    description: 'Only critical operations require approval'
  },
  { 
    value: 'none', 
    label: 'Fully Autonomous', 
    icon: <ShieldOff className="h-4 w-4" />,
    description: 'No approvals - fully automated'
  },
];

const PHASE_CONFIG: { phase: WorkflowPhase; label: string; icon: React.ReactNode; risk: string }[] = [
  { phase: 'start_task', label: 'Start Task', icon: <Play className="h-4 w-4" />, risk: 'low' },
  { phase: 'create_branch', label: 'Create Branch', icon: <GitBranch className="h-4 w-4" />, risk: 'low' },
  { phase: 'implement_code', label: 'Implement Code', icon: <Code className="h-4 w-4" />, risk: 'high' },
  { phase: 'create_pr', label: 'Create PR', icon: <GitPullRequest className="h-4 w-4" />, risk: 'high' },
  { phase: 'link_jira', label: 'Link Jira', icon: <Link className="h-4 w-4" />, risk: 'medium' },
  { phase: 'post_slack', label: 'Post to Slack', icon: <MessageSquare className="h-4 w-4" />, risk: 'low' },
];

interface AutonomousCheckpointConfigProps {
  config: CheckpointConfig;
  onConfigChange: (updates: Partial<CheckpointConfig>) => void;
  onPhaseToggle: (phase: WorkflowPhase, enabled: boolean) => void;
  className?: string;
}

export function AutonomousCheckpointConfig({
  config,
  onConfigChange,
  onPhaseToggle,
  className,
}: AutonomousCheckpointConfigProps) {
  const [showAdvanced, setShowAdvanced] = useState(false);

  const getRiskBadgeColor = (risk: string) => {
    switch (risk) {
      case 'low':
        return 'bg-status-success/20 text-status-success border-status-success/30';
      case 'medium':
        return 'bg-status-warning/20 text-status-warning border-status-warning/30';
      case 'high':
        return 'bg-status-error/20 text-status-error border-status-error/30';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <Card className={cn("border-border/50", className)}>
      <CardHeader className="pb-4">
        <CardTitle className="text-lg flex items-center gap-2">
          <Shield className="h-5 w-5 text-primary" />
          Checkpoint Configuration
        </CardTitle>
        <CardDescription>
          Configure when NAVI pauses for your approval during autonomous execution
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Checkpoint Level Selection */}
        <div className="space-y-3">
          <Label className="text-sm font-medium">Approval Level</Label>
          <Select
            value={config.level}
            onValueChange={(value: CheckpointLevel) => onConfigChange({ level: value })}
          >
            <SelectTrigger className="w-full">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {CHECKPOINT_LEVELS.map((level) => (
                <SelectItem key={level.value} value={level.value}>
                  <div className="flex items-center gap-2">
                    {level.icon}
                    <span>{level.label}</span>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <p className="text-xs text-muted-foreground">
            {CHECKPOINT_LEVELS.find(l => l.value === config.level)?.description}
          </p>
        </div>

        <Separator />

        {/* Per-Phase Checkpoints */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label className="text-sm font-medium">Phase Checkpoints</Label>
            <Badge variant="outline" className="text-[10px]">
              {config.level === 'none' ? 'Disabled' : 'Active'}
            </Badge>
          </div>
          
          <div className="space-y-2">
            {PHASE_CONFIG.map(({ phase, label, icon, risk }) => (
              <div
                key={phase}
                className={cn(
                  "flex items-center justify-between p-3 rounded-lg border border-border/50",
                  config.level === 'none' && "opacity-50 pointer-events-none"
                )}
              >
                <div className="flex items-center gap-3">
                  <div className="h-8 w-8 rounded-full bg-secondary flex items-center justify-center">
                    {icon}
                  </div>
                  <div>
                    <span className="text-sm font-medium">{label}</span>
                    <Badge 
                      variant="outline" 
                      className={cn("ml-2 text-[9px] uppercase", getRiskBadgeColor(risk))}
                    >
                      {risk}
                    </Badge>
                  </div>
                </div>
                <Switch
                  checked={config.phases[phase] ?? false}
                  onCheckedChange={(checked) => onPhaseToggle(phase, checked)}
                  disabled={config.level === 'none' || config.level === 'all'}
                />
              </div>
            ))}
          </div>
        </div>

        <Separator />

        {/* Advanced Settings Toggle */}
        <Button
          variant="ghost"
          className="w-full justify-between"
          onClick={() => setShowAdvanced(!showAdvanced)}
        >
          <span className="text-sm">Advanced Settings</span>
          <Badge variant="secondary" className="text-[10px]">
            {showAdvanced ? 'Hide' : 'Show'}
          </Badge>
        </Button>

        {showAdvanced && (
          <div className="space-y-4 pt-2">
            {/* Auto-Retry */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <RotateCcw className="h-4 w-4 text-muted-foreground" />
                <div>
                  <Label className="text-sm font-medium">Auto-Retry on Failure</Label>
                  <p className="text-xs text-muted-foreground">Automatically retry failed phases</p>
                </div>
              </div>
              <Switch
                checked={config.autoRetryOnFailure}
                onCheckedChange={(checked) => onConfigChange({ autoRetryOnFailure: checked })}
              />
            </div>

            {/* Max Retries */}
            {config.autoRetryOnFailure && (
              <div className="space-y-2 pl-7">
                <Label className="text-sm">Max Retries: {config.maxRetries}</Label>
                <Slider
                  value={[config.maxRetries]}
                  onValueChange={([value]) => onConfigChange({ maxRetries: value })}
                  min={1}
                  max={5}
                  step={1}
                  className="w-full"
                />
              </div>
            )}

            {/* Pause on Error */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Pause className="h-4 w-4 text-muted-foreground" />
                <div>
                  <Label className="text-sm font-medium">Pause on Error</Label>
                  <p className="text-xs text-muted-foreground">Stop execution when an error occurs</p>
                </div>
              </div>
              <Switch
                checked={config.pauseOnError}
                onCheckedChange={(checked) => onConfigChange({ pauseOnError: checked })}
              />
            </div>

            {/* Notify on Completion */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Bell className="h-4 w-4 text-muted-foreground" />
                <div>
                  <Label className="text-sm font-medium">Notify on Completion</Label>
                  <p className="text-xs text-muted-foreground">Show notification when workflow completes</p>
                </div>
              </div>
              <Switch
                checked={config.notifyOnCompletion}
                onCheckedChange={(checked) => onConfigChange({ notifyOnCompletion: checked })}
              />
            </div>

            {/* Timeout */}
            <div className="space-y-2">
              <div className="flex items-center gap-3">
                <Timer className="h-4 w-4 text-muted-foreground" />
                <div>
                  <Label className="text-sm font-medium">Phase Timeout: {config.timeout}s</Label>
                  <p className="text-xs text-muted-foreground">Maximum time per phase before timeout</p>
                </div>
              </div>
              <Slider
                value={[config.timeout]}
                onValueChange={([value]) => onConfigChange({ timeout: value })}
                min={30}
                max={600}
                step={30}
                className="w-full"
              />
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
