import { useState } from 'react';
import {
  Bot,
  Play,
  Pause,
  Square,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Clock,
  Loader2,
  GitBranch,
  Code,
  GitPullRequest,
  Link,
  MessageSquare,
  Settings2,
  ChevronRight,
  ChevronDown,
  Zap,
  SkipForward,
  RefreshCw,
  FileCode,
  Eye,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { Separator } from '@/components/ui/separator';
import { useAutonomousWorkflow } from '@/hooks/useAutonomousWorkflow';
import { AutonomousCheckpointConfig } from './AutonomousCheckpointConfig';
import { cn } from '@/lib/utils';
import type { JiraTask } from '@/types';
import type { WorkflowPhase } from '@/hooks/useEndToEndWorkflow';

const phaseIcons: Record<WorkflowPhase, React.ReactNode> = {
  idle: <Clock className="h-4 w-4" />,
  start_task: <Play className="h-4 w-4" />,
  create_branch: <GitBranch className="h-4 w-4" />,
  implement_code: <Code className="h-4 w-4" />,
  create_pr: <GitPullRequest className="h-4 w-4" />,
  link_jira: <Link className="h-4 w-4" />,
  post_slack: <MessageSquare className="h-4 w-4" />,
  completed: <CheckCircle2 className="h-4 w-4" />,
  failed: <XCircle className="h-4 w-4" />,
};

const phaseOrder: WorkflowPhase[] = [
  'start_task',
  'create_branch',
  'implement_code',
  'create_pr',
  'link_jira',
  'post_slack',
];

interface GeneratedFile {
  path: string;
  content: string;
  action: 'create' | 'modify' | 'delete';
}

interface AutonomousWorkflowPanelProps {
  task: JiraTask;
  owner?: string;
  repo?: string;
  onClose?: () => void;
  className?: string;
  onPreviewCode?: (files: GeneratedFile[], branchName: string) => void;
}

export function AutonomousWorkflowPanel({
  task,
  owner = 'organization',
  repo = 'repository',
  onClose,
  className,
  onPreviewCode,
}: AutonomousWorkflowPanelProps) {
  const [showConfig, setShowConfig] = useState(false);
  const [checkpointDialogOpen, setCheckpointDialogOpen] = useState(false);
  const [logsExpanded, setLogsExpanded] = useState(true);

  const {
    config,
    executionState,
    workflowState,
    startAutonomousExecution,
    pauseExecution,
    resumeExecution,
    cancelExecution,
    resumeFromCheckpoint,
    skipCheckpoint,
    updateConfig,
    togglePhaseCheckpoint,
    requiresCheckpoint,
    getPhaseInfo,
  } = useAutonomousWorkflow({
    owner,
    repo,
    onCheckpointReached: () => setCheckpointDialogOpen(true),
  });

  // Calculate progress
  const currentPhaseIndex = phaseOrder.indexOf(workflowState.currentPhase);
  const progress = workflowState.currentPhase === 'completed'
    ? 100
    : workflowState.currentPhase === 'failed' || workflowState.currentPhase === 'idle'
    ? 0
    : ((currentPhaseIndex + 1) / phaseOrder.length) * 100;

  // Get phase status
  const getPhaseStatus = (phase: WorkflowPhase) => {
    const phaseIdx = phaseOrder.indexOf(phase);
    const currentIdx = phaseOrder.indexOf(workflowState.currentPhase);

    if (workflowState.currentPhase === 'completed') return 'completed';
    if (workflowState.currentPhase === 'failed') {
      if (phaseIdx <= currentIdx) return 'failed';
      return 'pending';
    }
    if (executionState.skippedPhases.includes(phase)) return 'skipped';
    if (phaseIdx < currentIdx) return 'completed';
    if (phaseIdx === currentIdx) {
      if (executionState.isPaused) return 'paused';
      if (workflowState.awaitingApproval) return 'checkpoint';
      return 'executing';
    }
    return 'pending';
  };

  const handleStart = () => {
    startAutonomousExecution(task);
  };

  const handleCheckpointApprove = () => {
    setCheckpointDialogOpen(false);
    resumeFromCheckpoint();
  };

  const handleCheckpointSkip = () => {
    setCheckpointDialogOpen(false);
    skipCheckpoint();
  };

  const getLogIcon = (type: string) => {
    switch (type) {
      case 'success':
        return <CheckCircle2 className="h-3 w-3 text-status-success" />;
      case 'error':
        return <XCircle className="h-3 w-3 text-status-error" />;
      case 'warning':
        return <AlertTriangle className="h-3 w-3 text-status-warning" />;
      default:
        return <Clock className="h-3 w-3 text-muted-foreground" />;
    }
  };

  return (
    <>
      <Card className={cn("border-border/50", className)}>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg flex items-center gap-2">
                <Bot className="h-5 w-5 text-primary" />
                Autonomous Mode
                {executionState.isRunning && (
                  <Badge className="ml-2 text-[10px] bg-primary/20 text-primary border-primary/30 animate-pulse">
                    RUNNING
                  </Badge>
                )}
              </CardTitle>
              <CardDescription className="mt-1">
                {task.key}: {task.title}
              </CardDescription>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowConfig(!showConfig)}
            >
              <Settings2 className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>

        <CardContent className="space-y-4">
          {/* Config Panel (Collapsible) */}
          {showConfig && (
            <AutonomousCheckpointConfig
              config={config}
              onConfigChange={updateConfig}
              onPhaseToggle={togglePhaseCheckpoint}
              className="mb-4"
            />
          )}

          {/* Progress */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-2">
                <span className="text-muted-foreground">Progress</span>
                {executionState.isPaused && (
                  <Badge variant="outline" className="text-[9px] bg-status-warning/20 text-status-warning">
                    PAUSED
                  </Badge>
                )}
              </div>
              <span className="font-medium">{Math.round(progress)}%</span>
            </div>
            <Progress value={progress} className="h-2" />
            {executionState.estimatedCompletion && executionState.isRunning && (
              <p className="text-xs text-muted-foreground">
                Est. completion: {executionState.estimatedCompletion.toLocaleTimeString()}
              </p>
            )}
          </div>

          {/* Phase Status */}
          <div className="grid grid-cols-6 gap-1">
            {phaseOrder.map((phase) => {
              const status = getPhaseStatus(phase);
              const isCheckpoint = requiresCheckpoint(phase);
              
              return (
                <div
                  key={phase}
                  className={cn(
                    "relative p-2 rounded text-center transition-all",
                    status === 'completed' && 'bg-status-success/20',
                    status === 'executing' && 'bg-primary/20',
                    status === 'checkpoint' && 'bg-status-warning/20',
                    status === 'paused' && 'bg-muted',
                    status === 'failed' && 'bg-status-error/20',
                    status === 'skipped' && 'bg-muted/50',
                    status === 'pending' && 'bg-secondary/50',
                  )}
                >
                  <div className={cn(
                    "mx-auto h-6 w-6 rounded-full flex items-center justify-center",
                    status === 'completed' && 'bg-status-success/30 text-status-success',
                    status === 'executing' && 'bg-primary/30 text-primary',
                    status === 'checkpoint' && 'bg-status-warning/30 text-status-warning',
                    status === 'paused' && 'bg-muted-foreground/30 text-muted-foreground',
                    status === 'failed' && 'bg-status-error/30 text-status-error',
                    status === 'skipped' && 'bg-muted text-muted-foreground',
                    status === 'pending' && 'bg-secondary text-muted-foreground',
                  )}>
                    {status === 'executing' ? (
                      <Loader2 className="h-3 w-3 animate-spin" />
                    ) : status === 'checkpoint' ? (
                      <AlertTriangle className="h-3 w-3" />
                    ) : (
                      phaseIcons[phase]
                    )}
                  </div>
                  {isCheckpoint && status === 'pending' && (
                    <div className="absolute -top-1 -right-1 h-2 w-2 rounded-full bg-status-warning" />
                  )}
                  <p className="text-[9px] text-muted-foreground mt-1 truncate">
                    {getPhaseInfo(phase).label.split(' ')[0]}
                  </p>
                </div>
              );
            })}
          </div>

          <Separator />

          {/* Execution Logs */}
          <Collapsible open={logsExpanded} onOpenChange={setLogsExpanded}>
            <CollapsibleTrigger className="flex items-center justify-between w-full py-2">
              <span className="text-sm font-medium">Execution Logs</span>
              {logsExpanded ? (
                <ChevronDown className="h-4 w-4 text-muted-foreground" />
              ) : (
                <ChevronRight className="h-4 w-4 text-muted-foreground" />
              )}
            </CollapsibleTrigger>
            <CollapsibleContent>
              <ScrollArea className="h-[150px] border border-border rounded-lg p-2">
                {executionState.logs.length === 0 ? (
                  <p className="text-xs text-muted-foreground text-center py-4">
                    No logs yet. Start the workflow to see execution logs.
                  </p>
                ) : (
                  <div className="space-y-1">
                    {executionState.logs.map((log) => (
                      <div key={log.id} className="flex items-start gap-2 text-xs">
                        {getLogIcon(log.type)}
                        <span className="text-muted-foreground">
                          {log.timestamp.toLocaleTimeString()}
                        </span>
                        <span className={cn(
                          log.type === 'error' && 'text-status-error',
                          log.type === 'success' && 'text-status-success',
                          log.type === 'warning' && 'text-status-warning',
                        )}>
                          {log.message}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </CollapsibleContent>
          </Collapsible>

          {/* Generated Files Preview */}
          {workflowState.filesGenerated && workflowState.filesGenerated.length > 0 && (
            <div className="p-3 rounded-lg bg-primary/5 border border-primary/20">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <FileCode className="h-4 w-4 text-primary" />
                  <span className="text-sm font-medium">Generated Files</span>
                  <Badge variant="secondary" className="text-[10px]">
                    {workflowState.filesGenerated.length} files
                  </Badge>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-7 gap-1"
                  onClick={() => onPreviewCode?.(
                    workflowState.filesGenerated as GeneratedFile[],
                    workflowState.branchName || `feature/${task.key.toLowerCase()}`
                  )}
                >
                  <Eye className="h-3 w-3" />
                  Preview
                </Button>
              </div>
            </div>
          )}

          {/* Control Buttons */}
          <div className="flex items-center gap-2 pt-2">
            {!executionState.isRunning && workflowState.currentPhase === 'idle' && (
              <Button onClick={handleStart} className="gap-2 flex-1">
                <Zap className="h-4 w-4" />
                Start Autonomous Workflow
              </Button>
            )}

            {executionState.isRunning && !executionState.isPaused && (
              <>
                <Button onClick={pauseExecution} variant="outline" className="gap-2 flex-1">
                  <Pause className="h-4 w-4" />
                  Pause
                </Button>
                <Button onClick={cancelExecution} variant="destructive" size="icon">
                  <Square className="h-4 w-4" />
                </Button>
              </>
            )}

            {executionState.isRunning && executionState.isPaused && !workflowState.awaitingApproval && (
              <>
                <Button onClick={resumeExecution} className="gap-2 flex-1">
                  <Play className="h-4 w-4" />
                  Resume
                </Button>
                <Button onClick={cancelExecution} variant="destructive" size="icon">
                  <Square className="h-4 w-4" />
                </Button>
              </>
            )}

            {workflowState.awaitingApproval && (
              <Button onClick={() => setCheckpointDialogOpen(true)} className="gap-2 flex-1">
                <AlertTriangle className="h-4 w-4" />
                Review Checkpoint
              </Button>
            )}

            {(workflowState.currentPhase === 'completed' || workflowState.currentPhase === 'failed') && (
              <>
                <Button onClick={handleStart} variant="outline" className="gap-2 flex-1">
                  <RefreshCw className="h-4 w-4" />
                  Run Again
                </Button>
                {onClose && (
                  <Button onClick={onClose}>Done</Button>
                )}
              </>
            )}
          </div>

          {/* Retry Info */}
          {executionState.retryCount > 0 && (
            <p className="text-xs text-muted-foreground text-center">
              Retry attempt {executionState.retryCount}/{config.maxRetries}
            </p>
          )}
        </CardContent>
      </Card>

      {/* Checkpoint Dialog */}
      <Dialog open={checkpointDialogOpen} onOpenChange={setCheckpointDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-status-warning" />
              Checkpoint Reached
            </DialogTitle>
            <DialogDescription>
              Autonomous workflow has paused for your review
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="p-4 rounded-lg bg-secondary/50 space-y-2">
              <div className="flex items-center gap-2">
                <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                  {phaseIcons[workflowState.currentPhase]}
                </div>
                <div>
                  <h4 className="font-medium">{getPhaseInfo(workflowState.currentPhase).label}</h4>
                  <p className="text-xs text-muted-foreground">
                    {getPhaseInfo(workflowState.currentPhase).description}
                  </p>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <Badge variant="outline" className="text-[10px]">
                Task: {task.key}
              </Badge>
              <Badge variant="outline" className="text-[10px]">
                Phase {currentPhaseIndex + 1} of {phaseOrder.length}
              </Badge>
              {executionState.executedPhases.length > 0 && (
                <Badge variant="outline" className="text-[10px] bg-status-success/10 text-status-success">
                  {executionState.executedPhases.length} completed
                </Badge>
              )}
            </div>

            <div className="p-3 rounded-lg bg-muted/50 border border-border">
              <p className="text-xs text-muted-foreground">
                You configured this checkpoint to require approval. Review the action and decide whether to proceed or skip.
              </p>
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={handleCheckpointSkip} className="gap-2">
              <SkipForward className="h-4 w-4" />
              Skip
            </Button>
            <Button onClick={handleCheckpointApprove} className="gap-2">
              <CheckCircle2 className="h-4 w-4" />
              Approve & Continue
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
