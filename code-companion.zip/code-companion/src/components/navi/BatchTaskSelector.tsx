import { useState, useEffect, useCallback, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { 
  Search, 
  Plus, 
  ListPlus,
  Flag,
  Clock,
  RefreshCw,
  Loader2,
  CheckSquare,
  Square,
  AlertCircle,
  Inbox,
  Zap,
} from 'lucide-react';
import { useIntegrations } from '@/hooks/useIntegrations';
import { useIntegrationData } from '@/hooks/useIntegrationData';
import { useWorkflowQueue } from '@/hooks/useWorkflowQueue';
import { useWorkflowTemplates } from '@/hooks/useWorkflowTemplates';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import type { JiraTask } from '@/types';

interface BatchTaskSelectorProps {
  className?: string;
  onTasksQueued?: (count: number) => void;
}

const mapJiraStatusToLocal = (status: string): JiraTask['status'] => {
  const statusLower = status.toLowerCase();
  if (statusLower.includes('done') || statusLower.includes('complete')) return 'done';
  if (statusLower.includes('progress') || statusLower.includes('development')) return 'in_progress';
  if (statusLower.includes('review') || statusLower.includes('testing')) return 'in_review';
  if (statusLower.includes('blocked')) return 'blocked';
  return 'todo';
};

const mapJiraPriorityToLocal = (priority: string): JiraTask['priority'] => {
  const priorityLower = priority.toLowerCase();
  if (priorityLower.includes('critical') || priorityLower.includes('highest')) return 'critical';
  if (priorityLower.includes('high')) return 'high';
  if (priorityLower.includes('medium') || priorityLower.includes('normal')) return 'medium';
  return 'low';
};

const priorityToQueuePriority = (priority: JiraTask['priority']): 'high' | 'medium' | 'low' => {
  if (priority === 'critical' || priority === 'high') return 'high';
  if (priority === 'medium') return 'medium';
  return 'low';
};

const getStatusColor = (status: JiraTask['status']) => {
  switch (status) {
    case 'todo': return 'bg-muted text-muted-foreground';
    case 'in_progress': return 'bg-status-info/20 text-status-info border-status-info/30';
    case 'in_review': return 'bg-accent/20 text-accent border-accent/30';
    case 'done': return 'bg-status-success/20 text-status-success border-status-success/30';
    case 'blocked': return 'bg-status-error/20 text-status-error border-status-error/30';
    default: return 'bg-muted text-muted-foreground';
  }
};

const priorityConfig = {
  critical: { color: 'text-status-error', label: 'Critical' },
  high: { color: 'text-status-warning', label: 'High' },
  medium: { color: 'text-status-info', label: 'Medium' },
  low: { color: 'text-muted-foreground', label: 'Low' },
};

interface TransformedTask {
  id: string;
  key: string;
  title: string;
  status: JiraTask['status'];
  priority: JiraTask['priority'];
  project: string | null;
  storyPoints: number | null;
}

export function BatchTaskSelector({ className, onTasksQueued }: BatchTaskSelectorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [tasks, setTasks] = useState<TransformedTask[]>([]);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>('');
  const [defaultPriority, setDefaultPriority] = useState<'high' | 'medium' | 'low'>('medium');

  const { integrations, isAuthenticated } = useIntegrations();
  const { fetchJiraIssues, isLoading: isFetching } = useIntegrationData();
  const { addBatchToQueue } = useWorkflowQueue();
  const { templates } = useWorkflowTemplates();

  const jiraConnected = integrations.find(i => i.type === 'jira')?.status === 'connected';

  // Transform Jira API response
  const transformJiraIssue = (issue: any): TransformedTask => ({
    id: issue.id,
    key: issue.key,
    title: issue.fields?.summary || 'Untitled',
    status: mapJiraStatusToLocal(issue.fields?.status?.name || 'To Do'),
    priority: mapJiraPriorityToLocal(issue.fields?.priority?.name || 'Medium'),
    project: issue.fields?.project?.key || null,
    storyPoints: issue.fields?.storyPoints || null,
  });

  // Fetch tasks
  const fetchTasks = useCallback(async () => {
    if (!jiraConnected || !isAuthenticated) return;

    setIsLoading(true);
    try {
      const jiraIssues = await fetchJiraIssues();
      if (jiraIssues) {
        const transformed = jiraIssues.map(transformJiraIssue);
        setTasks(transformed);
      }
    } catch (err) {
      console.error('Failed to fetch Jira tasks:', err);
      toast.error('Failed to fetch tasks from Jira');
    } finally {
      setIsLoading(false);
    }
  }, [jiraConnected, isAuthenticated, fetchJiraIssues]);

  // Fetch on open
  useEffect(() => {
    if (isOpen && jiraConnected && isAuthenticated) {
      fetchTasks();
    }
  }, [isOpen, jiraConnected, isAuthenticated, fetchTasks]);

  // Filter tasks
  const filteredTasks = useMemo(() => {
    return tasks.filter(task => {
      // Search filter
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        if (!task.key.toLowerCase().includes(query) && 
            !task.title.toLowerCase().includes(query)) {
          return false;
        }
      }

      // Status filter
      if (statusFilter !== 'all' && task.status !== statusFilter) {
        return false;
      }

      // Priority filter
      if (priorityFilter !== 'all' && task.priority !== priorityFilter) {
        return false;
      }

      return true;
    });
  }, [tasks, searchQuery, statusFilter, priorityFilter]);

  // Toggle selection
  const toggleSelection = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  // Select all visible
  const selectAll = () => {
    setSelectedIds(new Set(filteredTasks.map(t => t.id)));
  };

  // Clear selection
  const clearSelection = () => {
    setSelectedIds(new Set());
  };

  // Add selected to queue
  const handleAddToQueue = () => {
    if (selectedIds.size === 0) {
      toast.error('No tasks selected');
      return;
    }

    const selectedTasks = tasks.filter(t => selectedIds.has(t.id));
    const selectedTemplate = templates.find(t => t.id === selectedTemplateId);

    const tasksToQueue = selectedTasks.map(task => ({
      taskId: task.id,
      taskKey: task.key,
      taskTitle: task.title,
      priority: defaultPriority === 'medium' 
        ? priorityToQueuePriority(task.priority)
        : defaultPriority,
      templateId: selectedTemplateId || undefined,
      templateName: selectedTemplate?.name || undefined,
    }));

    addBatchToQueue(tasksToQueue);
    onTasksQueued?.(tasksToQueue.length);
    setSelectedIds(new Set());
    setIsOpen(false);
  };

  const selectedCount = selectedIds.size;

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className={cn("gap-2", className)}>
          <ListPlus className="w-4 h-4" />
          Add Tasks to Queue
        </Button>
      </DialogTrigger>

      <DialogContent className="max-w-2xl max-h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-primary" />
            Select Tasks for Queue
          </DialogTitle>
          <DialogDescription>
            Select multiple Jira tasks to add to the autonomous workflow queue
          </DialogDescription>
        </DialogHeader>

        {!isAuthenticated || !jiraConnected ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center mb-3">
              <Inbox className="h-6 w-6 text-muted-foreground" />
            </div>
            <h3 className="text-sm font-medium mb-1">
              {!isAuthenticated ? 'Sign In Required' : 'Jira Not Connected'}
            </h3>
            <p className="text-xs text-muted-foreground">
              {!isAuthenticated 
                ? 'Sign in to access your Jira tasks'
                : 'Connect Jira in Integrations to select tasks'}
            </p>
          </div>
        ) : (
          <>
            {/* Filters */}
            <div className="flex flex-col gap-3 py-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search tasks..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9"
                />
              </div>

              <div className="flex items-center gap-2">
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[130px]">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="todo">To Do</SelectItem>
                    <SelectItem value="in_progress">In Progress</SelectItem>
                    <SelectItem value="in_review">In Review</SelectItem>
                    <SelectItem value="blocked">Blocked</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                  <SelectTrigger className="w-[130px]">
                    <SelectValue placeholder="Priority" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Priority</SelectItem>
                    <SelectItem value="critical">Critical</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                  </SelectContent>
                </Select>

                <div className="flex-1" />

                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={fetchTasks}
                  disabled={isLoading}
                >
                  <RefreshCw className={cn("w-4 h-4", isLoading && "animate-spin")} />
                </Button>

                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={selectedCount === filteredTasks.length ? clearSelection : selectAll}
                >
                  {selectedCount === filteredTasks.length ? (
                    <>
                      <Square className="w-4 h-4 mr-2" />
                      Deselect All
                    </>
                  ) : (
                    <>
                      <CheckSquare className="w-4 h-4 mr-2" />
                      Select All
                    </>
                  )}
                </Button>
              </div>
            </div>

            {/* Task List */}
            <ScrollArea className="flex-1 min-h-[300px] max-h-[400px] border rounded-lg">
              {isLoading ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
                </div>
              ) : filteredTasks.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <AlertCircle className="w-8 h-8 text-muted-foreground/50 mb-2" />
                  <p className="text-sm text-muted-foreground">No tasks found</p>
                </div>
              ) : (
                <div className="divide-y divide-border">
                  {filteredTasks.map(task => {
                    const isSelected = selectedIds.has(task.id);
                    const priority = priorityConfig[task.priority];

                    return (
                      <button
                        key={task.id}
                        onClick={() => toggleSelection(task.id)}
                        className={cn(
                          "w-full flex items-start gap-3 p-3 text-left hover:bg-muted/50 transition-colors",
                          isSelected && "bg-primary/5"
                        )}
                      >
                        <Checkbox
                          checked={isSelected}
                          className="mt-1"
                          onCheckedChange={() => toggleSelection(task.id)}
                        />

                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-xs font-mono text-primary">
                              {task.key}
                            </span>
                            <Badge 
                              variant="outline" 
                              className={cn("text-[10px]", getStatusColor(task.status))}
                            >
                              {task.status.replace('_', ' ')}
                            </Badge>
                            <Flag className={cn("w-3 h-3", priority.color)} />
                          </div>
                          <p className="text-sm truncate">{task.title}</p>
                          <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                            {task.project && <span>{task.project}</span>}
                            {task.storyPoints && (
                              <span className="flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                {task.storyPoints}pts
                              </span>
                            )}
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}
            </ScrollArea>

            {/* Queue Options */}
            <div className="flex items-center gap-3 pt-2 border-t">
              <div className="flex-1">
                <label className="text-xs text-muted-foreground mb-1 block">
                  Workflow Template
                </label>
                <Select value={selectedTemplateId} onValueChange={setSelectedTemplateId}>
                  <SelectTrigger className="h-9">
                    <SelectValue placeholder="Select template (optional)" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">No template</SelectItem>
                    {templates.map(t => (
                      <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-xs text-muted-foreground mb-1 block">
                  Queue Priority
                </label>
                <Select 
                  value={defaultPriority} 
                  onValueChange={(v) => setDefaultPriority(v as 'high' | 'medium' | 'low')}
                >
                  <SelectTrigger className="h-9 w-[120px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="medium">Use Task Priority</SelectItem>
                    <SelectItem value="low">Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </>
        )}

        <DialogFooter>
          <div className="flex items-center justify-between w-full">
            <span className="text-sm text-muted-foreground">
              {selectedCount} task{selectedCount !== 1 ? 's' : ''} selected
            </span>
            <div className="flex items-center gap-2">
              <Button variant="outline" onClick={() => setIsOpen(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handleAddToQueue}
                disabled={selectedCount === 0 || !isAuthenticated || !jiraConnected}
                className="gap-2"
              >
                <Plus className="w-4 h-4" />
                Add to Queue ({selectedCount})
              </Button>
            </div>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
