import { useState, useEffect } from 'react';
import { Sun, CheckCircle2, MessageSquare, Calendar, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';
import type { JiraTask } from '@/types';

interface BriefingWidgetProps {
  jiraTasks?: JiraTask[];
  slackMentionCount?: number;
  meetingCount?: number;
  onClick?: () => void;
  isActive?: boolean;
}

export function BriefingWidget({
  jiraTasks = [],
  slackMentionCount = 0,
  meetingCount = 0,
  onClick,
  isActive = false
}: BriefingWidgetProps) {
  const taskCount = jiraTasks.filter(t => t.status !== 'done').length;
  const totalItems = taskCount + slackMentionCount + meetingCount;

  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Button
          variant={isActive ? 'sidebarActive' : 'sidebar'}
          size="icon"
          onClick={onClick}
          className={cn(
            "h-10 w-full rounded-lg relative transition-all duration-200",
            isActive && "bg-primary/10 border border-primary/30 shadow-lg shadow-primary/10"
          )}
        >
          <Sun className="h-5 w-5" />
          {totalItems > 0 && (
            <span className="absolute -top-1 -right-1 h-4 min-w-4 px-1 rounded-full bg-primary text-[10px] font-medium text-primary-foreground flex items-center justify-center">
              {totalItems > 9 ? '9+' : totalItems}
            </span>
          )}
        </Button>
      </TooltipTrigger>
      <TooltipContent side="right" className="flex flex-col gap-1">
        <span className="font-medium">Daily Briefing</span>
        <div className="flex items-center gap-3 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <CheckCircle2 className="h-3 w-3" /> {taskCount}
          </span>
          <span className="flex items-center gap-1">
            <MessageSquare className="h-3 w-3" /> {slackMentionCount}
          </span>
          <span className="flex items-center gap-1">
            <Calendar className="h-3 w-3" /> {meetingCount}
          </span>
        </div>
      </TooltipContent>
    </Tooltip>
  );
}
