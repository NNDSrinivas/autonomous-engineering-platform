import { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import { Progress } from '@/components/ui/progress';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  GitBranch, 
  Play, 
  RefreshCw,
  CheckCircle2,
  XCircle,
  Clock,
  Loader2,
  ExternalLink,
  AlertTriangle,
  ChevronDown,
  ChevronUp,
  Terminal,
  Zap,
  TrendingUp,
  Activity,
  RotateCcw,
  StopCircle,
  Wrench
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useGitHubIntegration, GitHubWorkflowRun } from '@/hooks/useGitHubIntegration';
import { useCICDStreaming } from '@/hooks/useCICDStreaming';
import { formatDistanceToNow, format } from 'date-fns';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { toast } from 'sonner';

interface CICDDashboardProps {
  owner?: string;
  repo?: string;
  onAutoFix?: (run: GitHubWorkflowRun, logs: string) => void;
}

interface WorkflowStats {
  total: number;
  success: number;
  failure: number;
  inProgress: number;
  successRate: number;
}

const statusIcons: Record<string, React.ReactNode> = {
  success: <CheckCircle2 className="h-4 w-4 text-status-success" />,
  failure: <XCircle className="h-4 w-4 text-status-error" />,
  cancelled: <XCircle className="h-4 w-4 text-muted-foreground" />,
  in_progress: <Loader2 className="h-4 w-4 text-primary animate-spin" />,
  queued: <Clock className="h-4 w-4 text-status-warning" />,
  waiting: <Clock className="h-4 w-4 text-status-warning" />,
  action_required: <AlertTriangle className="h-4 w-4 text-status-warning" />,
};

const statusColors: Record<string, string> = {
  success: 'bg-status-success/10 text-status-success border-status-success/30',
  failure: 'bg-status-error/10 text-status-error border-status-error/30',
  cancelled: 'bg-muted text-muted-foreground border-muted',
  in_progress: 'bg-primary/10 text-primary border-primary/30',
  queued: 'bg-status-warning/10 text-status-warning border-status-warning/30',
};

export function CICDDashboard({ owner, repo, onAutoFix }: CICDDashboardProps) {
  const {
    isLoading,
    connection,
    workflowRuns,
    fetchWorkflowRuns,
    rerunWorkflow,
    cancelWorkflow,
    getWorkflowLogs,
  } = useGitHubIntegration();

  const [isRefreshing, setIsRefreshing] = useState(false);
  const [rerunningId, setRerunningId] = useState<number | null>(null);
  const [cancellingId, setCancellingId] = useState<number | null>(null);
  const [fixingId, setFixingId] = useState<number | null>(null);
  const [expandedRun, setExpandedRun] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState<'all' | 'failed' | 'running'>('all');
  const [streamingRunId, setStreamingRunId] = useState<number | null>(null);

  const {
    build: streamingBuild,
    isStreaming,
    clearLogs,
  } = useCICDStreaming({
    owner,
    repo,
    runId: streamingRunId || undefined,
    enabled: !!streamingRunId,
    pollInterval: 5000,
  });

  // Calculate stats
  const stats: WorkflowStats = {
    total: workflowRuns.length,
    success: workflowRuns.filter(r => r.conclusion === 'success').length,
    failure: workflowRuns.filter(r => r.conclusion === 'failure').length,
    inProgress: workflowRuns.filter(r => r.status === 'in_progress' || r.status === 'queued').length,
    successRate: workflowRuns.length > 0 
      ? Math.round((workflowRuns.filter(r => r.conclusion === 'success').length / workflowRuns.length) * 100)
      : 0,
  };

  // Auto-refresh for running workflows
  useEffect(() => {
    if (!connection.connected || !owner || !repo) return;
    
    fetchWorkflowRuns(owner, repo);
    
    const hasRunning = workflowRuns.some(r => 
      r.status === 'in_progress' || r.status === 'queued'
    );
    
    if (hasRunning) {
      const interval = setInterval(() => {
        fetchWorkflowRuns(owner, repo);
      }, 15000);
      
      return () => clearInterval(interval);
    }
  }, [connection.connected, owner, repo, fetchWorkflowRuns, workflowRuns.length]);

  const handleRefresh = useCallback(async () => {
    if (!owner || !repo) return;
    setIsRefreshing(true);
    await fetchWorkflowRuns(owner, repo);
    setIsRefreshing(false);
  }, [owner, repo, fetchWorkflowRuns]);

  const handleRerun = useCallback(async (run: GitHubWorkflowRun) => {
    if (!owner || !repo) return;
    setRerunningId(run.id);
    try {
      await rerunWorkflow(owner, repo, run.id);
      toast.success('Workflow re-run initiated');
      await fetchWorkflowRuns(owner, repo);
    } catch (error) {
      toast.error('Failed to re-run workflow');
    } finally {
      setRerunningId(null);
    }
  }, [owner, repo, rerunWorkflow, fetchWorkflowRuns]);

  const handleCancel = useCallback(async (run: GitHubWorkflowRun) => {
    if (!owner || !repo) return;
    setCancellingId(run.id);
    try {
      await cancelWorkflow(owner, repo, run.id);
      toast.success('Workflow cancelled');
      await fetchWorkflowRuns(owner, repo);
    } catch (error) {
      toast.error('Failed to cancel workflow');
    } finally {
      setCancellingId(null);
    }
  }, [owner, repo, cancelWorkflow, fetchWorkflowRuns]);

  const handleAutoFix = useCallback(async (run: GitHubWorkflowRun) => {
    if (!owner || !repo || !onAutoFix) return;
    setFixingId(run.id);
    try {
      const logs = await getWorkflowLogs(owner, repo, run.id);
      const logText = JSON.stringify(logs);
      onAutoFix(run, logText);
      toast.success('Analyzing build failure for auto-fix...');
    } catch (error) {
      toast.error('Failed to fetch logs for auto-fix');
    } finally {
      setFixingId(null);
    }
  }, [owner, repo, getWorkflowLogs, onAutoFix]);

  const handleStreamLogs = useCallback((run: GitHubWorkflowRun) => {
    if (streamingRunId === run.id) {
      setStreamingRunId(null);
      clearLogs();
    } else {
      setStreamingRunId(run.id);
    }
  }, [streamingRunId, clearLogs]);

  const filteredRuns = workflowRuns.filter(run => {
    if (activeTab === 'failed') return run.conclusion === 'failure';
    if (activeTab === 'running') return run.status === 'in_progress' || run.status === 'queued';
    return true;
  });

  if (!connection.connected) {
    return (
      <div className="p-6 text-center space-y-3">
        <GitBranch className="h-12 w-12 mx-auto text-muted-foreground/50" />
        <div>
          <h3 className="font-medium">GitHub Not Connected</h3>
          <p className="text-sm text-muted-foreground mt-1">
            Connect GitHub in Settings → Connectors to view CI/CD status
          </p>
        </div>
      </div>
    );
  }

  if (!owner || !repo) {
    return (
      <div className="p-6 text-center space-y-3">
        <Play className="h-12 w-12 mx-auto text-muted-foreground/50" />
        <div>
          <h3 className="font-medium">Select a Repository</h3>
          <p className="text-sm text-muted-foreground mt-1">
            Choose a repository to view workflow runs
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-background">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-lg bg-cicd-orange/20 flex items-center justify-center">
            <Activity className="h-4 w-4 text-cicd-orange" />
          </div>
          <div>
            <h2 className="font-semibold text-sm">CI/CD Dashboard</h2>
            <p className="text-xs text-muted-foreground">{owner}/{repo}</p>
          </div>
          {isStreaming && (
            <div className="flex items-center gap-1.5 px-2 py-1 rounded-full bg-status-success/10">
              <div className="h-2 w-2 rounded-full bg-status-success animate-pulse" />
              <span className="text-[10px] text-status-success font-medium">Live</span>
            </div>
          )}
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={handleRefresh}
          disabled={isRefreshing}
          className="h-8"
        >
          <RefreshCw className={cn("h-3.5 w-3.5 mr-1.5", isRefreshing && "animate-spin")} />
          Refresh
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-4 gap-3 p-4 border-b border-border">
        <Card className="bg-secondary/30 border-none">
          <CardContent className="p-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[10px] text-muted-foreground uppercase tracking-wide">Total Runs</p>
                <p className="text-xl font-bold">{stats.total}</p>
              </div>
              <Zap className="h-5 w-5 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
        <Card className="bg-status-success/10 border-none">
          <CardContent className="p-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[10px] text-status-success uppercase tracking-wide">Success</p>
                <p className="text-xl font-bold text-status-success">{stats.success}</p>
              </div>
              <CheckCircle2 className="h-5 w-5 text-status-success" />
            </div>
          </CardContent>
        </Card>
        <Card className="bg-status-error/10 border-none">
          <CardContent className="p-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[10px] text-status-error uppercase tracking-wide">Failed</p>
                <p className="text-xl font-bold text-status-error">{stats.failure}</p>
              </div>
              <XCircle className="h-5 w-5 text-status-error" />
            </div>
          </CardContent>
        </Card>
        <Card className="bg-primary/10 border-none">
          <CardContent className="p-3">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-[10px] text-primary uppercase tracking-wide">Success Rate</p>
                <p className="text-xl font-bold text-primary">{stats.successRate}%</p>
              </div>
              <TrendingUp className="h-5 w-5 text-primary" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Streaming Logs */}
      {streamingBuild && streamingBuild.logs.length > 0 && (
        <div className="border-b border-border bg-background/50">
          <div className="flex items-center justify-between px-4 py-2 border-b border-border/50">
            <div className="flex items-center gap-2">
              <Terminal className="h-4 w-4 text-primary" />
              <span className="text-xs font-medium">{streamingBuild.name}</span>
              <Badge variant="outline" className="text-[10px]">
                {streamingBuild.status}
              </Badge>
            </div>
            {streamingBuild.progress > 0 && (
              <div className="flex items-center gap-2">
                <Progress value={streamingBuild.progress} className="w-24 h-1.5" />
                <span className="text-[10px] text-muted-foreground">
                  {Math.round(streamingBuild.progress)}%
                </span>
              </div>
            )}
          </div>
          <ScrollArea className="h-32">
            <div className="p-2 font-mono text-[11px] space-y-0.5">
              {streamingBuild.logs.slice(-20).map((log) => (
                <div
                  key={log.id}
                  className={cn(
                    "px-2 py-0.5 rounded",
                    log.level === 'error' && 'bg-status-error/10 text-status-error',
                    log.level === 'warning' && 'bg-status-warning/10 text-status-warning',
                    log.level === 'success' && 'bg-status-success/10 text-status-success',
                    log.level === 'info' && 'text-muted-foreground',
                  )}
                >
                  {log.content}
                </div>
              ))}
            </div>
          </ScrollArea>
        </div>
      )}

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as typeof activeTab)} className="flex-1 flex flex-col">
        <div className="px-4 pt-3">
          <TabsList className="h-8">
            <TabsTrigger value="all" className="text-xs h-7">
              All ({workflowRuns.length})
            </TabsTrigger>
            <TabsTrigger value="failed" className="text-xs h-7">
              Failed ({stats.failure})
            </TabsTrigger>
            <TabsTrigger value="running" className="text-xs h-7">
              Running ({stats.inProgress})
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value={activeTab} className="flex-1 mt-0">
          <ScrollArea className="h-full">
            {isLoading ? (
              <div className="p-4 space-y-3">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-24 w-full" />
                ))}
              </div>
            ) : filteredRuns.length === 0 ? (
              <div className="p-6 text-center text-muted-foreground">
                <Clock className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">No workflow runs found</p>
              </div>
            ) : (
              <div className="p-4 space-y-2">
                {filteredRuns.map((run) => (
                  <Collapsible key={run.id}>
                    <Card className={cn(
                      "bg-secondary/20 border hover:bg-secondary/30 transition-colors",
                      streamingRunId === run.id && "ring-1 ring-primary"
                    )}>
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-start gap-3 min-w-0">
                            {statusIcons[run.conclusion || run.status]}
                            <div className="min-w-0">
                              <div className="font-medium text-sm truncate">{run.name}</div>
                              <div className="text-xs text-muted-foreground truncate mt-0.5">
                                {run.head_commit?.message || run.head_branch}
                              </div>
                              <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
                                <div className="flex items-center gap-1">
                                  <GitBranch className="h-3 w-3" />
                                  <span>{run.head_branch}</span>
                                </div>
                                <span>#{run.run_number}</span>
                                <span>{formatDistanceToNow(new Date(run.created_at), { addSuffix: true })}</span>
                              </div>
                            </div>
                          </div>
                          <Badge 
                            variant="outline" 
                            className={cn("text-[10px] flex-shrink-0", statusColors[run.conclusion || run.status])}
                          >
                            {run.conclusion || run.status}
                          </Badge>
                        </div>

                        <div className="flex items-center gap-2 mt-3 pt-3 border-t border-border/50">
                          {/* Running workflow actions */}
                          {(run.status === 'in_progress' || run.status === 'queued') && (
                            <>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleStreamLogs(run)}
                                className={cn(
                                  "h-7 text-xs gap-1.5",
                                  streamingRunId === run.id && "bg-primary/10 border-primary"
                                )}
                              >
                                <Terminal className="h-3 w-3" />
                                {streamingRunId === run.id ? 'Streaming' : 'Stream'}
                              </Button>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleCancel(run)}
                                disabled={cancellingId === run.id}
                                className="h-7 text-xs gap-1.5 text-status-error hover:text-status-error"
                              >
                                {cancellingId === run.id ? (
                                  <Loader2 className="h-3 w-3 animate-spin" />
                                ) : (
                                  <StopCircle className="h-3 w-3" />
                                )}
                                Cancel
                              </Button>
                            </>
                          )}

                          {/* Failed workflow actions */}
                          {run.conclusion === 'failure' && (
                            <>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleRerun(run)}
                                disabled={rerunningId === run.id}
                                className="h-7 text-xs gap-1.5"
                              >
                                {rerunningId === run.id ? (
                                  <Loader2 className="h-3 w-3 animate-spin" />
                                ) : (
                                  <RotateCcw className="h-3 w-3" />
                                )}
                                Re-run
                              </Button>
                              {onAutoFix && (
                                <Button
                                  variant="default"
                                  size="sm"
                                  onClick={() => handleAutoFix(run)}
                                  disabled={fixingId === run.id}
                                  className="h-7 text-xs gap-1.5"
                                >
                                  {fixingId === run.id ? (
                                    <Loader2 className="h-3 w-3 animate-spin" />
                                  ) : (
                                    <Wrench className="h-3 w-3" />
                                  )}
                                  Auto-Fix
                                </Button>
                              )}
                            </>
                          )}

                          {/* Success/cancelled re-run */}
                          {(run.conclusion === 'success' || run.conclusion === 'cancelled') && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleRerun(run)}
                              disabled={rerunningId === run.id}
                              className="h-7 text-xs gap-1.5"
                            >
                              {rerunningId === run.id ? (
                                <Loader2 className="h-3 w-3 animate-spin" />
                              ) : (
                                <RotateCcw className="h-3 w-3" />
                              )}
                              Re-run
                            </Button>
                          )}

                          <CollapsibleTrigger asChild>
                            <Button variant="ghost" size="sm" className="h-7 text-xs gap-1.5">
                              <ChevronDown className="h-3 w-3" />
                              Details
                            </Button>
                          </CollapsibleTrigger>

                          <Button variant="ghost" size="sm" asChild className="h-7 text-xs gap-1.5 ml-auto">
                            <a href={run.html_url} target="_blank" rel="noopener noreferrer">
                              <ExternalLink className="h-3 w-3" />
                              View on GitHub
                            </a>
                          </Button>
                        </div>

                        <CollapsibleContent>
                          <div className="mt-3 pt-3 border-t border-border/50 text-xs space-y-2">
                            <div className="grid grid-cols-2 gap-2">
                              <div>
                                <span className="text-muted-foreground">Workflow ID:</span>
                                <span className="ml-2">{run.workflow_id}</span>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Run Number:</span>
                                <span className="ml-2">#{run.run_number}</span>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Branch:</span>
                                <span className="ml-2">{run.head_branch}</span>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Created:</span>
                                <span className="ml-2">{format(new Date(run.created_at), 'PPp')}</span>
                              </div>
                            </div>
                            {run.head_commit && (
                              <div className="p-2 rounded bg-background/50">
                                <div className="text-muted-foreground mb-1">Commit:</div>
                                <div className="mt-1">{run.head_commit.message}</div>
                              </div>
                            )}
                          </div>
                        </CollapsibleContent>
                      </CardContent>
                    </Card>
                  </Collapsible>
                ))}
              </div>
            )}
          </ScrollArea>
        </TabsContent>
      </Tabs>
    </div>
  );
}
