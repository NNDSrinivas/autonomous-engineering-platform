import { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import { Progress } from '@/components/ui/progress';
import { 
  GitBranch, 
  Play, 
  RefreshCw,
  CheckCircle2,
  XCircle,
  Clock,
  Loader2,
  ExternalLink,
  AlertTriangle,
  ChevronRight,
  StopCircle,
  ChevronDown,
  ChevronUp,
  Terminal,
  Maximize2,
  Minimize2
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useGitHubIntegration, GitHubWorkflowRun } from '@/hooks/useGitHubIntegration';
import { useCICDStreaming, BuildLogLine } from '@/hooks/useCICDStreaming';
import { formatDistanceToNow } from 'date-fns';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';

interface CICDPanelProps {
  owner?: string;
  repo?: string;
}

interface WorkflowJob {
  id: number;
  name: string;
  status: string;
  conclusion: string | null;
  started_at: string;
  completed_at: string | null;
  steps?: {
    name: string;
    status: string;
    conclusion: string | null;
    number: number;
  }[];
}

const statusIcons: Record<string, React.ReactNode> = {
  success: <CheckCircle2 className="h-4 w-4 text-status-success" />,
  failure: <XCircle className="h-4 w-4 text-status-error" />,
  cancelled: <XCircle className="h-4 w-4 text-muted-foreground" />,
  in_progress: <Loader2 className="h-4 w-4 text-primary animate-spin" />,
  queued: <Clock className="h-4 w-4 text-status-warning" />,
  waiting: <Clock className="h-4 w-4 text-status-warning" />,
  action_required: <AlertTriangle className="h-4 w-4 text-status-warning" />,
  skipped: <ChevronRight className="h-4 w-4 text-muted-foreground" />,
  timed_out: <XCircle className="h-4 w-4 text-status-error" />,
};

const statusLabels: Record<string, string> = {
  success: 'Success',
  failure: 'Failed',
  cancelled: 'Cancelled',
  in_progress: 'Running',
  queued: 'Queued',
  waiting: 'Waiting',
  action_required: 'Action Required',
  skipped: 'Skipped',
  timed_out: 'Timed Out',
};

const logLevelColors: Record<string, string> = {
  info: 'text-muted-foreground',
  warning: 'text-status-warning',
  error: 'text-status-error',
  success: 'text-status-success',
};

export function CICDPanel({ owner, repo }: CICDPanelProps) {
  const {
    isLoading,
    connection,
    workflowRuns,
    fetchWorkflowRuns,
    rerunWorkflow,
    getWorkflowLogs,
    cancelWorkflow,
  } = useGitHubIntegration();

  const [isRefreshing, setIsRefreshing] = useState(false);
  const [rerunningId, setRerunningId] = useState<number | null>(null);
  const [cancellingId, setCancellingId] = useState<number | null>(null);
  const [expandedRun, setExpandedRun] = useState<number | null>(null);
  const [jobsMap, setJobsMap] = useState<Record<number, WorkflowJob[]>>({});
  const [loadingJobs, setLoadingJobs] = useState<number | null>(null);
  const [streamingRunId, setStreamingRunId] = useState<number | null>(null);
  const [logsExpanded, setLogsExpanded] = useState(false);

  // Real-time streaming for the selected run
  const {
    build: streamingBuild,
    isStreaming,
    clearLogs,
  } = useCICDStreaming({
    owner,
    repo,
    runId: streamingRunId || undefined,
    enabled: !!streamingRunId,
    pollInterval: 5000,
  });

  // Auto-refresh for running workflows
  useEffect(() => {
    if (!connection.connected || !owner || !repo) return;
    
    fetchWorkflowRuns(owner, repo);
    
    // Set up polling for running workflows
    const hasRunning = workflowRuns.some(r => 
      r.status === 'in_progress' || r.status === 'queued'
    );
    
    if (hasRunning) {
      const interval = setInterval(() => {
        fetchWorkflowRuns(owner, repo);
      }, 15000); // Poll every 15 seconds
      
      return () => clearInterval(interval);
    }
  }, [connection.connected, owner, repo, fetchWorkflowRuns, workflowRuns.length]);

  // Auto-select first running workflow for streaming
  useEffect(() => {
    if (!streamingRunId) {
      const runningRun = workflowRuns.find(r => r.status === 'in_progress');
      if (runningRun) {
        setStreamingRunId(runningRun.id);
      }
    }
  }, [workflowRuns, streamingRunId]);

  const handleRefresh = useCallback(async () => {
    if (!owner || !repo) return;
    setIsRefreshing(true);
    await fetchWorkflowRuns(owner, repo);
    setIsRefreshing(false);
  }, [owner, repo, fetchWorkflowRuns]);

  const handleRerun = useCallback(async (run: GitHubWorkflowRun) => {
    if (!owner || !repo) return;
    setRerunningId(run.id);
    try {
      await rerunWorkflow(owner, repo, run.id);
      await fetchWorkflowRuns(owner, repo);
    } finally {
      setRerunningId(null);
    }
  }, [owner, repo, rerunWorkflow, fetchWorkflowRuns]);

  const handleCancel = useCallback(async (run: GitHubWorkflowRun) => {
    if (!owner || !repo) return;
    setCancellingId(run.id);
    try {
      await cancelWorkflow(owner, repo, run.id);
      await fetchWorkflowRuns(owner, repo);
    } finally {
      setCancellingId(null);
    }
  }, [owner, repo, cancelWorkflow, fetchWorkflowRuns]);

  const handleToggleExpand = useCallback(async (run: GitHubWorkflowRun) => {
    if (expandedRun === run.id) {
      setExpandedRun(null);
      return;
    }
    
    setExpandedRun(run.id);
    
    // Fetch jobs if not already loaded
    if (!jobsMap[run.id] && owner && repo) {
      setLoadingJobs(run.id);
      try {
        const jobs = await getWorkflowLogs(owner, repo, run.id);
        setJobsMap(prev => ({ ...prev, [run.id]: jobs }));
      } finally {
        setLoadingJobs(null);
      }
    }
  }, [expandedRun, jobsMap, owner, repo, getWorkflowLogs]);

  const handleStreamLogs = useCallback((run: GitHubWorkflowRun) => {
    if (streamingRunId === run.id) {
      setStreamingRunId(null);
      clearLogs();
    } else {
      setStreamingRunId(run.id);
    }
  }, [streamingRunId, clearLogs]);

  if (!connection.connected) {
    return (
      <div className="p-6 text-center space-y-3">
        <GitBranch className="h-12 w-12 mx-auto text-muted-foreground/50" />
        <div>
          <h3 className="font-medium">GitHub Not Connected</h3>
          <p className="text-sm text-muted-foreground mt-1">
            Connect GitHub in Settings → Connectors to view CI/CD status
          </p>
        </div>
      </div>
    );
  }

  if (!owner || !repo) {
    return (
      <div className="p-6 text-center space-y-3">
        <Play className="h-12 w-12 mx-auto text-muted-foreground/50" />
        <div>
          <h3 className="font-medium">Select a Repository</h3>
          <p className="text-sm text-muted-foreground mt-1">
            Choose a repository to view workflow runs
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between p-3 border-b border-border">
        <div className="flex items-center gap-2">
          <Play className="h-4 w-4 text-cicd-orange" />
          <span className="font-medium text-sm">CI/CD Pipelines</span>
          <Badge variant="outline" className="text-[10px]">
            {owner}/{repo}
          </Badge>
          {isStreaming && (
            <div className="flex items-center gap-1">
              <div className="h-2 w-2 rounded-full bg-status-success animate-pulse" />
              <span className="text-[10px] text-status-success">Live</span>
            </div>
          )}
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={handleRefresh}
          disabled={isRefreshing}
          className="h-7 px-2"
        >
          <RefreshCw className={cn("h-3.5 w-3.5", isRefreshing && "animate-spin")} />
        </Button>
      </div>

      {/* Streaming Logs Panel */}
      {streamingBuild && streamingBuild.logs.length > 0 && (
        <div className={cn(
          "border-b border-border bg-background/50 transition-all",
          logsExpanded ? "h-64" : "h-32"
        )}>
          <div className="flex items-center justify-between px-3 py-2 border-b border-border/50">
            <div className="flex items-center gap-2">
              <Terminal className="h-4 w-4 text-primary" />
              <span className="text-xs font-medium">{streamingBuild.name}</span>
              <Badge variant="outline" className="text-[10px]">
                {streamingBuild.status}
              </Badge>
            </div>
            <div className="flex items-center gap-2">
              {streamingBuild.progress > 0 && (
                <div className="flex items-center gap-2">
                  <Progress value={streamingBuild.progress} className="w-20 h-1.5" />
                  <span className="text-[10px] text-muted-foreground">
                    {Math.round(streamingBuild.progress)}%
                  </span>
                </div>
              )}
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6"
                onClick={() => setLogsExpanded(!logsExpanded)}
              >
                {logsExpanded ? (
                  <Minimize2 className="h-3 w-3" />
                ) : (
                  <Maximize2 className="h-3 w-3" />
                )}
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6"
                onClick={() => setStreamingRunId(null)}
              >
                <XCircle className="h-3 w-3" />
              </Button>
            </div>
          </div>
          <ScrollArea className="h-full">
            <div className="p-2 font-mono text-[11px] space-y-0.5">
              {streamingBuild.logs.map((log) => (
                <div
                  key={log.id}
                  className={cn(
                    "px-2 py-0.5 rounded",
                    log.level === 'error' && 'bg-status-error/10',
                    log.level === 'warning' && 'bg-status-warning/10',
                    log.level === 'success' && 'bg-status-success/10',
                  )}
                >
                  <span className={logLevelColors[log.level]}>
                    {log.content}
                  </span>
                </div>
              ))}
            </div>
          </ScrollArea>
        </div>
      )}

      <ScrollArea className="flex-1">
        {isLoading ? (
          <div className="p-4 space-y-3">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-20 w-full" />
            ))}
          </div>
        ) : workflowRuns.length === 0 ? (
          <div className="p-6 text-center text-muted-foreground">
            <Clock className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm">No workflow runs found</p>
          </div>
        ) : (
          <div className="p-2 space-y-2">
            {workflowRuns.map((run) => (
              <Collapsible key={run.id} open={expandedRun === run.id}>
                <div className={cn(
                  "p-3 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors space-y-2",
                  streamingRunId === run.id && "ring-1 ring-primary"
                )}>
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      {statusIcons[run.conclusion || run.status] || statusIcons.queued}
                      <div className="min-w-0">
                        <div className="font-medium text-sm truncate">{run.name}</div>
                        <div className="text-xs text-muted-foreground truncate">
                          {run.head_commit?.message || run.head_branch}
                        </div>
                      </div>
                    </div>
                    <Badge 
                      variant="outline" 
                      className={cn(
                        "text-[10px] flex-shrink-0",
                        run.conclusion === 'success' && "bg-status-success/10 text-status-success border-status-success/30",
                        run.conclusion === 'failure' && "bg-status-error/10 text-status-error border-status-error/30",
                        (run.status === 'in_progress' || run.status === 'queued') && "bg-primary/10 text-primary border-primary/30"
                      )}
                    >
                      {statusLabels[run.conclusion || run.status] || run.status}
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <div className="flex items-center gap-2">
                      <GitBranch className="h-3 w-3" />
                      <span>{run.head_branch}</span>
                      <span>•</span>
                      <span>#{run.run_number}</span>
                    </div>
                    <span>{formatDistanceToNow(new Date(run.created_at), { addSuffix: true })}</span>
                  </div>

                  <div className="flex items-center gap-2 pt-1">
                    {(run.status === 'in_progress' || run.status === 'queued') && (
                      <>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleStreamLogs(run)}
                          className={cn(
                            "h-7 text-xs gap-1.5",
                            streamingRunId === run.id && "bg-primary/10 border-primary"
                          )}
                        >
                          <Terminal className="h-3 w-3" />
                          {streamingRunId === run.id ? 'Streaming' : 'Stream Logs'}
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleCancel(run)}
                          disabled={cancellingId === run.id}
                          className="h-7 text-xs gap-1.5"
                        >
                          {cancellingId === run.id ? (
                            <Loader2 className="h-3 w-3 animate-spin" />
                          ) : (
                            <StopCircle className="h-3 w-3" />
                          )}
                          Cancel
                        </Button>
                      </>
                    )}
                    {(run.conclusion === 'failure' || run.conclusion === 'cancelled') && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleRerun(run)}
                        disabled={rerunningId === run.id}
                        className="h-7 text-xs gap-1.5"
                      >
                        {rerunningId === run.id ? (
                          <Loader2 className="h-3 w-3 animate-spin" />
                        ) : (
                          <RefreshCw className="h-3 w-3" />
                        )}
                        Re-run
                      </Button>
                    )}
                    <CollapsibleTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleToggleExpand(run)}
                        className="h-7 text-xs gap-1.5"
                      >
                        {expandedRun === run.id ? (
                          <ChevronUp className="h-3 w-3" />
                        ) : (
                          <ChevronDown className="h-3 w-3" />
                        )}
                        Jobs
                      </Button>
                    </CollapsibleTrigger>
                    <Button variant="ghost" size="sm" asChild className="h-7 text-xs gap-1.5">
                      <a href={run.html_url} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="h-3 w-3" />
                        View
                      </a>
                    </Button>
                  </div>

                  <CollapsibleContent>
                    <div className="mt-2 pt-2 border-t border-border/50 space-y-1.5">
                      {loadingJobs === run.id ? (
                        <div className="flex items-center gap-2 text-xs text-muted-foreground py-2">
                          <Loader2 className="h-3 w-3 animate-spin" />
                          Loading jobs...
                        </div>
                      ) : jobsMap[run.id]?.length ? (
                        jobsMap[run.id].map((job) => (
                          <div key={job.id} className="text-xs p-2 rounded bg-background/50">
                            <div className="flex items-center gap-2">
                              {statusIcons[job.conclusion || job.status] || statusIcons.queued}
                              <span className="font-medium">{job.name}</span>
                            </div>
                            {job.steps && job.steps.length > 0 && (
                              <div className="ml-6 mt-1 space-y-0.5">
                                {job.steps.slice(0, 5).map((step) => (
                                  <div key={step.number} className="flex items-center gap-1.5 text-muted-foreground">
                                    {statusIcons[step.conclusion || step.status] || <Clock className="h-3 w-3" />}
                                    <span className="truncate">{step.name}</span>
                                  </div>
                                ))}
                                {job.steps.length > 5 && (
                                  <span className="text-muted-foreground">+{job.steps.length - 5} more steps</span>
                                )}
                              </div>
                            )}
                          </div>
                        ))
                      ) : (
                        <div className="text-xs text-muted-foreground py-2">No job details available</div>
                      )}
                    </div>
                  </CollapsibleContent>
                </div>
              </Collapsible>
            ))}
          </div>
        )}
      </ScrollArea>
    </div>
  );
}
