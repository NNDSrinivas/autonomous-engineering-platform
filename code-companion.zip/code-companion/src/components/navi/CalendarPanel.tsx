import { useState, useEffect } from 'react';
import { 
  Calendar, 
  Video, 
  Clock, 
  Users, 
  MapPin, 
  ExternalLink, 
  RefreshCw,
  FileText,
  Sparkles,
  Link2,
  CheckCircle2,
  AlertCircle,
  ChevronRight
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import { useCalendarZoomSync, type LinkedMeeting } from '@/hooks/useCalendarZoomSync';
import { format, isToday, isTomorrow, isPast, isFuture } from 'date-fns';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export function CalendarPanel() {
  const [activeTab, setActiveTab] = useState<'today' | 'upcoming' | 'completed'>('today');
  const [generatingNotes, setGeneratingNotes] = useState<string | null>(null);

  const {
    linkedMeetings,
    isLoading,
    isSyncing,
    syncCalendarAndZoom,
    generateMeetingNotes,
    getUpcomingMeetings,
    getCompletedMeetings,
    getMeetingsNeedingAttention,
    calendarConnections,
  } = useCalendarZoomSync();

  useEffect(() => {
    syncCalendarAndZoom();
  }, []);

  const todayMeetings = linkedMeetings.filter(m => isToday(m.calendarEvent.start));
  const upcomingMeetings = getUpcomingMeetings().filter(m => !isToday(m.calendarEvent.start));
  const completedMeetings = getCompletedMeetings();
  const needsAttention = getMeetingsNeedingAttention();

  const handleGenerateNotes = async (meetingId: string) => {
    setGeneratingNotes(meetingId);
    await generateMeetingNotes(meetingId);
    setGeneratingNotes(null);
  };

  const formatMeetingTime = (start: Date, end: Date) => {
    return `${format(start, 'h:mm a')} - ${format(end, 'h:mm a')}`;
  };

  const getStatusBadge = (meeting: LinkedMeeting) => {
    switch (meeting.status) {
      case 'in_progress':
        return <Badge className="bg-green-500/20 text-green-400">In Progress</Badge>;
      case 'completed':
        return <Badge className="bg-primary/20 text-primary">Completed</Badge>;
      case 'missed':
        return <Badge className="bg-destructive/20 text-destructive">Missed</Badge>;
      default:
        return <Badge variant="outline">Scheduled</Badge>;
    }
  };

  const MeetingCard = ({ meeting, showDate = false }: { meeting: LinkedMeeting; showDate?: boolean }) => (
    <Card className="bg-secondary/30 border-border/50 hover:border-primary/30 transition-colors">
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              {getStatusBadge(meeting)}
              {meeting.zoomMeeting && (
                <Badge variant="outline" className="text-[10px]">
                  <Video className="h-3 w-3 mr-1" />
                  Zoom
                </Badge>
              )}
              {meeting.recording && (
                <Badge variant="outline" className="text-[10px] text-green-400">
                  <FileText className="h-3 w-3 mr-1" />
                  Recording
                </Badge>
              )}
            </div>
            
            <h4 className="font-medium text-sm truncate">{meeting.calendarEvent.title}</h4>
            
            <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground">
              <div className="flex items-center gap-1">
                <Clock className="h-3 w-3" />
                {showDate && (
                  <span>{format(meeting.calendarEvent.start, 'MMM d')} · </span>
                )}
                {formatMeetingTime(meeting.calendarEvent.start, meeting.calendarEvent.end)}
              </div>
              
              {meeting.calendarEvent.attendees.length > 0 && (
                <div className="flex items-center gap-1">
                  <Users className="h-3 w-3" />
                  {meeting.calendarEvent.attendees.length}
                </div>
              )}
              
              {meeting.calendarEvent.location && (
                <div className="flex items-center gap-1 truncate">
                  <MapPin className="h-3 w-3" />
                  <span className="truncate">{meeting.calendarEvent.location}</span>
                </div>
              )}
            </div>

            {/* Action Items */}
            {meeting.actionItems && meeting.actionItems.length > 0 && (
              <div className="mt-3 pt-3 border-t border-border/50">
                <p className="text-xs font-medium text-muted-foreground mb-1">Action Items</p>
                <ul className="space-y-1">
                  {meeting.actionItems.slice(0, 3).map((item, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-xs">
                      <CheckCircle2 className="h-3 w-3 text-primary mt-0.5 flex-shrink-0" />
                      <span className="line-clamp-1">{item}</span>
                    </li>
                  ))}
                  {meeting.actionItems.length > 3 && (
                    <li className="text-xs text-muted-foreground">
                      +{meeting.actionItems.length - 3} more
                    </li>
                  )}
                </ul>
              </div>
            )}

            {/* Notes Preview */}
            {meeting.notes && (
              <div className="mt-3 pt-3 border-t border-border/50">
                <p className="text-xs text-muted-foreground line-clamp-2">{meeting.notes}</p>
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="flex flex-col gap-1">
            {meeting.calendarEvent.meetingUrl && (
              <Button variant="ghost" size="icon" className="h-8 w-8" asChild>
                <a href={meeting.calendarEvent.meetingUrl} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="h-4 w-4" />
                </a>
              </Button>
            )}
            
            {meeting.transcript && !meeting.notes && (
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => handleGenerateNotes(meeting.id)}
                disabled={generatingNotes === meeting.id}
              >
                {generatingNotes === meeting.id ? (
                  <RefreshCw className="h-4 w-4 animate-spin" />
                ) : (
                  <Sparkles className="h-4 w-4 text-primary" />
                )}
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-primary/10">
            <Calendar className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h2 className="font-semibold">Calendar & Meetings</h2>
            <p className="text-xs text-muted-foreground">
              {linkedMeetings.length} synced meetings
            </p>
          </div>
        </div>
        <Button
          variant="outline"
          size="sm"
          onClick={() => syncCalendarAndZoom()}
          disabled={isSyncing}
        >
          <RefreshCw className={cn("h-4 w-4 mr-2", isSyncing && "animate-spin")} />
          Sync
        </Button>
      </div>

      {/* Connection Status */}
      {calendarConnections.length === 0 && (
        <div className="p-4 border-b border-border">
          <Card className="bg-muted/50">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <Link2 className="h-5 w-5 text-muted-foreground" />
                <div className="flex-1">
                  <p className="text-sm font-medium">Connect your calendar</p>
                  <p className="text-xs text-muted-foreground">
                    Link Google or Microsoft calendar to sync meetings
                  </p>
                </div>
                <Button 
                  variant="default" 
                  size="sm"
                  onClick={async () => {
                    try {
                      const { data: { session } } = await supabase.auth.getSession();
                      if (!session) {
                        toast.error('Please sign in first');
                        return;
                      }
                      
                      const response = await fetch(
                        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/oauth?provider=google`,
                        {
                          headers: {
                            Authorization: `Bearer ${session.access_token}`,
                          },
                        }
                      );
                      
                      const result = await response.json();
                      if (result.authUrl) {
                        window.open(result.authUrl, '_blank', 'width=600,height=700');
                      } else {
                        toast.error('Failed to initiate calendar connection');
                      }
                    } catch (error) {
                      console.error('Failed to connect calendar:', error);
                      toast.error('Failed to connect calendar');
                    }
                  }}
                >
                  <Calendar className="h-4 w-4 mr-2" />
                  Connect
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Needs Attention */}
      {needsAttention.length > 0 && (
        <div className="p-4 border-b border-border">
          <div className="flex items-center gap-2 mb-2">
            <AlertCircle className="h-4 w-4 text-status-warning" />
            <span className="text-sm font-medium">Needs Attention</span>
            <Badge variant="outline" className="text-status-warning">
              {needsAttention.length}
            </Badge>
          </div>
          <div className="flex gap-2 overflow-x-auto pb-1">
            {needsAttention.slice(0, 3).map(meeting => (
              <Card key={meeting.id} className="flex-shrink-0 w-64 bg-status-warning/5 border-status-warning/30">
                <CardContent className="p-3">
                  <p className="text-sm font-medium truncate">{meeting.calendarEvent.title}</p>
                  <p className="text-xs text-muted-foreground">
                    {meeting.status === 'missed' ? 'Meeting missed' : 'No recording found'}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as any)} className="flex-1 flex flex-col">
        <TabsList className="mx-4 mt-4">
          <TabsTrigger value="today" className="flex-1">
            Today
            {todayMeetings.length > 0 && (
              <Badge variant="secondary" className="ml-1.5">{todayMeetings.length}</Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="upcoming" className="flex-1">
            Upcoming
            {upcomingMeetings.length > 0 && (
              <Badge variant="secondary" className="ml-1.5">{upcomingMeetings.length}</Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="completed" className="flex-1">
            Completed
            {completedMeetings.length > 0 && (
              <Badge variant="secondary" className="ml-1.5">{completedMeetings.length}</Badge>
            )}
          </TabsTrigger>
        </TabsList>

        <ScrollArea className="flex-1 p-4">
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map(i => (
                <Skeleton key={i} className="h-32 w-full" />
              ))}
            </div>
          ) : (
            <>
              <TabsContent value="today" className="m-0 space-y-3">
                {todayMeetings.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                    <Calendar className="h-12 w-12 mb-4 opacity-30" />
                    <p className="text-sm">No meetings today</p>
                  </div>
                ) : (
                  todayMeetings.map(meeting => (
                    <MeetingCard key={meeting.id} meeting={meeting} />
                  ))
                )}
              </TabsContent>

              <TabsContent value="upcoming" className="m-0 space-y-3">
                {upcomingMeetings.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                    <Calendar className="h-12 w-12 mb-4 opacity-30" />
                    <p className="text-sm">No upcoming meetings</p>
                  </div>
                ) : (
                  upcomingMeetings.map(meeting => (
                    <MeetingCard key={meeting.id} meeting={meeting} showDate />
                  ))
                )}
              </TabsContent>

              <TabsContent value="completed" className="m-0 space-y-3">
                {completedMeetings.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                    <CheckCircle2 className="h-12 w-12 mb-4 opacity-30" />
                    <p className="text-sm">No completed meetings</p>
                  </div>
                ) : (
                  completedMeetings.map(meeting => (
                    <MeetingCard key={meeting.id} meeting={meeting} showDate />
                  ))
                )}
              </TabsContent>
            </>
          )}
        </ScrollArea>
      </Tabs>
    </div>
  );
}
