import { useState, useEffect, useMemo } from 'react';
import {
  History,
  Search,
  Trash2,
  Archive,
  ArchiveRestore,
  MessageSquare,
  Calendar,
  ChevronDown,
  MoreVertical,
  Star,
  StarOff,
  Clock,
  Filter,
  X,
  Loader2,
  Download,
  FileJson,
  FileText,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { formatDistanceToNow } from 'date-fns';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';

export interface ChatConversation {
  id: string;
  name: string;
  messages: Array<{
    id: string;
    role: 'user' | 'assistant';
    content: string;
    timestamp: Date;
  }>;
  timestamp: Date;
  isArchived?: boolean;
  isStarred?: boolean;
  preview?: string;
  messageCount?: number;
}

interface ChatHistorySidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectConversation: (conversation: ChatConversation) => void;
  currentConversationId?: string;
}

const CHAT_HISTORY_KEY = 'navi-chat-history';

export function ChatHistorySidebar({
  isOpen,
  onClose,
  onSelectConversation,
  currentConversationId,
}: ChatHistorySidebarProps) {
  const [conversations, setConversations] = useState<ChatConversation[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showArchived, setShowArchived] = useState(false);
  const [filterStarred, setFilterStarred] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [conversationToDelete, setConversationToDelete] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [todayOpen, setTodayOpen] = useState(true);
  const [thisWeekOpen, setThisWeekOpen] = useState(true);
  const [olderOpen, setOlderOpen] = useState(false);

  // Load conversations from localStorage
  useEffect(() => {
    loadConversations();
  }, []);

  const loadConversations = () => {
    setIsLoading(true);
    try {
      const saved = localStorage.getItem(CHAT_HISTORY_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        // Convert timestamps back to Date objects
        const conversations = parsed.map((conv: any) => ({
          ...conv,
          timestamp: new Date(conv.timestamp),
          messages: conv.messages?.map((msg: any) => ({
            ...msg,
            timestamp: new Date(msg.timestamp),
          })) || [],
        }));
        setConversations(conversations);
      }
    } catch (error) {
      console.error('Failed to load chat history:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const saveConversations = (updatedConversations: ChatConversation[]) => {
    try {
      localStorage.setItem(CHAT_HISTORY_KEY, JSON.stringify(updatedConversations));
    } catch (error) {
      console.error('Failed to save chat history:', error);
    }
  };

  const handleArchive = (id: string) => {
    const updated = conversations.map(conv =>
      conv.id === id ? { ...conv, isArchived: !conv.isArchived } : conv
    );
    setConversations(updated);
    saveConversations(updated);
    const conv = conversations.find(c => c.id === id);
    toast.success(conv?.isArchived ? 'Conversation restored' : 'Conversation archived');
  };

  const handleStar = (id: string) => {
    const updated = conversations.map(conv =>
      conv.id === id ? { ...conv, isStarred: !conv.isStarred } : conv
    );
    setConversations(updated);
    saveConversations(updated);
    const conv = updated.find(c => c.id === id);
    toast.success(conv?.isStarred ? 'Added to favorites' : 'Removed from favorites');
  };

  const handleDelete = (id: string) => {
    setConversationToDelete(id);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (!conversationToDelete) return;
    const updated = conversations.filter(conv => conv.id !== conversationToDelete);
    setConversations(updated);
    saveConversations(updated);
    toast.success('Conversation deleted');
    setDeleteDialogOpen(false);
    setConversationToDelete(null);
  };

  const handleClearAll = () => {
    setConversations([]);
    saveConversations([]);
    toast.success('All conversations cleared');
  };

  // Export to JSON
  const exportToJSON = () => {
    try {
      const exportData = {
        exportedAt: new Date().toISOString(),
        totalConversations: filteredConversations.length,
        conversations: filteredConversations.map(conv => ({
          id: conv.id,
          name: conv.name,
          timestamp: conv.timestamp,
          messageCount: conv.messages?.length || 0,
          isStarred: conv.isStarred,
          isArchived: conv.isArchived,
          messages: conv.messages?.map(msg => ({
            role: msg.role,
            content: msg.content,
            timestamp: msg.timestamp,
          })) || [],
        })),
      };
      
      const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `navi-chat-history-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success('Chat history exported to JSON');
    } catch (error) {
      console.error('Failed to export to JSON:', error);
      toast.error('Failed to export chat history');
    }
  };

  // Export to PDF (HTML-based printable format)
  const exportToPDF = () => {
    try {
      const printContent = `
        <!DOCTYPE html>
        <html>
        <head>
          <title>Navi Chat History</title>
          <style>
            body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; padding: 40px; max-width: 800px; margin: 0 auto; }
            h1 { color: #333; border-bottom: 2px solid #6366f1; padding-bottom: 10px; }
            .conversation { margin: 30px 0; page-break-inside: avoid; }
            .conv-header { background: #f3f4f6; padding: 12px; border-radius: 8px 8px 0 0; }
            .conv-name { font-weight: 600; font-size: 16px; }
            .conv-meta { font-size: 12px; color: #666; margin-top: 4px; }
            .messages { border: 1px solid #e5e7eb; border-top: none; border-radius: 0 0 8px 8px; }
            .message { padding: 12px; border-bottom: 1px solid #f3f4f6; }
            .message:last-child { border-bottom: none; }
            .user-msg { background: #f0f9ff; }
            .assistant-msg { background: #faf5ff; }
            .role { font-weight: 600; font-size: 12px; text-transform: uppercase; margin-bottom: 4px; }
            .user-role { color: #0369a1; }
            .assistant-role { color: #7c3aed; }
            .content { font-size: 14px; line-height: 1.6; white-space: pre-wrap; }
            .timestamp { font-size: 10px; color: #999; margin-top: 6px; }
            .footer { margin-top: 40px; font-size: 12px; color: #999; text-align: center; }
            @media print { body { padding: 20px; } .conversation { page-break-inside: avoid; } }
          </style>
        </head>
        <body>
          <h1>🤖 Navi Chat History</h1>
          <p>Exported on ${new Date().toLocaleString()} • ${filteredConversations.length} conversations</p>
          ${filteredConversations.map(conv => `
            <div class="conversation">
              <div class="conv-header">
                <div class="conv-name">${conv.isStarred ? '⭐ ' : ''}${conv.name}</div>
                <div class="conv-meta">${new Date(conv.timestamp).toLocaleString()} • ${conv.messages?.length || 0} messages${conv.isArchived ? ' • Archived' : ''}</div>
              </div>
              <div class="messages">
                ${conv.messages?.map(msg => `
                  <div class="message ${msg.role === 'user' ? 'user-msg' : 'assistant-msg'}">
                    <div class="role ${msg.role === 'user' ? 'user-role' : 'assistant-role'}">${msg.role}</div>
                    <div class="content">${msg.content.replace(/</g, '&lt;').replace(/>/g, '&gt;')}</div>
                    <div class="timestamp">${new Date(msg.timestamp).toLocaleTimeString()}</div>
                  </div>
                `).join('') || '<div class="message">No messages</div>'}
              </div>
            </div>
          `).join('')}
          <div class="footer">Generated by Navi AI Assistant</div>
        </body>
        </html>
      `;
      
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        printWindow.document.write(printContent);
        printWindow.document.close();
        setTimeout(() => {
          printWindow.print();
        }, 250);
        toast.success('Opening print dialog for PDF export');
      } else {
        toast.error('Please allow popups to export PDF');
      }
    } catch (error) {
      console.error('Failed to export to PDF:', error);
      toast.error('Failed to export chat history');
    }
  };

  // Filter and group conversations
  const filteredConversations = useMemo(() => {
    let filtered = conversations.filter(conv => {
      // Filter by archive status
      if (showArchived !== conv.isArchived) return false;
      // Filter by starred
      if (filterStarred && !conv.isStarred) return false;
      // Filter by search query
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        const matchesName = conv.name.toLowerCase().includes(query);
        const matchesContent = conv.messages?.some(msg =>
          msg.content.toLowerCase().includes(query)
        );
        return matchesName || matchesContent;
      }
      return true;
    });
    
    // Sort by timestamp descending
    return filtered.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }, [conversations, searchQuery, showArchived, filterStarred]);

  // Group conversations by date
  const groupedConversations = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const weekAgo = new Date(today);
    weekAgo.setDate(weekAgo.getDate() - 7);

    const groups = {
      today: [] as ChatConversation[],
      thisWeek: [] as ChatConversation[],
      older: [] as ChatConversation[],
    };

    filteredConversations.forEach(conv => {
      const convDate = new Date(conv.timestamp);
      convDate.setHours(0, 0, 0, 0);

      if (convDate.getTime() >= today.getTime()) {
        groups.today.push(conv);
      } else if (convDate.getTime() >= weekAgo.getTime()) {
        groups.thisWeek.push(conv);
      } else {
        groups.older.push(conv);
      }
    });

    return groups;
  }, [filteredConversations]);

  const getPreview = (conv: ChatConversation) => {
    if (conv.preview) return conv.preview;
    const lastMessage = conv.messages?.[conv.messages.length - 1];
    if (lastMessage) {
      return lastMessage.content.slice(0, 80) + (lastMessage.content.length > 80 ? '...' : '');
    }
    return 'No messages';
  };

  if (!isOpen) return null;

  return (
    <>
      <div className="w-80 bg-sidebar border-r border-border flex flex-col h-full">
        {/* Header */}
        <div className="p-4 border-b border-border space-y-3 flex-shrink-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <History className="h-5 w-5 text-primary" />
              <h2 className="font-semibold">Chat History</h2>
            </div>
            <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search conversations..."
              className="pl-9 h-9"
            />
            {searchQuery && (
              <Button
                variant="ghost"
                size="icon"
                className="absolute right-1 top-1/2 -translate-y-1/2 h-6 w-6"
                onClick={() => setSearchQuery('')}
              >
                <X className="h-3 w-3" />
              </Button>
            )}
          </div>

          {/* Filters */}
          <div className="flex items-center gap-2">
            <Button
              variant={showArchived ? 'secondary' : 'outline'}
              size="sm"
              className="h-7 text-xs gap-1"
              onClick={() => setShowArchived(!showArchived)}
            >
              <Archive className="h-3 w-3" />
              {showArchived ? 'Archived' : 'Active'}
            </Button>
            <Button
              variant={filterStarred ? 'secondary' : 'outline'}
              size="sm"
              className="h-7 text-xs gap-1"
              onClick={() => setFilterStarred(!filterStarred)}
            >
              <Star className="h-3 w-3" />
              Starred
            </Button>
            <Badge variant="outline" className="ml-auto text-xs">
              {filteredConversations.length}
            </Badge>
          </div>
        </div>

        {/* Conversation List */}
        <ScrollArea className="flex-1">
          {isLoading ? (
            <div className="flex items-center justify-center h-40">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : filteredConversations.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-40 px-4 text-center">
              <MessageSquare className="h-10 w-10 text-muted-foreground mb-3" />
              <h3 className="text-sm font-medium mb-1">No Conversations</h3>
              <p className="text-xs text-muted-foreground">
                {searchQuery
                  ? 'No conversations match your search'
                  : showArchived
                  ? 'No archived conversations'
                  : 'Start chatting to see your history here'}
              </p>
            </div>
          ) : (
            <div className="p-2 space-y-2">
              {/* Today */}
              {groupedConversations.today.length > 0 && (
                <Collapsible open={todayOpen} onOpenChange={setTodayOpen}>
                  <CollapsibleTrigger className="flex items-center gap-2 w-full px-2 py-1.5 text-xs font-medium text-muted-foreground hover:text-foreground">
                    <ChevronDown className={cn("h-3 w-3 transition-transform", !todayOpen && "-rotate-90")} />
                    Today
                    <Badge variant="secondary" className="ml-auto text-[10px] h-4 px-1">
                      {groupedConversations.today.length}
                    </Badge>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    {groupedConversations.today.map(conv => (
                      <ConversationItem
                        key={conv.id}
                        conversation={conv}
                        isSelected={conv.id === currentConversationId}
                        preview={getPreview(conv)}
                        onSelect={() => onSelectConversation(conv)}
                        onArchive={() => handleArchive(conv.id)}
                        onStar={() => handleStar(conv.id)}
                        onDelete={() => handleDelete(conv.id)}
                      />
                    ))}
                  </CollapsibleContent>
                </Collapsible>
              )}

              {/* This Week */}
              {groupedConversations.thisWeek.length > 0 && (
                <Collapsible open={thisWeekOpen} onOpenChange={setThisWeekOpen}>
                  <CollapsibleTrigger className="flex items-center gap-2 w-full px-2 py-1.5 text-xs font-medium text-muted-foreground hover:text-foreground">
                    <ChevronDown className={cn("h-3 w-3 transition-transform", !thisWeekOpen && "-rotate-90")} />
                    This Week
                    <Badge variant="secondary" className="ml-auto text-[10px] h-4 px-1">
                      {groupedConversations.thisWeek.length}
                    </Badge>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    {groupedConversations.thisWeek.map(conv => (
                      <ConversationItem
                        key={conv.id}
                        conversation={conv}
                        isSelected={conv.id === currentConversationId}
                        preview={getPreview(conv)}
                        onSelect={() => onSelectConversation(conv)}
                        onArchive={() => handleArchive(conv.id)}
                        onStar={() => handleStar(conv.id)}
                        onDelete={() => handleDelete(conv.id)}
                      />
                    ))}
                  </CollapsibleContent>
                </Collapsible>
              )}

              {/* Older */}
              {groupedConversations.older.length > 0 && (
                <Collapsible open={olderOpen} onOpenChange={setOlderOpen}>
                  <CollapsibleTrigger className="flex items-center gap-2 w-full px-2 py-1.5 text-xs font-medium text-muted-foreground hover:text-foreground">
                    <ChevronDown className={cn("h-3 w-3 transition-transform", !olderOpen && "-rotate-90")} />
                    Older
                    <Badge variant="secondary" className="ml-auto text-[10px] h-4 px-1">
                      {groupedConversations.older.length}
                    </Badge>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    {groupedConversations.older.map(conv => (
                      <ConversationItem
                        key={conv.id}
                        conversation={conv}
                        isSelected={conv.id === currentConversationId}
                        preview={getPreview(conv)}
                        onSelect={() => onSelectConversation(conv)}
                        onArchive={() => handleArchive(conv.id)}
                        onStar={() => handleStar(conv.id)}
                        onDelete={() => handleDelete(conv.id)}
                      />
                    ))}
                  </CollapsibleContent>
                </Collapsible>
              )}
            </div>
          )}
        </ScrollArea>

        {/* Footer Actions */}
        {conversations.length > 0 && (
          <div className="p-3 border-t border-border flex-shrink-0 space-y-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full text-xs gap-2"
                >
                  <Download className="h-3 w-3" />
                  Export History
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="center" className="w-48">
                <DropdownMenuItem onClick={exportToJSON} className="gap-2">
                  <FileJson className="h-4 w-4" />
                  Export as JSON
                </DropdownMenuItem>
                <DropdownMenuItem onClick={exportToPDF} className="gap-2">
                  <FileText className="h-4 w-4" />
                  Export as PDF
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button
              variant="ghost"
              size="sm"
              className="w-full text-xs text-muted-foreground hover:text-destructive"
              onClick={handleClearAll}
            >
              <Trash2 className="h-3 w-3 mr-2" />
              Clear All History
            </Button>
          </div>
        )}
      </div>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Conversation</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this conversation? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

// Conversation Item Component
interface ConversationItemProps {
  conversation: ChatConversation;
  isSelected: boolean;
  preview: string;
  onSelect: () => void;
  onArchive: () => void;
  onStar: () => void;
  onDelete: () => void;
}

function ConversationItem({
  conversation,
  isSelected,
  preview,
  onSelect,
  onArchive,
  onStar,
  onDelete,
}: ConversationItemProps) {
  return (
    <div
      className={cn(
        "group flex items-start gap-2 p-2 rounded-lg cursor-pointer transition-colors",
        isSelected 
          ? "bg-primary/10 border border-primary/20" 
          : "hover:bg-secondary/50"
      )}
      onClick={onSelect}
    >
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          {conversation.isStarred && (
            <Star className="h-3 w-3 text-yellow-400 fill-yellow-400 flex-shrink-0" />
          )}
          <span className="text-sm font-medium truncate">{conversation.name}</span>
        </div>
        <p className="text-xs text-muted-foreground truncate mt-0.5">{preview}</p>
        <div className="flex items-center gap-2 mt-1">
          <Clock className="h-3 w-3 text-muted-foreground" />
          <span className="text-[10px] text-muted-foreground">
            {formatDistanceToNow(conversation.timestamp, { addSuffix: true })}
          </span>
          {conversation.messageCount && (
            <Badge variant="outline" className="text-[10px] h-4 px-1">
              {conversation.messageCount} msgs
            </Badge>
          )}
        </div>
      </div>

      <DropdownMenu>
        <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
          <Button
            variant="ghost"
            size="icon"
            className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
          >
            <MoreVertical className="h-3 w-3" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-40 bg-popover border border-border shadow-lg z-50">
          <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onStar(); }}>
            {conversation.isStarred ? (
              <>
                <StarOff className="h-3.5 w-3.5 mr-2" />
                Unstar
              </>
            ) : (
              <>
                <Star className="h-3.5 w-3.5 mr-2" />
                Star
              </>
            )}
          </DropdownMenuItem>
          <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onArchive(); }}>
            {conversation.isArchived ? (
              <>
                <ArchiveRestore className="h-3.5 w-3.5 mr-2" />
                Restore
              </>
            ) : (
              <>
                <Archive className="h-3.5 w-3.5 mr-2" />
                Archive
              </>
            )}
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem 
            className="text-destructive focus:text-destructive"
            onClick={(e) => { e.stopPropagation(); onDelete(); }}
          >
            <Trash2 className="h-3.5 w-3.5 mr-2" />
            Delete
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}

// Helper function to save a conversation to history
export function saveConversationToHistory(conversation: ChatConversation) {
  try {
    const saved = localStorage.getItem(CHAT_HISTORY_KEY);
    const conversations: ChatConversation[] = saved ? JSON.parse(saved) : [];
    
    // Check if conversation already exists
    const existingIndex = conversations.findIndex(c => c.id === conversation.id);
    
    if (existingIndex >= 0) {
      // Update existing
      conversations[existingIndex] = conversation;
    } else {
      // Add new (keep last 50)
      conversations.unshift(conversation);
      if (conversations.length > 50) {
        conversations.pop();
      }
    }
    
    localStorage.setItem(CHAT_HISTORY_KEY, JSON.stringify(conversations));
  } catch (error) {
    console.error('Failed to save conversation to history:', error);
  }
}
