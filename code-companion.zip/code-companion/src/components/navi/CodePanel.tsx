import { useState, useRef, useCallback } from 'react';
import { 
  ChevronRight, 
  ChevronDown,
  File,
  Folder,
  X,
  Circle,
  GitBranch,
  Plus,
  RefreshCw,
  Sparkles,
  Play,
  Bug,
  Check
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface FileNode {
  name: string;
  type: 'file' | 'folder';
  children?: FileNode[];
  language?: string;
  modified?: boolean;
}

const mockFileTree: FileNode[] = [
  {
    name: 'src',
    type: 'folder',
    children: [
      {
        name: 'agent',
        type: 'folder',
        children: [
          { name: 'context.ts', type: 'file', language: 'typescript', modified: true },
          { name: 'loop.ts', type: 'file', language: 'typescript' },
          { name: 'memory.ts', type: 'file', language: 'typescript' },
          { name: 'integrations.ts', type: 'file', language: 'typescript' },
        ],
      },
      {
        name: 'components',
        type: 'folder',
        children: [
          { name: 'Chat.tsx', type: 'file', language: 'tsx' },
          { name: 'TaskPanel.tsx', type: 'file', language: 'tsx' },
          { name: 'ContextPanel.tsx', type: 'file', language: 'tsx' },
        ],
      },
      { name: 'index.ts', type: 'file', language: 'typescript' },
      { name: 'types.ts', type: 'file', language: 'typescript' },
    ],
  },
  {
    name: 'tests',
    type: 'folder',
    children: [
      { name: 'context.test.ts', type: 'file', language: 'typescript' },
      { name: 'loop.test.ts', type: 'file', language: 'typescript' },
    ],
  },
  { name: 'package.json', type: 'file', language: 'json' },
  { name: 'tsconfig.json', type: 'file', language: 'json' },
  { name: 'README.md', type: 'file', language: 'markdown' },
];

// Copilot-style suggestions based on context
const getSuggestion = (currentLine: string): string | null => {
  const trimmed = currentLine.trim();
  
  if (trimmed === 'async' || trimmed === 'async ') {
    return 'function handleFileChange(event: FileEvent): Promise<void> {';
  }
  if (trimmed === 'const' || trimmed === 'const ') {
    return 'watcher = new FileWatcher(workspacePath);';
  }
  if (trimmed === 'import' || trimmed === 'import ') {
    return "{ FileWatcher } from './watcher';";
  }
  if (trimmed === 'export' || trimmed === 'export ') {
    return 'class AgentLoop {';
  }
  if (trimmed === 'if' || trimmed === 'if ') {
    return '(this.isRunning) return;';
  }
  if (trimmed === 'try' || trimmed === 'try ') {
    return '{';
  }
  if (trimmed === 'catch' || trimmed === 'catch ') {
    return '(error) { console.error("[NAVI] Error:", error); }';
  }
  if (trimmed.endsWith('this.')) {
    return 'context.updateFile(event.path, content);';
  }
  if (trimmed.endsWith('console.')) {
    return "log('[NAVI] Agent loop started');";
  }
  if (trimmed === 'await' || trimmed === 'await ') {
    return 'this.watcher.start();';
  }
  if (trimmed === '// ' || trimmed === '//') {
    return 'TODO: Implement error handling for edge cases';
  }
  
  return null;
};

interface Tab {
  id: string;
  name: string;
  language: string;
  modified: boolean;
  content: string;
}

const initialCode = `import { FileWatcher } from './watcher';
import { ContextManager } from './context';
import { MemoryStore } from './memory';

export class AgentLoop {
  private watcher: FileWatcher;
  private context: ContextManager;
  private memory: MemoryStore;
  private isRunning: boolean = false;

  constructor(workspacePath: string) {
    this.watcher = new FileWatcher(workspacePath);
    this.context = new ContextManager();
    this.memory = new MemoryStore({ maxSize: 500 * 1024 * 1024 });
  }

  async start(): Promise<void> {
    if (this.isRunning) return;
    
    this.isRunning = true;
    console.log('[NAVI] Agent loop started');

    this.watcher.on('change', async (event) => {
      await this.handleFileChange(event);
    });

    await this.context.initialize();
    await this.watcher.start();
  }

  private async handleFileChange(event: FileEvent): Promise<void> {
    const content = await this.watcher.readFile(event.path);
    this.context.updateFile(event.path, content);
    
    this.memory.add({
      type: 'file_change',
      path: event.path,
      timestamp: Date.now(),
      diff: event.diff,
    });

    this.emit('context_updated', this.context.getSnapshot());
  }

  `;

function FileTreeNode({ 
  node, 
  depth = 0,
  onFileSelect 
}: { 
  node: FileNode; 
  depth?: number;
  onFileSelect: (node: FileNode) => void;
}) {
  const [isOpen, setIsOpen] = useState(depth < 2);

  const getFileIcon = (language?: string) => {
    if (language === 'typescript' || language === 'tsx') {
      return <span className="text-syntax-function text-xs">TS</span>;
    }
    if (language === 'json') {
      return <span className="text-syntax-type text-xs">{'{}'}</span>;
    }
    if (language === 'markdown') {
      return <span className="text-muted-foreground text-xs">MD</span>;
    }
    return <File className="h-3.5 w-3.5 text-muted-foreground" />;
  };

  if (node.type === 'folder') {
    return (
      <div>
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="w-full flex items-center gap-1.5 px-2 py-1 hover:bg-sidebar-hover rounded text-sm text-muted-foreground hover:text-foreground transition-colors"
          style={{ paddingLeft: `${depth * 12 + 8}px` }}
        >
          {isOpen ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronRight className="h-3.5 w-3.5" />}
          <Folder className={cn("h-3.5 w-3.5", isOpen ? "text-syntax-type" : "text-syntax-type/70")} />
          <span className="truncate">{node.name}</span>
        </button>
        {isOpen && node.children && (
          <div className="animate-fade-in">
            {node.children.map((child, i) => (
              <FileTreeNode key={i} node={child} depth={depth + 1} onFileSelect={onFileSelect} />
            ))}
          </div>
        )}
      </div>
    );
  }

  return (
    <button
      onClick={() => onFileSelect(node)}
      className="w-full flex items-center gap-1.5 px-2 py-1 hover:bg-sidebar-hover rounded text-sm text-muted-foreground hover:text-foreground transition-colors group"
      style={{ paddingLeft: `${depth * 12 + 20}px` }}
    >
      {getFileIcon(node.language)}
      <span className="truncate flex-1 text-left">{node.name}</span>
      {node.modified && <Circle className="h-2 w-2 fill-primary text-primary" />}
    </button>
  );
}

// Ghost text editor component
function GhostTextEditor({ 
  value, 
  onChange, 
  suggestion,
  onAcceptSuggestion,
  cursorLine,
  onCursorChange
}: {
  value: string;
  onChange: (value: string) => void;
  suggestion: string | null;
  onAcceptSuggestion: () => void;
  cursorLine: number;
  onCursorChange: (line: number, col: number) => void;
}) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [isFocused, setIsFocused] = useState(false);

  const lines = value.split('\n');

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Tab' && suggestion) {
      e.preventDefault();
      onAcceptSuggestion();
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newValue = e.target.value;
    onChange(newValue);
    
    const pos = e.target.selectionStart;
    const textBeforeCursor = newValue.substring(0, pos);
    const linesBeforeCursor = textBeforeCursor.split('\n');
    const newLine = linesBeforeCursor.length;
    const newCol = linesBeforeCursor[linesBeforeCursor.length - 1].length + 1;
    onCursorChange(newLine, newCol);
  };

  const handleClick = (e: React.MouseEvent<HTMLTextAreaElement>) => {
    const target = e.target as HTMLTextAreaElement;
    const pos = target.selectionStart;
    const textBeforeCursor = value.substring(0, pos);
    const linesBeforeCursor = textBeforeCursor.split('\n');
    const newLine = linesBeforeCursor.length;
    const newCol = linesBeforeCursor[linesBeforeCursor.length - 1].length + 1;
    onCursorChange(newLine, newCol);
  };

  const highlightLine = (line: string) => {
    return line
      .replace(/(import|export|class|async|await|if|return|const|private|new|function|try|catch)/g, '{{KW}}$1{{/KW}}')
      .replace(/(string|number|boolean|void|Promise|FileEvent|FileWatcher|ContextManager|MemoryStore)/g, '{{TY}}$1{{/TY}}')
      .replace(/('.*?'|".*?")/g, '{{ST}}$1{{/ST}}')
      .replace(/(\/\/.*)$/g, '{{CM}}$1{{/CM}}')
      .split(/({{KW}}.*?{{\/KW}}|{{TY}}.*?{{\/TY}}|{{ST}}.*?{{\/ST}}|{{CM}}.*?{{\/CM}})/g)
      .map((part, j) => {
        if (part.includes('{{KW}}')) return <span key={j} className="text-syntax-keyword">{part.replace(/{{KW}}|{{\/KW}}/g, '')}</span>;
        if (part.includes('{{TY}}')) return <span key={j} className="text-syntax-type">{part.replace(/{{TY}}|{{\/TY}}/g, '')}</span>;
        if (part.includes('{{ST}}')) return <span key={j} className="text-syntax-string">{part.replace(/{{ST}}|{{\/ST}}/g, '')}</span>;
        if (part.includes('{{CM}}')) return <span key={j} className="text-syntax-comment">{part.replace(/{{CM}}|{{\/CM}}/g, '')}</span>;
        return part;
      });
  };

  return (
    <div className="relative flex-1 font-mono text-xs">
      {/* Rendered code with syntax highlighting and ghost text */}
      <div className="absolute inset-0 pointer-events-none overflow-auto pt-2">
        {lines.map((line, i) => (
          <div key={i} className="px-2 min-h-5 leading-5 whitespace-pre">
            <span className="text-syntax-variable">{highlightLine(line)}</span>
            {/* Ghost text suggestion on current line */}
            {i === cursorLine - 1 && suggestion && isFocused && (
              <span className="text-muted-foreground/40 italic">{suggestion}</span>
            )}
          </div>
        ))}
      </div>
      
      {/* Hidden textarea for input */}
      <textarea
        ref={textareaRef}
        value={value}
        onChange={handleChange}
        onKeyDown={handleKeyDown}
        onClick={handleClick}
        onFocus={() => setIsFocused(true)}
        onBlur={() => setIsFocused(false)}
        className="absolute inset-0 w-full h-full resize-none bg-transparent text-transparent caret-primary outline-none pt-2 px-2 font-mono text-xs leading-5"
        spellCheck={false}
        autoComplete="off"
        autoCorrect="off"
        autoCapitalize="off"
      />
    </div>
  );
}

export function CodePanel() {
  const [tabs, setTabs] = useState<Tab[]>([
    { id: '1', name: 'context.ts', language: 'typescript', modified: true, content: initialCode },
    { id: '2', name: 'loop.ts', language: 'typescript', modified: false, content: '// loop.ts content\n\n' },
  ]);
  const [activeTab, setActiveTab] = useState('1');
  const [showAISuggestion, setShowAISuggestion] = useState(true);
  const [cursorLine, setCursorLine] = useState(44);
  const [cursorCol, setCursorCol] = useState(3);
  const [suggestion, setSuggestion] = useState<string | null>(null);
  const [showAcceptHint, setShowAcceptHint] = useState(false);

  const activeTabData = tabs.find(t => t.id === activeTab);
  const code = activeTabData?.content || '';

  const handleCodeChange = useCallback((newCode: string) => {
    setTabs(prev => prev.map(t => t.id === activeTab ? { ...t, content: newCode, modified: true } : t));
    
    const lines = newCode.split('\n');
    const currentLine = lines[cursorLine - 1] || '';
    const newSuggestion = getSuggestion(currentLine);
    setSuggestion(newSuggestion);
    setShowAcceptHint(!!newSuggestion);
  }, [activeTab, cursorLine]);

  const handleAcceptSuggestion = useCallback(() => {
    if (!suggestion) return;
    
    const lines = code.split('\n');
    const currentLine = lines[cursorLine - 1] || '';
    lines[cursorLine - 1] = currentLine + suggestion;
    
    const newCode = lines.join('\n');
    setTabs(prev => prev.map(t => t.id === activeTab ? { ...t, content: newCode, modified: true } : t));
    setSuggestion(null);
    setShowAcceptHint(false);
  }, [suggestion, code, cursorLine, activeTab]);

  const handleCursorChange = useCallback((line: number, col: number) => {
    setCursorLine(line);
    setCursorCol(col);
    
    const lines = code.split('\n');
    const currentLine = lines[line - 1] || '';
    const newSuggestion = getSuggestion(currentLine);
    setSuggestion(newSuggestion);
    setShowAcceptHint(!!newSuggestion);
  }, [code]);

  const handleFileSelect = (node: FileNode) => {
    if (node.type === 'file') {
      const existing = tabs.find(t => t.name === node.name);
      if (existing) {
        setActiveTab(existing.id);
      } else {
        const newTab: Tab = {
          id: Date.now().toString(),
          name: node.name,
          language: node.language || 'plaintext',
          modified: node.modified || false,
          content: `// ${node.name} content\n\n`,
        };
        setTabs([...tabs, newTab]);
        setActiveTab(newTab.id);
      }
    }
  };

  const closeTab = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const newTabs = tabs.filter(t => t.id !== id);
    setTabs(newTabs);
    if (activeTab === id && newTabs.length > 0) {
      setActiveTab(newTabs[0].id);
    }
  };

  const lines = code.split('\n');

  return (
    <div className="flex-1 flex h-full bg-editor overflow-hidden">
      {/* File Explorer */}
      <div className="w-56 bg-sidebar border-r border-border flex flex-col">
        <div className="px-3 py-2 border-b border-border flex items-center justify-between">
          <span className="text-xs font-medium uppercase text-muted-foreground tracking-wider">Explorer</span>
          <div className="flex gap-1">
            <Button variant="ghost" size="icon" className="h-5 w-5"><Plus className="h-3 w-3" /></Button>
            <Button variant="ghost" size="icon" className="h-5 w-5"><RefreshCw className="h-3 w-3" /></Button>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto py-1">
          {mockFileTree.map((node, i) => (
            <FileTreeNode key={i} node={node} onFileSelect={handleFileSelect} />
          ))}
        </div>
        <div className="border-t border-border p-2">
          <div className="flex items-center gap-2 px-2 py-1.5 rounded bg-card">
            <GitBranch className="h-3.5 w-3.5 text-syntax-string" />
            <span className="text-xs text-muted-foreground">feature/workspace-context</span>
          </div>
        </div>
      </div>

      {/* Editor Area */}
      <div className="flex-1 flex flex-col">
        {/* Tabs */}
        <div className="h-9 bg-sidebar border-b border-border flex items-center">
          <div className="flex items-center overflow-x-auto">
            {tabs.map((tab) => (
              <div
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  "flex items-center gap-2 px-3 h-9 border-r border-border cursor-pointer group transition-colors",
                  activeTab === tab.id ? "bg-editor text-foreground" : "bg-sidebar text-muted-foreground hover:bg-sidebar-hover"
                )}
              >
                <span className="text-syntax-function text-xs">TS</span>
                <span className="text-xs">{tab.name}</span>
                {tab.modified && <Circle className="h-2 w-2 fill-primary text-primary" />}
                <button onClick={(e) => closeTab(tab.id, e)} className="opacity-0 group-hover:opacity-100 hover:bg-muted rounded p-0.5 transition-opacity">
                  <X className="h-3 w-3" />
                </button>
              </div>
            ))}
          </div>
          <div className="ml-auto flex items-center gap-1 px-2">
            <Button variant="ghost" size="icon" className="h-6 w-6"><Play className="h-3.5 w-3.5 text-syntax-string" /></Button>
            <Button variant="ghost" size="icon" className="h-6 w-6"><Bug className="h-3.5 w-3.5 text-syntax-number" /></Button>
          </div>
        </div>

        {/* Code Content */}
        <div className="flex-1 overflow-hidden flex flex-col relative">
          {/* Breadcrumb */}
          <div className="h-6 px-4 flex items-center gap-1 text-xs text-muted-foreground border-b border-border bg-editor flex-shrink-0">
            <span>src</span>
            <ChevronRight className="h-3 w-3" />
            <span>agent</span>
            <ChevronRight className="h-3 w-3" />
            <span className="text-foreground">{activeTabData?.name || 'context.ts'}</span>
          </div>

          {/* Code Editor with Ghost Text */}
          <div className="flex-1 flex overflow-hidden">
            {/* Line Numbers */}
            <div className="w-12 flex-shrink-0 pt-2 text-right pr-4 select-none bg-editor overflow-hidden">
              {lines.map((_, i) => (
                <div key={i} className={cn("h-5 text-xs leading-5", i + 1 === cursorLine ? "text-foreground" : "text-editor-gutter")}>
                  {i + 1}
                </div>
              ))}
            </div>

            {/* Editor with ghost text */}
            <GhostTextEditor
              value={code}
              onChange={handleCodeChange}
              suggestion={suggestion}
              onAcceptSuggestion={handleAcceptSuggestion}
              cursorLine={cursorLine}
              onCursorChange={handleCursorChange}
            />
          </div>

          {/* Copilot Accept Hint */}
          {showAcceptHint && suggestion && (
            <div className="absolute bottom-16 right-4 animate-fade-in">
              <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-primary/20 border border-primary/30 text-xs">
                <Sparkles className="h-3.5 w-3.5 text-primary" />
                <span className="text-muted-foreground">Press</span>
                <kbd className="px-1.5 py-0.5 bg-muted rounded text-foreground font-mono">Tab</kbd>
                <span className="text-muted-foreground">to accept</span>
              </div>
            </div>
          )}

          {/* AI Suggestion Overlay */}
          {showAISuggestion && (
            <div className="absolute bottom-4 right-4 w-80 animate-fade-in">
              <div className="rounded-lg border border-primary/30 bg-card/95 backdrop-blur-sm shadow-lg overflow-hidden">
                <div className="px-3 py-2 border-b border-border flex items-center gap-2 bg-primary/10">
                  <Sparkles className="h-4 w-4 text-primary" />
                  <span className="text-xs font-medium">NAVI Suggestion</span>
                  <Button variant="ghost" size="icon" className="h-5 w-5 ml-auto" onClick={() => setShowAISuggestion(false)}>
                    <X className="h-3 w-3" />
                  </Button>
                </div>
                <div className="p-3">
                  <p className="text-xs text-muted-foreground mb-2">Add error handling for the file watcher:</p>
                  <pre className="p-2 rounded bg-editor text-[10px] font-mono text-syntax-variable overflow-x-auto mb-3">
{`try {
  await this.watcher.start();
} catch (error) {
  console.error('[NAVI]:', error);
}`}
                  </pre>
                  <div className="flex gap-2">
                    <Button variant="ai" size="xs" className="flex-1"><Check className="h-3 w-3 mr-1" />Apply</Button>
                    <Button variant="outline" size="xs" className="flex-1">Explain</Button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Status Bar */}
        <div className="h-6 bg-primary/10 border-t border-border flex items-center px-3 justify-between text-[10px] text-muted-foreground flex-shrink-0">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1"><Sparkles className="h-3 w-3 text-primary" />NAVI Copilot Active</span>
            <span className="flex items-center gap-1"><GitBranch className="h-3 w-3" />feature/workspace-context</span>
          </div>
          <div className="flex items-center gap-4">
            <span>TypeScript</span>
            <span>UTF-8</span>
            <span>Ln {cursorLine}, Col {cursorCol}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
