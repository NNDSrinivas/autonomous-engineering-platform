import { useState } from 'react';
import { 
  Copy, 
  Check, 
  X, 
  Maximize2, 
  Minimize2,
  FileCode
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';

// Mock file contents for demo
const mockFileContents: Record<string, { content: string; language: string }> = {
  'NaviChat.tsx': {
    language: 'typescript',
    content: `import { useState, useRef, useEffect } from 'react';
import { Send, Bot, User } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

export function NaviChat({ selectedTask, userName }) {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([]);
  
  const handleSend = async () => {
    if (!input.trim()) return;
    // Send message logic
    setInput('');
  };

  return (
    <div className="flex-1 flex flex-col">
      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-6">
        {messages.map((msg) => (
          <div key={msg.id}>{msg.content}</div>
        ))}
      </div>
      
      {/* Input */}
      <div className="p-4 border-t">
        <Input 
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask NAVI..."
        />
      </div>
    </div>
  );
}`,
  },
  'button.tsx': {
    language: 'typescript',
    content: `import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center...",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground",
        destructive: "bg-destructive text-destructive-foreground",
        outline: "border border-input bg-background",
        secondary: "bg-secondary text-secondary-foreground",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 rounded-md px-3",
        lg: "h-11 rounded-md px-8",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return (
      <Comp
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        {...props}
      />
    );
  }
);
Button.displayName = "Button";

export { Button, buttonVariants };`,
  },
  'useTheme.ts': {
    language: 'typescript',
    content: `import { useState, useEffect } from 'react';

type Theme = 'light' | 'dark' | 'system';

export function useTheme() {
  const [theme, setTheme] = useState<Theme>('dark');

  useEffect(() => {
    const stored = localStorage.getItem('theme') as Theme;
    if (stored) setTheme(stored);
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    root.classList.remove('light', 'dark');
    
    if (theme === 'system') {
      const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches 
        ? 'dark' 
        : 'light';
      root.classList.add(systemTheme);
    } else {
      root.classList.add(theme);
    }
    
    localStorage.setItem('theme', theme);
  }, [theme]);

  return { theme, setTheme };
}`,
  },
  'index.css': {
    language: 'css',
    content: `@tailwind base;
@tailwind components;
@tailwind utilities;

:root {
  --background: 222.2 84% 4.9%;
  --foreground: 210 40% 98%;
  --primary: 217.2 91.2% 59.8%;
  --primary-foreground: 222.2 47.4% 11.2%;
  --secondary: 217.2 32.6% 17.5%;
  --muted: 217.2 32.6% 17.5%;
  --accent: 217.2 32.6% 17.5%;
  --border: 217.2 32.6% 17.5%;
}

.dark {
  --background: 222.2 84% 4.9%;
  --foreground: 210 40% 98%;
}

@layer base {
  * {
    @apply border-border;
  }
  body {
    @apply bg-background text-foreground;
  }
}`,
  },
  'package.json': {
    language: 'json',
    content: `{
  "name": "navi-app",
  "private": true,
  "version": "0.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "tsc && vite build",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.3.1",
    "react-dom": "^18.3.1",
    "react-router-dom": "^6.30.1",
    "@supabase/supabase-js": "^2.89.0",
    "lucide-react": "^0.462.0",
    "tailwindcss": "^3.4.0"
  },
  "devDependencies": {
    "@types/react": "^18.3.0",
    "typescript": "^5.5.0",
    "vite": "^5.4.0"
  }
}`,
  },
};

// Syntax highlighting colors
const syntaxColors: Record<string, string> = {
  keyword: 'text-purple-400',
  string: 'text-green-400',
  number: 'text-orange-400',
  comment: 'text-muted-foreground italic',
  function: 'text-yellow-400',
  variable: 'text-blue-400',
  type: 'text-cyan-400',
  operator: 'text-pink-400',
  property: 'text-sky-400',
};

function highlightCode(code: string, language: string): React.ReactNode[] {
  const lines = code.split('\n');
  
  return lines.map((line, lineIndex) => {
    // Simple syntax highlighting
    let highlighted = line;
    
    if (language === 'typescript' || language === 'javascript') {
      // Keywords
      highlighted = highlighted.replace(
        /\b(import|export|from|const|let|var|function|return|if|else|for|while|class|extends|interface|type|async|await|default|new|this|typeof|null|undefined|true|false)\b/g,
        '<span class="text-purple-400">$1</span>'
      );
      // Strings
      highlighted = highlighted.replace(
        /(["'`])(?:(?!\1)[^\\]|\\.)*?\1/g,
        '<span class="text-green-400">$&</span>'
      );
      // Comments
      highlighted = highlighted.replace(
        /(\/\/.*$|\/\*[\s\S]*?\*\/)/gm,
        '<span class="text-muted-foreground italic">$1</span>'
      );
      // JSX tags
      highlighted = highlighted.replace(
        /(&lt;\/?[A-Z][a-zA-Z]*)/g,
        '<span class="text-cyan-400">$1</span>'
      );
    } else if (language === 'css') {
      // Properties
      highlighted = highlighted.replace(
        /([a-z-]+)(?=\s*:)/g,
        '<span class="text-sky-400">$1</span>'
      );
      // Values
      highlighted = highlighted.replace(
        /:\s*([^;]+)/g,
        ': <span class="text-orange-400">$1</span>'
      );
      // Selectors
      highlighted = highlighted.replace(
        /^(\.[a-zA-Z-]+|[a-z]+|\*)/gm,
        '<span class="text-yellow-400">$1</span>'
      );
    } else if (language === 'json') {
      // Keys
      highlighted = highlighted.replace(
        /"([^"]+)"(?=\s*:)/g,
        '<span class="text-sky-400">"$1"</span>'
      );
      // String values
      highlighted = highlighted.replace(
        /:\s*"([^"]+)"/g,
        ': <span class="text-green-400">"$1"</span>'
      );
      // Numbers
      highlighted = highlighted.replace(
        /:\s*(\d+)/g,
        ': <span class="text-orange-400">$1</span>'
      );
    }
    
    return (
      <div key={lineIndex} className="flex">
        <span className="w-10 text-right pr-4 text-muted-foreground/50 select-none flex-shrink-0">
          {lineIndex + 1}
        </span>
        <span 
          className="flex-1"
          dangerouslySetInnerHTML={{ __html: highlighted }}
        />
      </div>
    );
  });
}

interface CodePreviewProps {
  fileName: string | null;
  onClose?: () => void;
}

export function CodePreview({ fileName, onClose }: CodePreviewProps) {
  const [copied, setCopied] = useState(false);
  const [isMaximized, setIsMaximized] = useState(false);

  if (!fileName) {
    return (
      <div className="h-full flex items-center justify-center text-muted-foreground bg-panel-content">
        <div className="text-center">
          <FileCode className="h-12 w-12 mx-auto mb-4 opacity-50" />
          <p className="text-sm">Select a file to preview</p>
          <p className="text-xs mt-1">Click on any file in the explorer</p>
        </div>
      </div>
    );
  }

  const fileData = mockFileContents[fileName];
  
  if (!fileData) {
    return (
      <div className="h-full flex items-center justify-center text-muted-foreground bg-panel-content">
        <div className="text-center">
          <FileCode className="h-12 w-12 mx-auto mb-4 opacity-50" />
          <p className="text-sm">Preview not available</p>
          <p className="text-xs mt-1">{fileName}</p>
        </div>
      </div>
    );
  }

  const handleCopy = async () => {
    await navigator.clipboard.writeText(fileData.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className={cn(
      "h-full flex flex-col bg-panel-content",
      isMaximized && "fixed inset-0 z-50"
    )}>
      {/* Header */}
      <div className="h-10 flex items-center justify-between px-3 border-b border-border bg-secondary/30">
        <div className="flex items-center gap-2">
          <FileCode className="h-4 w-4 text-blue-400" />
          <span className="text-xs font-medium">{fileName}</span>
          <span className="text-[10px] text-muted-foreground px-1.5 py-0.5 rounded bg-secondary">
            {fileData.language}
          </span>
        </div>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" className="h-6 w-6" onClick={handleCopy}>
            {copied ? <Check className="h-3 w-3 text-green-400" /> : <Copy className="h-3 w-3" />}
          </Button>
          <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setIsMaximized(!isMaximized)}>
            {isMaximized ? <Minimize2 className="h-3 w-3" /> : <Maximize2 className="h-3 w-3" />}
          </Button>
          {onClose && (
            <Button variant="ghost" size="icon" className="h-6 w-6" onClick={onClose}>
              <X className="h-3 w-3" />
            </Button>
          )}
        </div>
      </div>

      {/* Code content */}
      <ScrollArea className="flex-1">
        <pre className="p-4 text-xs font-mono leading-relaxed">
          <code>{highlightCode(fileData.content, fileData.language)}</code>
        </pre>
      </ScrollArea>
    </div>
  );
}