import { useState, useEffect, useRef } from 'react';
import { Search, Code2, FileCode2, X, Loader2, ExternalLink, Copy, Check } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { useSemanticCodeSearch } from '@/hooks/useSemanticCodeSearch';
import Prism from 'prismjs';

interface CodeSearchPanelProps {
  isOpen: boolean;
  onClose: () => void;
  onInsertContext: (context: string) => void;
}

export function CodeSearchPanel({ isOpen, onClose, onInsertContext }: CodeSearchPanelProps) {
  const [query, setQuery] = useState('');
  const [copiedPath, setCopiedPath] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const { isSearching, searchResults, searchCode, clearResults } = useSemanticCodeSearch();

  // Focus input when panel opens
  useEffect(() => {
    if (isOpen && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [isOpen]);

  // Search on query change with debounce
  useEffect(() => {
    if (!query.trim()) {
      clearResults();
      return;
    }

    const timer = setTimeout(() => {
      searchCode(query, { limit: 10 });
    }, 300);

    return () => clearTimeout(timer);
  }, [query, searchCode, clearResults]);

  const handleInsertResult = (result: { path: string; snippet: string; language: string }) => {
    const contextBlock = `**📁 ${result.path}** (${result.language})\n\`\`\`${result.language}\n${result.snippet}\n\`\`\``;
    onInsertContext(contextBlock);
    onClose();
  };

  const handleInsertAll = () => {
    if (searchResults.length === 0) return;
    
    const contextParts = ['📁 **Code Context:**\n'];
    for (const result of searchResults.slice(0, 5)) {
      contextParts.push(`### ${result.path}`);
      contextParts.push('```' + result.language);
      contextParts.push(result.snippet);
      contextParts.push('```\n');
    }
    onInsertContext(contextParts.join('\n'));
    onClose();
  };

  const copyPath = async (path: string) => {
    await navigator.clipboard.writeText(path);
    setCopiedPath(path);
    setTimeout(() => setCopiedPath(null), 2000);
  };

  if (!isOpen) return null;

  return (
    <div className="absolute bottom-full left-0 right-0 mb-2 bg-popover border border-border rounded-xl shadow-xl overflow-hidden z-50 animate-fade-in">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-border bg-secondary/30">
        <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center">
          <Code2 className="h-4 w-4 text-primary" />
        </div>
        <div className="flex-1">
          <h3 className="text-sm font-medium">Semantic Code Search</h3>
          <p className="text-[10px] text-muted-foreground">Search indexed repository files for context</p>
        </div>
        <Button variant="ghost" size="icon" onClick={onClose} className="h-8 w-8">
          <X className="h-4 w-4" />
        </Button>
      </div>

      {/* Search Input */}
      <div className="p-3 border-b border-border">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search for functions, components, APIs..."
            className="pl-10 pr-10 h-10 bg-background"
          />
          {isSearching && (
            <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 animate-spin text-muted-foreground" />
          )}
        </div>
      </div>

      {/* Results */}
      <ScrollArea className="max-h-80">
        <div className="p-3">
          {searchResults.length === 0 && query.trim() && !isSearching && (
            <div className="text-center py-8 text-muted-foreground">
              <FileCode2 className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No matching files found</p>
              <p className="text-xs mt-1">Try different keywords or index your repository first</p>
            </div>
          )}

          {searchResults.length === 0 && !query.trim() && (
            <div className="text-center py-8 text-muted-foreground">
              <Search className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">Start typing to search indexed files</p>
              <p className="text-xs mt-1">Results will include code snippets and context</p>
            </div>
          )}

          {searchResults.length > 0 && (
            <div className="space-y-3">
              {/* Insert all button */}
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted-foreground">
                  {searchResults.length} result{searchResults.length !== 1 ? 's' : ''} found
                </span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleInsertAll}
                  className="h-7 text-xs gap-1"
                >
                  Insert Top {Math.min(5, searchResults.length)} as Context
                </Button>
              </div>

              {/* Results list */}
              {searchResults.map((result, index) => (
                <div
                  key={`${result.path}-${index}`}
                  className="group rounded-lg border border-border bg-card hover:border-primary/50 transition-colors overflow-hidden"
                >
                  {/* File header */}
                  <div className="flex items-center gap-2 px-3 py-2 bg-secondary/30 border-b border-border">
                    <FileCode2 className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                    <span className="text-xs font-mono truncate flex-1">{result.path}</span>
                    <Badge variant="outline" className="text-[10px] px-1.5 py-0">
                      {result.language}
                    </Badge>
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => copyPath(result.path)}
                        className="h-6 w-6"
                        title="Copy path"
                      >
                        {copiedPath === result.path ? (
                          <Check className="h-3 w-3 text-green-500" />
                        ) : (
                          <Copy className="h-3 w-3" />
                        )}
                      </Button>
                    </div>
                  </div>

                  {/* Code snippet */}
                  <div className="relative">
                    <pre className="p-3 text-xs font-mono overflow-x-auto bg-terminal max-h-32">
                      <code className={`language-${result.language}`}>
                        {result.snippet}
                      </code>
                    </pre>
                    
                    {/* Hover actions */}
                    <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button
                        variant="secondary"
                        size="sm"
                        onClick={() => handleInsertResult(result)}
                        className="h-7 text-xs gap-1 shadow-md"
                      >
                        <ExternalLink className="h-3 w-3" />
                        Insert as Context
                      </Button>
                    </div>
                  </div>

                  {/* Score indicator */}
                  <div className="px-3 py-1.5 border-t border-border bg-secondary/20">
                    <div className="flex items-center gap-2">
                      <div className="flex-1 h-1 bg-secondary rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-primary rounded-full transition-all"
                          style={{ width: `${Math.min(100, result.score)}%` }}
                        />
                      </div>
                      <span className="text-[10px] text-muted-foreground">
                        {Math.round(result.score)}% match
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </ScrollArea>

      {/* Footer tips */}
      <div className="px-4 py-2 border-t border-border bg-secondary/20">
        <p className="text-[10px] text-muted-foreground text-center">
          💡 Tip: Use specific function or component names for better results
        </p>
      </div>
    </div>
  );
}
