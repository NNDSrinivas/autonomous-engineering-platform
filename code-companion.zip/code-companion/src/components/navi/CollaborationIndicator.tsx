import { useState, useEffect } from 'react';
import { Bot, Eye, Edit3, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';

interface Collaborator {
  id: string;
  name: string;
  type: 'user' | 'ai';
  status: 'viewing' | 'editing' | 'thinking';
  file?: string;
}

// Mock collaborators - in real app this would come from WebSocket/Realtime
const mockCollaborators: Collaborator[] = [
  { id: 'navi', name: 'NAVI', type: 'ai', status: 'viewing' },
];

interface CollaborationIndicatorProps {
  className?: string;
  currentFile?: string | null;
  isNaviThinking?: boolean;
  naviCurrentFile?: string | null;
}

export function CollaborationIndicator({ 
  className,
  currentFile,
  isNaviThinking = false,
  naviCurrentFile
}: CollaborationIndicatorProps) {
  const [collaborators, setCollaborators] = useState<Collaborator[]>(mockCollaborators);

  // Update NAVI status based on props
  useEffect(() => {
    setCollaborators(prev => prev.map(c => {
      if (c.id === 'navi') {
        return {
          ...c,
          status: isNaviThinking ? 'thinking' : (naviCurrentFile ? 'editing' : 'viewing'),
          file: naviCurrentFile || undefined
        };
      }
      return c;
    }));
  }, [isNaviThinking, naviCurrentFile]);

  const getStatusIcon = (status: Collaborator['status']) => {
    switch (status) {
      case 'editing': return <Edit3 className="h-2.5 w-2.5" />;
      case 'thinking': return <Loader2 className="h-2.5 w-2.5 animate-spin" />;
      default: return <Eye className="h-2.5 w-2.5" />;
    }
  };

  const getStatusColor = (status: Collaborator['status']) => {
    switch (status) {
      case 'editing': return 'bg-yellow-500';
      case 'thinking': return 'bg-primary animate-pulse';
      default: return 'bg-green-500';
    }
  };

  return (
    <div className={cn("flex items-center gap-1", className)}>
      {collaborators.map((collaborator) => (
        <Tooltip key={collaborator.id}>
          <TooltipTrigger asChild>
            <div className="relative">
              <div className={cn(
                "h-6 w-6 rounded-full flex items-center justify-center text-primary-foreground",
                collaborator.type === 'ai' ? 'gradient-ai' : 'bg-secondary'
              )}>
                {collaborator.type === 'ai' ? (
                  <Bot className="h-3 w-3" />
                ) : (
                  <span className="text-[10px] font-medium">{collaborator.name.charAt(0)}</span>
                )}
              </div>
              <div className={cn(
                "absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full flex items-center justify-center text-white",
                getStatusColor(collaborator.status)
              )}>
                {getStatusIcon(collaborator.status)}
              </div>
            </div>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="text-xs">
            <div className="font-medium">{collaborator.name}</div>
            <div className="text-muted-foreground capitalize">
              {collaborator.status === 'thinking' && 'Thinking...'}
              {collaborator.status === 'editing' && `Editing ${collaborator.file || 'file'}`}
              {collaborator.status === 'viewing' && 'Viewing'}
            </div>
          </TooltipContent>
        </Tooltip>
      ))}
    </div>
  );
}

// Mini indicator for file explorer/code preview
export function FileCollaborationIndicator({ 
  fileName,
  isNaviEditing = false 
}: { 
  fileName: string;
  isNaviEditing?: boolean;
}) {
  if (!isNaviEditing) return null;

  return (
    <div className="flex items-center gap-1 text-[10px] text-primary">
      <div className="h-4 w-4 rounded-full gradient-ai flex items-center justify-center">
        <Edit3 className="h-2 w-2 text-primary-foreground" />
      </div>
      <span>NAVI editing</span>
    </div>
  );
}
