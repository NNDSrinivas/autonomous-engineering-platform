import { useState, useEffect } from 'react';
import { 
  Terminal, 
  Play, 
  Check, 
  X, 
  Shield,
  Clock,
  ChevronDown,
  ChevronUp,
  Loader2,
  AlertTriangle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';

export type CommandApprovalChoice = 'allow' | 'always_allow' | 'skip';

export interface CommandToApprove {
  id: string;
  command: string;
  description?: string;
  type: 'terminal' | 'file_write' | 'api_call' | 'git' | 'system';
  risk: 'low' | 'medium' | 'high';
  workingDir?: string;
  timestamp: Date;
  status: 'pending' | 'approved' | 'skipped' | 'running' | 'completed' | 'failed';
  output?: string;
}

interface CommandApprovalCardProps {
  command: CommandToApprove;
  onApprove: (choice: CommandApprovalChoice) => void;
  onSkip: () => void;
  isProcessing?: boolean;
}

const typeConfig: Record<CommandToApprove['type'], { icon: React.ReactNode; label: string; color: string }> = {
  terminal: { icon: <Terminal className="h-4 w-4" />, label: 'Terminal', color: 'text-green-400' },
  file_write: { icon: <Terminal className="h-4 w-4" />, label: 'File Write', color: 'text-blue-400' },
  api_call: { icon: <Terminal className="h-4 w-4" />, label: 'API Call', color: 'text-purple-400' },
  git: { icon: <Terminal className="h-4 w-4" />, label: 'Git', color: 'text-orange-400' },
  system: { icon: <Terminal className="h-4 w-4" />, label: 'System', color: 'text-pink-400' },
};

const riskConfig: Record<CommandToApprove['risk'], { label: string; color: string; bgColor: string }> = {
  low: { label: 'Low Risk', color: 'text-status-success', bgColor: 'bg-status-success/10 border-status-success/30' },
  medium: { label: 'Medium Risk', color: 'text-status-warning', bgColor: 'bg-status-warning/10 border-status-warning/30' },
  high: { label: 'High Risk', color: 'text-status-error', bgColor: 'bg-status-error/10 border-status-error/30' },
};

export function CommandApprovalCard({
  command,
  onApprove,
  onSkip,
  isProcessing = false,
}: CommandApprovalCardProps) {
  const [isExpanded, setIsExpanded] = useState(true);
  const [showOutput, setShowOutput] = useState(false);
  
  const typeInfo = typeConfig[command.type];
  const riskInfo = riskConfig[command.risk];

  // Pulse animation for pending commands
  const isPending = command.status === 'pending';
  const isRunning = command.status === 'running';
  const isComplete = command.status === 'completed' || command.status === 'failed' || command.status === 'skipped';

  return (
    <div className={cn(
      "rounded-lg border overflow-hidden transition-all duration-300",
      isPending && "border-primary/50 bg-primary/5 animate-pulse",
      isRunning && "border-yellow-400/50 bg-yellow-400/5",
      command.status === 'completed' && "border-status-success/30 bg-status-success/5",
      command.status === 'failed' && "border-status-error/30 bg-status-error/5",
      command.status === 'skipped' && "border-muted-foreground/30 bg-muted/50 opacity-60"
    )}>
      <Collapsible open={isExpanded} onOpenChange={setIsExpanded}>
        <CollapsibleTrigger className="w-full">
          <div className="flex items-center justify-between p-3 hover:bg-secondary/30 transition-colors">
            <div className="flex items-center gap-3">
              {/* Status indicator */}
              <div className={cn(
                "relative h-8 w-8 rounded-full flex items-center justify-center",
                isPending && "bg-primary/20",
                isRunning && "bg-yellow-400/20",
                command.status === 'completed' && "bg-status-success/20",
                command.status === 'failed' && "bg-status-error/20",
                command.status === 'skipped' && "bg-muted-foreground/20"
              )}>
                {isPending && (
                  <div className="absolute inset-0 rounded-full bg-primary/30 animate-ping" />
                )}
                {isRunning && <Loader2 className="h-4 w-4 animate-spin text-yellow-400" />}
                {command.status === 'completed' && <Check className="h-4 w-4 text-status-success" />}
                {command.status === 'failed' && <X className="h-4 w-4 text-status-error" />}
                {command.status === 'skipped' && <X className="h-4 w-4 text-muted-foreground" />}
                {isPending && <Clock className="h-4 w-4 text-primary relative z-10" />}
              </div>

              <div className="text-left">
                <div className="flex items-center gap-2">
                  <span className={cn("text-sm font-medium", typeInfo.color)}>
                    {typeInfo.label} Command
                  </span>
                  {isPending && (
                    <Badge variant="outline" className={cn("text-[10px] uppercase border", riskInfo.bgColor, riskInfo.color)}>
                      {riskInfo.label}
                    </Badge>
                  )}
                  {command.status === 'approved' && (
                    <Badge variant="secondary" className="text-[10px]">Approved</Badge>
                  )}
                </div>
                <p className="text-xs text-muted-foreground font-mono truncate max-w-[300px]">
                  {command.command.substring(0, 50)}{command.command.length > 50 ? '...' : ''}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {isRunning && (
                <Badge variant="outline" className="text-[10px] bg-yellow-400/10 border-yellow-400/30 text-yellow-400">
                  Running...
                </Badge>
              )}
              {isExpanded ? (
                <ChevronUp className="h-4 w-4 text-muted-foreground" />
              ) : (
                <ChevronDown className="h-4 w-4 text-muted-foreground" />
              )}
            </div>
          </div>
        </CollapsibleTrigger>

        <CollapsibleContent>
          <div className="px-3 pb-3 space-y-3">
            {/* Command details */}
            <div className="p-3 rounded-md bg-terminal border border-border">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Terminal className="h-3 w-3 text-muted-foreground" />
                  <span className="text-[10px] uppercase text-muted-foreground tracking-wider">Command</span>
                </div>
                {command.workingDir && (
                  <span className="text-[10px] text-muted-foreground font-mono">
                    {command.workingDir}
                  </span>
                )}
              </div>
              <code className="text-xs font-mono text-foreground whitespace-pre-wrap break-all">
                {command.command}
              </code>
            </div>

            {/* Description */}
            {command.description && (
              <div className="text-xs text-muted-foreground">
                {command.description}
              </div>
            )}

            {/* Risk warning for high risk commands */}
            {command.risk === 'high' && isPending && (
              <div className="flex items-start gap-2 p-2 rounded-md bg-status-error/10 border border-status-error/30">
                <AlertTriangle className="h-4 w-4 text-status-error flex-shrink-0 mt-0.5" />
                <p className="text-xs text-status-error">
                  This command has high risk. Review carefully before approving.
                </p>
              </div>
            )}

            {/* Command output */}
            {command.output && (
              <Collapsible open={showOutput} onOpenChange={setShowOutput}>
                <CollapsibleTrigger asChild>
                  <Button variant="ghost" size="sm" className="text-xs gap-1 h-6 px-2">
                    {showOutput ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
                    Output
                  </Button>
                </CollapsibleTrigger>
                <CollapsibleContent>
                  <pre className="mt-2 p-2 rounded-md bg-terminal text-[10px] font-mono text-muted-foreground max-h-32 overflow-auto whitespace-pre-wrap">
                    {command.output}
                  </pre>
                </CollapsibleContent>
              </Collapsible>
            )}

            {/* Approval buttons - only show for pending commands */}
            {isPending && (
              <div className="flex items-center gap-2 pt-2 border-t border-border">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={onSkip}
                  disabled={isProcessing}
                  className="h-8 text-xs gap-1.5 text-muted-foreground hover:text-foreground"
                >
                  <X className="h-3.5 w-3.5" />
                  Skip
                </Button>
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => onApprove('always_allow')}
                  disabled={isProcessing}
                  className="h-8 text-xs gap-1.5"
                >
                  <Shield className="h-3.5 w-3.5" />
                  Always Allow
                </Button>
                <Button
                  variant="ai"
                  size="sm"
                  onClick={() => onApprove('allow')}
                  disabled={isProcessing}
                  className="h-8 text-xs gap-1.5 flex-1"
                >
                  {isProcessing ? (
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  ) : (
                    <Play className="h-3.5 w-3.5" />
                  )}
                  {isProcessing ? 'Running...' : 'Allow'}
                </Button>
              </div>
            )}
          </div>
        </CollapsibleContent>
      </Collapsible>
    </div>
  );
}

// Mini inline version for the activity panel
export function CommandApprovalInline({
  command,
  onApprove,
  onSkip,
}: Omit<CommandApprovalCardProps, 'isProcessing'>) {
  const isPending = command.status === 'pending';
  const riskInfo = riskConfig[command.risk];

  if (!isPending) return null;

  return (
    <div className="flex items-center gap-2 p-2 rounded-md bg-primary/10 border border-primary/30 animate-pulse">
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <Terminal className="h-3 w-3 text-primary flex-shrink-0" />
          <span className="text-xs font-mono truncate">{command.command}</span>
        </div>
        <Badge variant="outline" className={cn("mt-1 text-[9px] uppercase", riskInfo.bgColor, riskInfo.color)}>
          {riskInfo.label}
        </Badge>
      </div>
      <div className="flex gap-1 flex-shrink-0">
        <Button
          variant="ghost"
          size="icon"
          onClick={onSkip}
          className="h-6 w-6"
          title="Skip"
        >
          <X className="h-3 w-3" />
        </Button>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => onApprove('always_allow')}
          className="h-6 w-6"
          title="Always Allow"
        >
          <Shield className="h-3 w-3" />
        </Button>
        <Button
          variant="ai"
          size="icon"
          onClick={() => onApprove('allow')}
          className="h-6 w-6"
          title="Allow"
        >
          <Play className="h-3 w-3" />
        </Button>
      </div>
    </div>
  );
}
