import { useState, useEffect, useCallback } from 'react';
import {
  Command,
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from '@/components/ui/command';
import { 
  Search, 
  FileText, 
  MessageSquare, 
  Video, 
  GitBranch, 
  Activity,
  LayoutGrid,
  Settings,
  User,
  Zap,
  Play,
  Bug,
  RefreshCw,
  Terminal,
  Database,
  Cloud,
  Plus,
  FolderOpen,
  Sparkles
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

interface CommandPaletteProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const commandGroups = [
  {
    heading: 'Navigation',
    items: [
      { icon: Search, label: 'Universal Search', shortcut: '⌘K', description: 'Search everything', category: 'search' },
      { icon: LayoutGrid, label: 'Tasks Panel', shortcut: '⌘T', description: 'View Jira tasks', category: 'search' },
      { icon: Activity, label: 'Activity Feed', shortcut: '⌘⇧A', description: 'View recent activity', category: 'search' },
      { icon: RefreshCw, label: 'History', shortcut: '⌘H', description: 'View chat history', category: 'search' },
      { icon: Settings, label: 'Settings', shortcut: '⌘,', description: 'Open preferences', category: 'settings' },
      { icon: Cloud, label: 'Integrations', shortcut: '⌘⇧I', description: 'Manage connectors', category: 'settings' },
    ],
  },
  {
    heading: 'NAVI Actions',
    items: [
      { icon: Sparkles, label: 'Ask NAVI', shortcut: '⌘B', description: 'Focus chat input', category: 'ai' },
      { icon: Play, label: 'Start Working on Task', description: 'Begin current Jira task', category: 'ai' },
      { icon: FileText, label: 'Explain Selected Code', shortcut: '⌘E', description: 'Get AI explanation', category: 'ai' },
      { icon: Bug, label: 'Debug with NAVI', shortcut: '⌘D', description: 'AI-powered debugging', category: 'ai' },
    ],
  },
  {
    heading: 'Search',
    items: [
      { icon: LayoutGrid, label: 'Search Jira Tasks', description: 'Find Jira issues', category: 'search' },
      { icon: MessageSquare, label: 'Search Slack/Teams', description: 'Search messages', category: 'search' },
      { icon: FileText, label: 'Search Confluence', description: 'Find documentation', category: 'search' },
      { icon: Video, label: 'Search Meetings', description: 'Find meeting notes', category: 'search' },
      { icon: GitBranch, label: 'Search Git History', description: 'Search commits & PRs', category: 'search' },
    ],
  },
  {
    heading: 'Actions',
    items: [
      { icon: GitBranch, label: 'Create Pull Request', shortcut: '⌘⇧P', description: 'Open new PR', category: 'git' },
      { icon: Activity, label: 'Run CI/CD Pipeline', description: 'Trigger build', category: 'ci' },
      { icon: Terminal, label: 'Open Terminal', shortcut: '⌘`', description: 'New terminal window', category: 'dev' },
      { icon: RefreshCw, label: 'Sync All Integrations', description: 'Refresh data', category: 'system' },
    ],
  },
  {
    heading: 'Notifications',
    items: [
      { icon: Plus, label: 'Toggle Notifications', shortcut: '⌘N', description: 'Show/hide notifications', category: 'system' },
    ],
  },
  {
    heading: 'General',
    items: [
      { icon: User, label: 'Profile', description: 'Manage profile', category: 'settings' },
      { icon: Database, label: 'Memory & Context', description: 'View NAVI memory', category: 'settings' },
    ],
  },
];

const recentItems = [
  { icon: FileText, label: 'context.ts', type: 'file' },
  { icon: LayoutGrid, label: 'AEP-142: Add workspace-aware agent loop', type: 'task' },
  { icon: MessageSquare, label: '#engineering - Discussion on context retention', type: 'slack' },
];

export function CommandPalette({ open, onOpenChange }: CommandPaletteProps) {
  const [search, setSearch] = useState('');

  // Handle keyboard shortcut ⌘/
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === '/' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        onOpenChange(!open);
      }
    };

    document.addEventListener('keydown', down);
    return () => document.removeEventListener('keydown', down);
  }, [open, onOpenChange]);

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'ai': return 'text-primary';
      case 'search': return 'text-syntax-function';
      case 'git': return 'text-syntax-string';
      case 'ci': return 'text-syntax-number';
      case 'dev': return 'text-syntax-keyword';
      case 'integration': return 'text-syntax-type';
      case 'settings': return 'text-muted-foreground';
      default: return 'text-muted-foreground';
    }
  };

  return (
    <CommandDialog open={open} onOpenChange={onOpenChange}>
      <Command className="rounded-lg border shadow-md">
        <div className="flex items-center border-b px-3 gap-2">
          <Zap className="h-4 w-4 text-primary" />
          <CommandInput 
            placeholder="Ask NAVI or search across all integrations..." 
            value={search}
            onValueChange={setSearch}
            className="h-12"
          />
        </div>
        <CommandList className="max-h-[400px]">
          <CommandEmpty>
            <div className="py-6 text-center">
              <Sparkles className="h-8 w-8 mx-auto mb-2 text-primary opacity-50" />
              <p className="text-sm text-muted-foreground">No results found.</p>
              <p className="text-xs text-muted-foreground mt-1">
                Ask NAVI: "{search}"
              </p>
            </div>
          </CommandEmpty>

          {/* Recent Items */}
          {!search && (
            <>
              <CommandGroup heading="Recent">
                {recentItems.map((item, i) => (
                  <CommandItem key={i} className="gap-3">
                    <item.icon className="h-4 w-4 text-muted-foreground" />
                    <span className="flex-1">{item.label}</span>
                    <Badge variant="outline" className="text-[10px]">
                      {item.type}
                    </Badge>
                  </CommandItem>
                ))}
              </CommandGroup>
              <CommandSeparator />
            </>
          )}

          {/* Command Groups */}
          {commandGroups.map((group) => (
            <CommandGroup key={group.heading} heading={group.heading}>
              {group.items.map((item) => (
                <CommandItem key={item.label} className="gap-3">
                  <item.icon className={cn("h-4 w-4", getCategoryColor(item.category))} />
                  <div className="flex-1">
                    <span>{item.label}</span>
                    <span className="text-xs text-muted-foreground ml-2">
                      {item.description}
                    </span>
                  </div>
                  {item.shortcut && (
                    <kbd className="px-1.5 py-0.5 text-[10px] font-mono bg-muted rounded">
                      {item.shortcut}
                    </kbd>
                  )}
                </CommandItem>
              ))}
            </CommandGroup>
          ))}
        </CommandList>
        
        {/* Footer */}
        <div className="border-t px-3 py-2 flex items-center justify-between text-[10px] text-muted-foreground">
          <div className="flex gap-4">
            <span className="flex items-center gap-1">
              <kbd className="px-1 py-0.5 bg-muted rounded">↑↓</kbd> Navigate
            </span>
            <span className="flex items-center gap-1">
              <kbd className="px-1 py-0.5 bg-muted rounded">↵</kbd> Select
            </span>
            <span className="flex items-center gap-1">
              <kbd className="px-1 py-0.5 bg-muted rounded">esc</kbd> Close
            </span>
          </div>
          <span className="flex items-center gap-1">
            <Sparkles className="h-3 w-3 text-primary" />
            Powered by NAVI
          </span>
        </div>
      </Command>
    </CommandDialog>
  );
}
