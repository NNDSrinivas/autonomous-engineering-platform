import { useState } from 'react';
import { Search, FileText, ExternalLink, Loader2, BookOpen, RefreshCw } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { useAtlassianMCP, ConfluenceMCPPage } from '@/hooks/useAtlassianMCP';

interface ConfluenceSearchPanelProps {
  onPageSelect?: (page: ConfluenceMCPPage) => void;
  confluencePages?: ConfluenceMCPPage[];
  isLoading?: boolean;
  onRefresh?: () => void;
}

export function ConfluenceSearchPanel({ 
  onPageSelect, 
  confluencePages = [], 
  isLoading = false,
  onRefresh 
}: ConfluenceSearchPanelProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const { cloudUrl, isLoading: processingLoading } = useAtlassianMCP();

  const filteredPages = confluencePages.filter(page =>
    page.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    page.body?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 7) return `${diffDays} days ago`;
    return date.toLocaleDateString();
  };

  return (
    <div className="flex flex-col h-full bg-sidebar">
      {/* Header */}
      <div className="px-4 py-3 border-b border-border">
        <div className="flex items-center justify-between mb-2">
          <h2 className="font-semibold text-sm flex items-center gap-2">
            <div className="h-5 w-5 rounded bg-blue-500/20 flex items-center justify-center">
              <BookOpen className="h-3 w-3 text-blue-400" />
            </div>
            Confluence Docs
          </h2>
          {onRefresh && (
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-7 w-7"
              onClick={onRefresh}
              disabled={isLoading || processingLoading}
            >
              <RefreshCw className={cn("h-4 w-4", (isLoading || processingLoading) && "animate-spin")} />
            </Button>
          )}
        </div>
        <p className="text-xs text-muted-foreground mb-3">
          {confluencePages.length} pages via Atlassian MCP
        </p>
        
        {/* Search Input */}
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search documentation..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 h-8 text-sm"
          />
        </div>
      </div>

      {/* Content */}
      <ScrollArea className="flex-1">
        {isLoading || processingLoading ? (
          <div className="flex items-center justify-center h-32">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : filteredPages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-32 px-4 text-center">
            <FileText className="h-8 w-8 text-muted-foreground mb-2" />
            <p className="text-sm text-muted-foreground">
              {searchQuery ? 'No pages match your search' : 'No Confluence pages found'}
            </p>
          </div>
        ) : (
          <div className="p-2 space-y-1">
            {filteredPages.map((page) => (
              <button
                key={page.id}
                onClick={() => onPageSelect?.(page)}
                className="w-full px-3 py-2.5 rounded-lg text-left hover:bg-sidebar-hover transition-colors group"
              >
                <div className="flex items-start gap-3">
                  <FileText className="h-4 w-4 text-blue-400 mt-0.5 flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <h3 className="text-sm font-medium text-foreground truncate group-hover:text-primary transition-colors">
                      {page.title}
                    </h3>
                    {page.body && (
                      <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                        {page.body.substring(0, 150)}...
                      </p>
                    )}
                    <div className="flex items-center gap-2 mt-1.5">
                      <Badge variant="outline" className="text-[10px] px-1.5 py-0">
                        {page.status}
                      </Badge>
                      <span className="text-[10px] text-muted-foreground">
                        {formatDate(page.createdAt)}
                      </span>
                    </div>
                  </div>
                  <ExternalLink className="h-3.5 w-3.5 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity mt-0.5" />
                </div>
              </button>
            ))}
          </div>
        )}
      </ScrollArea>

      {/* Footer */}
      <div className="px-4 py-2 border-t border-border">
        <a
          href={`${cloudUrl}/wiki`}
          target="_blank"
          rel="noopener noreferrer"
          className="text-xs text-primary hover:underline flex items-center gap-1"
        >
          Open Confluence
          <ExternalLink className="h-3 w-3" />
        </a>
      </div>
    </div>
  );
}
