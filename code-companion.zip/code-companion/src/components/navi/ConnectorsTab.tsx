import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { 
  Plug, 
  Loader2, 
  Eye, 
  EyeOff, 
  Save, 
  Trash2,
  CheckCircle2,
  AlertCircle,
  Building2,
  Copy,
  ExternalLink
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface OAuthConfig {
  id: string;
  provider: string;
  client_id: string;
  client_secret: string;
  created_at: string;
  updated_at: string;
}

interface Organization {
  id: string;
  name: string;
  slug: string;
}

const providerInfo: Record<string, { name: string; docUrl: string; instructions: string }> = {
  github: {
    name: 'GitHub',
    docUrl: 'https://docs.github.com/en/apps/oauth-apps/building-oauth-apps/creating-an-oauth-app',
    instructions: 'Create an OAuth App in GitHub Settings > Developer settings > OAuth Apps',
  },
  slack: {
    name: 'Slack',
    docUrl: 'https://api.slack.com/apps',
    instructions: 'Create an app at api.slack.com/apps, then add OAuth scopes and get credentials',
  },
  jira: {
    name: 'Jira / Atlassian',
    docUrl: 'https://developer.atlassian.com/cloud/jira/platform/oauth-2-3lo-apps/',
    instructions: 'Create an OAuth 2.0 app in Atlassian Developer Console',
  },
  confluence: {
    name: 'Confluence',
    docUrl: 'https://developer.atlassian.com/cloud/confluence/oauth-2-3lo-apps/',
    instructions: 'Uses the same Atlassian OAuth app as Jira',
  },
  google_calendar: {
    name: 'Google Calendar',
    docUrl: 'https://console.cloud.google.com/apis/credentials',
    instructions: 'Create OAuth 2.0 credentials in Google Cloud Console with Calendar API enabled',
  },
  microsoft_calendar: {
    name: 'Microsoft 365 / Outlook',
    docUrl: 'https://portal.azure.com/#view/Microsoft_AAD_RegisteredApps/ApplicationsListBlade',
    instructions: 'Register an app in Azure AD with Calendars.Read permission',
  },
};

const availableProviders = ['google_calendar', 'microsoft_calendar', 'github', 'slack', 'jira', 'confluence'];

// Get the OAuth callback URL
const getCallbackUrl = () => {
  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
  return `${supabaseUrl}/functions/v1/oauth?action=callback`;
};

export function ConnectorsTab() {
  const [configs, setConfigs] = useState<OAuthConfig[]>([]);
  const [organization, setOrganization] = useState<Organization | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState<string | null>(null);
  const [editingProvider, setEditingProvider] = useState<string | null>(null);
  const [showSecrets, setShowSecrets] = useState<Record<string, boolean>>({});
  const [formData, setFormData] = useState<Record<string, { client_id: string; client_secret: string }>>({});
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    fetchOrganizationAndConfigs();
  }, []);

  const fetchOrganizationAndConfigs = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      // Get user's current organization from profile
      const { data: profile } = await supabase
        .from('profiles')
        .select('current_organization_id')
        .eq('user_id', session.user.id)
        .maybeSingle();

      if (!profile?.current_organization_id) {
        // No org yet - check if they have any org memberships
        const { data: memberships } = await supabase
          .from('organization_members')
          .select('organization_id, role, organizations(id, name, slug)')
          .eq('user_id', session.user.id)
          .limit(1);

        if (memberships && memberships.length > 0) {
          const membership = memberships[0];
          const org = membership.organizations as unknown as Organization;
          setOrganization(org);
          setIsAdmin(membership.role === 'owner' || membership.role === 'admin');
          
          // Update profile with current org
          await supabase
            .from('profiles')
            .update({ current_organization_id: org.id })
            .eq('user_id', session.user.id);

          if (membership.role === 'owner' || membership.role === 'admin') {
            await fetchOAuthConfigs(org.id);
          }
        }
        setIsLoading(false);
        return;
      }

      // Get organization details
      const { data: org } = await supabase
        .from('organizations')
        .select('*')
        .eq('id', profile.current_organization_id)
        .single();

      if (org) {
        setOrganization(org);

        // Check if user is admin
        const { data: membership } = await supabase
          .from('organization_members')
          .select('role')
          .eq('organization_id', org.id)
          .eq('user_id', session.user.id)
          .single();

        const userIsAdmin = membership?.role === 'owner' || membership?.role === 'admin';
        setIsAdmin(userIsAdmin);

        if (userIsAdmin) {
          await fetchOAuthConfigs(org.id);
        }
      }
    } catch (error) {
      console.error('Error fetching organization:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchOAuthConfigs = async (orgId: string) => {
    const { data, error } = await supabase
      .from('organization_oauth_configs')
      .select('*')
      .eq('organization_id', orgId);

    if (error) {
      console.error('Error fetching OAuth configs:', error);
      return;
    }

    setConfigs(data || []);
    
    // Initialize form data for existing configs
    const newFormData: Record<string, { client_id: string; client_secret: string }> = {};
    data?.forEach(config => {
      newFormData[config.provider] = {
        client_id: config.client_id,
        client_secret: config.client_secret,
      };
    });
    setFormData(newFormData);
  };

  const createOrganization = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const orgName = session.user.email?.split('@')[0] || 'My Organization';
      const slug = orgName.toLowerCase().replace(/[^a-z0-9]/g, '-') + '-' + Date.now();

      // Create organization
      const { data: org, error: orgError } = await supabase
        .from('organizations')
        .insert({ name: orgName, slug })
        .select()
        .single();

      if (orgError) throw orgError;

      // Add user as owner
      const { error: memberError } = await supabase
        .from('organization_members')
        .insert({
          organization_id: org.id,
          user_id: session.user.id,
          role: 'owner',
        });

      if (memberError) throw memberError;

      // Update profile
      await supabase
        .from('profiles')
        .update({ current_organization_id: org.id })
        .eq('user_id', session.user.id);

      setOrganization(org);
      setIsAdmin(true);
      toast.success('Organization created');
    } catch (error) {
      console.error('Error creating organization:', error);
      toast.error('Failed to create organization');
    }
  };

  const saveConfig = async (provider: string) => {
    if (!organization || !formData[provider]) return;

    const { client_id, client_secret } = formData[provider];
    if (!client_id || !client_secret) {
      toast.error('Both Client ID and Client Secret are required');
      return;
    }

    setIsSaving(provider);
    try {
      const existingConfig = configs.find(c => c.provider === provider);

      if (existingConfig) {
        const { error } = await supabase
          .from('organization_oauth_configs')
          .update({ client_id, client_secret })
          .eq('id', existingConfig.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('organization_oauth_configs')
          .insert({
            organization_id: organization.id,
            provider,
            client_id,
            client_secret,
          });

        if (error) throw error;
      }

      await fetchOAuthConfigs(organization.id);
      setEditingProvider(null);
      toast.success(`${providerInfo[provider]?.name || provider} credentials saved`);
    } catch (error) {
      console.error('Error saving config:', error);
      toast.error('Failed to save credentials');
    } finally {
      setIsSaving(null);
    }
  };

  const deleteConfig = async (provider: string) => {
    if (!organization) return;

    const config = configs.find(c => c.provider === provider);
    if (!config) return;

    try {
      const { error } = await supabase
        .from('organization_oauth_configs')
        .delete()
        .eq('id', config.id);

      if (error) throw error;

      await fetchOAuthConfigs(organization.id);
      setFormData(prev => {
        const updated = { ...prev };
        delete updated[provider];
        return updated;
      });
      toast.success(`${providerInfo[provider]?.name || provider} credentials removed`);
    } catch (error) {
      console.error('Error deleting config:', error);
      toast.error('Failed to remove credentials');
    }
  };

  const toggleShowSecret = (provider: string) => {
    setShowSecrets(prev => ({ ...prev, [provider]: !prev[provider] }));
  };

  const updateFormData = (provider: string, field: 'client_id' | 'client_secret', value: string) => {
    setFormData(prev => ({
      ...prev,
      [provider]: {
        ...prev[provider],
        [field]: value,
      },
    }));
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!organization) {
    return (
      <div className="rounded-xl border border-border bg-card p-6 text-center">
        <Building2 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
        <h3 className="font-medium mb-2">No Organization</h3>
        <p className="text-sm text-muted-foreground mb-4">
          Create an organization to configure OAuth credentials for your team.
        </p>
        <Button onClick={createOrganization}>
          Create Organization
        </Button>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="rounded-xl border border-border bg-card p-6 text-center">
        <AlertCircle className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
        <h3 className="font-medium mb-2">Admin Access Required</h3>
        <p className="text-sm text-muted-foreground">
          Only organization admins can configure OAuth credentials.
          Contact your organization admin to set up integrations.
        </p>
      </div>
    );
  }

  const callbackUrl = getCallbackUrl();

  const copyCallbackUrl = () => {
    navigator.clipboard.writeText(callbackUrl);
    toast.success('Callback URL copied to clipboard');
  };

  return (
    <div className="space-y-6">
      {/* OAuth Support Notice */}
      <div className="rounded-xl border border-amber-500/30 bg-amber-500/5 p-4 space-y-2">
        <div className="flex items-center gap-2">
          <AlertCircle className="h-4 w-4 text-amber-500" />
          <h4 className="font-medium text-sm text-amber-500">OAuth Integration Status</h4>
        </div>
        <p className="text-xs text-muted-foreground">
          <strong>Currently supported:</strong> Google OAuth is fully supported.
        </p>
        <p className="text-xs text-muted-foreground">
          <strong>Coming soon:</strong> GitHub, Jira, Slack, and Confluence OAuth integrations are not yet available in Lovable Cloud.
          You can configure credentials below for when support becomes available.
        </p>
      </div>

      {/* OAuth Callback URL Helper */}
      <div className="rounded-xl border border-primary/30 bg-primary/5 p-4 space-y-3">
        <div className="flex items-center gap-2">
          <ExternalLink className="h-4 w-4 text-primary" />
          <h4 className="font-medium text-sm">OAuth Redirect URL</h4>
        </div>
        <p className="text-xs text-muted-foreground">
          When creating your OAuth apps, use this URL as the callback/redirect URL:
        </p>
        <div className="flex items-center gap-2">
          <code className="flex-1 px-3 py-2 rounded-md bg-background border border-border text-xs font-mono break-all">
            {callbackUrl}
          </code>
          <Button variant="outline" size="sm" onClick={copyCallbackUrl}>
            <Copy className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="rounded-xl border border-border bg-card p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-medium flex items-center gap-2">
              <Plug className="h-4 w-4" />
              OAuth Credentials
            </h3>
            <p className="text-sm text-muted-foreground mt-1">
              Configure OAuth app credentials for <span className="font-medium">{organization.name}</span>
            </p>
          </div>
          <Badge variant="outline">
            <Building2 className="h-3 w-3 mr-1" />
            {organization.name}
          </Badge>
        </div>

        <div className="space-y-4">
          {availableProviders.map(provider => {
            const info = providerInfo[provider];
            const config = configs.find(c => c.provider === provider);
            const isEditing = editingProvider === provider;
            const data = formData[provider] || { client_id: '', client_secret: '' };

            return (
              <div key={provider} className="rounded-lg border border-border p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      "h-2 w-2 rounded-full",
                      config ? 'bg-green-400' : 'bg-muted-foreground'
                    )} />
                    <div>
                      <p className="font-medium">{info.name}</p>
                      <p className="text-xs text-muted-foreground">{info.instructions}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {config ? (
                      <Badge variant="secondary" className="gap-1">
                        <CheckCircle2 className="h-3 w-3" />
                        Configured
                      </Badge>
                    ) : (
                      <Badge variant="outline">Not configured</Badge>
                    )}
                  </div>
                </div>

                {(isEditing || !config) && (
                  <div className="space-y-3 pt-2 border-t border-border">
                    <div className="space-y-2">
                      <Label>Client ID</Label>
                      <Input
                        value={data.client_id}
                        onChange={(e) => updateFormData(provider, 'client_id', e.target.value)}
                        placeholder="Enter Client ID"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Client Secret</Label>
                      <div className="relative">
                        <Input
                          type={showSecrets[provider] ? 'text' : 'password'}
                          value={data.client_secret}
                          onChange={(e) => updateFormData(provider, 'client_secret', e.target.value)}
                          placeholder="Enter Client Secret"
                          className="pr-10"
                        />
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="absolute right-0 top-0 h-full px-3"
                          onClick={() => toggleShowSecret(provider)}
                        >
                          {showSecrets[provider] ? (
                            <EyeOff className="h-4 w-4" />
                          ) : (
                            <Eye className="h-4 w-4" />
                          )}
                        </Button>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        size="sm"
                        onClick={() => saveConfig(provider)}
                        disabled={isSaving === provider}
                      >
                        {isSaving === provider ? (
                          <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        ) : (
                          <Save className="h-4 w-4 mr-2" />
                        )}
                        Save
                      </Button>
                      {config && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setEditingProvider(null)}
                        >
                          Cancel
                        </Button>
                      )}
                      <a
                        href={info.docUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs text-primary hover:underline ml-auto"
                      >
                        View setup guide →
                      </a>
                    </div>
                  </div>
                )}

                {config && !isEditing && (
                  <div className="flex items-center gap-2 pt-2 border-t border-border">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setEditingProvider(provider);
                        setFormData(prev => ({
                          ...prev,
                          [provider]: {
                            client_id: config.client_id,
                            client_secret: config.client_secret,
                          },
                        }));
                      }}
                    >
                      Edit Credentials
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deleteConfig(provider)}
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Remove
                    </Button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      <div className="rounded-xl border border-border bg-card/50 p-4">
        <p className="text-xs text-muted-foreground">
          <strong>How it works:</strong> Once you configure OAuth credentials, your team members can connect their accounts 
          using the "Connect" buttons on integration cards. The credentials are stored securely and used to authenticate with 
          each provider's OAuth flow.
        </p>
      </div>
    </div>
  );
}
