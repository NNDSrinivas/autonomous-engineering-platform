import { useState } from 'react';
import { 
  ChevronDown, 
  ChevronRight, 
  FileText, 
  MessageSquare, 
  Video, 
  GitBranch,
  Activity,
  ExternalLink,
  Search,
  RefreshCw,
  Inbox
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';
import { useIntegrations } from '@/hooks/useIntegrations';
import type { JiraTask, GitHubPR, CICDBuild, MeetingNote } from '@/types';

interface ContextPanelProps {
  selectedTask: JiraTask | null;
}

function CollapsibleSection({ 
  title, 
  icon, 
  count, 
  children, 
  defaultOpen = true,
  isEmpty = false
}: { 
  title: string;
  icon: React.ReactNode;
  count?: number;
  children: React.ReactNode;
  defaultOpen?: boolean;
  isEmpty?: boolean;
}) {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="border-b border-border">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full px-4 py-3 flex items-center gap-2 hover:bg-sidebar-hover transition-colors"
      >
        {isOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
        {icon}
        <span className="text-sm font-medium flex-1 text-left">{title}</span>
        {count !== undefined && (
          <Badge variant="secondary" className="text-xs">{count}</Badge>
        )}
      </button>
      {isOpen && (
        <div className="px-4 pb-3 animate-fade-in">
          {isEmpty ? (
            <p className="text-xs text-muted-foreground text-center py-2">
              No data available
            </p>
          ) : (
            children
          )}
        </div>
      )}
    </div>
  );
}

export function ContextPanel({ selectedTask }: ContextPanelProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const { integrations } = useIntegrations();
  
  const githubConnected = integrations.find(i => i.type === 'github')?.status === 'connected';
  const cicdConnected = integrations.find(i => i.type === 'cicd')?.status === 'connected';
  const zoomConnected = integrations.find(i => i.type === 'zoom')?.status === 'connected';

  // Empty arrays - will be populated when integrations fetch real data
  const relatedPRs: GitHubPR[] = [];
  const builds: CICDBuild[] = [];
  const meetings: MeetingNote[] = [];

  return (
    <div className="w-80 bg-sidebar border-l border-border flex flex-col h-full">
      {/* Header */}
      <div className="px-4 py-3 border-b border-border">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold text-sm">Context</h2>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button variant="ghost" size="xs" className="h-7 w-7 p-0">
                <RefreshCw className="h-3.5 w-3.5" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>Refresh context</TooltipContent>
          </Tooltip>
        </div>
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search context..."
            className="h-8 pl-8 text-xs bg-input"
          />
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto">
        {selectedTask ? (
          <>
            {/* Current Task */}
            <CollapsibleSection
              title="Current Task"
              icon={<FileText className="h-4 w-4 text-blue-400" />}
            >
              <div className="p-3 rounded-lg bg-card border border-border">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xs font-mono text-primary">{selectedTask.key}</span>
                  <Badge variant="outline" className="text-[10px] bg-blue-500/10 text-blue-400 border-blue-500/30">
                    {selectedTask.status.replace('_', ' ')}
                  </Badge>
                </div>
                <h3 className="text-sm font-medium mb-1">{selectedTask.title}</h3>
                <p className="text-xs text-muted-foreground line-clamp-2">
                  {selectedTask.description}
                </p>
              </div>
            </CollapsibleSection>

            {/* Related PRs */}
            <CollapsibleSection
              title="Related PRs"
              icon={<GitBranch className="h-4 w-4 text-green-400" />}
              count={relatedPRs.length}
              isEmpty={!githubConnected || relatedPRs.length === 0}
            >
              {!githubConnected ? (
                <p className="text-xs text-muted-foreground text-center py-2">
                  Connect GitHub to see related PRs
                </p>
              ) : (
                <div className="space-y-2">
                  {relatedPRs.map((pr) => (
                    <a
                      key={pr.id}
                      href={pr.url}
                      className="block p-2.5 rounded-lg bg-card border border-border hover:bg-secondary transition-colors group"
                    >
                      <div className="flex items-start gap-2">
                        <GitBranch className={cn(
                          "h-4 w-4 mt-0.5",
                          pr.checksStatus === 'passing' ? 'text-green-400' : 'text-red-400'
                        )} />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-muted-foreground">#{pr.number}</span>
                            <Badge 
                              variant="outline" 
                              className={cn(
                                "text-[10px] px-1",
                                pr.reviewStatus === 'approved' && 'bg-green-500/10 text-green-400 border-green-500/30',
                                pr.reviewStatus === 'changes_requested' && 'bg-yellow-500/10 text-yellow-400 border-yellow-500/30',
                                pr.reviewStatus === 'pending' && 'bg-muted text-muted-foreground'
                              )}
                            >
                              {pr.reviewStatus.replace('_', ' ')}
                            </Badge>
                          </div>
                          <p className="text-xs font-medium truncate mt-0.5">{pr.title}</p>
                          <div className="flex items-center gap-3 mt-1 text-[10px] text-muted-foreground">
                            <span className="text-green-400">+{pr.additions}</span>
                            <span className="text-red-400">-{pr.deletions}</span>
                            <span>{pr.comments} comments</span>
                          </div>
                        </div>
                        <ExternalLink className="h-3 w-3 text-muted-foreground opacity-0 group-hover:opacity-100" />
                      </div>
                    </a>
                  ))}
                </div>
              )}
            </CollapsibleSection>

            {/* CI/CD Status */}
            <CollapsibleSection
              title="Build Status"
              icon={<Activity className="h-4 w-4 text-orange-400" />}
              count={builds.length}
              isEmpty={!cicdConnected || builds.length === 0}
            >
              {!cicdConnected ? (
                <p className="text-xs text-muted-foreground text-center py-2">
                  Connect CI/CD to see build status
                </p>
              ) : (
                <div className="space-y-2">
                  {builds.map((build) => (
                    <div
                      key={build.id}
                      className="p-2.5 rounded-lg bg-card border border-border"
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <span className={cn(
                          "w-2 h-2 rounded-full",
                          build.status === 'success' && 'bg-green-400',
                          build.status === 'failed' && 'bg-red-400',
                          build.status === 'running' && 'bg-yellow-400 animate-pulse'
                        )} />
                        <span className="text-xs font-medium">{build.pipeline}</span>
                        <span className="text-[10px] text-muted-foreground ml-auto">
                          {build.duration ? `${Math.floor(build.duration / 60)}m ${build.duration % 60}s` : 'Running...'}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
                        <span className="font-mono">{build.commit}</span>
                        <span>on {build.branch}</span>
                      </div>
                      {build.failureReason && (
                        <p className="text-[10px] text-red-400 mt-1">{build.failureReason}</p>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CollapsibleSection>

            {/* Recent Meetings */}
            <CollapsibleSection
              title="Meeting Notes"
              icon={<Video className="h-4 w-4 text-sky-400" />}
              count={meetings.length}
              isEmpty={!zoomConnected || meetings.length === 0}
            >
              {!zoomConnected ? (
                <p className="text-xs text-muted-foreground text-center py-2">
                  Connect Zoom to see meeting notes
                </p>
              ) : (
                <div className="space-y-2">
                  {meetings.map((meeting) => (
                    <div
                      key={meeting.id}
                      className="p-2.5 rounded-lg bg-card border border-border"
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <Video className="h-3.5 w-3.5 text-sky-400" />
                        <span className="text-xs font-medium flex-1">{meeting.title}</span>
                        <Badge variant="outline" className="text-[10px]">{meeting.type.replace('_', ' ')}</Badge>
                      </div>
                      <p className="text-[10px] text-muted-foreground line-clamp-2 mb-2">
                        {meeting.summary}
                      </p>
                      {meeting.decisions.length > 0 && (
                        <div className="text-[10px]">
                          <span className="text-muted-foreground">Decisions: </span>
                          <span className="text-foreground">{meeting.decisions.join(', ')}</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </CollapsibleSection>

            {/* Discussions */}
            <CollapsibleSection
              title="Discussions"
              icon={<MessageSquare className="h-4 w-4 text-purple-400" />}
              count={(selectedTask.relatedMessages?.length || 0)}
              defaultOpen={false}
              isEmpty={!selectedTask.relatedMessages || selectedTask.relatedMessages.length === 0}
            >
              <div className="space-y-2">
                {selectedTask.relatedMessages?.map((msg, i) => (
                  <a
                    key={i}
                    href={msg.url}
                    className="block p-2.5 rounded-lg bg-card border border-border hover:bg-secondary transition-colors"
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <MessageSquare className={cn(
                        "h-3.5 w-3.5",
                        msg.type === 'slack' ? 'text-purple-400' : 'text-violet-400'
                      )} />
                      <span className="text-xs font-medium truncate">{msg.title}</span>
                    </div>
                    {msg.snippet && (
                      <p className="text-[10px] text-muted-foreground line-clamp-2">{msg.snippet}</p>
                    )}
                  </a>
                ))}
              </div>
            </CollapsibleSection>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-center p-6">
            <div className="h-12 w-12 rounded-xl bg-muted flex items-center justify-center mb-3">
              <Inbox className="h-6 w-6 text-muted-foreground" />
            </div>
            <h3 className="text-sm font-medium mb-1">No Task Selected</h3>
            <p className="text-xs text-muted-foreground">
              Select a task from the panel to see related context, PRs, builds, and discussions.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
