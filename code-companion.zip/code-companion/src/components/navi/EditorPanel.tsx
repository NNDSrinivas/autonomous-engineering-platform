import { useState } from 'react';
import { 
  X, 
  Maximize2, 
  Minimize2,
  Settings,
  History,
  FileText,
  Activity,
  Search,
  FolderTree,
  Brain,
  MessageSquare,
  BookOpen,
  Sun,
  GitBranch,
  Play,
  Zap,
  Clock,
  Code,
  Link,
  Sparkles,
  Shield,
  Video,
  Users,
  FileCode
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { SettingsPanel } from './SettingsPanel';
import { ActivityFeed } from './ActivityFeed';
import { TaskPanel } from './TaskPanel';
import { UniversalSearch } from './UniversalSearch';
import { IntegrationStatus } from './IntegrationStatus';
import { ContextPanel } from './ContextPanel';
import { FileExplorer } from './FileExplorer';
import { CodePreview } from './CodePreview';
import { GeneratedCodePreview } from './GeneratedCodePreview';
import { MemoryPanel } from './MemoryPanel';
import { SlackPanel } from './SlackPanel';
import { ConfluenceSearchPanel } from './ConfluenceSearchPanel';
import { MorningBriefing } from './MorningBriefing';
import { GitHubPanel } from './GitHubPanel';
import { CICDPanel } from './CICDPanel';
import { WorkflowExecutor } from './WorkflowExecutor';
import { WorkflowHistoryPanel } from './WorkflowHistoryPanel';
import { AICodeGenerator } from './AICodeGenerator';
import { TaskCorrelationPanel } from './TaskCorrelationPanel';
import { GitHubActions } from './GitHubActions';
import { AISummarizer } from './AISummarizer';
import { PendingApprovalsPanel } from './PendingApprovalsPanel';
import { ApprovalSettingsPanel } from './ApprovalSettingsPanel';
import { ZoomPanel } from './ZoomPanel';
import { TeamsPanel } from './TeamsPanel';
import { CICDDashboard } from './CICDDashboard';
import { CalendarPanel } from './CalendarPanel';
import { UnifiedNotificationCenter } from './UnifiedNotificationCenter';
import { WorkflowAnalyticsDashboard } from './WorkflowAnalyticsDashboard';
import { WorkflowQueuePanel } from './WorkflowQueuePanel';
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from '@/components/ui/resizable';
import type { JiraTask } from '@/types';
import type { ConfluenceMCPPage } from '@/hooks/useAtlassianMCP';

interface GeneratedFile {
  path: string;
  content: string;
  action: 'create' | 'modify' | 'delete';
}

type EditorView = 'settings' | 'activity' | 'tasks' | 'search' | 'integrations' | 'context' | 'history' | 'files' | 'memory' | 'slack' | 'confluence' | 'briefing' | 'github' | 'cicd' | 'workflows' | 'workflow' | 'autonomous-workflow' | 'workflow-history' | 'ai-code' | 'task-correlation' | 'github-actions' | 'ai-summarize' | 'approvals' | 'approval-settings' | 'zoom' | 'teams' | 'cicd-dashboard' | 'calendar' | 'notifications' | 'analytics' | 'queue' | 'code-preview' | null;

interface EditorPanelProps {
  activeView: EditorView;
  onClose: () => void;
  selectedTask?: JiraTask | null;
  onTaskSelect?: (task: JiraTask) => void;
  selectedFileName?: string | null;
  onFileSelect?: (fileName: string | null) => void;
  onStartWorkflow?: (task: JiraTask) => void;
  generatedFiles?: GeneratedFile[];
  onCommitFiles?: (branchName: string, commitMessage: string) => Promise<void>;
  isCommitting?: boolean;
}

const viewConfig: Record<string, { title: string; icon: React.ReactNode }> = {
  settings: { title: 'Settings', icon: <Settings className="h-4 w-4" /> },
  activity: { title: 'Activity', icon: <Activity className="h-4 w-4" /> },
  tasks: { title: 'Tasks', icon: <FileText className="h-4 w-4" /> },
  search: { title: 'Search', icon: <Search className="h-4 w-4" /> },
  integrations: { title: 'Integrations', icon: <Activity className="h-4 w-4" /> },
  context: { title: 'Context', icon: <FileText className="h-4 w-4" /> },
  history: { title: 'History', icon: <History className="h-4 w-4" /> },
  files: { title: 'File Explorer', icon: <FolderTree className="h-4 w-4" /> },
  memory: { title: 'Memory Store', icon: <Brain className="h-4 w-4" /> },
  slack: { title: 'Slack Messages', icon: <MessageSquare className="h-4 w-4" /> },
  confluence: { title: 'Confluence Docs', icon: <BookOpen className="h-4 w-4" /> },
  briefing: { title: 'Daily Briefing', icon: <Sun className="h-4 w-4" /> },
  github: { title: 'GitHub', icon: <GitBranch className="h-4 w-4" /> },
  cicd: { title: 'CI/CD Dashboard', icon: <Play className="h-4 w-4" /> },
  workflows: { title: 'Workflow Engine', icon: <Zap className="h-4 w-4" /> },
  'workflow-history': { title: 'Workflow History', icon: <Clock className="h-4 w-4" /> },
  'ai-code': { title: 'AI Code Generator', icon: <Code className="h-4 w-4" /> },
  'task-correlation': { title: 'Task Correlation', icon: <Link className="h-4 w-4" /> },
  'github-actions': { title: 'GitHub Actions', icon: <GitBranch className="h-4 w-4" /> },
  'ai-summarize': { title: 'AI Summarizer', icon: <Sparkles className="h-4 w-4" /> },
  'approvals': { title: 'Pending Approvals', icon: <Shield className="h-4 w-4" /> },
  'approval-settings': { title: 'Approval Settings', icon: <Shield className="h-4 w-4" /> },
  'zoom': { title: 'Zoom Meetings', icon: <Video className="h-4 w-4" /> },
  'teams': { title: 'Microsoft Teams', icon: <Users className="h-4 w-4" /> },
  'cicd-dashboard': { title: 'CI/CD Dashboard', icon: <Play className="h-4 w-4" /> },
  'calendar': { title: 'Calendar & Meetings', icon: <Clock className="h-4 w-4" /> },
  'notifications': { title: 'Notification Center', icon: <Activity className="h-4 w-4" /> },
  'analytics': { title: 'Workflow Analytics', icon: <Activity className="h-4 w-4" /> },
  'queue': { title: 'Workflow Queue', icon: <Zap className="h-4 w-4" /> },
  'code-preview': { title: 'Generated Code', icon: <FileCode className="h-4 w-4" /> },
};

export function EditorPanel({ 
  activeView, 
  onClose, 
  selectedTask, 
  onTaskSelect,
  selectedFileName,
  onFileSelect,
  onStartWorkflow,
  generatedFiles,
  onCommitFiles,
  isCommitting,
}: EditorPanelProps) {
  const [isMaximized, setIsMaximized] = useState(false);
  const [localSelectedFile, setLocalSelectedFile] = useState<string | null>(null);

  const currentSelectedFile = selectedFileName ?? localSelectedFile;
  const handleFileSelect = (fileName: string | null) => {
    if (onFileSelect) {
      onFileSelect(fileName);
    } else {
      setLocalSelectedFile(fileName);
    }
  };

  if (!activeView) return null;

  const config = viewConfig[activeView];

  const renderContent = () => {
    switch (activeView) {
      case 'settings':
        return <SettingsPanel />;
      case 'activity':
        return <ActivityFeed />;
      case 'tasks':
        return (
          <TaskPanel 
            onTaskSelect={onTaskSelect || (() => {})} 
            selectedTask={selectedTask || null}
            onStartWorkflow={onStartWorkflow}
          />
        );
      case 'search':
        return <UniversalSearch />;
      case 'integrations':
        return <IntegrationStatus />;
      case 'context':
        return <ContextPanel selectedTask={selectedTask || null} />;
      case 'files':
        return (
          <ResizablePanelGroup direction="horizontal" className="h-full">
            <ResizablePanel id="file-tree" order={1} defaultSize={35} minSize={20} maxSize={50}>
              <FileExplorer onFileSelect={(file) => handleFileSelect(file.name)} />
            </ResizablePanel>
            <ResizableHandle withHandle className="bg-border hover:bg-primary/20 transition-colors" />
            <ResizablePanel id="code-preview" order={2} defaultSize={65} minSize={30}>
              <CodePreview 
                fileName={currentSelectedFile} 
                onClose={() => handleFileSelect(null)}
              />
            </ResizablePanel>
          </ResizablePanelGroup>
        );
      case 'memory':
        return <MemoryPanel />;
      case 'slack':
        return <SlackPanel />;
      case 'confluence':
        return <ConfluenceSearchPanel confluencePages={[]} />;
      case 'github':
        return <GitHubPanel />;
      case 'cicd':
      case 'cicd-dashboard':
        return <CICDDashboard />;
      case 'zoom':
        return <ZoomPanel />;
      case 'teams':
        return <TeamsPanel />;
      case 'workflows':
        return <WorkflowExecutor onClose={onClose} />;
      case 'workflow-history':
        return <WorkflowHistoryPanel />;
      case 'ai-code':
        return <AICodeGenerator selectedTask={selectedTask || null} />;
      case 'task-correlation':
        return <TaskCorrelationPanel selectedTask={selectedTask || null} />;
      case 'github-actions':
        return <GitHubActions selectedTask={selectedTask || null} codeChanges={null} />;
      case 'ai-summarize':
        return <AISummarizer />;
      case 'approvals':
        return <PendingApprovalsPanel />;
      case 'approval-settings':
        return <ApprovalSettingsPanel />;
      case 'calendar':
        return <CalendarPanel />;
      case 'notifications':
        return <UnifiedNotificationCenter />;
      case 'analytics':
        return <WorkflowAnalyticsDashboard />;
      case 'queue':
        return <WorkflowQueuePanel />;
      case 'code-preview':
        return (
          <GeneratedCodePreview
            files={generatedFiles || []}
            onCommit={onCommitFiles}
            isCommitting={isCommitting}
            onClose={onClose}
          />
        );
      case 'briefing':
        return <MorningBriefing jiraTasks={[]} onDismiss={() => {}} />;
      case 'history':
        return (
          <div className="flex-1 flex items-center justify-center text-muted-foreground">
            <div className="text-center">
              <History className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p className="text-sm">Chat history will appear here</p>
              <p className="text-xs mt-1">Your conversation history with NAVI</p>
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <div 
      className={cn(
        "flex flex-col bg-panel-content h-full overflow-hidden",
        isMaximized && "fixed inset-0 z-50"
      )}
    >
      {/* Header */}
      <div className="h-12 flex items-center justify-between px-4 border-b border-border bg-panel-header">
        <div className="flex items-center gap-2">
          {config?.icon}
          <span className="font-medium text-sm">{config?.title}</span>
        </div>
        <div className="flex items-center gap-1">
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-7 w-7"
            onClick={() => setIsMaximized(!isMaximized)}
          >
            {isMaximized ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
          </Button>
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-hidden">
        {renderContent()}
      </div>
    </div>
  );
}
