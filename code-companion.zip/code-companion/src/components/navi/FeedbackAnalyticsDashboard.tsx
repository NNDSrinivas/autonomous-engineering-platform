import { useState } from 'react';
import { 
  ThumbsUp, 
  ThumbsDown, 
  TrendingUp, 
  TrendingDown,
  RefreshCw,
  AlertTriangle,
  BarChart3,
  MessageSquare,
  Calendar,
  Shield,
  Download,
  CalendarIcon
} from 'lucide-react';
import { toast } from 'sonner';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { useAdminAnalytics } from '@/hooks/useAdminAnalytics';
import { cn } from '@/lib/utils';
import { format, parseISO, isAfter, isBefore, startOfDay, endOfDay, subDays } from 'date-fns';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from 'recharts';

export function FeedbackAnalyticsDashboard() {
  const { isAdmin, isLoading, analytics, error, refetch } = useAdminAnalytics();
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [dateRange, setDateRange] = useState<{ from: Date | undefined; to: Date | undefined }>({
    from: subDays(new Date(), 30),
    to: new Date(),
  });

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await refetch();
    setIsRefreshing(false);
  };

  const exportToCSV = () => {
    if (!analytics) return;
    
    setIsExporting(true);
    try {
      // Build CSV content
      let csvContent = '';
      
      // Summary section
      csvContent += 'FEEDBACK SUMMARY\n';
      csvContent += 'Metric,Value\n';
      csvContent += `Total Likes,${analytics.total_likes}\n`;
      csvContent += `Total Dislikes,${analytics.total_dislikes}\n`;
      csvContent += `Total Feedback,${analytics.total_likes + analytics.total_dislikes}\n`;
      const rate = analytics.total_likes + analytics.total_dislikes > 0
        ? Math.round(analytics.total_likes / (analytics.total_likes + analytics.total_dislikes) * 100)
        : 0;
      csvContent += `Satisfaction Rate,${rate}%\n`;
      csvContent += '\n';
      
      // Daily breakdown
      csvContent += 'DAILY BREAKDOWN\n';
      csvContent += 'Date,Likes,Dislikes,Total\n';
      (analytics.feedback_by_day || []).forEach((day: any) => {
        const likes = Number(day.likes) || 0;
        const dislikes = Number(day.dislikes) || 0;
        csvContent += `${day.day},${likes},${dislikes},${likes + dislikes}\n`;
      });
      csvContent += '\n';
      
      // Recent negative feedback
      csvContent += 'RECENT NEGATIVE FEEDBACK\n';
      csvContent += 'Date,Message Content\n';
      (analytics.recent_dislikes || []).forEach((feedback: any) => {
        const date = feedback.created_at ? format(parseISO(feedback.created_at), 'yyyy-MM-dd HH:mm:ss') : '';
        // Escape quotes and wrap in quotes for CSV
        const content = (feedback.message_content || '').replace(/"/g, '""');
        csvContent += `${date},"${content}"\n`;
      });
      
      // Create and trigger download
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', `feedback-analytics-${format(new Date(), 'yyyy-MM-dd')}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      toast.success('Feedback data exported successfully');
    } catch (err) {
      console.error('Export error:', err);
      toast.error('Failed to export data');
    } finally {
      setIsExporting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-9 w-24" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
        </div>
        <Skeleton className="h-80" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-8 text-center">
        <div className="h-16 w-16 rounded-full bg-destructive/10 flex items-center justify-center mb-4">
          <Shield className="h-8 w-8 text-destructive" />
        </div>
        <h2 className="text-xl font-semibold mb-2">Access Denied</h2>
        <p className="text-muted-foreground max-w-md">
          You don't have permission to view the analytics dashboard. 
          This feature is only available to administrators.
        </p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-8 text-center">
        <div className="h-16 w-16 rounded-full bg-destructive/10 flex items-center justify-center mb-4">
          <AlertTriangle className="h-8 w-8 text-destructive" />
        </div>
        <h2 className="text-xl font-semibold mb-2">Error Loading Analytics</h2>
        <p className="text-muted-foreground max-w-md mb-4">{error}</p>
        <Button onClick={handleRefresh} variant="outline">
          <RefreshCw className="h-4 w-4 mr-2" />
          Try Again
        </Button>
      </div>
    );
  }

  // Filter data based on date range
  const filterByDateRange = (data: any[], dateField: string) => {
    if (!dateRange.from && !dateRange.to) return data;
    return data.filter((item: any) => {
      const itemDate = parseISO(item[dateField]);
      const fromValid = !dateRange.from || !isBefore(itemDate, startOfDay(dateRange.from));
      const toValid = !dateRange.to || !isAfter(itemDate, endOfDay(dateRange.to));
      return fromValid && toValid;
    });
  };

  const filteredDayData = filterByDateRange(analytics?.feedback_by_day || [], 'day');
  const filteredDislikes = filterByDateRange(analytics?.recent_dislikes || [], 'created_at');

  // Calculate filtered stats
  const filteredLikes = filteredDayData.reduce((sum: number, day: any) => sum + (Number(day.likes) || 0), 0);
  const filteredDislikesCount = filteredDayData.reduce((sum: number, day: any) => sum + (Number(day.dislikes) || 0), 0);
  const totalFeedback = filteredLikes + filteredDislikesCount;
  const satisfactionRate = totalFeedback > 0 
    ? Math.round(filteredLikes / totalFeedback * 100) 
    : 0;

  // Prepare chart data
  const chartData = filteredDayData.map((day: any) => ({
    date: format(parseISO(day.day), 'MMM d'),
    likes: Number(day.likes) || 0,
    dislikes: Number(day.dislikes) || 0,
  })).reverse();

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <BarChart3 className="h-6 w-6 text-primary" />
            Feedback Analytics
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Monitor AI response quality and user satisfaction
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          {/* Date Range Picker */}
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm" className="justify-start text-left font-normal">
                <CalendarIcon className="h-4 w-4 mr-2" />
                {dateRange.from ? (
                  dateRange.to ? (
                    <>
                      {format(dateRange.from, 'MMM d')} - {format(dateRange.to, 'MMM d, yyyy')}
                    </>
                  ) : (
                    format(dateRange.from, 'MMM d, yyyy')
                  )
                ) : (
                  <span>Pick a date range</span>
                )}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="end">
              <div className="flex">
                <CalendarComponent
                  mode="range"
                  selected={{ from: dateRange.from, to: dateRange.to }}
                  onSelect={(range) => setDateRange({ from: range?.from, to: range?.to })}
                  numberOfMonths={2}
                  className="pointer-events-auto"
                />
              </div>
              <div className="p-3 border-t flex gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setDateRange({ from: subDays(new Date(), 7), to: new Date() })}
                >
                  Last 7 days
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setDateRange({ from: subDays(new Date(), 30), to: new Date() })}
                >
                  Last 30 days
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setDateRange({ from: undefined, to: undefined })}
                >
                  All time
                </Button>
              </div>
            </PopoverContent>
          </Popover>

          <Button 
            onClick={exportToCSV} 
            variant="outline" 
            size="sm"
            disabled={isExporting || !analytics}
          >
            <Download className={cn("h-4 w-4 mr-2", isExporting && "animate-pulse")} />
            Export CSV
          </Button>
          <Button 
            onClick={handleRefresh} 
            variant="outline" 
            size="sm"
            disabled={isRefreshing}
          >
            <RefreshCw className={cn("h-4 w-4 mr-2", isRefreshing && "animate-spin")} />
            Refresh
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardDescription className="flex items-center gap-1">
              <ThumbsUp className="h-3.5 w-3.5" />
              Helpful Responses
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-bold text-green-500">
                {filteredLikes}
              </span>
              <TrendingUp className="h-4 w-4 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription className="flex items-center gap-1">
              <ThumbsDown className="h-3.5 w-3.5" />
              Not Helpful Responses
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-bold text-red-500">
                {filteredDislikesCount}
              </span>
              <TrendingDown className="h-4 w-4 text-red-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardDescription>Satisfaction Rate</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline gap-2">
              <span className={cn(
                "text-3xl font-bold",
                satisfactionRate >= 80 ? "text-green-500" :
                satisfactionRate >= 60 ? "text-yellow-500" : "text-red-500"
              )}>
                {satisfactionRate}%
              </span>
              <Badge variant={satisfactionRate >= 80 ? "default" : "secondary"} className="text-xs">
                {totalFeedback} total
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Calendar className="h-4 w-4" />
            Feedback Over Time
            {dateRange.from && dateRange.to && (
              <span className="text-muted-foreground font-normal text-sm ml-1">
                ({format(dateRange.from, 'MMM d')} - {format(dateRange.to, 'MMM d, yyyy')})
              </span>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis 
                  dataKey="date" 
                  tick={{ fontSize: 12 }}
                  className="text-muted-foreground"
                />
                <YAxis 
                  tick={{ fontSize: 12 }}
                  className="text-muted-foreground"
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px',
                  }}
                />
                <Legend />
                <Bar 
                  dataKey="likes" 
                  name="Helpful" 
                  fill="hsl(142, 76%, 36%)" 
                  radius={[4, 4, 0, 0]}
                />
                <Bar 
                  dataKey="dislikes" 
                  name="Not Helpful" 
                  fill="hsl(0, 84%, 60%)" 
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-[300px] text-muted-foreground">
              No feedback data available for the selected date range
            </div>
          )}
        </CardContent>
      </Card>

      {/* Recent Dislikes */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <MessageSquare className="h-4 w-4" />
            Recent Negative Feedback
          </CardTitle>
          <CardDescription>
            Review responses that users found unhelpful for improvement
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[300px]">
            {filteredDislikes && filteredDislikes.length > 0 ? (
              <div className="space-y-3">
                {filteredDislikes.map((feedback: any) => (
                  <div 
                    key={feedback.id}
                    className="p-3 rounded-lg bg-secondary/50 border border-border"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="destructive" className="text-xs">
                        <ThumbsDown className="h-3 w-3 mr-1" />
                        Not Helpful
                      </Badge>
                      <span className="text-xs text-muted-foreground">
                        {format(parseISO(feedback.created_at), 'MMM d, yyyy h:mm a')}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground line-clamp-3">
                      {feedback.message_content || 'No message content available'}
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex items-center justify-center h-full text-muted-foreground">
                No negative feedback in the selected date range
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}
