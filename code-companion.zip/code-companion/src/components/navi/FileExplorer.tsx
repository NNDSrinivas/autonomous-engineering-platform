import { useState } from 'react';
import { 
  ChevronRight, 
  ChevronDown, 
  File, 
  Folder, 
  FolderOpen,
  FileCode,
  FileJson,
  FileText,
  Image,
  FileType
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { ScrollArea } from '@/components/ui/scroll-area';

interface FileItem {
  id: string;
  name: string;
  type: 'file' | 'folder';
  children?: FileItem[];
  language?: string;
}

// Mock file structure
const mockFileTree: FileItem[] = [
  {
    id: 'src',
    name: 'src',
    type: 'folder',
    children: [
      {
        id: 'components',
        name: 'components',
        type: 'folder',
        children: [
          {
            id: 'navi',
            name: 'navi',
            type: 'folder',
            children: [
              { id: 'NaviChat.tsx', name: 'NaviChat.tsx', type: 'file', language: 'typescript' },
              { id: 'NaviHeader.tsx', name: 'NaviHeader.tsx', type: 'file', language: 'typescript' },
              { id: 'FileExplorer.tsx', name: 'FileExplorer.tsx', type: 'file', language: 'typescript' },
              { id: 'SettingsPanel.tsx', name: 'SettingsPanel.tsx', type: 'file', language: 'typescript' },
            ]
          },
          {
            id: 'ui',
            name: 'ui',
            type: 'folder',
            children: [
              { id: 'button.tsx', name: 'button.tsx', type: 'file', language: 'typescript' },
              { id: 'input.tsx', name: 'input.tsx', type: 'file', language: 'typescript' },
              { id: 'dialog.tsx', name: 'dialog.tsx', type: 'file', language: 'typescript' },
            ]
          }
        ]
      },
      {
        id: 'hooks',
        name: 'hooks',
        type: 'folder',
        children: [
          { id: 'useNaviChat.ts', name: 'useNaviChat.ts', type: 'file', language: 'typescript' },
          { id: 'useTheme.ts', name: 'useTheme.ts', type: 'file', language: 'typescript' },
        ]
      },
      {
        id: 'pages',
        name: 'pages',
        type: 'folder',
        children: [
          { id: 'Index.tsx', name: 'Index.tsx', type: 'file', language: 'typescript' },
          { id: 'Auth.tsx', name: 'Auth.tsx', type: 'file', language: 'typescript' },
        ]
      },
      { id: 'App.tsx', name: 'App.tsx', type: 'file', language: 'typescript' },
      { id: 'main.tsx', name: 'main.tsx', type: 'file', language: 'typescript' },
      { id: 'index.css', name: 'index.css', type: 'file', language: 'css' },
    ]
  },
  {
    id: 'public',
    name: 'public',
    type: 'folder',
    children: [
      { id: 'favicon.ico', name: 'favicon.ico', type: 'file', language: 'image' },
      { id: 'robots.txt', name: 'robots.txt', type: 'file', language: 'text' },
    ]
  },
  { id: 'package.json', name: 'package.json', type: 'file', language: 'json' },
  { id: 'tsconfig.json', name: 'tsconfig.json', type: 'file', language: 'json' },
  { id: 'vite.config.ts', name: 'vite.config.ts', type: 'file', language: 'typescript' },
  { id: 'tailwind.config.ts', name: 'tailwind.config.ts', type: 'file', language: 'typescript' },
  { id: 'README.md', name: 'README.md', type: 'file', language: 'markdown' },
];

function getFileIcon(language?: string) {
  switch (language) {
    case 'typescript':
    case 'javascript':
      return <FileCode className="h-4 w-4 text-blue-400" />;
    case 'json':
      return <FileJson className="h-4 w-4 text-yellow-400" />;
    case 'css':
      return <FileCode className="h-4 w-4 text-purple-400" />;
    case 'markdown':
      return <FileText className="h-4 w-4 text-muted-foreground" />;
    case 'image':
      return <Image className="h-4 w-4 text-green-400" />;
    case 'text':
      return <FileType className="h-4 w-4 text-muted-foreground" />;
    default:
      return <File className="h-4 w-4 text-muted-foreground" />;
  }
}

interface FileTreeItemProps {
  item: FileItem;
  depth: number;
  selectedFile: string | null;
  onFileSelect: (file: FileItem) => void;
  expandedFolders: Set<string>;
  onToggleFolder: (folderId: string) => void;
}

function FileTreeItem({ 
  item, 
  depth, 
  selectedFile, 
  onFileSelect,
  expandedFolders,
  onToggleFolder
}: FileTreeItemProps) {
  const isExpanded = expandedFolders.has(item.id);
  const isFolder = item.type === 'folder';
  const isSelected = selectedFile === item.id;

  const handleClick = () => {
    if (isFolder) {
      onToggleFolder(item.id);
    } else {
      onFileSelect(item);
    }
  };

  return (
    <div>
      <button
        onClick={handleClick}
        className={cn(
          "w-full flex items-center gap-1.5 px-2 py-1 text-xs rounded-md transition-colors text-left",
          "hover:bg-secondary/50",
          isSelected && "bg-primary/10 text-primary"
        )}
        style={{ paddingLeft: `${depth * 12 + 8}px` }}
      >
        {isFolder ? (
          <>
            {isExpanded ? (
              <ChevronDown className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />
            ) : (
              <ChevronRight className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />
            )}
            {isExpanded ? (
              <FolderOpen className="h-4 w-4 text-amber-400 flex-shrink-0" />
            ) : (
              <Folder className="h-4 w-4 text-amber-400 flex-shrink-0" />
            )}
          </>
        ) : (
          <>
            <span className="w-3.5" />
            {getFileIcon(item.language)}
          </>
        )}
        <span className="truncate">{item.name}</span>
      </button>
      
      {isFolder && isExpanded && item.children && (
        <div className="animate-fade-in">
          {item.children.map((child) => (
            <FileTreeItem
              key={child.id}
              item={child}
              depth={depth + 1}
              selectedFile={selectedFile}
              onFileSelect={onFileSelect}
              expandedFolders={expandedFolders}
              onToggleFolder={onToggleFolder}
            />
          ))}
        </div>
      )}
    </div>
  );
}

interface FileExplorerProps {
  onFileSelect?: (file: FileItem) => void;
}

export function FileExplorer({ onFileSelect }: FileExplorerProps) {
  const [selectedFile, setSelectedFile] = useState<string | null>(null);
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set(['src', 'components', 'navi']));

  const handleFileSelect = (file: FileItem) => {
    setSelectedFile(file.id);
    onFileSelect?.(file);
  };

  const handleToggleFolder = (folderId: string) => {
    setExpandedFolders(prev => {
      const next = new Set(prev);
      if (next.has(folderId)) {
        next.delete(folderId);
      } else {
        next.add(folderId);
      }
      return next;
    });
  };

  return (
    <div className="h-full flex flex-col bg-panel-content">
      <div className="px-3 py-2 border-b border-border">
        <h3 className="text-xs font-semibold uppercase text-muted-foreground tracking-wider">
          Explorer
        </h3>
      </div>
      <ScrollArea className="flex-1">
        <div className="py-2">
          {mockFileTree.map((item) => (
            <FileTreeItem
              key={item.id}
              item={item}
              depth={0}
              selectedFile={selectedFile}
              onFileSelect={handleFileSelect}
              expandedFolders={expandedFolders}
              onToggleFolder={handleToggleFolder}
            />
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}