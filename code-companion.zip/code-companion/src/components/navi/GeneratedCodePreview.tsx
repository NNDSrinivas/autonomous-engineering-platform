import { useState } from 'react';
import {
  X,
  FileCode,
  Check,
  Copy,
  GitBranch,
  Loader2,
  ChevronDown,
  ChevronRight,
  Plus,
  Edit3,
  Trash2,
  Eye,
  EyeOff,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

interface GeneratedFile {
  path: string;
  content: string;
  action: 'create' | 'modify' | 'delete';
}

interface GeneratedCodePreviewProps {
  files: GeneratedFile[];
  explanation?: string;
  branchName?: string;
  isCommitting?: boolean;
  onCommit?: (branchName: string, commitMessage: string) => Promise<void>;
  onClose?: () => void;
  onFileToggle?: (path: string, include: boolean) => void;
}

const ACTION_STYLES = {
  create: {
    bg: 'bg-green-500/10',
    text: 'text-green-400',
    icon: Plus,
    label: 'New',
  },
  modify: {
    bg: 'bg-yellow-500/10',
    text: 'text-yellow-400',
    icon: Edit3,
    label: 'Modified',
  },
  delete: {
    bg: 'bg-red-500/10',
    text: 'text-red-400',
    icon: Trash2,
    label: 'Deleted',
  },
};

function getLanguageFromPath(path: string): string {
  const ext = path.split('.').pop()?.toLowerCase() || '';
  const langMap: Record<string, string> = {
    ts: 'typescript',
    tsx: 'typescript',
    js: 'javascript',
    jsx: 'javascript',
    py: 'python',
    css: 'css',
    html: 'html',
    json: 'json',
    md: 'markdown',
    sql: 'sql',
    yaml: 'yaml',
    yml: 'yaml',
  };
  return langMap[ext] || 'text';
}

function highlightCode(code: string, language: string): React.ReactNode[] {
  const lines = code.split('\n');

  return lines.map((line, lineIndex) => {
    let highlighted = line
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');

    if (language === 'typescript' || language === 'javascript') {
      highlighted = highlighted.replace(
        /\b(import|export|from|const|let|var|function|return|if|else|for|while|class|extends|interface|type|async|await|default|new|this|typeof|null|undefined|true|false)\b/g,
        '<span class="text-purple-400">$1</span>'
      );
      highlighted = highlighted.replace(
        /(["'`])(?:(?!\1)[^\\]|\\.)*?\1/g,
        '<span class="text-green-400">$&</span>'
      );
      highlighted = highlighted.replace(
        /(\/\/.*$)/gm,
        '<span class="text-muted-foreground italic">$1</span>'
      );
    } else if (language === 'css') {
      highlighted = highlighted.replace(
        /([a-z-]+)(?=\s*:)/g,
        '<span class="text-sky-400">$1</span>'
      );
    } else if (language === 'json') {
      highlighted = highlighted.replace(
        /"([^"]+)"(?=\s*:)/g,
        '<span class="text-sky-400">"$1"</span>'
      );
      highlighted = highlighted.replace(
        /:\s*"([^"]+)"/g,
        ': <span class="text-green-400">"$1"</span>'
      );
    }

    return (
      <div key={lineIndex} className="flex hover:bg-secondary/30">
        <span className="w-12 text-right pr-4 text-muted-foreground/50 select-none flex-shrink-0 text-xs">
          {lineIndex + 1}
        </span>
        <span
          className="flex-1"
          dangerouslySetInnerHTML={{ __html: highlighted }}
        />
      </div>
    );
  });
}

function FileItem({
  file,
  isSelected,
  isIncluded,
  onSelect,
  onToggleInclude,
}: {
  file: GeneratedFile;
  isSelected: boolean;
  isIncluded: boolean;
  onSelect: () => void;
  onToggleInclude: () => void;
}) {
  const actionStyle = ACTION_STYLES[file.action];
  const ActionIcon = actionStyle.icon;

  return (
    <div
      className={cn(
        'flex items-center gap-2 px-3 py-2 cursor-pointer hover:bg-secondary/50 transition-colors',
        isSelected && 'bg-secondary'
      )}
      onClick={onSelect}
    >
      <Button
        variant="ghost"
        size="icon"
        className="h-5 w-5"
        onClick={(e) => {
          e.stopPropagation();
          onToggleInclude();
        }}
      >
        {isIncluded ? (
          <Eye className="h-3 w-3 text-green-400" />
        ) : (
          <EyeOff className="h-3 w-3 text-muted-foreground" />
        )}
      </Button>
      <ActionIcon className={cn('h-3.5 w-3.5', actionStyle.text)} />
      <span className={cn('text-xs flex-1 truncate', !isIncluded && 'opacity-50')}>
        {file.path}
      </span>
      <Badge variant="secondary" className={cn('text-[10px] px-1', actionStyle.bg, actionStyle.text)}>
        {actionStyle.label}
      </Badge>
    </div>
  );
}

export function GeneratedCodePreview({
  files,
  explanation,
  branchName: initialBranch = '',
  isCommitting = false,
  onCommit,
  onClose,
  onFileToggle,
}: GeneratedCodePreviewProps) {
  const [selectedFile, setSelectedFile] = useState<GeneratedFile | null>(files[0] || null);
  const [includedFiles, setIncludedFiles] = useState<Set<string>>(
    new Set(files.map((f) => f.path))
  );
  const [branchName, setBranchName] = useState(initialBranch);
  const [commitMessage, setCommitMessage] = useState('');
  const [copied, setCopied] = useState(false);
  const [showFileList, setShowFileList] = useState(true);

  const handleToggleInclude = (path: string) => {
    setIncludedFiles((prev) => {
      const next = new Set(prev);
      if (next.has(path)) {
        next.delete(path);
      } else {
        next.add(path);
      }
      onFileToggle?.(path, next.has(path));
      return next;
    });
  };

  const handleCopy = async () => {
    if (!selectedFile) return;
    await navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCommit = async () => {
    if (!onCommit || !branchName.trim() || !commitMessage.trim()) return;
    await onCommit(branchName.trim(), commitMessage.trim());
  };

  const includedCount = includedFiles.size;
  const totalCount = files.length;

  if (files.length === 0) {
    return (
      <div className="h-full flex items-center justify-center text-muted-foreground bg-panel-content">
        <div className="text-center">
          <FileCode className="h-12 w-12 mx-auto mb-4 opacity-50" />
          <p className="text-sm">No files generated yet</p>
          <p className="text-xs mt-1">Code will appear here after generation</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-panel-content">
      {/* Header */}
      <div className="h-12 flex items-center justify-between px-4 border-b border-border bg-panel-header">
        <div className="flex items-center gap-2">
          <FileCode className="h-4 w-4 text-primary" />
          <span className="font-medium text-sm">Generated Code Preview</span>
          <Badge variant="secondary" className="text-xs">
            {includedCount}/{totalCount} files
          </Badge>
        </div>
        {onClose && (
          <Button variant="ghost" size="icon" className="h-7 w-7" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        )}
      </div>

      {/* Explanation */}
      {explanation && (
        <div className="px-4 py-2 text-xs text-muted-foreground bg-secondary/20 border-b border-border">
          {explanation}
        </div>
      )}

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* File List */}
        <div
          className={cn(
            'border-r border-border transition-all duration-200',
            showFileList ? 'w-64' : 'w-8'
          )}
        >
          <div
            className="h-8 flex items-center px-2 border-b border-border cursor-pointer hover:bg-secondary/30"
            onClick={() => setShowFileList(!showFileList)}
          >
            {showFileList ? (
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            ) : (
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            )}
            {showFileList && (
              <span className="text-xs font-medium ml-2">Files</span>
            )}
          </div>
          {showFileList && (
            <ScrollArea className="h-[calc(100%-2rem)]">
              {files.map((file) => (
                <FileItem
                  key={file.path}
                  file={file}
                  isSelected={selectedFile?.path === file.path}
                  isIncluded={includedFiles.has(file.path)}
                  onSelect={() => setSelectedFile(file)}
                  onToggleInclude={() => handleToggleInclude(file.path)}
                />
              ))}
            </ScrollArea>
          )}
        </div>

        {/* Code Preview */}
        <div className="flex-1 flex flex-col">
          {selectedFile ? (
            <>
              {/* File Header */}
              <div className="h-10 flex items-center justify-between px-3 border-b border-border bg-secondary/20">
                <div className="flex items-center gap-2">
                  <FileCode className="h-4 w-4 text-blue-400" />
                  <span className="text-xs font-medium">{selectedFile.path}</span>
                  <Badge variant="outline" className="text-[10px]">
                    {getLanguageFromPath(selectedFile.path)}
                  </Badge>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6"
                  onClick={handleCopy}
                >
                  {copied ? (
                    <Check className="h-3 w-3 text-green-400" />
                  ) : (
                    <Copy className="h-3 w-3" />
                  )}
                </Button>
              </div>

              {/* Code Content */}
              <ScrollArea className="flex-1">
                <pre className="p-4 text-xs font-mono leading-relaxed">
                  <code>
                    {highlightCode(
                      selectedFile.content,
                      getLanguageFromPath(selectedFile.path)
                    )}
                  </code>
                </pre>
              </ScrollArea>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-muted-foreground">
              Select a file to preview
            </div>
          )}
        </div>
      </div>

      {/* Commit Controls */}
      {onCommit && (
        <div className="p-4 border-t border-border bg-secondary/20 space-y-3">
          <div className="flex items-center gap-3">
            <GitBranch className="h-4 w-4 text-muted-foreground" />
            <Input
              value={branchName}
              onChange={(e) => setBranchName(e.target.value)}
              placeholder="Branch name (e.g., feature/new-feature)"
              className="flex-1 h-8 text-xs"
            />
          </div>
          <div className="flex items-center gap-3">
            <Input
              value={commitMessage}
              onChange={(e) => setCommitMessage(e.target.value)}
              placeholder="Commit message..."
              className="flex-1 h-8 text-xs"
            />
            <Button
              onClick={handleCommit}
              disabled={
                isCommitting ||
                !branchName.trim() ||
                !commitMessage.trim() ||
                includedCount === 0
              }
              size="sm"
              className="h-8"
            >
              {isCommitting ? (
                <>
                  <Loader2 className="h-3 w-3 mr-2 animate-spin" />
                  Committing...
                </>
              ) : (
                <>
                  <Check className="h-3 w-3 mr-2" />
                  Commit {includedCount} files
                </>
              )}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
