import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { 
  GitBranch, 
  GitPullRequest, 
  Loader2,
  Check,
  ExternalLink,
  FileCode,
  Sparkles
} from 'lucide-react';
import { useGitHubWrite } from '@/hooks/useGitHubWrite';
import { useTaskCorrelation } from '@/hooks/useAIFeatures';
import type { JiraTask } from '@/types';

interface GitHubActionsProps {
  selectedTask: JiraTask | null;
  codeChanges?: Array<{ path: string; content: string }> | null;
  owner?: string;
  repo?: string;
}

export function GitHubActions({ selectedTask, codeChanges, owner = 'owner', repo = 'repo' }: GitHubActionsProps) {
  const task = selectedTask;
  const generatedFiles = codeChanges || undefined;
  const { isLoading, createBranch, createFeaturePR } = useGitHubWrite();
  const { linkItems } = useTaskCorrelation();
  
  const [branchDialogOpen, setBranchDialogOpen] = useState(false);
  const [prDialogOpen, setPrDialogOpen] = useState(false);
  const [createdPR, setCreatedPR] = useState<{ number: number; html_url: string } | null>(null);
  
  // Form states
  const [branchName, setBranchName] = useState(task ? `feature/${task.key.toLowerCase()}` : '');
  const [baseBranch, setBaseBranch] = useState('main');
  const [prTitle, setPrTitle] = useState(task ? `[${task.key}] ${task.title}` : '');
  const [prBody, setPrBody] = useState(task ? `## Description\n\nImplements ${task.key}: ${task.title}\n\n## Changes\n\n- \n\n## Testing\n\n- [ ] Unit tests\n- [ ] Manual testing` : '');
  const [commitMessage, setCommitMessage] = useState(task ? `feat(${task.key.toLowerCase()}): implement ${task.title.toLowerCase()}` : '');

  const handleCreateBranch = async () => {
    if (!task) return;
    const result = await createBranch({
      owner,
      repo,
      branchName,
      baseBranch
    });

    if (result) {
      // Link the branch to the task
      await linkItems(
        task.key,
        [{
          type: 'branch',
          id: branchName,
          url: `https://github.com/${owner}/${repo}/tree/${branchName}`,
          title: branchName
        }],
        task.title
      );
      setBranchDialogOpen(false);
    }
  };

  const handleCreatePR = async () => {
    if (!generatedFiles?.length || !task) return;

    const result = await createFeaturePR({
      owner,
      repo,
      branchName,
      baseBranch,
      files: generatedFiles,
      commitMessage,
      prTitle,
      prBody
    });

    if (result) {
      setCreatedPR({ number: result.number, html_url: result.html_url });
      
      // Link the PR to the task
      await linkItems(
        task.key,
        [{
          type: 'pr',
          id: String(result.number),
          url: result.html_url,
          title: prTitle
        }],
        task.title
      );
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <GitBranch className="h-4 w-4 text-primary" />
        <h3 className="font-medium text-sm">GitHub Actions</h3>
        <Badge variant="outline" className="text-xs">
          {owner}/{repo}
        </Badge>
      </div>

      {createdPR ? (
        <div className="p-4 bg-green-500/10 border border-green-500/30 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <Check className="h-5 w-5 text-green-500" />
            <span className="font-medium text-green-500">PR Created Successfully!</span>
          </div>
          <p className="text-sm text-muted-foreground mb-3">
            Pull request #{createdPR.number} has been created with the generated code.
          </p>
          <Button
            variant="outline"
            size="sm"
            onClick={() => window.open(createdPR.html_url, '_blank')}
          >
            <ExternalLink className="h-4 w-4 mr-2" />
            View PR #{createdPR.number}
          </Button>
        </div>
      ) : (
        <div className="grid gap-2">
          {/* Create Branch */}
          <Dialog open={branchDialogOpen} onOpenChange={setBranchDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="justify-start">
                <GitBranch className="h-4 w-4 mr-2" />
                Create Branch
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create Feature Branch</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label>Branch Name</Label>
                  <Input
                    value={branchName}
                    onChange={(e) => setBranchName(e.target.value)}
                    placeholder="feature/task-name"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Base Branch</Label>
                  <Input
                    value={baseBranch}
                    onChange={(e) => setBaseBranch(e.target.value)}
                    placeholder="main"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setBranchDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreateBranch} disabled={isLoading}>
                  {isLoading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                  Create Branch
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* Create PR with Generated Code */}
          {generatedFiles?.length ? (
            <Dialog open={prDialogOpen} onOpenChange={setPrDialogOpen}>
              <DialogTrigger asChild>
                <Button className="justify-start">
                  <Sparkles className="h-4 w-4 mr-2" />
                  Create PR with Generated Code
                  <Badge variant="secondary" className="ml-2">
                    {generatedFiles.length} files
                  </Badge>
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-2xl">
                <DialogHeader>
                  <DialogTitle>Create Pull Request</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4 max-h-[60vh] overflow-y-auto">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Branch Name</Label>
                      <Input
                        value={branchName}
                        onChange={(e) => setBranchName(e.target.value)}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Base Branch</Label>
                      <Input
                        value={baseBranch}
                        onChange={(e) => setBaseBranch(e.target.value)}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>Commit Message</Label>
                    <Input
                      value={commitMessage}
                      onChange={(e) => setCommitMessage(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>PR Title</Label>
                    <Input
                      value={prTitle}
                      onChange={(e) => setPrTitle(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>PR Description</Label>
                    <Textarea
                      value={prBody}
                      onChange={(e) => setPrBody(e.target.value)}
                      rows={6}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Files to Commit</Label>
                    <div className="border rounded-lg p-2 space-y-1">
                      {generatedFiles.map((file) => (
                        <div key={file.path} className="flex items-center gap-2 text-sm">
                          <FileCode className="h-4 w-4 text-muted-foreground" />
                          <code className="text-xs">{file.path}</code>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setPrDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleCreatePR} disabled={isLoading}>
                    {isLoading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                    Create PR
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          ) : (
            <Button variant="outline" className="justify-start" disabled>
              <GitPullRequest className="h-4 w-4 mr-2" />
              Create PR
              <span className="text-xs text-muted-foreground ml-2">(generate code first)</span>
            </Button>
          )}
        </div>
      )}
    </div>
  );
}
