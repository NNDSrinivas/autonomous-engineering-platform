import { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  GitBranch, 
  GitPullRequest,
  RefreshCw,
  ExternalLink,
  Plus,
  ChevronRight,
  Circle,
  GitMerge,
  Loader2
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useGitHubIntegration, GitHubRepo, GitHubPullRequest } from '@/hooks/useGitHubIntegration';
import { formatDistanceToNow } from 'date-fns';
import { ApprovalDialog, ApprovalAction } from './ApprovalDialog';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import type { WriteActionType } from '@/hooks/useApprovalGate';

interface GitHubPanelProps {
  onRepoSelect?: (owner: string, repo: string) => void;
}

export function GitHubPanel({ onRepoSelect }: GitHubPanelProps) {
  const {
    isLoading,
    connection,
    repos,
    branches,
    pullRequests,
    fetchRepos,
    fetchBranches,
    fetchPullRequests,
    createPullRequest,
    createBranch,
  } = useGitHubIntegration();

  const [selectedRepo, setSelectedRepo] = useState<GitHubRepo | null>(null);
  const [view, setView] = useState<'repos' | 'prs' | 'branches'>('repos');
  const [approvalAction, setApprovalAction] = useState<ApprovalAction | null>(null);
  const [showApproval, setShowApproval] = useState(false);
  const [newBranchName, setNewBranchName] = useState('');
  const [baseBranch, setBaseBranch] = useState('');

  useEffect(() => {
    if (connection.connected) {
      fetchRepos();
    }
  }, [connection.connected, fetchRepos]);

  useEffect(() => {
    if (selectedRepo) {
      const [owner, repo] = selectedRepo.full_name.split('/');
      fetchBranches(owner, repo);
      fetchPullRequests(owner, repo);
      onRepoSelect?.(owner, repo);
    }
  }, [selectedRepo, fetchBranches, fetchPullRequests, onRepoSelect]);

  const handleRepoSelect = useCallback((repo: GitHubRepo) => {
    setSelectedRepo(repo);
    setView('prs');
  }, []);

  const handleCreateBranch = useCallback(() => {
    if (!selectedRepo || !newBranchName || !baseBranch) return;
    
    const [owner, repo] = selectedRepo.full_name.split('/');
    
    setApprovalAction({
      id: `create-branch-${Date.now()}`,
      type: 'github_create_branch' as WriteActionType,
      title: `Create branch "${newBranchName}"`,
      description: `Create a new branch from ${baseBranch} in ${selectedRepo.full_name}`,
      details: {
        repository: selectedRepo.full_name,
        new_branch: newBranchName,
        from_branch: baseBranch,
      },
      risk: 'low',
      createdAt: new Date(),
    });
    setShowApproval(true);
  }, [selectedRepo, newBranchName, baseBranch]);

  const handleApprove = async (action: ApprovalAction) => {
    if (!selectedRepo) return;
    
    const [owner, repo] = selectedRepo.full_name.split('/');
    
    try {
      if (action.type === 'github_create_branch') {
        await createBranch(
          owner,
          repo,
          String(action.details?.new_branch),
          String(action.details?.from_branch)
        );
        setNewBranchName('');
        fetchBranches(owner, repo);
      }
    } catch (error) {
      console.error('Action failed:', error);
    }
  };

  const handleReject = (action: ApprovalAction) => {
    toast.info(`Action "${action.title}" was rejected`);
  };

  const handleConnectGitHub = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error('Please sign in first');
        return;
      }
      
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/oauth?provider=github`,
        {
          headers: {
            Authorization: `Bearer ${session.access_token}`,
          },
        }
      );
      
      const result = await response.json();
      if (result.authUrl) {
        window.open(result.authUrl, '_blank', 'width=600,height=700');
      } else {
        toast.error('Failed to initiate GitHub connection');
      }
    } catch (error) {
      console.error('Failed to connect GitHub:', error);
      toast.error('Failed to connect to GitHub');
    }
  };

  if (!connection.connected) {
    return (
      <div className="p-6 text-center space-y-4">
        <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center mx-auto">
          <GitBranch className="h-6 w-6 text-muted-foreground" />
        </div>
        <div>
          <h3 className="font-medium">GitHub Not Connected</h3>
          <p className="text-sm text-muted-foreground mt-1">
            Connect GitHub to view repositories, branches, and pull requests.
          </p>
        </div>
        <Button onClick={handleConnectGitHub} variant="default" size="sm">
          <GitBranch className="h-4 w-4 mr-2" />
          Connect GitHub
        </Button>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-3 border-b border-border">
        <div className="flex items-center gap-2">
          <GitBranch className="h-4 w-4 text-github-green" />
          <span className="font-medium text-sm">GitHub</span>
          {connection.user && (
            <Badge variant="outline" className="text-[10px]">
              {connection.user.login}
            </Badge>
          )}
        </div>
        {selectedRepo && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setSelectedRepo(null)}
            className="h-7 px-2 text-xs"
          >
            Change Repo
          </Button>
        )}
      </div>

      {/* View Tabs */}
      {selectedRepo && (
        <div className="flex border-b border-border">
          {(['prs', 'branches'] as const).map((v) => (
            <button
              key={v}
              onClick={() => setView(v)}
              className={cn(
                "flex-1 px-4 py-2 text-xs font-medium transition-colors",
                view === v 
                  ? "border-b-2 border-primary text-foreground" 
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {v === 'prs' ? 'Pull Requests' : 'Branches'}
            </button>
          ))}
        </div>
      )}

      <ScrollArea className="flex-1">
        {isLoading ? (
          <div className="p-4 space-y-3">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-16 w-full" />
            ))}
          </div>
        ) : !selectedRepo ? (
          // Repo List
          <div className="p-2 space-y-1">
            {repos.map((repo) => (
              <button
                key={repo.id}
                onClick={() => handleRepoSelect(repo)}
                className="w-full p-3 rounded-lg text-left hover:bg-secondary/50 transition-colors flex items-center gap-3"
              >
                <div className="h-8 w-8 rounded-full bg-secondary flex items-center justify-center flex-shrink-0">
                  <GitBranch className="h-4 w-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm truncate">{repo.name}</div>
                  <div className="text-xs text-muted-foreground truncate">
                    {repo.description || repo.full_name}
                  </div>
                </div>
                {repo.language && (
                  <Badge variant="outline" className="text-[10px] flex-shrink-0">
                    {repo.language}
                  </Badge>
                )}
                <ChevronRight className="h-4 w-4 text-muted-foreground flex-shrink-0" />
              </button>
            ))}
          </div>
        ) : view === 'prs' ? (
          // Pull Requests
          <div className="p-2 space-y-2">
            {pullRequests.length === 0 ? (
              <div className="p-6 text-center text-muted-foreground">
                <GitPullRequest className="h-8 w-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">No open pull requests</p>
              </div>
            ) : (
              pullRequests.map((pr) => (
                <div
                  key={pr.id}
                  className="p-3 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors space-y-2"
                >
                  <div className="flex items-start gap-2">
                    {pr.merged_at ? (
                      <GitMerge className="h-4 w-4 text-purple-500 flex-shrink-0 mt-0.5" />
                    ) : pr.state === 'open' ? (
                      <GitPullRequest className="h-4 w-4 text-status-success flex-shrink-0 mt-0.5" />
                    ) : (
                      <GitPullRequest className="h-4 w-4 text-status-error flex-shrink-0 mt-0.5" />
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-sm">{pr.title}</div>
                      <div className="text-xs text-muted-foreground mt-1 flex items-center gap-2">
                        <span>#{pr.number}</span>
                        <span>•</span>
                        <span>{pr.head.ref} → {pr.base.ref}</span>
                      </div>
                    </div>
                    {pr.draft && (
                      <Badge variant="outline" className="text-[10px]">Draft</Badge>
                    )}
                  </div>
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>by {pr.user.login}</span>
                    <span>{formatDistanceToNow(new Date(pr.created_at), { addSuffix: true })}</span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    asChild
                    className="h-7 text-xs gap-1.5"
                  >
                    <a href={pr.html_url} target="_blank" rel="noopener noreferrer">
                      <ExternalLink className="h-3 w-3" />
                      View on GitHub
                    </a>
                  </Button>
                </div>
              ))
            )}
          </div>
        ) : (
          // Branches
          <div className="p-2 space-y-4">
            {/* Create Branch Form */}
            <div className="p-3 rounded-lg bg-secondary/30 space-y-3">
              <h4 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
                Create Branch
              </h4>
              <div className="space-y-2">
                <Input
                  placeholder="Branch name"
                  value={newBranchName}
                  onChange={(e) => setNewBranchName(e.target.value)}
                  className="h-8 text-sm"
                />
                <Select value={baseBranch} onValueChange={setBaseBranch}>
                  <SelectTrigger className="h-8 text-sm">
                    <SelectValue placeholder="From branch..." />
                  </SelectTrigger>
                  <SelectContent>
                    {branches.map((branch) => (
                      <SelectItem key={branch.name} value={branch.name}>
                        {branch.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button
                  size="sm"
                  onClick={handleCreateBranch}
                  disabled={!newBranchName || !baseBranch}
                  className="w-full h-8 gap-1.5"
                >
                  <Plus className="h-3.5 w-3.5" />
                  Create Branch
                </Button>
              </div>
            </div>

            {/* Branch List */}
            <div className="space-y-1">
              {branches.map((branch) => (
                <div
                  key={branch.name}
                  className="flex items-center gap-2 p-2 rounded-lg hover:bg-secondary/30 transition-colors"
                >
                  <Circle className={cn(
                    "h-2 w-2 flex-shrink-0",
                    branch.protected ? "fill-status-warning text-status-warning" : "fill-status-success text-status-success"
                  )} />
                  <span className="text-sm font-mono truncate">{branch.name}</span>
                  {branch.protected && (
                    <Badge variant="outline" className="text-[10px] ml-auto">Protected</Badge>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}
      </ScrollArea>

      {/* Approval Dialog */}
      <ApprovalDialog
        open={showApproval}
        onOpenChange={setShowApproval}
        action={approvalAction}
        onApprove={handleApprove}
        onReject={handleReject}
      />
    </div>
  );
}
