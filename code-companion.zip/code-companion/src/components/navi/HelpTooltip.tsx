import { HelpCircle, Info } from 'lucide-react';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';

interface HelpTooltipProps {
  content: React.ReactNode;
  title?: string;
  side?: 'top' | 'right' | 'bottom' | 'left';
  variant?: 'help' | 'info';
  className?: string;
}

export function HelpTooltip({ 
  content, 
  title, 
  side = 'top', 
  variant = 'help',
  className 
}: HelpTooltipProps) {
  const Icon = variant === 'help' ? HelpCircle : Info;
  
  return (
    <TooltipProvider>
      <Tooltip delayDuration={200}>
        <TooltipTrigger asChild>
          <button 
            type="button"
            className={cn(
              "inline-flex items-center justify-center h-4 w-4 rounded-full text-muted-foreground hover:text-foreground hover:bg-muted transition-colors",
              className
            )}
          >
            <Icon className="h-3.5 w-3.5" />
          </button>
        </TooltipTrigger>
        <TooltipContent side={side} className="max-w-xs">
          {title && <p className="font-medium mb-1">{title}</p>}
          <div className="text-xs text-muted-foreground">{content}</div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}
