import { useState } from 'react';
import { 
  CheckCircle2, 
  AlertCircle, 
  Circle, 
  RefreshCw, 
  Settings,
  LayoutGrid,
  MessageSquare,
  FileText,
  GitBranch,
  Video,
  Activity,
  X,
  Plus,
  ExternalLink,
  Lock
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { useIntegrations, type IntegrationState } from '@/hooks/useIntegrations';

interface IntegrationCardProps {
  integration: IntegrationState;
  onConnect: () => void;
  onDisconnect: () => void;
  onSettings: () => void;
  isLoading: boolean;
  isAuthenticated: boolean;
  isConfigured: boolean;
}

const integrationIcons: Record<string, React.ReactNode> = {
  jira: <LayoutGrid className="h-5 w-5" />,
  slack: <MessageSquare className="h-5 w-5" />,
  teams: <MessageSquare className="h-5 w-5" />,
  confluence: <FileText className="h-5 w-5" />,
  github: <GitBranch className="h-5 w-5" />,
  zoom: <Video className="h-5 w-5" />,
  cicd: <Activity className="h-5 w-5" />,
};

const integrationColors: Record<string, string> = {
  jira: 'text-blue-400 bg-blue-500/10 border-blue-500/30',
  slack: 'text-purple-400 bg-purple-500/10 border-purple-500/30',
  teams: 'text-violet-400 bg-violet-500/10 border-violet-500/30',
  confluence: 'text-blue-300 bg-blue-400/10 border-blue-400/30',
  github: 'text-green-400 bg-green-500/10 border-green-500/30',
  zoom: 'text-sky-400 bg-sky-500/10 border-sky-500/30',
  cicd: 'text-orange-400 bg-orange-500/10 border-orange-500/30',
};

const oauthProviders = ['jira', 'slack', 'github', 'confluence'];

function IntegrationCard({ 
  integration, 
  onConnect, 
  onDisconnect, 
  onSettings, 
  isLoading,
  isAuthenticated,
  isConfigured
}: IntegrationCardProps) {
  const isOAuthSupported = oauthProviders.includes(integration.type);
  
  return (
    <div className={cn(
      "p-4 rounded-xl border transition-all",
      integration.status === 'connected' 
        ? "bg-card border-border" 
        : "bg-card/50 border-dashed border-border"
    )}>
      <div className="flex items-start gap-3">
        <div className={cn(
          "h-10 w-10 rounded-lg flex items-center justify-center border",
          integrationColors[integration.type]
        )}>
          {integrationIcons[integration.type]}
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h3 className="font-medium text-sm">{integration.name}</h3>
            {integration.status === 'connected' && (
              <CheckCircle2 className="h-4 w-4 text-green-400" />
            )}
            {integration.status === 'error' && (
              <AlertCircle className="h-4 w-4 text-red-400" />
            )}
            {isOAuthSupported && isConfigured && (
              <Badge variant="outline" className="text-[10px] px-1.5 py-0 bg-green-500/10 text-green-400 border-green-500/30">Ready</Badge>
            )}
            {isOAuthSupported && !isConfigured && (
              <Badge variant="outline" className="text-[10px] px-1.5 py-0 bg-amber-500/10 text-amber-400 border-amber-500/30">Not configured</Badge>
            )}
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">
            {integration.status === 'connected' && integration.lastSync && (
              <>
                {integration.displayName && <span className="text-foreground">{integration.displayName} · </span>}
                Synced {new Date(integration.lastSync).toLocaleTimeString()}
              </>
            )}
            {integration.status === 'disconnected' && 'Not connected'}
            {integration.status === 'error' && 'Connection error'}
          </p>
        </div>
        <div className="flex items-center gap-1">
          {integration.status === 'connected' ? (
            <>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={onSettings}
              >
                <Settings className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={onDisconnect}
                disabled={isLoading}
              >
                {isLoading ? (
                  <RefreshCw className="h-4 w-4 animate-spin" />
                ) : (
                  <X className="h-4 w-4" />
                )}
              </Button>
            </>
          ) : (
            <Button
              variant="outline"
              size="sm"
              onClick={onConnect}
              disabled={isLoading || !isAuthenticated || (isOAuthSupported && !isConfigured)}
              className="gap-1.5"
              title={isOAuthSupported && !isConfigured ? 'Admin needs to configure OAuth credentials first' : undefined}
            >
              {isLoading ? (
                <RefreshCw className="h-3.5 w-3.5 animate-spin" />
              ) : !isAuthenticated ? (
                <Lock className="h-3.5 w-3.5" />
              ) : isOAuthSupported && !isConfigured ? (
                <AlertCircle className="h-3.5 w-3.5" />
              ) : isOAuthSupported ? (
                <ExternalLink className="h-3.5 w-3.5" />
              ) : (
                <Plus className="h-3.5 w-3.5" />
              )}
              {!isAuthenticated ? 'Sign in' : isOAuthSupported && !isConfigured ? 'Setup needed' : 'Connect'}
            </Button>
          )}
        </div>
      </div>

      {/* Connection details for connected integrations */}
      {integration.status === 'connected' && (
        <div className="mt-3 pt-3 border-t border-border">
          <div className="flex flex-wrap gap-2">
            {integration.type === 'jira' && (
              <>
                <Badge variant="secondary" className="text-xs">Projects</Badge>
                <Badge variant="secondary" className="text-xs">Issues</Badge>
              </>
            )}
            {integration.type === 'slack' && (
              <>
                <Badge variant="secondary" className="text-xs">Channels</Badge>
                <Badge variant="secondary" className="text-xs">Messages</Badge>
              </>
            )}
            {integration.type === 'github' && (
              <>
                <Badge variant="secondary" className="text-xs">Repositories</Badge>
                <Badge variant="secondary" className="text-xs">Pull Requests</Badge>
              </>
            )}
            {integration.type === 'confluence' && (
              <>
                <Badge variant="secondary" className="text-xs">Spaces</Badge>
                <Badge variant="secondary" className="text-xs">Pages</Badge>
              </>
            )}
            {integration.type === 'zoom' && (
              <Badge variant="secondary" className="text-xs">Recordings</Badge>
            )}
            {integration.type === 'cicd' && (
              <>
                <Badge variant="secondary" className="text-xs">Pipelines</Badge>
                <Badge variant="secondary" className="text-xs">Builds</Badge>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

interface IntegrationStatusProps {
  integrations?: never; // We now use the hook internally
}

export function IntegrationStatus(_props: IntegrationStatusProps) {
  const { 
    integrations, 
    isLoading, 
    isAuthenticated, 
    initiateOAuth, 
    disconnect, 
    refresh 
  } = useIntegrations();

  const connectedCount = integrations.filter(i => i.status === 'connected').length;

  return (
    <div className="p-6 flex-1 overflow-auto">
      <div className="mb-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold">Integrations</h2>
            <p className="text-sm text-muted-foreground mt-1">
              Connect NAVI to your tools for complete engineering awareness
            </p>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={refresh}
            disabled={isLoading}
          >
            <RefreshCw className={cn("h-4 w-4", isLoading && "animate-spin")} />
          </Button>
        </div>
        <div className="flex items-center gap-4 mt-3">
          <Badge variant="outline" className="gap-1.5">
            <CheckCircle2 className="h-3 w-3 text-green-400" />
            {connectedCount} Connected
          </Badge>
          <Badge variant="outline" className="gap-1.5">
            <Circle className="h-3 w-3 text-muted-foreground" />
            {integrations.length - connectedCount} Available
          </Badge>
          {!isAuthenticated && (
            <Badge variant="destructive" className="gap-1.5">
              <Lock className="h-3 w-3" />
              Sign in required
            </Badge>
          )}
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {integrations.map((integration) => (
          <IntegrationCard
            key={integration.id}
            integration={integration}
            onConnect={() => initiateOAuth(integration.type)}
            onDisconnect={() => disconnect(integration.type)}
            onSettings={() => {}}
            isLoading={isLoading}
            isAuthenticated={isAuthenticated}
            isConfigured={integration.isConfigured || false}
          />
        ))}
      </div>

      {/* OAuth setup instructions - only show if not all configured */}
      {integrations.filter(i => oauthProviders.includes(i.type) && !i.isConfigured).length > 0 && (
        <div className="mt-6 p-4 rounded-xl border border-dashed border-border bg-muted/30">
          <h3 className="text-sm font-medium mb-2">Setup Required</h3>
          <p className="text-xs text-muted-foreground">
            Some integrations need OAuth credentials. Go to <span className="font-medium">Settings → Connectors</span> to configure them (requires admin access).
          </p>
        </div>
      )}
    </div>
  );
}
