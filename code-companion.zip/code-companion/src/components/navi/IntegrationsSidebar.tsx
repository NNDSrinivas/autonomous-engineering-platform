import { 
  LayoutGrid, 
  Search,
  Activity,
  Settings,
  Bell,
  User,
  History,
  FolderTree,
  Sun,
  Zap,
  ClipboardList,
  Shield,
  Play,
  BarChart3,
  ListOrdered,
  Calendar,
  Github,
  MessageSquare,
  Users,
  Video,
  FileText,
  Brain
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { HoverCard, HoverCardContent, HoverCardTrigger } from '@/components/ui/hover-card';
import { cn } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';
import { useApprovalStatus } from '@/hooks/useApprovalGate';
import { useSidebarPins, type SidebarItemId } from '@/hooks/useSidebarPins';
import { RepoIndexingIndicator } from './RepoIndexingIndicator';

// Icon mapping for dynamic rendering
const ICON_COMPONENTS: Record<string, React.ReactNode> = {
  Sun: <Sun className="h-5 w-5" />,
  FolderTree: <FolderTree className="h-5 w-5" />,
  LayoutGrid: <LayoutGrid className="h-5 w-5" />,
  Search: <Search className="h-5 w-5" />,
  Activity: <Activity className="h-5 w-5" />,
  Play: <Play className="h-5 w-5" />,
  Zap: <Zap className="h-5 w-5" />,
  ListOrdered: <ListOrdered className="h-5 w-5" />,
  BarChart3: <BarChart3 className="h-5 w-5" />,
  ClipboardList: <ClipboardList className="h-5 w-5" />,
  Calendar: <Calendar className="h-5 w-5" />,
  Github: <Github className="h-5 w-5" />,
  MessageSquare: <MessageSquare className="h-5 w-5" />,
  Users: <Users className="h-5 w-5" />,
  Video: <Video className="h-5 w-5" />,
  FileText: <FileText className="h-5 w-5" />,
  Brain: <Brain className="h-5 w-5" />,
};

interface RepoIndex {
  owner: string;
  repo: string;
  branch: string;
  totalFiles: number;
  lastFullScan: string;
  files?: Array<{ path: string; language?: string }>;
}

interface IntegrationsSidebarProps {
  activeView: string;
  onViewChange: (view: string) => void;
  onIntegrationSelect: (id: string) => void;
  activeIntegration: string | null;
  onSettingsClick?: () => void;
  onProfileClick?: () => void;
  onHistoryClick?: () => void;
  onNotificationClick?: () => void;
  onApprovalsClick?: () => void;
  notificationCount?: number;
  isCollapsed?: boolean;
  // Repo indexing props
  isIndexing?: boolean;
  indexProgress?: number;
  repoIndex?: RepoIndex | null;
  onRefreshIndex?: () => void;
}

export function IntegrationsSidebar({ 
  activeView, 
  onViewChange, 
  onSettingsClick,
  onProfileClick,
  onHistoryClick,
  onNotificationClick,
  onApprovalsClick,
  notificationCount = 0,
  isCollapsed = false,
  isIndexing = false,
  indexProgress = 0,
  repoIndex = null,
  onRefreshIndex,
}: IntegrationsSidebarProps) {
  const { pendingCount } = useApprovalStatus();
  const { getPinnedItems } = useSidebarPins();
  const pinnedItems = getPinnedItems();
  
  return (
    <div 
      className={cn(
        "bg-background border-r border-border flex flex-col items-center py-3 gap-1 transition-all duration-300 ease-in-out",
        isCollapsed ? "w-0 overflow-hidden opacity-0" : "w-16 opacity-100"
      )}
    >
      {/* Main Nav - Pinned Items */}
      <div className="flex flex-col gap-1 w-full px-2">
        {pinnedItems.map((item) => (
          <Tooltip key={item.id}>
            <TooltipTrigger asChild>
              <Button
                variant={activeView === item.id ? 'sidebarActive' : 'sidebar'}
                size="icon"
                onClick={() => onViewChange(item.id)}
                className={cn(
                  "h-10 w-full rounded-lg relative transition-all duration-200",
                  activeView === item.id && "bg-primary/10 border border-primary/30 shadow-lg shadow-primary/10"
                )}
              >
                {ICON_COMPONENTS[item.icon]}
              </Button>
            </TooltipTrigger>
            <TooltipContent side="right">{item.name}</TooltipContent>
          </Tooltip>
        ))}
      </div>

      {/* Repo Indexing Indicator */}
      <RepoIndexingIndicator
        isIndexing={isIndexing}
        indexProgress={indexProgress}
        repoIndex={repoIndex}
        onRefresh={onRefreshIndex}
        isCollapsed={isCollapsed}
      />

      <div className="flex-1" />

      {/* Bottom actions */}
      <div className="flex flex-col gap-1 w-full px-2 mt-auto">
        {/* Pending Approvals */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant={activeView === 'approvals' ? 'sidebarActive' : 'sidebar'}
              size="icon"
              className={cn(
                "h-10 w-full rounded-lg relative transition-all duration-200",
                activeView === 'approvals' && "bg-primary/10 border border-primary/30",
                pendingCount > 0 && "ring-1 ring-status-warning/50"
              )}
              onClick={onApprovalsClick}
            >
              <Shield className="h-5 w-5" />
              {pendingCount > 0 && (
                <span 
                  key={pendingCount}
                  className="absolute top-1 right-1 h-4 min-w-4 px-1 rounded-full bg-status-warning text-[10px] font-medium text-status-warning-foreground flex items-center justify-center animate-scale-in"
                >
                  {pendingCount > 9 ? '9+' : pendingCount}
                </span>
              )}
            </Button>
          </TooltipTrigger>
          <TooltipContent side="right">
            {pendingCount > 0 ? `${pendingCount} Pending Approval${pendingCount > 1 ? 's' : ''}` : 'Approvals'}
          </TooltipContent>
        </Tooltip>

        {/* History */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant={activeView === 'history' ? 'sidebarActive' : 'sidebar'}
              size="icon"
              className={cn(
                "h-10 w-full rounded-lg transition-all duration-200",
                activeView === 'history' && "bg-primary/10 border border-primary/30"
              )}
              onClick={onHistoryClick}
            >
              <History className="h-5 w-5" />
            </Button>
          </TooltipTrigger>
          <TooltipContent side="right">Chat History</TooltipContent>
        </Tooltip>

        {/* Notifications with Hover Preview */}
        <HoverCard openDelay={200}>
          <HoverCardTrigger asChild>
            <Button
              variant="sidebar"
              size="icon"
              className="h-10 w-full rounded-lg relative transition-all duration-200"
              onClick={onNotificationClick}
            >
              <Bell className="h-5 w-5" />
              {notificationCount > 0 && (
                <span 
                  key={notificationCount}
                  className="absolute -top-1 -right-1 h-5 min-w-5 px-1 rounded-full bg-destructive text-[10px] font-bold text-destructive-foreground flex items-center justify-center animate-scale-in shadow-lg border-2 border-background"
                >
                  {notificationCount > 9 ? '9+' : notificationCount}
                </span>
              )}
            </Button>
          </HoverCardTrigger>
          <HoverCardContent side="right" align="start" className="w-72 p-0">
            <div className="p-3 border-b border-border">
              <h4 className="font-semibold text-sm">Recent Notifications</h4>
              <p className="text-xs text-muted-foreground">
                {notificationCount > 0 ? `${notificationCount} unread` : 'All caught up!'}
              </p>
            </div>
            <div className="max-h-48 overflow-y-auto">
              {notificationCount > 0 ? (
                <div className="divide-y divide-border">
                  <div className="p-3 hover:bg-secondary/50 cursor-pointer transition-colors">
                    <div className="flex items-start gap-2">
                      <div className="h-2 w-2 rounded-full bg-primary mt-1.5 animate-pulse" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">Build completed</p>
                        <p className="text-xs text-muted-foreground">CI/CD pipeline finished successfully</p>
                        <p className="text-[10px] text-muted-foreground mt-0.5">2 minutes ago</p>
                      </div>
                    </div>
                  </div>
                  <div className="p-3 hover:bg-secondary/50 cursor-pointer transition-colors">
                    <div className="flex items-start gap-2">
                      <div className="h-2 w-2 rounded-full bg-primary mt-1.5 animate-pulse" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">PR Review requested</p>
                        <p className="text-xs text-muted-foreground">John requested your review</p>
                        <p className="text-[10px] text-muted-foreground mt-0.5">15 minutes ago</p>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-6 text-center text-muted-foreground">
                  <Bell className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p className="text-sm">No new notifications</p>
                </div>
              )}
            </div>
            <div className="p-2 border-t border-border">
              <button 
                onClick={onNotificationClick}
                className="w-full text-xs text-primary hover:text-primary/80 font-medium py-1.5 rounded hover:bg-primary/10 transition-colors"
              >
                View All Notifications
              </button>
            </div>
          </HoverCardContent>
        </HoverCard>

        {/* Settings */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant={activeView === 'settings' ? 'sidebarActive' : 'sidebar'}
              size="icon"
              className={cn(
                "h-10 w-full rounded-lg transition-all duration-200",
                activeView === 'settings' && "bg-primary/10 border border-primary/30"
              )}
              onClick={onSettingsClick}
            >
              <Settings className="h-5 w-5" />
            </Button>
          </TooltipTrigger>
          <TooltipContent side="right">Settings</TooltipContent>
        </Tooltip>

        {/* Profile */}
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="sidebar"
              size="icon"
              className="h-10 w-full rounded-lg transition-all duration-200"
              onClick={onProfileClick}
            >
              <User className="h-5 w-5" />
            </Button>
          </TooltipTrigger>
          <TooltipContent side="right">Profile</TooltipContent>
        </Tooltip>
      </div>
    </div>
  );
}
