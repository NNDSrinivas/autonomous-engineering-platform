import { useEffect } from 'react';
import { X, Keyboard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

interface KeyboardShortcutsModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface ShortcutGroup {
  title: string;
  shortcuts: {
    keys: string[];
    description: string;
  }[];
}

const shortcutGroups: ShortcutGroup[] = [
  {
    title: 'Navigation',
    shortcuts: [
      { keys: ['⌘', 'K'], description: 'Open search panel' },
      { keys: ['⌘', '/'], description: 'Open command palette' },
      { keys: ['⌘', 'T'], description: 'Open tasks panel' },
      { keys: ['⌘', ','], description: 'Open settings' },
      { keys: ['⌘', 'H'], description: 'Open history' },
      { keys: ['⌘', 'B'], description: 'Focus chat input' },
    ],
  },
  {
    title: 'Panels',
    shortcuts: [
      { keys: ['⌘', '⇧', 'A'], description: 'Open activity feed' },
      { keys: ['⌘', '⇧', 'I'], description: 'Open integrations' },
      { keys: ['⌘', 'N'], description: 'Toggle notifications' },
      { keys: ['Esc'], description: 'Close active panel' },
    ],
  },
  {
    title: 'Actions',
    shortcuts: [
      { keys: ['⌘', '⇧', 'W'], description: 'Start workflow on task' },
      { keys: ['⌘', '⇧', 'P'], description: 'Create pull request' },
      { keys: ['⌘', '`'], description: 'Open terminal' },
      { keys: ['⌘', 'E'], description: 'Explain selected code' },
      { keys: ['⌘', 'D'], description: 'Debug with NAVI' },
    ],
  },
  {
    title: 'Help',
    shortcuts: [
      { keys: ['⌘', '?'], description: 'Show keyboard shortcuts' },
    ],
  },
];

function ShortcutKey({ children }: { children: string }) {
  return (
    <kbd className="min-w-[24px] h-6 px-1.5 flex items-center justify-center text-xs font-mono font-medium bg-secondary border border-border rounded shadow-sm">
      {children}
    </kbd>
  );
}

export function KeyboardShortcutsModal({ open, onOpenChange }: KeyboardShortcutsModalProps) {
  // Handle ⌘? to open this modal
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === '?' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        onOpenChange(!open);
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [open, onOpenChange]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] bg-background border-border p-0 gap-0 overflow-hidden">
        <DialogHeader className="px-6 py-4 border-b border-border bg-card/50">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center">
              <Keyboard className="h-5 w-5 text-primary" />
            </div>
            <div>
              <DialogTitle className="text-lg font-semibold">Keyboard Shortcuts</DialogTitle>
              <p className="text-xs text-muted-foreground mt-0.5">Quick navigation and actions</p>
            </div>
          </div>
        </DialogHeader>
        
        <div className="p-6 max-h-[60vh] overflow-y-auto">
          <div className="grid grid-cols-2 gap-6">
            {shortcutGroups.map((group) => (
              <div key={group.title} className="space-y-3">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  {group.title}
                </h3>
                <div className="space-y-2">
                  {group.shortcuts.map((shortcut, index) => (
                    <div 
                      key={index} 
                      className="flex items-center justify-between gap-4 py-1.5 px-2 rounded-lg hover:bg-secondary/50 transition-colors"
                    >
                      <span className="text-sm text-foreground">{shortcut.description}</span>
                      <div className="flex items-center gap-1">
                        {shortcut.keys.map((key, keyIndex) => (
                          <ShortcutKey key={keyIndex}>{key}</ShortcutKey>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="px-6 py-3 border-t border-border bg-card/50 flex items-center justify-between">
          <p className="text-xs text-muted-foreground">
            Press <ShortcutKey>Esc</ShortcutKey> to close
          </p>
          <Button variant="outline" size="sm" onClick={() => onOpenChange(false)}>
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
