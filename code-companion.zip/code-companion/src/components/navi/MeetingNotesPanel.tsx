import { useState, useCallback } from 'react';
import { 
  FileText, 
  Upload, 
  Calendar, 
  Users, 
  CheckSquare, 
  MessageSquare,
  Video,
  Plus,
  Trash2,
  Save,
  Search,
  Filter
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter,
  DialogDescription
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { toast } from 'sonner';
import { useMemory } from '@/hooks/useMemory';
import type { MeetingNote } from '@/types';

interface MeetingNotesPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

const MEETING_TYPES = [
  { value: 'standup', label: 'Daily Standup' },
  { value: 'grooming', label: 'Backlog Grooming' },
  { value: 'sprint_planning', label: 'Sprint Planning' },
  { value: 'retrospective', label: 'Retrospective' },
  { value: 'ad_hoc', label: 'Ad-hoc Meeting' },
] as const;

const PLATFORMS = [
  { value: 'zoom', label: 'Zoom' },
  { value: 'teams', label: 'Microsoft Teams' },
  { value: 'google_meet', label: 'Google Meet' },
] as const;

export function MeetingNotesPanel({ isOpen, onClose }: MeetingNotesPanelProps) {
  const { storeMemory } = useMemory();
  const [notes, setNotes] = useState<MeetingNote[]>([]);
  const [isAddingNote, setIsAddingNote] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [isSaving, setIsSaving] = useState(false);
  
  // Form state for new note
  const [newNote, setNewNote] = useState({
    title: '',
    date: new Date().toISOString().split('T')[0],
    type: 'ad_hoc' as MeetingNote['type'],
    platform: 'zoom' as MeetingNote['platform'],
    summary: '',
    actionItems: '',
    decisions: '',
    mentions: '',
    transcriptUrl: '',
  });

  const handleAddNote = useCallback(async () => {
    if (!newNote.title.trim() || !newNote.summary.trim()) {
      toast.error('Please provide a title and summary');
      return;
    }

    setIsSaving(true);
    
    const meetingNote: MeetingNote = {
      id: Date.now().toString(),
      title: newNote.title,
      date: new Date(newNote.date),
      type: newNote.type,
      platform: newNote.platform,
      summary: newNote.summary,
      actionItems: newNote.actionItems.split('\n').filter(Boolean),
      decisions: newNote.decisions.split('\n').filter(Boolean),
      mentions: newNote.mentions.split(',').map(m => m.trim()).filter(Boolean),
      transcriptUrl: newNote.transcriptUrl || undefined,
    };

    // Save to memory engine
    try {
      await storeMemory({
        content: `Meeting: ${meetingNote.title}\n\nSummary: ${meetingNote.summary}\n\nAction Items:\n${meetingNote.actionItems.join('\n')}\n\nDecisions:\n${meetingNote.decisions.join('\n')}`,
        title: meetingNote.title,
        memory_type: 'meeting_note',
        source: meetingNote.platform === 'zoom' ? 'zoom' : 'manual',
        metadata: {
          type: meetingNote.type,
          platform: meetingNote.platform,
          date: meetingNote.date.toISOString(),
          actionItems: meetingNote.actionItems,
          decisions: meetingNote.decisions,
          mentions: meetingNote.mentions,
          transcriptUrl: meetingNote.transcriptUrl,
        },
      });

      setNotes(prev => [meetingNote, ...prev]);
      setNewNote({
        title: '',
        date: new Date().toISOString().split('T')[0],
        type: 'ad_hoc',
        platform: 'zoom',
        summary: '',
        actionItems: '',
        decisions: '',
        mentions: '',
        transcriptUrl: '',
      });
      setIsAddingNote(false);
      toast.success('Meeting notes saved to memory!');
    } catch (error) {
      console.error('Failed to save meeting notes:', error);
      toast.error('Failed to save meeting notes');
    } finally {
      setIsSaving(false);
    }
  }, [newNote, storeMemory]);

  const handleDeleteNote = useCallback((noteId: string) => {
    setNotes(prev => prev.filter(n => n.id !== noteId));
    toast.success('Meeting note deleted');
  }, []);

  const handlePasteTranscript = useCallback(() => {
    navigator.clipboard.readText().then(text => {
      if (text) {
        setNewNote(prev => ({
          ...prev,
          summary: text.slice(0, 5000), // Limit to 5000 chars
        }));
        toast.success('Transcript pasted! You can edit the summary.');
      }
    }).catch(() => {
      toast.error('Failed to read clipboard');
    });
  }, []);

  const handleFileUpload = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      if (content) {
        setNewNote(prev => ({
          ...prev,
          summary: content.slice(0, 10000),
          title: prev.title || file.name.replace(/\.[^.]+$/, ''),
        }));
        toast.success(`Loaded ${file.name}`);
      }
    };
    reader.readAsText(file);
  }, []);

  const filteredNotes = notes.filter(note => {
    const matchesSearch = note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      note.summary.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesType = filterType === 'all' || note.type === filterType;
    return matchesSearch && matchesType;
  });

  const getMeetingTypeColor = (type: MeetingNote['type']) => {
    const colors: Record<MeetingNote['type'], string> = {
      standup: 'bg-emerald-500/20 text-emerald-400',
      grooming: 'bg-blue-500/20 text-blue-400',
      sprint_planning: 'bg-purple-500/20 text-purple-400',
      retrospective: 'bg-amber-500/20 text-amber-400',
      ad_hoc: 'bg-slate-500/20 text-slate-400',
    };
    return colors[type];
  };

  const getPlatformIcon = (platform: MeetingNote['platform']) => {
    return <Video className="h-3 w-3" />;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[85vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-primary" />
            Meeting Notes
          </DialogTitle>
          <DialogDescription>
            Upload, paste, or manually add meeting notes to help NAVI understand your project context.
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 flex flex-col gap-4 overflow-hidden">
          {/* Actions Bar */}
          <div className="flex items-center gap-2 flex-wrap">
            <Button 
              onClick={() => setIsAddingNote(true)}
              size="sm"
              className="gap-1"
            >
              <Plus className="h-4 w-4" />
              Add Notes
            </Button>
            
            <div className="flex-1 flex items-center gap-2">
              <div className="relative flex-1 max-w-xs">
                <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search notes..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-8 h-8"
                />
              </div>
              
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-40 h-8">
                  <Filter className="h-3 w-3 mr-1" />
                  <SelectValue placeholder="Filter" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  {MEETING_TYPES.map(type => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Add Note Form */}
          {isAddingNote && (
            <div className="border rounded-lg p-4 space-y-4 bg-card">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Title</label>
                  <Input
                    placeholder="Sprint Planning - Week 12"
                    value={newNote.title}
                    onChange={(e) => setNewNote(prev => ({ ...prev, title: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Date</label>
                  <Input
                    type="date"
                    value={newNote.date}
                    onChange={(e) => setNewNote(prev => ({ ...prev, date: e.target.value }))}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Meeting Type</label>
                  <Select 
                    value={newNote.type} 
                    onValueChange={(v) => setNewNote(prev => ({ ...prev, type: v as MeetingNote['type'] }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {MEETING_TYPES.map(type => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Platform</label>
                  <Select 
                    value={newNote.platform} 
                    onValueChange={(v) => setNewNote(prev => ({ ...prev, platform: v as MeetingNote['platform'] }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {PLATFORMS.map(p => (
                        <SelectItem key={p.value} value={p.value}>
                          {p.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">Summary / Transcript</label>
                  <div className="flex gap-2">
                    <Button variant="ghost" size="sm" onClick={handlePasteTranscript}>
                      <MessageSquare className="h-3 w-3 mr-1" />
                      Paste
                    </Button>
                    <label className="cursor-pointer">
                      <Button variant="ghost" size="sm" asChild>
                        <span>
                          <Upload className="h-3 w-3 mr-1" />
                          Upload
                        </span>
                      </Button>
                      <input
                        type="file"
                        accept=".txt,.md,.vtt,.srt"
                        className="hidden"
                        onChange={handleFileUpload}
                      />
                    </label>
                  </div>
                </div>
                <Textarea
                  placeholder="Paste meeting transcript or summary here..."
                  value={newNote.summary}
                  onChange={(e) => setNewNote(prev => ({ ...prev, summary: e.target.value }))}
                  className="min-h-[120px]"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-1">
                    <CheckSquare className="h-3 w-3" />
                    Action Items (one per line)
                  </label>
                  <Textarea
                    placeholder="- Implement feature X&#10;- Review PR #123&#10;- Update documentation"
                    value={newNote.actionItems}
                    onChange={(e) => setNewNote(prev => ({ ...prev, actionItems: e.target.value }))}
                    className="min-h-[80px]"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-1">
                    <MessageSquare className="h-3 w-3" />
                    Key Decisions (one per line)
                  </label>
                  <Textarea
                    placeholder="- Use React Query for state&#10;- Deploy to staging first"
                    value={newNote.decisions}
                    onChange={(e) => setNewNote(prev => ({ ...prev, decisions: e.target.value }))}
                    className="min-h-[80px]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium flex items-center gap-1">
                    <Users className="h-3 w-3" />
                    Participants (comma-separated)
                  </label>
                  <Input
                    placeholder="John, Sarah, Mike"
                    value={newNote.mentions}
                    onChange={(e) => setNewNote(prev => ({ ...prev, mentions: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Recording URL (optional)</label>
                  <Input
                    placeholder="https://zoom.us/rec/..."
                    value={newNote.transcriptUrl}
                    onChange={(e) => setNewNote(prev => ({ ...prev, transcriptUrl: e.target.value }))}
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2">
                <Button variant="ghost" onClick={() => setIsAddingNote(false)}>
                  Cancel
                </Button>
                <Button onClick={handleAddNote} disabled={isSaving}>
                  <Save className="h-4 w-4 mr-1" />
                  {isSaving ? 'Saving...' : 'Save to Memory'}
                </Button>
              </div>
            </div>
          )}

          {/* Notes List */}
          <ScrollArea className="flex-1">
            {filteredNotes.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No meeting notes yet</p>
                <p className="text-sm">Add notes to help NAVI understand your project context</p>
              </div>
            ) : (
              <div className="space-y-3 pr-4">
                {filteredNotes.map(note => (
                  <div 
                    key={note.id} 
                    className="border rounded-lg p-4 hover:bg-accent/50 transition-colors"
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-medium truncate">{note.title}</h4>
                          <Badge variant="secondary" className={getMeetingTypeColor(note.type)}>
                            {MEETING_TYPES.find(t => t.value === note.type)?.label}
                          </Badge>
                        </div>
                        
                        <div className="flex items-center gap-3 text-xs text-muted-foreground mb-2">
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {note.date.toLocaleDateString()}
                          </span>
                          <span className="flex items-center gap-1">
                            {getPlatformIcon(note.platform)}
                            {PLATFORMS.find(p => p.value === note.platform)?.label}
                          </span>
                          {note.mentions.length > 0 && (
                            <span className="flex items-center gap-1">
                              <Users className="h-3 w-3" />
                              {note.mentions.length} participants
                            </span>
                          )}
                        </div>

                        <p className="text-sm text-muted-foreground line-clamp-2">
                          {note.summary}
                        </p>

                        {note.actionItems.length > 0 && (
                          <div className="mt-2 flex items-center gap-1">
                            <CheckSquare className="h-3 w-3 text-primary" />
                            <span className="text-xs">{note.actionItems.length} action items</span>
                          </div>
                        )}
                      </div>
                      
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-muted-foreground hover:text-destructive"
                        onClick={() => handleDeleteNote(note.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
