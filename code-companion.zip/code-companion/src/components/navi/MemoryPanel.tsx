import { useState, useEffect } from 'react';
import {
  Brain,
  Search,
  Trash2,
  RefreshCw,
  FileText,
  MessageSquare,
  Code,
  Video,
  BookOpen,
  Settings,
  Plus,
  Filter,
  ChevronDown,
  ExternalLink,
  Loader2,
  Clock,
  Tag,
  AlertCircle,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { useMemory, Memory, MemoryType, MemorySource } from '@/hooks/useMemory';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

const sourceIcons: Record<MemorySource, React.ReactNode> = {
  jira: <FileText className="h-3.5 w-3.5 text-blue-400" />,
  confluence: <BookOpen className="h-3.5 w-3.5 text-blue-300" />,
  slack: <MessageSquare className="h-3.5 w-3.5 text-purple-400" />,
  teams: <MessageSquare className="h-3.5 w-3.5 text-violet-400" />,
  zoom: <Video className="h-3.5 w-3.5 text-sky-400" />,
  github: <Code className="h-3.5 w-3.5 text-green-400" />,
  manual: <Settings className="h-3.5 w-3.5 text-muted-foreground" />,
  conversation: <MessageSquare className="h-3.5 w-3.5 text-primary" />,
};

const typeColors: Record<MemoryType, string> = {
  user_preference: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
  task_context: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  code_snippet: 'bg-green-500/20 text-green-400 border-green-500/30',
  meeting_note: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
  conversation: 'bg-primary/20 text-primary border-primary/30',
  documentation: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
  slack_message: 'bg-violet-500/20 text-violet-400 border-violet-500/30',
  jira_ticket: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
};

interface MemoryCardProps {
  memory: Memory;
  onDelete: (id: string) => void;
  isDeleting: boolean;
}

function MemoryCard({ memory, onDelete, isDeleting }: MemoryCardProps) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div 
      className={cn(
        "p-3 rounded-lg border border-border bg-card/50 hover:bg-card transition-colors",
        expanded && "bg-card"
      )}
    >
      <div className="flex items-start gap-3">
        <div className="flex-shrink-0 mt-0.5">
          {sourceIcons[memory.source]}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            {memory.title && (
              <span className="font-medium text-sm truncate">{memory.title}</span>
            )}
            <Badge variant="outline" className={cn("text-[10px]", typeColors[memory.memory_type])}>
              {memory.memory_type.replace('_', ' ')}
            </Badge>
          </div>
          <p 
            className={cn(
              "text-xs text-muted-foreground",
              !expanded && "line-clamp-2"
            )}
          >
            {memory.content}
          </p>
          {memory.content.length > 150 && (
            <button 
              onClick={() => setExpanded(!expanded)}
              className="text-xs text-primary hover:underline mt-1"
            >
              {expanded ? 'Show less' : 'Show more'}
            </button>
          )}
          <div className="flex items-center gap-3 mt-2 text-[10px] text-muted-foreground">
            <span className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              {new Date(memory.created_at).toLocaleDateString()}
            </span>
            {memory.similarity !== undefined && (
              <span className="flex items-center gap-1">
                <Tag className="h-3 w-3" />
                {Math.round(memory.similarity * 100)}% match
              </span>
            )}
            {memory.source_url && (
              <a 
                href={memory.source_url} 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-primary hover:underline"
              >
                <ExternalLink className="h-3 w-3" />
                Source
              </a>
            )}
          </div>
        </div>
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-7 w-7 flex-shrink-0 opacity-50 hover:opacity-100"
              disabled={isDeleting}
            >
              {isDeleting ? (
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
              ) : (
                <Trash2 className="h-3.5 w-3.5" />
              )}
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete Memory</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to delete this memory? This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={() => onDelete(memory.id)}>Delete</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}

export function MemoryPanel() {
  const [searchQuery, setSearchQuery] = useState('');
  const [memories, setMemories] = useState<Memory[]>([]);
  const [searchResults, setSearchResults] = useState<Memory[] | null>(null);
  const [filterType, setFilterType] = useState<MemoryType | 'all'>('all');
  const [filterSource, setFilterSource] = useState<MemorySource | 'all'>('all');
  const [isSearching, setIsSearching] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const { 
    isLoading, 
    error, 
    getMemories, 
    searchMemories, 
    deleteMemory 
  } = useMemory();

  // Load initial memories
  useEffect(() => {
    loadMemories();
  }, [filterType, filterSource]);

  const loadMemories = async () => {
    try {
      const options: any = { limit: 50 };
      if (filterType !== 'all') options.memory_type = filterType;
      if (filterSource !== 'all') options.source = filterSource;
      
      const data = await getMemories(options);
      setMemories(data);
      setSearchResults(null);
    } catch (err) {
      console.error('Failed to load memories:', err);
    }
  };

  const handleSearch = async () => {
    if (!searchQuery.trim()) {
      setSearchResults(null);
      return;
    }

    setIsSearching(true);
    try {
      const results = await searchMemories(searchQuery, { match_count: 20 });
      setSearchResults(results);
      toast.success(`Found ${results.length} related memories`);
    } catch (err) {
      toast.error('Search failed. Please try again.');
    } finally {
      setIsSearching(false);
    }
  };

  const handleDelete = async (memoryId: string) => {
    setDeletingId(memoryId);
    try {
      await deleteMemory(memoryId);
      setMemories(prev => prev.filter(m => m.id !== memoryId));
      if (searchResults) {
        setSearchResults(prev => prev?.filter(m => m.id !== memoryId) || null);
      }
      toast.success('Memory deleted');
    } catch (err) {
      toast.error('Failed to delete memory');
    } finally {
      setDeletingId(null);
    }
  };

  const displayMemories = searchResults || memories;
  const memoryTypes: MemoryType[] = [
    'user_preference', 'task_context', 'code_snippet', 'meeting_note',
    'conversation', 'documentation', 'slack_message', 'jira_ticket'
  ];
  const memorySources: MemorySource[] = [
    'jira', 'confluence', 'slack', 'teams', 'zoom', 'github', 'manual', 'conversation'
  ];

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-border space-y-3">
        <div className="flex items-center gap-2">
          <Brain className="h-5 w-5 text-primary" />
          <h2 className="font-semibold">Memory Store</h2>
          <Badge variant="secondary" className="ml-auto">
            {displayMemories.length} memories
          </Badge>
        </div>

        {/* Search */}
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              placeholder="Search memories semantically..."
              className="pl-9 h-9"
            />
          </div>
          <Button 
            variant="secondary" 
            size="sm" 
            onClick={handleSearch}
            disabled={isSearching}
            className="h-9"
          >
            {isSearching ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Search'}
          </Button>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="h-8 gap-1.5 text-xs">
                <Filter className="h-3.5 w-3.5" />
                Type: {filterType === 'all' ? 'All' : filterType.replace('_', ' ')}
                <ChevronDown className="h-3 w-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start">
              <DropdownMenuItem onClick={() => setFilterType('all')}>All Types</DropdownMenuItem>
              <DropdownMenuSeparator />
              {memoryTypes.map(type => (
                <DropdownMenuItem 
                  key={type} 
                  onClick={() => setFilterType(type)}
                  className={filterType === type ? 'bg-primary/10' : ''}
                >
                  {type.replace('_', ' ')}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="sm" className="h-8 gap-1.5 text-xs">
                Source: {filterSource === 'all' ? 'All' : filterSource}
                <ChevronDown className="h-3 w-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start">
              <DropdownMenuItem onClick={() => setFilterSource('all')}>All Sources</DropdownMenuItem>
              <DropdownMenuSeparator />
              {memorySources.map(source => (
                <DropdownMenuItem 
                  key={source} 
                  onClick={() => setFilterSource(source)}
                  className={cn(
                    "flex items-center gap-2",
                    filterSource === source && 'bg-primary/10'
                  )}
                >
                  {sourceIcons[source]}
                  {source}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          <Button 
            variant="ghost" 
            size="icon" 
            className="h-8 w-8 ml-auto"
            onClick={loadMemories}
            disabled={isLoading}
          >
            <RefreshCw className={cn("h-4 w-4", isLoading && "animate-spin")} />
          </Button>
        </div>
      </div>

      {/* Content */}
      <ScrollArea className="flex-1">
        <div className="p-4 space-y-3">
          {isLoading && memories.length === 0 ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          ) : error ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <AlertCircle className="h-12 w-12 text-destructive mb-4" />
              <p className="text-sm text-muted-foreground">Failed to load memories</p>
              <p className="text-xs text-muted-foreground mt-1">{error}</p>
              <Button variant="outline" size="sm" onClick={loadMemories} className="mt-4">
                Try Again
              </Button>
            </div>
          ) : displayMemories.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Brain className="h-12 w-12 text-muted-foreground mb-4 opacity-50" />
              <p className="text-sm font-medium">No memories yet</p>
              <p className="text-xs text-muted-foreground mt-1">
                {searchQuery 
                  ? 'No memories match your search. Try different keywords.' 
                  : 'NAVI will remember context from your conversations, tasks, and integrations.'}
              </p>
            </div>
          ) : (
            <>
              {searchResults && (
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-muted-foreground">
                    Search results for "{searchQuery}"
                  </span>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="h-6 text-xs"
                    onClick={() => {
                      setSearchQuery('');
                      setSearchResults(null);
                    }}
                  >
                    Clear
                  </Button>
                </div>
              )}
              {displayMemories.map(memory => (
                <MemoryCard 
                  key={memory.id} 
                  memory={memory} 
                  onDelete={handleDelete}
                  isDeleting={deletingId === memory.id}
                />
              ))}
            </>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
