import { useState } from 'react';
import { ThumbsUp, ThumbsDown, Copy, Check, RotateCcw, History, Pencil, X, ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

const regenerateModels = [
  { id: 'google/gemini-2.5-flash', name: 'Gemini 2.5 Flash', description: 'Fast & balanced' },
  { id: 'google/gemini-2.5-pro', name: 'Gemini 2.5 Pro', description: 'Top-tier' },
  { id: 'openai/gpt-5-mini', name: 'GPT-5 Mini', description: 'Fast & efficient' },
  { id: 'openai/gpt-5', name: 'GPT-5', description: 'Most capable' },
];

interface MessageActionsProps {
  role: 'user' | 'assistant';
  content: string;
  messageId: string;
  onRetry?: () => void;
  onRetryWithModel?: (modelId: string) => void;
  onRestore?: () => void;
  onEdit?: (newContent: string) => void;
  onFeedback?: (type: 'like' | 'dislike') => void;
  className?: string;
  initialFeedback?: 'like' | 'dislike' | null;
}

export function MessageActions({
  role,
  content,
  messageId,
  onRetry,
  onRetryWithModel,
  onRestore,
  onEdit,
  onFeedback,
  className,
  initialFeedback = null,
}: MessageActionsProps) {
  const [copied, setCopied] = useState(false);
  const [feedback, setFeedback] = useState<'like' | 'dislike' | null>(initialFeedback);
  const [isEditing, setIsEditing] = useState(false);
  const [editContent, setEditContent] = useState(content);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(content);
    setCopied(true);
    toast.success('Copied to clipboard');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleLike = () => {
    const newFeedback = feedback === 'like' ? null : 'like';
    setFeedback(newFeedback);
    if (newFeedback) {
      onFeedback?.('like');
    }
  };

  const handleDislike = () => {
    const newFeedback = feedback === 'dislike' ? null : 'dislike';
    setFeedback(newFeedback);
    if (newFeedback) {
      onFeedback?.('dislike');
    }
  };

  const handleStartEdit = () => {
    setEditContent(content);
    setIsEditing(true);
  };

  const handleCancelEdit = () => {
    setEditContent(content);
    setIsEditing(false);
  };

  const handleSaveEdit = () => {
    if (editContent.trim() && editContent !== content) {
      onEdit?.(editContent.trim());
    }
    setIsEditing(false);
  };

  // Render inline editor for user messages
  if (role === 'user' && isEditing) {
    return (
      <div className="mt-2 space-y-2 animate-fade-in">
        <Textarea
          value={editContent}
          onChange={(e) => setEditContent(e.target.value)}
          className="min-h-[80px] text-sm bg-background resize-none"
          autoFocus
        />
        <div className="flex items-center gap-2 justify-end">
          <Button
            variant="ghost"
            size="sm"
            onClick={handleCancelEdit}
            className="h-7 px-2 text-xs"
          >
            <X className="h-3 w-3 mr-1" />
            Cancel
          </Button>
          <Button
            variant="default"
            size="sm"
            onClick={handleSaveEdit}
            disabled={!editContent.trim()}
            className="h-7 px-2 text-xs"
          >
            <Check className="h-3 w-3 mr-1" />
            Save
          </Button>
        </div>
      </div>
    );
  }

  if (role === 'assistant') {
    return (
      <TooltipProvider delayDuration={100}>
        <div className={cn(
          "flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200",
          className
        )}>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className={cn(
                  "h-6 w-6 rounded",
                  feedback === 'like' && "text-green-500 bg-green-500/10"
                )}
                onClick={handleLike}
              >
                <ThumbsUp className="h-3.5 w-3.5" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="text-xs">
              Helpful
            </TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className={cn(
                  "h-6 w-6 rounded",
                  feedback === 'dislike' && "text-red-500 bg-red-500/10"
                )}
                onClick={handleDislike}
              >
                <ThumbsDown className="h-3.5 w-3.5" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="text-xs">
              Not helpful
            </TooltipContent>
          </Tooltip>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6 rounded"
                onClick={handleCopy}
              >
                {copied ? (
                  <Check className="h-3.5 w-3.5 text-green-500" />
                ) : (
                  <Copy className="h-3.5 w-3.5" />
                )}
              </Button>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="text-xs">
              Copy
            </TooltipContent>
          </Tooltip>

          <DropdownMenu>
            <Tooltip>
              <TooltipTrigger asChild>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 rounded"
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                  </Button>
                </DropdownMenuTrigger>
              </TooltipTrigger>
              <TooltipContent side="bottom" className="text-xs">
                Retry
              </TooltipContent>
            </Tooltip>
            <DropdownMenuContent align="start" className="w-48">
              <DropdownMenuItem onClick={onRetry}>
                <RotateCcw className="h-3.5 w-3.5 mr-2" />
                Retry with same model
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuLabel className="text-xs text-muted-foreground">
                Retry with different model
              </DropdownMenuLabel>
              {regenerateModels.map((model) => (
                <DropdownMenuItem 
                  key={model.id}
                  onClick={() => onRetryWithModel?.(model.id)}
                >
                  <span className="text-sm">{model.name}</span>
                  <span className="ml-auto text-xs text-muted-foreground">{model.description}</span>
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          <Tooltip>
            <TooltipTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-6 w-6 rounded"
                onClick={onRestore}
              >
                <History className="h-3.5 w-3.5" />
              </Button>
            </TooltipTrigger>
            <TooltipContent side="bottom" className="text-xs">
              Restore to this checkpoint
            </TooltipContent>
          </Tooltip>
        </div>
      </TooltipProvider>
    );
  }

  // User message actions
  return (
    <TooltipProvider delayDuration={100}>
      <div className={cn(
        "flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity duration-200",
        className
      )}>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6 rounded"
              onClick={handleCopy}
            >
              {copied ? (
                <Check className="h-3.5 w-3.5 text-green-500" />
              ) : (
                <Copy className="h-3.5 w-3.5" />
              )}
            </Button>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="text-xs">
            Copy
          </TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6 rounded"
              onClick={handleStartEdit}
            >
              <Pencil className="h-3.5 w-3.5" />
            </Button>
          </TooltipTrigger>
          <TooltipContent side="bottom" className="text-xs">
            Edit
          </TooltipContent>
        </Tooltip>
      </div>
    </TooltipProvider>
  );
}
