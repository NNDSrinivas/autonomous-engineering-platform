import { useState, useRef, useEffect, useCallback } from 'react';
import { 
  Send, 
  Sparkles, 
  Copy, 
  Check, 
  Bot, 
  User,
  ExternalLink,
  FileText,
  MessageSquare,
  Video,
  GitBranch,
  Play,
  X,
  CheckCircle2,
  Loader2,
  ChevronDown,
  History,
  Terminal,
  HelpCircle,
  Trash2,
  ListTodo,
  Cpu,
  Moon,
  Sun,
  Download,
  Keyboard,
  Plus,
  Bookmark,
  FolderOpen,
  Mic,
  MicOff,
  Upload,
  Paperclip,
  AlertTriangle,
  Search as SearchIcon,
  Brain,
  RotateCcw,
  ArrowDown
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { useNaviChat, llmProviders, chatModes, ChatMode } from '@/hooks/useNaviChat';
import { getRecommendedModel, getAllModelRecommendations, type TaskType } from '@/lib/llmRouter';
import { useTheme } from '@/hooks/useTheme';
import { useMemory } from '@/hooks/useMemory';
import { useSmartPrompts } from '@/hooks/useSmartPrompts';
import { useProjectFiles } from '@/hooks/useProjectFiles';
import type { JiraTask, SourceLink, ActionItem } from '@/types';
import { CollaborationIndicator } from './CollaborationIndicator';
import { MeetingNotesPanel } from './MeetingNotesPanel';
import { MorningBriefing } from './MorningBriefing';
import { AudioWaveform } from './AudioWaveform';
import { AgentActivityPanel } from './AgentActivityPanel';
import { MessageActions } from './MessageActions';
import { ProjectFilesDialog } from './ProjectFilesDialog';
import { ChatHistorySidebar, saveConversationToHistory, type ChatConversation } from './ChatHistorySidebar';
import { CodeSearchPanel } from './CodeSearchPanel';
import { useAgentActivityStream } from '@/hooks/useAgentActivityStream';
import { useMessageFeedback } from '@/hooks/useMessageFeedback';
import { toast } from 'sonner';
import smartToast from '@/hooks/useToastPreferences';
import Prism from 'prismjs';
import 'prismjs/themes/prism-tomorrow.css';
import 'prismjs/components/prism-typescript';
import 'prismjs/components/prism-javascript';
import 'prismjs/components/prism-jsx';
import 'prismjs/components/prism-tsx';
import 'prismjs/components/prism-css';
import 'prismjs/components/prism-json';
import 'prismjs/components/prism-bash';
import 'prismjs/components/prism-python';
import 'prismjs/components/prism-sql';
import 'prismjs/components/prism-markdown';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
interface NaviChatProps {
  selectedTask: JiraTask | null;
  userName: string;
  jiraTasks?: JiraTask[];
  onTaskClick?: (task: JiraTask) => void;
}

function getGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return 'Good morning';
  if (hour < 17) return 'Good afternoon';
  return 'Good evening';
}

function CodeBlockComponent({ code, language }: { code: string; language: string }) {
  const [copied, setCopied] = useState(false);
  const codeRef = useRef<HTMLElement>(null);

  useEffect(() => {
    if (codeRef.current) {
      Prism.highlightElement(codeRef.current);
    }
  }, [code, language]);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Map common language aliases
  const getLangClass = (lang: string) => {
    const aliases: Record<string, string> = {
      'ts': 'typescript',
      'js': 'javascript',
      'py': 'python',
      'sh': 'bash',
      'shell': 'bash',
      'plaintext': 'text',
    };
    return aliases[lang.toLowerCase()] || lang.toLowerCase();
  };

  return (
    <div className="my-2 rounded-lg overflow-hidden border border-border">
      <div className="flex items-center justify-between px-3 py-1.5 bg-secondary text-xs">
        <span className="text-muted-foreground">{language}</span>
        <Button variant="ghost" size="xs" onClick={handleCopy} className="h-6 gap-1">
          {copied ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
          {copied ? 'Copied' : 'Copy'}
        </Button>
      </div>
      <pre className="p-3 bg-terminal overflow-x-auto !m-0">
        <code 
          ref={codeRef}
          className={`text-xs font-mono language-${getLangClass(language)}`}
        >
          {code}
        </code>
      </pre>
    </div>
  );
}

function SourceCard({ source }: { source: SourceLink }) {
  const icons = {
    jira: <FileText className="h-3.5 w-3.5 text-blue-400" />,
    slack: <MessageSquare className="h-3.5 w-3.5 text-purple-400" />,
    teams: <MessageSquare className="h-3.5 w-3.5 text-violet-400" />,
    confluence: <FileText className="h-3.5 w-3.5 text-blue-300" />,
    github: <GitBranch className="h-3.5 w-3.5 text-green-400" />,
    zoom: <Video className="h-3.5 w-3.5 text-sky-400" />,
    meeting: <Video className="h-3.5 w-3.5 text-sky-400" />,
  };

  return (
    <a
      href={source.url}
      target="_blank"
      rel="noopener noreferrer"
      className="flex items-start gap-2 p-2 rounded-lg bg-card hover:bg-secondary border border-border transition-colors group"
    >
      <div className="mt-0.5">{icons[source.type]}</div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1">
          <span className="text-xs font-medium truncate">{source.title}</span>
          <ExternalLink className="h-3 w-3 text-muted-foreground opacity-0 group-hover:opacity-100 flex-shrink-0" />
        </div>
        {source.snippet && (
          <p className="text-[10px] text-muted-foreground mt-0.5 line-clamp-2">{source.snippet}</p>
        )}
      </div>
    </a>
  );
}

function ActionButton({ action, onApprove, onReject }: { 
  action: ActionItem; 
  onApprove: () => void;
  onReject: () => void;
}) {
  const icons = {
    implement: <Play className="h-3.5 w-3.5" />,
    fix: <CheckCircle2 className="h-3.5 w-3.5" />,
    create_pr: <GitBranch className="h-3.5 w-3.5" />,
    commit: <GitBranch className="h-3.5 w-3.5" />,
    run_tests: <Play className="h-3.5 w-3.5" />,
    deploy: <Loader2 className="h-3.5 w-3.5" />,
  };

  if (action.status === 'completed') {
    return (
      <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-green-500/10 border border-green-500/20 text-green-400">
        <CheckCircle2 className="h-4 w-4" />
        <span className="text-sm">{action.label}</span>
        <Badge variant="outline" className="ml-auto text-[10px] bg-green-500/20 text-green-400 border-green-500/30">
          Completed
        </Badge>
      </div>
    );
  }

  if (action.status === 'pending') {
    return (
      <div className="flex items-center gap-2 p-3 rounded-lg bg-card border border-primary/30">
        <div className="flex-1">
          <div className="flex items-center gap-2">
            {icons[action.type]}
            <span className="text-sm font-medium">{action.label}</span>
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            NAVI is waiting for your approval to proceed.
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={onReject} className="h-8 px-3 text-destructive hover:bg-destructive/10">
            <X className="h-3.5 w-3.5 mr-1" />Reject
          </Button>
          <Button variant="ai" size="sm" onClick={onApprove} className="h-8 px-3">
            <Check className="h-3.5 w-3.5 mr-1" />Approve
          </Button>
        </div>
      </div>
    );
  }

  return null;
}

function MessageContent({ content, sources, actions, onActionApprove, onActionReject }: { 
  content: string;
  sources?: SourceLink[];
  actions?: ActionItem[];
  onActionApprove?: (id: string) => void;
  onActionReject?: (id: string) => void;
}) {
  const parts = content.split(/(```[\s\S]*?```)/g);
  
  return (
    <div className="space-y-3">
      <div className="text-sm leading-relaxed">
        {parts.map((part, index) => {
          if (part.startsWith('```')) {
            const match = part.match(/```(\w+)?\n?([\s\S]*?)```/);
            if (match) {
              return <CodeBlockComponent key={index} language={match[1] || 'plaintext'} code={match[2].trim()} />;
            }
          }
          return <span key={index} className="whitespace-pre-wrap">{part}</span>;
        })}
      </div>

      {sources && sources.length > 0 && (
        <div className="space-y-2">
          <span className="text-[10px] uppercase text-muted-foreground tracking-wider">Sources</span>
          <div className="grid gap-2">
            {sources.map((source, i) => <SourceCard key={i} source={source} />)}
          </div>
        </div>
      )}

      {actions && actions.length > 0 && (
        <div className="space-y-2">
          {actions.map((action) => (
            <ActionButton
              key={action.id}
              action={action}
              onApprove={() => onActionApprove?.(action.id)}
              onReject={() => onActionReject?.(action.id)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

const COMMAND_HISTORY_KEY = 'navi-command-history';
const SAVED_CHATS_KEY = 'navi-saved-chats';

// Context-aware common prompts for autocomplete (static fallback)
const COMMON_PROMPTS = [
  'Show my tasks',
  'Generate code',
  'Explain this task',
  'Review my PR',
  'Debug help',
  'What files need to change?',
  'How should I implement this?',
  'Explain the requirements',
  'Create a new component',
  'Fix this bug',
  'Check CI/CD status',
  'Search Confluence docs',
  'Summarize recent Slack messages',
  'Update Jira status',
  'Create a feature branch',
];

interface SavedChat {
  id: string;
  name: string;
  messages: any[];
  timestamp: Date;
}

interface SlashCommand {
  command: string;
  description: string;
  action: () => void;
}

// Fuzzy match function - scores how well query matches target
function fuzzyMatch(query: string, target: string): number {
  const q = query.toLowerCase();
  const t = target.toLowerCase();
  
  // Exact match gets highest score
  if (t === q) return 1000;
  
  // Starts with gets high score
  if (t.startsWith(q)) return 500 + (q.length / t.length) * 100;
  
  // Contains gets medium score
  if (t.includes(q)) return 200 + (q.length / t.length) * 100;
  
  // Fuzzy matching - each character in query should appear in order in target
  let queryIndex = 0;
  let score = 0;
  let consecutiveBonus = 0;
  let lastMatchIndex = -2;
  
  for (let i = 0; i < t.length && queryIndex < q.length; i++) {
    if (t[i] === q[queryIndex]) {
      // Bonus for consecutive matches
      if (i === lastMatchIndex + 1) {
        consecutiveBonus += 10;
      }
      score += 10 + consecutiveBonus;
      lastMatchIndex = i;
      queryIndex++;
    }
  }
  
  // All characters matched?
  if (queryIndex === q.length) {
    return score;
  }
  
  return 0; // No match
}

export function NaviChat({ selectedTask, userName, jiraTasks = [], onTaskClick }: NaviChatProps) {
  const greeting = getGreeting();
  const [input, setInput] = useState('');
  const [commandHistory, setCommandHistory] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(COMMAND_HISTORY_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [tempInput, setTempInput] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [selectedSuggestionIndex, setSelectedSuggestionIndex] = useState(0);
  const [showLoadDialog, setShowLoadDialog] = useState(false);
  const [savedChats, setSavedChats] = useState<SavedChat[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [dragCounter, setDragCounter] = useState(0);
  const [attachedFiles, setAttachedFiles] = useState<File[]>([]);
  const [isListening, setIsListening] = useState(false);
  const [voiceTranscript, setVoiceTranscript] = useState('');
  const [voiceSupported, setVoiceSupported] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showMemoryDialog, setShowMemoryDialog] = useState(false);
  const [showProjectFilesDialog, setShowProjectFilesDialog] = useState(false);
  const [attachedProjectFiles, setAttachedProjectFiles] = useState<{ name: string; path: string; content?: string }[]>([]);
  const [isLoadingProjectFiles, setIsLoadingProjectFiles] = useState(false);
  const [showMeetingNotesPanel, setShowMeetingNotesPanel] = useState(false);
  const [showMorningBriefing, setShowMorningBriefing] = useState(() => {
    // Show briefing on first visit of the day
    const lastShown = localStorage.getItem('morning-briefing-last-shown');
    const today = new Date().toDateString();
    return lastShown !== today;
  });
  const [memoryInput, setMemoryInput] = useState('');
  const [memorySearchQuery, setMemorySearchQuery] = useState('');
  const [memorySearchResults, setMemorySearchResults] = useState<any[]>([]);
  const [isSearchingMemory, setIsSearchingMemory] = useState(false);
  const [conversationId] = useState(() => `conv-${Date.now()}`);
  const [lastSummarizedCount, setLastSummarizedCount] = useState(0);
  const [detectedTask, setDetectedTask] = useState<{ taskType: TaskType; modelId: string; modelName: string; reason: string } | null>(null);
  const [useAutoModel, setUseAutoModel] = useState(true);
  const [showScrollButton, setShowScrollButton] = useState(false);
  const [showChatHistory, setShowChatHistory] = useState(false);
  const [showCodeSearch, setShowCodeSearch] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const messagesContainerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const suggestionsRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const recognitionRef = useRef<any>(null);
  
  const { 
    messages, 
    setMessages, 
    isLoading, 
    sendMessage,
    retryWithModel,
    selectedModel,
    selectedProvider,
    setModel,
    resetModelPreference,
    chatMode,
    setChatMode,
    getDisplayModelName,
    lastRouterInfo,
    registerStreamCallback,
  } = useNaviChat({ selectedTask, userName });
  
  const { toggleTheme, resolvedTheme } = useTheme();
  const { 
    storeMemory, 
    searchMemories, 
    saveConversation,
  } = useMemory();

  // Project files hook for reading content
  const { 
    fetchMultipleFiles, 
    formatFilesForContext,
    isLoading: isLoadingFiles 
  } = useProjectFiles();

  // Agent activity with real-time streaming for visual feedback
  const agentActivity = useAgentActivityStream();

  // Message feedback persistence
  const { submitFeedback } = useMessageFeedback();

  // Smart context-aware prompts
  const { 
    smartPrompts, 
    currentPlaceholder, 
    isPlaceholderTransitioning 
  } = useSmartPrompts(selectedTask, messages, {
    github: false, // Will be connected to real status
    slack: false,
    confluence: false,
    hasPendingPR: false,
    hasFailingBuild: false,
  });

  // Determine if a request should show agent activity (only for truly complex operations)
  const isComplexWorkOperation = useCallback((message: string) => {
    const workPatterns = [
      /generate\s*(code|tests|component|function)/i,
      /create\s*(pr|pull\s*request|branch|file|component)/i,
      /implement\s+/i,
      /refactor\s+/i,
      /deploy\s+/i,
      /run\s*(tests|build|pipeline)/i,
      /fix\s*(bug|error|issue)/i,
      /analyze\s*(code|files|codebase)/i,
      /review\s*(pr|code|changes)/i,
      /search\s*(confluence|docs|files|codebase)/i,
      /update\s*(jira|status|task)/i,
    ];
    return workPatterns.some(pattern => pattern.test(message.trim()));
  }, []);

  // Register stream callback to parse AI responses in real-time
  useEffect(() => {
    registerStreamCallback((chunk, fullContent) => {
      // Parse the AI response for file operations and code changes
      if (agentActivity.isActive) {
        agentActivity.parseAIResponse(fullContent);
      }
    });

    return () => {
      registerStreamCallback(null);
    };
  }, [registerStreamCallback, agentActivity.isActive, agentActivity.parseAIResponse]);

  // Only trigger agent activity for complex work operations with real-time streaming
  useEffect(() => {
    if (isLoading) {
      const lastMessage = messages[messages.length - 1];
      if (lastMessage?.role === 'user' && isComplexWorkOperation(lastMessage.content)) {
        // Start real-time streaming activity (without simulation)
        agentActivity.startActivity(`Analyzing: ${lastMessage.content.substring(0, 50)}...`);
      }
    }
  }, [isLoading, messages, isComplexWorkOperation, agentActivity.startActivity]);

  // Complete activity and save to history when loading finishes
  useEffect(() => {
    if (!isLoading && agentActivity.isActive) {
      agentActivity.completeActivity();
      
      // Save activity to database
      agentActivity.saveActivityToHistory(
        conversationId,
        selectedTask?.key,
        `Processed ${agentActivity.files.length} files, ${agentActivity.linesChanged} lines changed`
      );
      
      const resetTimeout = setTimeout(() => agentActivity.resetActivity(), 2000);
      return () => clearTimeout(resetTimeout);
    }
  }, [isLoading, agentActivity.isActive, conversationId, selectedTask?.key]);

  // Real-time task detection as user types
  useEffect(() => {
    if (selectedModel === 'auto/recommended' && input.trim().length > 10) {
      const recommendation = getRecommendedModel(input);
      setDetectedTask({
        taskType: recommendation.taskType,
        modelId: recommendation.modelId,
        modelName: recommendation.modelName,
        reason: recommendation.reason,
      });
    } else {
      setDetectedTask(null);
    }
  }, [input, selectedModel]);

  // Auto-summarize conversation every 10 messages
  useEffect(() => {
    const messageCount = messages.length;
    if (messageCount > 0 && messageCount % 10 === 0 && messageCount > lastSummarizedCount) {
      summarizeConversation();
      setLastSummarizedCount(messageCount);
    }
  }, [messages.length]);

  const summarizeConversation = useCallback(async () => {
    if (messages.length < 5) return;
    
    try {
      // Extract key topics from messages
      const userMessages = messages.filter(m => m.role === 'user').map(m => m.content);
      const keyTopics = userMessages
        .slice(-5)
        .flatMap(m => m.split(' ').filter(w => w.length > 5))
        .slice(0, 10);
      
      // Create a summary of the conversation
      const summary = messages
        .slice(-10)
        .map(m => `${m.role}: ${m.content.substring(0, 100)}`)
        .join('\n');

      await saveConversation({
        conversation_id: conversationId,
        summary: summary.substring(0, 500),
        message_count: messages.length,
        key_topics: [...new Set(keyTopics)],
        metadata: {
          task_key: selectedTask?.key,
          last_updated: new Date().toISOString(),
        },
      });
      
      console.log('[NaviChat] Conversation auto-saved to memory');
    } catch (err) {
      console.error('Failed to save conversation summary:', err);
    }
  }, [messages, conversationId, selectedTask, saveConversation]);

  // Memory search handler
  const handleMemorySearch = useCallback(async () => {
    if (!memorySearchQuery.trim()) return;
    
    setIsSearchingMemory(true);
    try {
      const results = await searchMemories(memorySearchQuery, { match_count: 5 });
      setMemorySearchResults(results);
      
      if (results.length === 0) {
        smartToast.info('No matching memories found');
      }
    } catch (err) {
      toast.error('Failed to search memories');
    } finally {
      setIsSearchingMemory(false);
    }
  }, [memorySearchQuery, searchMemories]);

  // Save to memory handler
  const handleSaveToMemory = useCallback(async () => {
    if (!memoryInput.trim()) {
      toast.error('Please enter content to save');
      return;
    }
    
    try {
      await storeMemory({
        memory_type: 'conversation',
        source: 'manual',
        title: `Manual note - ${new Date().toLocaleDateString()}`,
        content: memoryInput,
        metadata: {
          task_key: selectedTask?.key,
          saved_from: 'chat',
        },
      });
      
      smartToast.success('Saved to memory!');
      setMemoryInput('');
      setShowMemoryDialog(false);
    } catch (err) {
      toast.error('Failed to save to memory');
    }
  }, [memoryInput, selectedTask, storeMemory]);

  // Check for Web Speech API support
  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    setVoiceSupported(!!SpeechRecognition);
  }, []);

  // Keyboard shortcut: Cmd+M to toggle Auto/Manual model selection
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'm') {
        e.preventDefault();
        if (selectedModel === 'auto/recommended') {
          setUseAutoModel(prev => !prev);
          smartToast.success(useAutoModel ? 'Switched to manual model selection' : 'Switched to auto model selection');
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedModel, useAutoModel]);

  // Voice recognition functions with extended silence detection
  const silenceTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const lastSpeechTimeRef = useRef<number>(Date.now());
  const SILENCE_TIMEOUT = 3000; // 3 seconds of silence before stopping

  const startVoiceInput = useCallback(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      toast.error('Voice input is not supported in your browser');
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true; // Keep listening continuously
    recognition.interimResults = true;
    recognition.lang = 'en-US';
    recognition.maxAlternatives = 1;

    // Reset silence detection
    const resetSilenceTimer = () => {
      lastSpeechTimeRef.current = Date.now();
      if (silenceTimeoutRef.current) {
        clearTimeout(silenceTimeoutRef.current);
      }
      silenceTimeoutRef.current = setTimeout(() => {
        // Stop after silence
        if (recognitionRef.current && Date.now() - lastSpeechTimeRef.current >= SILENCE_TIMEOUT) {
          smartToast.info('Stopped listening after pause');
          recognitionRef.current.stop();
        }
      }, SILENCE_TIMEOUT + 500);
    };

    recognition.onstart = () => {
      setIsListening(true);
      setVoiceTranscript('');
      smartToast.success('Listening... Speak naturally, I\'ll wait for you to finish');
      resetSilenceTimer();
    };

    recognition.onresult = (event: any) => {
      let interimTranscript = '';
      let finalTranscript = '';
      
      // Reset silence timer on any speech
      resetSilenceTimer();
      
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          finalTranscript += transcript;
        } else {
          interimTranscript += transcript;
        }
      }
      
      // Show interim results in real-time
      setVoiceTranscript(interimTranscript || finalTranscript);
      
      // Set final input when we have final results
      if (finalTranscript) {
        setInput(prev => prev + finalTranscript + ' ');
      }
    };

    recognition.onerror = (event: any) => {
      console.error('Speech recognition error:', event.error);
      // Don't stop on no-speech error - just continue listening
      if (event.error === 'no-speech') {
        return; // Keep listening
      }
      setIsListening(false);
      if (event.error === 'not-allowed') {
        toast.error('Microphone access denied. Please enable microphone permissions.');
      } else if (event.error !== 'aborted') {
        toast.error(`Voice input error: ${event.error}`);
      }
    };

    recognition.onend = () => {
      // Clear silence timer
      if (silenceTimeoutRef.current) {
        clearTimeout(silenceTimeoutRef.current);
        silenceTimeoutRef.current = null;
      }
      setIsListening(false);
      setVoiceTranscript('');
    };

    recognitionRef.current = recognition;
    recognition.start();
  }, []);

  const stopVoiceInput = useCallback(() => {
    if (silenceTimeoutRef.current) {
      clearTimeout(silenceTimeoutRef.current);
      silenceTimeoutRef.current = null;
    }
    if (recognitionRef.current) {
      recognitionRef.current.stop();
      setIsListening(false);
      setVoiceTranscript('');
    }
  }, []);

  // File drag and drop handlers - improved to work on the entire component
  const handleDragEnter = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragCounter(prev => prev + 1);
    if (e.dataTransfer.items && e.dataTransfer.items.length > 0) {
      setIsDragging(true);
    }
  }, []);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragCounter(prev => {
      const newCounter = prev - 1;
      if (newCounter <= 0) {
        setIsDragging(false);
        return 0;
      }
      return newCounter;
    });
  }, []);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setAttachedFiles(prev => [...prev, ...files].slice(0, 5));
    if (files.length > 0) {
      smartToast.success(`${files.length} file(s) attached`);
    }
  }, []);

  const removeAttachedFile = useCallback((index: number) => {
    setAttachedFiles(prev => prev.filter((_, i) => i !== index));
  }, []);

  const readFileContent = async (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsText(file);
    });
  };

  // AI-powered code analysis function
  const analyzeCode = useCallback(async (files: File[]) => {
    if (files.length === 0) return;
    
    setIsAnalyzing(true);
    
    // Add a placeholder message for analysis
    const analysisMessageId = Date.now().toString();
    setMessages(prev => [...prev, {
      id: analysisMessageId,
      role: 'assistant',
      content: `🔍 **Analyzing ${files.length} file(s)...**\n\nScanning for potential issues, code smells, and improvement suggestions...`,
      timestamp: new Date(),
    }]);

    try {
      // Read all file contents
      const fileContents: { name: string; content: string; ext: string }[] = [];
      for (const file of files) {
        try {
          const content = await readFileContent(file);
          const ext = file.name.split('.').pop() || 'txt';
          fileContents.push({ name: file.name, content, ext });
        } catch (err) {
          console.error('Error reading file:', err);
        }
      }

      // Build analysis prompt
      const analysisPrompt = `Please analyze the following code file(s) for potential issues and provide a detailed code review. For each file, identify:

1. **Bugs & Errors**: Syntax errors, logic bugs, potential runtime errors
2. **Security Issues**: Security vulnerabilities, XSS risks, SQL injection, etc.
3. **Performance**: Performance bottlenecks, inefficient algorithms, memory leaks
4. **Best Practices**: Code style issues, missing error handling, anti-patterns
5. **Improvements**: Suggestions for cleaner, more maintainable code

Format your response with clear sections for each file and use emojis to indicate severity:
- 🔴 Critical (bugs, security issues)
- 🟡 Warning (potential issues, performance concerns)
- 🟢 Suggestion (improvements, best practices)

${fileContents.map(f => `**File: ${f.name}**\n\`\`\`${f.ext}\n${f.content}\n\`\`\``).join('\n\n')}

Provide a comprehensive code review with actionable recommendations.`;

      // Stream the analysis response
      let analysisContent = `🔍 **Code Analysis Report**\n\n`;
      
      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/navi-chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
        },
        body: JSON.stringify({
          messages: [{ role: 'user', content: analysisPrompt }],
          model: 'google/gemini-2.5-flash',
          stream: true,
        }),
      });

      if (!response.ok) {
        throw new Error('Analysis request failed');
      }

      const reader = response.body?.getReader();
      if (!reader) throw new Error('No response body');

      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        
        buffer += decoder.decode(value, { stream: true });

        let newlineIndex: number;
        while ((newlineIndex = buffer.indexOf('\n')) !== -1) {
          let line = buffer.slice(0, newlineIndex);
          buffer = buffer.slice(newlineIndex + 1);

          if (line.endsWith('\r')) line = line.slice(0, -1);
          if (line.startsWith(':') || line.trim() === '') continue;
          if (!line.startsWith('data: ')) continue;

          const jsonStr = line.slice(6).trim();
          if (jsonStr === '[DONE]') break;

          try {
            const parsed = JSON.parse(jsonStr);
            const content = parsed.choices?.[0]?.delta?.content;
            if (content) {
              analysisContent += content;
              setMessages(prev => prev.map(m => 
                m.id === analysisMessageId 
                  ? { ...m, content: analysisContent }
                  : m
              ));
            }
          } catch {
            buffer = line + '\n' + buffer;
            break;
          }
        }
      }

      smartToast.success('Code analysis complete!');
    } catch (error) {
      console.error('Analysis error:', error);
      setMessages(prev => prev.map(m => 
        m.id === analysisMessageId 
          ? { ...m, content: `❌ **Analysis Failed**\n\nCould not analyze the files. Please try again or send them as a regular message.` }
          : m
      ));
      toast.error('Failed to analyze code');
    } finally {
      setIsAnalyzing(false);
    }
  }, [setMessages]);

  // handleDrop must be defined after analyzeCode
  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const files = Array.from(e.dataTransfer.files);
    const codeFiles = files.filter(file => {
      const ext = file.name.split('.').pop()?.toLowerCase();
      return ['js', 'ts', 'jsx', 'tsx', 'py', 'css', 'html', 'json', 'md', 'txt', 'sql', 'sh', 'go', 'rs', 'java', 'c', 'cpp', 'h'].includes(ext || '');
    });

    if (codeFiles.length === 0) {
      toast.error('Please drop code files (js, ts, py, css, html, json, etc.)');
      return;
    }

    const limitedFiles = codeFiles.slice(0, 5);
    smartToast.success(`Analyzing ${limitedFiles.length} file(s)...`);
    
    // Auto-analyze dropped files
    analyzeCode(limitedFiles);
  }, [analyzeCode]);

  // Slash commands
  const slashCommands: SlashCommand[] = [
    { 
      command: '/help', 
      description: 'Show available commands and tips',
      action: () => {
        setMessages(prev => [...prev, {
          id: Date.now().toString(),
          role: 'assistant',
          content: `**Available Commands:**\n\n• \`/help\` - Show this help message\n• \`/clear\` - Clear chat history\n• \`/history\` - Show command history\n• \`/tasks\` - List your current tasks\n• \`/model\` - Show current AI model\n• \`/models\` - Show all models with best use cases\n• \`/meetings\` - Open meeting notes panel\n• \`/theme\` - Toggle dark/light mode\n• \`/export\` - Export chat history\n• \`/shortcuts\` - Show keyboard shortcuts\n• \`/new\` - Start a fresh chat session\n• \`/save\` - Bookmark this conversation\n• \`/load\` - Load a saved conversation\n• \`/voice\` - Toggle voice input\n• \`/analyze\` - Analyze attached files for issues\n• \`/memory\` - Save or search your knowledge base\n• \`/search\` - Semantic search indexed code files\n• \`/demo\` - Demo agent activity animations\n• \`/demo-approval\` - Demo command approval flow\n\n**Tips:**\n• Use ↑↓ arrows to navigate command history\n• Type to see autocomplete suggestions\n• Press Tab to complete suggestions\n• Press ⌘M to toggle auto/manual model selection\n• Drag & drop code files to auto-analyze them\n• Click the search icon to find code context\n• Conversations auto-save every 10 messages`,
          timestamp: new Date(),
        }]);
      }
    },
    { 
      command: '/search', 
      description: 'Search indexed code files',
      action: () => {
        setShowCodeSearch(true);
      }
    },
    { 
      command: '/clear', 
      description: 'Clear chat history',
      action: () => {
        setMessages([{
          id: Date.now().toString(),
          role: 'assistant',
          content: `Chat cleared! How can I help you, ${userName}?`,
          timestamp: new Date(),
        }]);
      }
    },
    { 
      command: '/history', 
      description: 'Show command history',
      action: () => {
        const historyList = commandHistory.length > 0 
          ? commandHistory.slice(-10).map((cmd, i) => `${i + 1}. ${cmd}`).join('\n')
          : 'No command history yet.';
        setMessages(prev => [...prev, {
          id: Date.now().toString(),
          role: 'assistant',
          content: `**Recent Commands:**\n\n${historyList}\n\n*Use ↑↓ arrows in the input to recall these commands.*`,
          timestamp: new Date(),
        }]);
      }
    },
    { 
      command: '/tasks', 
      description: 'List your current tasks',
      action: () => {
        sendMessage('Show my tasks');
      }
    },
    { 
      command: '/model', 
      description: 'Show current AI model',
      action: () => {
        setMessages(prev => [...prev, {
          id: Date.now().toString(),
          role: 'assistant',
          content: `**Current Model:** ${getDisplayModelName()}\n\nYou can change the model using the dropdown below the input.`,
          timestamp: new Date(),
        }]);
      }
    },
    { 
      command: '/theme', 
      description: 'Toggle dark/light mode',
      action: () => {
        toggleTheme();
        const newTheme = resolvedTheme === 'dark' ? 'light' : 'dark';
        smartToast.success(`Switched to ${newTheme} mode`);
      }
    },
    { 
      command: '/export', 
      description: 'Export chat history',
      action: () => {
        const chatExport = messages.map(msg => ({
          role: msg.role,
          content: msg.content,
          timestamp: msg.timestamp,
        }));
        const blob = new Blob([JSON.stringify(chatExport, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `navi-chat-${new Date().toISOString().split('T')[0]}.json`;
        a.click();
        URL.revokeObjectURL(url);
        smartToast.success('Chat history exported!');
      }
    },
    { 
      command: '/shortcuts', 
      description: 'Show keyboard shortcuts',
      action: () => {
        setMessages(prev => [...prev, {
          id: Date.now().toString(),
          role: 'assistant',
          content: `**Keyboard Shortcuts:**\n\n| Keys | Action |\n|------|--------|\n| ⌘K | Open search |\n| ⌘T | Open tasks |\n| ⌘, | Settings |\n| ⌘H | History |\n| ⌘N | Notifications |\n| ⌘? | Show all shortcuts |\n| ⌘[ | Toggle sidebar |\n| Esc | Close panel |\n\n*Press ⌘? (Ctrl+? on Windows) to see the full shortcuts overlay.*`,
          timestamp: new Date(),
        }]);
      }
    },
    { 
      command: '/new', 
      description: 'Start a fresh chat session',
      action: () => {
        setMessages([{
          id: Date.now().toString(),
          role: 'assistant',
          content: `New session started! 🚀\n\nHello ${userName}! I'm ready to help you with a fresh conversation. What would you like to work on?`,
          timestamp: new Date(),
        }]);
        smartToast.success('New chat session started');
      }
    },
    { 
      command: '/save', 
      description: 'Bookmark this conversation',
      action: () => {
        try {
          const chatName = `Chat ${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}`;
          saveConversationToHistory({
            id: conversationId,
            name: chatName,
            messages: messages,
            timestamp: new Date(),
            messageCount: messages.length,
          });
          smartToast.success('Conversation saved to history!');
          setMessages(prev => [...prev, {
            id: Date.now().toString(),
            role: 'assistant',
            content: `✅ **Conversation saved!**\n\nThis chat has been bookmarked as "${chatName}". Click **History** button to view all saved conversations.`,
            timestamp: new Date(),
          }]);
        } catch {
          toast.error('Failed to save conversation');
        }
      }
    },
    { 
      command: '/load', 
      description: 'Load a saved conversation',
      action: () => {
        try {
          const saved = JSON.parse(localStorage.getItem(SAVED_CHATS_KEY) || '[]') as SavedChat[];
          setSavedChats(saved);
          if (saved.length === 0) {
            smartToast.info('No saved conversations found. Use /save to bookmark a chat.');
          } else {
            setShowLoadDialog(true);
          }
        } catch {
          toast.error('Failed to load saved conversations');
        }
      }
    },
    { 
      command: '/voice', 
      description: 'Toggle voice input',
      action: () => {
        if (!voiceSupported) {
          toast.error('Voice input is not supported in your browser. Try Chrome or Edge.');
          return;
        }
        if (isListening) {
          stopVoiceInput();
        } else {
          startVoiceInput();
        }
      }
    },
    { 
      command: '/analyze', 
      description: 'Analyze attached files for issues',
      action: () => {
        if (attachedFiles.length === 0) {
          smartToast.info('No files attached. Drag & drop or use the 📎 button to attach code files first.');
          setMessages(prev => [...prev, {
            id: Date.now().toString(),
            role: 'assistant',
            content: `📎 **No files to analyze**\n\nTo use the code analyzer:\n1. Drag & drop code files into the chat\n2. Or click the 📎 button to select files\n3. Then type \`/analyze\` or the analysis will start automatically\n\n**Supported file types:** .js, .ts, .jsx, .tsx, .py, .css, .html, .json, .sql, .go, .rs, .java, .c, .cpp`,
            timestamp: new Date(),
          }]);
          return;
        }
        analyzeCode(attachedFiles);
        setAttachedFiles([]);
      }
    },
    { 
      command: '/briefing', 
      description: 'Show morning briefing',
      action: () => {
        setShowMorningBriefing(true);
        setMessages(prev => [...prev, {
          id: Date.now().toString(),
          role: 'assistant',
          content: `☀️ **Morning Briefing**\n\nShowing your daily overview with tasks, mentions, and meetings.`,
          timestamp: new Date(),
        }]);
      }
    },
    { 
      command: '/memory', 
      description: 'Save or search memories',
      action: () => {
        setShowMemoryDialog(true);
        setMessages(prev => [...prev, {
          id: Date.now().toString(),
          role: 'assistant',
          content: `🧠 **Memory Panel**\n\nOpening memory dialog. You can:\n• **Save** important information for future reference\n• **Search** your knowledge base semantically\n\nYour memories help me provide more personalized and context-aware responses.`,
          timestamp: new Date(),
        }]);
      }
    },
    { 
      command: '/demo', 
      description: 'Demo agent activity animations',
      action: () => {
        agentActivity.startActivity('Implementing a new feature with code generation and file modifications');
        // Simulate a demo workflow
        setTimeout(() => agentActivity.setPhase('reading', 'Reading codebase structure...'), 500);
        setTimeout(() => agentActivity.addFileActivity({ path: 'src/components/Example.tsx', action: 'read', status: 'active' }), 800);
        setTimeout(() => agentActivity.setPhase('analyzing', 'Analyzing component patterns...'), 2000);
        setTimeout(() => agentActivity.addFileActivity({ path: 'src/hooks/useExample.ts', action: 'analyze', status: 'active' }), 2500);
        setTimeout(() => agentActivity.setPhase('writing', 'Generating implementation...'), 4000);
        setTimeout(() => agentActivity.addFileActivity({ path: 'src/components/NewFeature.tsx', action: 'create', status: 'active' }), 4500);
        setTimeout(() => agentActivity.completeActivity(), 7000);
        setTimeout(() => agentActivity.resetActivity(), 10000);
        
        setMessages(prev => [...prev, {
          id: Date.now().toString(),
          role: 'assistant',
          content: `🎬 **Agent Activity Demo**\n\nStarting a demonstration of the agent activity panel. Watch as I simulate:\n\n• Reading files\n• Analyzing code\n• Planning changes\n• Writing code\n• Reviewing results\n\nThis shows what you'll see when NAVI is working on a real task.`,
          timestamp: new Date(),
        }]);
      }
    },
    { 
      command: '/demo-approval', 
      description: 'Demo command approval flow',
      action: () => {
        agentActivity.startActivity('Installing dependencies and running build');
        
        // Add sample commands that need approval
        setTimeout(() => {
          agentActivity.setPhase('awaiting_approval', 'Command needs your approval');
          agentActivity.addPendingCommand({
            command: 'npm install @tanstack/react-query@latest',
            description: 'Installing latest version of React Query for data fetching',
            type: 'terminal',
            risk: 'low',
            workingDir: '/project',
          });
        }, 500);
        
        setTimeout(() => {
          agentActivity.addPendingCommand({
            command: 'git checkout -b feature/new-component',
            description: 'Creating a new feature branch for development',
            type: 'git',
            risk: 'low',
            workingDir: '/project',
          });
        }, 1000);
        
        setTimeout(() => {
          agentActivity.addPendingCommand({
            command: 'rm -rf node_modules && npm install',
            description: 'Clean reinstall of all dependencies',
            type: 'terminal',
            risk: 'medium',
            workingDir: '/project',
          });
        }, 1500);
        
        setTimeout(() => {
          agentActivity.addPendingCommand({
            command: 'npm run deploy:production',
            description: 'Deploy to production environment - this will affect live users',
            type: 'system',
            risk: 'high',
            workingDir: '/project',
          });
        }, 2000);
        
        setMessages(prev => [...prev, {
          id: Date.now().toString(),
          role: 'assistant',
          content: `🔐 **Command Approval Demo**\n\nI'm showing you the command approval flow. You'll see several commands appear that need your approval:\n\n• **Allow** - Run this command once\n• **Always Allow** - Auto-approve this command in the future\n• **Skip** - Don't run this command\n\nTry approving or skipping the commands to see how it works!\n\n⚠️ Note: In this demo, no actual commands are executed.`,
          timestamp: new Date(),
        }]);
      }
    },
    { 
      command: '/models', 
      description: 'Show all models and their best use cases',
      action: () => {
        const recommendations = getAllModelRecommendations();
        const modelsByProvider: Record<string, string[]> = {};
        
        // Group by task type to show use cases
        const useCases = recommendations.map(({ taskType, recommendation }) => 
          `| ${taskType.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())} | **${recommendation.modelName}** | ${recommendation.reason} |`
        ).join('\n');

        const content = `## 🤖 Available Models & Best Use Cases

NAVI's intelligent routing automatically selects the optimal model based on your task:

| Task Type | Recommended Model | Why |
|-----------|------------------|-----|
${useCases}

---

### Model Providers

**OpenAI**
• GPT-5 — Most capable, best for complex reasoning & conversation
• GPT-5 Mini — Balanced performance, faster response
• GPT-5 Nano — Ultra-fast for simple tasks

**Anthropic**
• Claude Sonnet 4 — Excellent for code generation & refactoring
• Claude Opus 4 — Most capable Claude model

**Google**
• Gemini 2.5 Pro — Top-tier multimodal & RAG reasoning
• Gemini 2.5 Flash — Fast & balanced for most tasks
• Gemini 3 Pro — Next-gen preview

---

💡 **Tip:** Use "Auto (Recommended)" to let NAVI intelligently route your requests, or select a specific model from the dropdown. Press **⌘M** to toggle between auto and manual selection.`;

        setMessages(prev => [...prev, {
          id: Date.now().toString(),
          role: 'assistant',
          content,
          timestamp: new Date(),
        }]);
      }
    },
    { 
      command: '/meetings', 
      description: 'Open meeting notes panel',
      action: () => {
        setShowMeetingNotesPanel(true);
        smartToast.success('Opening meeting notes panel');
      }
    },
  ];

  // Persist command history to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(COMMAND_HISTORY_KEY, JSON.stringify(commandHistory.slice(-50)));
    } catch {
      // Ignore storage errors
    }
  }, [commandHistory]);

  // Check if input is a slash command
  const isSlashCommand = input.startsWith('/');
  
  // Get filtered slash commands
  const filteredSlashCommands = isSlashCommand
    ? slashCommands.filter(cmd => 
        cmd.command.toLowerCase().startsWith(input.toLowerCase()) ||
        fuzzyMatch(input.slice(1), cmd.command.slice(1)) > 0
      )
    : [];

  // Get filtered suggestions with fuzzy matching
  const suggestions = !isSlashCommand && input.trim().length > 0 
    ? [...new Set([...commandHistory, ...COMMON_PROMPTS])]
        .map(cmd => ({ cmd, score: fuzzyMatch(input, cmd) }))
        .filter(({ score }) => score > 0)
        .sort((a, b) => b.score - a.score)
        .slice(0, 6)
        .map(({ cmd }) => cmd)
    : [];

  // Close suggestions when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (suggestionsRef.current && !suggestionsRef.current.contains(e.target as Node) &&
          inputRef.current && !inputRef.current.contains(e.target as Node)) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    if (messages.length === 0) {
      setMessages([{
        id: '1',
        role: 'assistant',
        content: `Hello ${userName}! ${greeting}! 👋\n\nI'm NAVI, your Autonomous Engineering Intelligence. I'm connected to Lovable AI and ready to help you with:\n\n• **Code generation** - I can write, explain, and debug code\n• **Task assistance** - Explain Jira tasks and suggest implementations\n• **Documentation** - Search and summarize Confluence docs\n• **Code review** - Help with PR comments and suggestions`,
        timestamp: new Date(),
      }]);
    }
  }, []);

  useEffect(() => {
    if (selectedTask && messages.length > 0) {
      const taskContextMessage = {
        id: Date.now().toString(),
        role: 'assistant' as const,
        content: `Great choice! Let me analyze **${selectedTask.key}: ${selectedTask.title}**.\n\n**Description:**\n${selectedTask.description}\n\n**Acceptance Criteria:**\n${selectedTask.acceptanceCriteria?.map(c => `• ${c}`).join('\n') || 'None specified'}\n\n**Status:** ${selectedTask.status.replace('_', ' ')} | **Priority:** ${selectedTask.priority}\n\nI have this task's context loaded. Feel free to ask me:\n- "How should I implement this?"\n- "What files need to change?"\n- "Generate the code for this feature"\n- "Explain the requirements"`,
        timestamp: new Date(),
        sources: selectedTask.relatedDocs,
      };
      setMessages(prev => [...prev, taskContextMessage]);
    }
  }, [selectedTask?.id]);

  const handleSend = async () => {
    if ((!input.trim() && attachedFiles.length === 0 && attachedProjectFiles.length === 0) || isLoading) return;
    let message = input;
    
    // Check if it's a slash command
    if (isSlashCommand && attachedFiles.length === 0 && attachedProjectFiles.length === 0) {
      const matchedCommand = slashCommands.find(cmd => 
        cmd.command.toLowerCase() === message.toLowerCase()
      );
      if (matchedCommand) {
        setInput('');
        setShowSuggestions(false);
        matchedCommand.action();
        return;
      }
    }

    // Process attached files from computer
    if (attachedFiles.length > 0) {
      let fileContents = '';
      for (const file of attachedFiles) {
        try {
          const content = await readFileContent(file);
          const ext = file.name.split('.').pop() || 'txt';
          fileContents += `\n\n**File: ${file.name}**\n\`\`\`${ext}\n${content}\n\`\`\``;
        } catch (err) {
          console.error('Error reading file:', err);
        }
      }
      message = message + fileContents;
      setAttachedFiles([]);
    }

    // Process attached project files - fetch their content
    if (attachedProjectFiles.length > 0) {
      setIsLoadingProjectFiles(true);
      try {
        const projectFiles = await fetchMultipleFiles(attachedProjectFiles.map(f => f.path));
        const formattedContext = formatFilesForContext(projectFiles);
        message = message + '\n\n**Project Files Context:**\n' + formattedContext;
      } catch (err) {
        console.error('Error loading project files:', err);
        toast.error('Failed to load some project files');
      } finally {
        setIsLoadingProjectFiles(false);
      }
      setAttachedProjectFiles([]);
    }
    
    // Regular message - add to command history
    if (input.trim()) {
      setCommandHistory(prev => [...prev.filter(cmd => cmd !== input), input]);
    }
    setHistoryIndex(-1);
    setTempInput('');
    setInput('');
    setShowSuggestions(false);
    await sendMessage(message);
  };

  const loadSavedChat = (chat: SavedChat) => {
    setMessages(chat.messages);
    setShowLoadDialog(false);
    smartToast.success(`Loaded: ${chat.name}`);
  };

  const deleteSavedChat = (chatId: string) => {
    try {
      const updated = savedChats.filter(c => c.id !== chatId);
      localStorage.setItem(SAVED_CHATS_KEY, JSON.stringify(updated));
      setSavedChats(updated);
      smartToast.success('Conversation deleted');
    } catch {
      toast.error('Failed to delete conversation');
    }
  };

  const selectSlashCommand = (command: SlashCommand) => {
    setInput('');
    setShowSuggestions(false);
    setSelectedSuggestionIndex(0);
    command.action();
  };

  const selectSuggestion = (suggestion: string) => {
    setInput(suggestion);
    setShowSuggestions(false);
    setSelectedSuggestionIndex(0);
    inputRef.current?.focus();
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    // Handle slash command navigation
    if (showSuggestions && isSlashCommand && filteredSlashCommands.length > 0) {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedSuggestionIndex(prev => 
          prev < filteredSlashCommands.length - 1 ? prev + 1 : 0
        );
        return;
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedSuggestionIndex(prev => 
          prev > 0 ? prev - 1 : filteredSlashCommands.length - 1
        );
        return;
      }
      if (e.key === 'Tab' || (e.key === 'Enter' && !e.shiftKey)) {
        e.preventDefault();
        selectSlashCommand(filteredSlashCommands[selectedSuggestionIndex]);
        return;
      }
      if (e.key === 'Escape') {
        e.preventDefault();
        setShowSuggestions(false);
        return;
      }
    }
    
    // Handle regular suggestion navigation
    if (showSuggestions && !isSlashCommand && suggestions.length > 0) {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedSuggestionIndex(prev => 
          prev < suggestions.length - 1 ? prev + 1 : 0
        );
        return;
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedSuggestionIndex(prev => 
          prev > 0 ? prev - 1 : suggestions.length - 1
        );
        return;
      }
      if (e.key === 'Tab' || (e.key === 'Enter' && !e.shiftKey)) {
        e.preventDefault();
        selectSuggestion(suggestions[selectedSuggestionIndex]);
        if (e.key === 'Enter') {
          setTimeout(() => handleSend(), 0);
        }
        return;
      }
      if (e.key === 'Escape') {
        e.preventDefault();
        setShowSuggestions(false);
        return;
      }
    }

    if (e.key === 'Enter' && !e.shiftKey) {
      handleSend();
      return;
    }
    
    // Navigate history with up/down arrows (only when no suggestions shown)
    if (!showSuggestions) {
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        if (commandHistory.length === 0) return;
        
        if (historyIndex === -1) {
          setTempInput(input);
          setHistoryIndex(commandHistory.length - 1);
          setInput(commandHistory[commandHistory.length - 1]);
        } else if (historyIndex > 0) {
          setHistoryIndex(historyIndex - 1);
          setInput(commandHistory[historyIndex - 1]);
        }
        return;
      }
      
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        if (historyIndex === -1) return;
        
        if (historyIndex < commandHistory.length - 1) {
          setHistoryIndex(historyIndex + 1);
          setInput(commandHistory[historyIndex + 1]);
        } else {
          setHistoryIndex(-1);
          setInput(tempInput);
        }
        return;
      }
    }
  };

  const handleActionApprove = (actionId: string) => {
    setMessages(prev => prev.map(msg => ({
      ...msg,
      actions: msg.actions?.map(a => a.id === actionId ? { ...a, status: 'approved' as const } : a),
    })));
  };

  const handleActionReject = (actionId: string) => {
    setMessages(prev => prev.map(msg => ({
      ...msg,
      actions: msg.actions?.map(a => a.id === actionId ? { ...a, status: 'rejected' as const } : a),
    })));
  };

  return (
    <div className="flex-1 flex h-full bg-panel-content">
      {/* Chat History Sidebar */}
      <ChatHistorySidebar
        isOpen={showChatHistory}
        onClose={() => setShowChatHistory(false)}
        currentConversationId={conversationId}
        onSelectConversation={(conv: ChatConversation) => {
          setMessages(conv.messages.map(msg => ({
            ...msg,
            timestamp: new Date(msg.timestamp),
          })));
          setShowChatHistory(false);
          smartToast.success(`Loaded: ${conv.name}`);
        }}
      />
      
      <div className="flex-1 flex flex-col h-full">
        {/* Collaboration indicator bar */}
        <div className="flex items-center justify-between px-4 py-2 border-b border-border bg-secondary/20">
          <div className="flex items-center gap-2">
            <span className="text-xs text-muted-foreground">Active collaborators:</span>
            <CollaborationIndicator isNaviThinking={isLoading} />
          </div>
          <div className="flex items-center gap-2">
            {isLoading && (
              <div className="flex items-center gap-2 text-xs text-primary animate-pulse">
                <Loader2 className="h-3 w-3 animate-spin" />
                <span>NAVI is working...</span>
              </div>
            )}
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowChatHistory(true)}
                    className="h-7 gap-1.5 text-xs hover:bg-primary/10 hover:text-primary"
                  >
                    <History className="h-3.5 w-3.5" />
                    History
                  </Button>
                </TooltipTrigger>
                <TooltipContent side="bottom">
                  <p>View chat history</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      // Save current conversation before starting new
                      if (messages.length > 1) {
                        saveConversationToHistory({
                          id: conversationId,
                          name: `Chat ${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}`,
                          messages: messages,
                          timestamp: new Date(),
                          messageCount: messages.length,
                        });
                      }
                      setMessages([{
                        id: Date.now().toString(),
                        role: 'assistant',
                        content: `New session started! 🚀\n\nHello ${userName}! I'm ready to help you with a fresh conversation. What would you like to work on?`,
                        timestamp: new Date(),
                      }]);
                      setInput('');
                      smartToast.success('New chat session started');
                    }}
                    className="h-7 gap-1.5 text-xs hover:bg-primary/10 hover:text-primary"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    New Chat
                  </Button>
                </TooltipTrigger>
                <TooltipContent side="bottom">
                  <p>Start a fresh conversation (or type /new)</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </div>

      {/* Messages */}
      <div 
        ref={messagesContainerRef}
        className="flex-1 overflow-y-auto p-6 space-y-6 relative"
        onScroll={(e) => {
          const target = e.currentTarget;
          const isNearBottom = target.scrollHeight - target.scrollTop - target.clientHeight < 100;
          setShowScrollButton(!isNearBottom);
        }}
      >
        {/* Morning Briefing - shows at start of day */}
        {showMorningBriefing && messages.length <= 1 && (
          <div className="mb-4 animate-fade-in">
            <MorningBriefing 
              userName={userName}
              jiraTasks={jiraTasks}
              onTaskClick={onTaskClick}
              onDismiss={() => {
                setShowMorningBriefing(false);
                localStorage.setItem('morning-briefing-last-shown', new Date().toDateString());
              }}
            />
          </div>
        )}
        
        {messages.map((message, index) => (
          <div key={message.id} className={cn("flex gap-3 animate-fade-in group", message.role === 'user' && "flex-row-reverse")}>
            <div className={cn("flex-shrink-0 h-6 w-6 rounded-md flex items-center justify-center", message.role === 'assistant' ? "gradient-ai" : "bg-secondary")}>
              {message.role === 'assistant' ? <Bot className="h-3 w-3 text-primary-foreground" /> : <User className="h-3 w-3 text-foreground" />}
            </div>
            <div className="flex-1 max-w-3xl flex flex-col gap-1">
              <div className={cn("rounded-xl px-4 py-3", message.role === 'assistant' ? "bg-card border border-border" : "bg-primary/10 border border-primary/20")}>
                <MessageContent 
                  content={message.content} 
                  sources={message.sources}
                  actions={message.actions}
                  onActionApprove={handleActionApprove}
                  onActionReject={handleActionReject}
                />
                {message.role === 'assistant' && message.modelName && (
                  <div className="mt-2 pt-2 border-t border-border/50">
                    <span className="text-[10px] text-muted-foreground/70 font-mono">
                      via {message.modelName}
                    </span>
                  </div>
                )}
              </div>
              <MessageActions
                role={message.role}
                content={message.content}
                messageId={message.id}
                onRetry={() => {
                  // Find the user message before this assistant message and resend
                  if (message.role === 'assistant' && index > 0) {
                    const prevUserMessage = messages.slice(0, index).reverse().find(m => m.role === 'user');
                    if (prevUserMessage) {
                      // Remove current assistant message and regenerate
                      setMessages(prev => prev.slice(0, index));
                      sendMessage(prevUserMessage.content);
                      smartToast.info('Regenerating response...');
                    }
                  }
                }}
                onRetryWithModel={async (modelId) => {
                  if (message.role === 'assistant') {
                    const modelName = llmProviders
                      .flatMap(p => p.models)
                      .find(m => m.id === modelId)?.name || modelId;
                    smartToast.info(`Regenerating with ${modelName}...`);
                    retryWithModel(index, modelId);
                  }
                }}
                onRestore={() => {
                  // Restore conversation to this point
                  const newMessages = messages.slice(0, index + 1);
                  setMessages(newMessages);
                  smartToast.success('Restored to this checkpoint');
                }}
                onEdit={(newContent) => {
                  // Update the message content inline
                  const updatedMessages = [...messages];
                  updatedMessages[index] = { ...message, content: newContent };
                  setMessages(updatedMessages);
                  smartToast.success('Message updated');
                }}
                onFeedback={(type) => {
                  submitFeedback({
                    messageId: message.id,
                    conversationId,
                    feedbackType: type,
                    messageContent: message.content,
                    messageRole: message.role,
                  });
                  smartToast.success(type === 'like' ? 'Thanks for the feedback!' : 'Feedback recorded');
                }}
                className={message.role === 'user' ? 'justify-end' : 'justify-start'}
              />
            </div>
          </div>
        ))}
        
        {/* Agent Activity Panel - Shows during AI processing */}
        {(agentActivity.isActive || agentActivity.phase !== 'idle') && (
          <div className="animate-fade-in">
            <AgentActivityPanel
              isActive={agentActivity.isActive}
              phase={agentActivity.phase}
              currentThought={agentActivity.currentThought}
              files={agentActivity.files}
              steps={agentActivity.steps}
              totalEdits={agentActivity.totalEdits}
              linesChanged={agentActivity.linesChanged}
              tokensProcessed={agentActivity.tokensProcessed}
              pendingCommands={agentActivity.pendingCommands}
              onCommandApprove={agentActivity.approveCommand}
              onCommandSkip={agentActivity.skipCommand}
              onDismiss={() => agentActivity.resetActivity()}
            />
          </div>
        )}
        
        {isLoading && messages[messages.length - 1]?.role === 'user' && !agentActivity.isActive && (
          <div className="flex gap-3 animate-fade-in">
            <div className="flex-shrink-0 h-6 w-6 rounded-md gradient-ai flex items-center justify-center">
              <Bot className="h-3 w-3 text-primary-foreground" />
            </div>
            <div className="bg-card border border-border rounded-xl px-4 py-3">
              <div className="flex items-center gap-2">
                <div className="flex gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce" style={{ animationDelay: '0ms' }} />
                  <span className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce" style={{ animationDelay: '150ms' }} />
                  <span className="w-1.5 h-1.5 rounded-full bg-primary animate-bounce" style={{ animationDelay: '300ms' }} />
                </div>
                <span className="text-xs text-muted-foreground">NAVI is thinking...</span>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
        
        {/* Scroll to bottom button */}
        {showScrollButton && (
          <button
            onClick={() => {
              messagesContainerRef.current?.scrollTo({
                top: messagesContainerRef.current.scrollHeight,
                behavior: 'smooth'
              });
            }}
            className="fixed bottom-48 left-1/2 -translate-x-1/2 z-50 h-10 w-10 rounded-full bg-background border border-border shadow-lg flex items-center justify-center hover:bg-secondary transition-all hover:scale-105"
            aria-label="Scroll to bottom"
          >
            <ArrowDown className="h-4 w-4" />
          </button>
        )}
      </div>

      {/* Quick actions - Dynamic based on context */}
      <div className="px-6 py-3 border-t border-border">
        <div className="flex flex-wrap gap-2">
          {smartPrompts.map((action) => (
            <Button 
              key={action} 
              variant="outline" 
              size="sm" 
              onClick={() => setInput(action)} 
              className="text-xs transition-all hover:border-primary/50 hover:bg-primary/5"
            >
              {action}
            </Button>
          ))}
        </div>
      </div>

      {/* Input */}
      <div 
        className={cn(
          "p-6 pt-3 border-t border-border relative",
          isDragging && "bg-primary/5"
        )}
        onDragEnter={handleDragEnter}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        {/* Drag overlay */}
        {isDragging && (
          <div className="absolute inset-0 flex items-center justify-center bg-primary/10 border-2 border-dashed border-primary rounded-lg z-50 pointer-events-none">
            <div className="flex flex-col items-center gap-2 text-primary">
              <Upload className="h-8 w-8" />
              <span className="text-sm font-medium">Drop files here to attach</span>
              <span className="text-xs text-muted-foreground">Code files will be auto-analyzed</span>
            </div>
          </div>
        )}

        {/* Voice transcription indicator */}
        {isListening && voiceTranscript && (
          <div className="flex items-center gap-2 mb-3 px-3 py-2 bg-destructive/10 border border-destructive/30 rounded-lg animate-pulse">
            <Mic className="h-4 w-4 text-destructive flex-shrink-0" />
            <span className="text-sm text-muted-foreground italic flex-1 truncate">
              {voiceTranscript || 'Listening...'}
            </span>
          </div>
        )}

        {/* Attached files preview with analyze button */}
        {attachedFiles.length > 0 && (
          <div className="flex flex-wrap items-center gap-2 mb-3">
            {attachedFiles.map((file, index) => (
              <div key={index} className="flex items-center gap-2 px-3 py-1.5 bg-secondary rounded-lg text-xs">
                <FileText className="h-3 w-3 text-muted-foreground" />
                <span className="truncate max-w-[150px]">{file.name}</span>
                <button 
                  onClick={() => removeAttachedFile(index)}
                  className="text-muted-foreground hover:text-destructive"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            ))}
            <Button
              variant="ai"
              size="sm"
              onClick={() => {
                analyzeCode(attachedFiles);
                setAttachedFiles([]);
              }}
              disabled={isAnalyzing}
              className="h-7 text-xs gap-1"
            >
              {isAnalyzing ? (
                <>
                  <Loader2 className="h-3 w-3 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <SearchIcon className="h-3 w-3" />
                  Analyze Files
                </>
              )}
            </Button>
          </div>
        )}

        {/* Task Detection Preview - shows when Auto mode is active and user is typing */}
        {selectedModel === 'auto/recommended' && input.trim().length > 10 && detectedTask && (
          <TooltipProvider>
            <div className="flex items-center gap-2 mb-2 px-3 py-2 rounded-lg bg-secondary/50 border border-border text-xs animate-fade-in">
              <Tooltip>
                <TooltipTrigger asChild>
                  <div className="flex items-center gap-2 flex-1 min-w-0 cursor-help">
                    <Cpu className="h-3.5 w-3.5 text-primary flex-shrink-0" />
                    <div>
                      <span className="text-muted-foreground">Detected: </span>
                      <span className="font-medium text-foreground capitalize">{detectedTask.taskType.replace(/_/g, ' ')}</span>
                      <span className="text-muted-foreground"> → Will use </span>
                      <span className="font-medium text-primary">{detectedTask.modelName}</span>
                    </div>
                  </div>
                </TooltipTrigger>
                <TooltipContent side="top" className="max-w-xs">
                  <div className="space-y-1">
                    <p className="font-medium">Why {detectedTask.modelName}?</p>
                    <p className="text-muted-foreground">{detectedTask.reason}</p>
                    <p className="text-[10px] text-muted-foreground mt-2">Press ⌘M to toggle auto/manual mode</p>
                  </div>
                </TooltipContent>
              </Tooltip>
              <div className="flex items-center gap-1.5 flex-shrink-0">
                {useAutoModel ? (
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 px-2 text-[10px]"
                        onClick={() => setUseAutoModel(false)}
                      >
                        Override
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent side="top">
                      <p>Select a different model manually (⌘M)</p>
                    </TooltipContent>
                  </Tooltip>
                ) : (
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 px-2 text-[10px] text-primary"
                        onClick={() => setUseAutoModel(true)}
                      >
                        Use Auto
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent side="top">
                      <p>Let NAVI choose the best model (⌘M)</p>
                    </TooltipContent>
                  </Tooltip>
                )}
              </div>
            </div>
          </TooltipProvider>
        )}

        {/* Override model selector when user chose to override */}
        {selectedModel === 'auto/recommended' && !useAutoModel && input.trim().length > 10 && (
          <div className="flex items-center gap-2 mb-2 px-3 py-2 rounded-lg bg-amber-500/10 border border-amber-500/30 text-xs">
            <AlertTriangle className="h-3.5 w-3.5 text-amber-500 flex-shrink-0" />
            <span className="text-muted-foreground">Override active: Select model below (⌘M to toggle back)</span>
          </div>
        )}

        <div className="flex gap-2 relative items-center">
          {/* Left side - Project files, Voice, and hidden file input */}
          <div className="flex items-center gap-0.5 flex-shrink-0">
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept=".js,.ts,.jsx,.tsx,.py,.css,.html,.json,.md,.txt,.sql,.sh,.go,.rs,.java,.c,.cpp,.h"
              onChange={handleFileSelect}
              className="hidden"
            />
            
            {/* Project files button - uses paperclip icon */}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowProjectFilesDialog(true)}
              className="h-9 w-9"
              title="Attach project files"
            >
              <Paperclip className="h-4 w-4" />
            </Button>

            {/* Code search button */}
            <Button
              variant={showCodeSearch ? "secondary" : "ghost"}
              size="icon"
              onClick={() => setShowCodeSearch(!showCodeSearch)}
              className="h-9 w-9"
              title="Search indexed code (Semantic search)"
            >
              <SearchIcon className="h-4 w-4" />
            </Button>

            {/* Voice input button */}
            {voiceSupported && (
              <div className="flex items-center gap-0.5">
                <Button
                  variant={isListening ? "destructive" : "ghost"}
                  size="icon"
                  onClick={isListening ? stopVoiceInput : startVoiceInput}
                  className={cn("h-9 w-9", isListening && "animate-pulse")}
                  title={isListening ? "Stop listening" : "Start voice input"}
                >
                  {isListening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
                </Button>
                <AudioWaveform isActive={isListening} className="h-6" />
              </div>
            )}
          </div>

          {/* Main input - takes up remaining space */}
          <div className="flex-1 relative">
            <Input
              ref={inputRef}
              value={input}
              onChange={(e) => {
                setInput(e.target.value);
                setShowSuggestions(e.target.value.trim().length > 0);
                setSelectedSuggestionIndex(0);
                if (historyIndex !== -1) {
                  setHistoryIndex(-1);
                  setTempInput('');
                }
              }}
              onFocus={() => input.trim().length > 0 && setShowSuggestions(true)}
              onKeyDown={handleKeyDown}
              placeholder={isListening ? "Listening..." : currentPlaceholder}
              className={cn(
                "h-14 bg-input text-sm w-full transition-opacity duration-200 pr-4 rounded-xl border-2 border-border/50 focus:border-primary/50",
                isPlaceholderTransitioning && "opacity-70"
              )}
              disabled={isLoading}
            />
            
            {/* Code Search Panel */}
            <CodeSearchPanel
              isOpen={showCodeSearch}
              onClose={() => setShowCodeSearch(false)}
              onInsertContext={(context) => {
                setInput(prev => prev + (prev ? '\n\n' : '') + context);
                smartToast.success('Code context added to message');
              }}
            />
            
            {/* Slash commands dropdown */}
            {showSuggestions && isSlashCommand && filteredSlashCommands.length > 0 && (
              <div 
                ref={suggestionsRef}
                className="absolute bottom-full left-0 right-0 mb-1 bg-popover border border-border rounded-lg shadow-lg overflow-hidden z-50 animate-fade-in"
              >
                <div className="px-3 py-1.5 border-b border-border bg-secondary/30">
                  <span className="text-[10px] uppercase text-muted-foreground tracking-wider font-medium">Commands</span>
                </div>
                <div className="py-1 max-h-48 overflow-y-auto">
                  {filteredSlashCommands.map((cmd, index) => (
                    <button
                      key={cmd.command}
                      onClick={() => selectSlashCommand(cmd)}
                      className={cn(
                        "w-full px-3 py-2 text-left text-sm flex items-center gap-3 transition-colors",
                        index === selectedSuggestionIndex 
                          ? "bg-primary/10 text-foreground" 
                          : "hover:bg-secondary text-muted-foreground"
                      )}
                    >
                      <div className="h-6 w-6 rounded-md bg-secondary flex items-center justify-center">
                        {cmd.command === '/help' && <HelpCircle className="h-3.5 w-3.5 text-primary" />}
                        {cmd.command === '/clear' && <Trash2 className="h-3.5 w-3.5 text-primary" />}
                        {cmd.command === '/history' && <History className="h-3.5 w-3.5 text-primary" />}
                        {cmd.command === '/tasks' && <ListTodo className="h-3.5 w-3.5 text-primary" />}
                        {cmd.command === '/model' && <Cpu className="h-3.5 w-3.5 text-primary" />}
                        {cmd.command === '/theme' && (resolvedTheme === 'dark' ? <Sun className="h-3.5 w-3.5 text-primary" /> : <Moon className="h-3.5 w-3.5 text-primary" />)}
                        {cmd.command === '/export' && <Download className="h-3.5 w-3.5 text-primary" />}
                        {cmd.command === '/shortcuts' && <Keyboard className="h-3.5 w-3.5 text-primary" />}
                        {cmd.command === '/new' && <Plus className="h-3.5 w-3.5 text-primary" />}
                        {cmd.command === '/save' && <Bookmark className="h-3.5 w-3.5 text-primary" />}
                        {cmd.command === '/load' && <FolderOpen className="h-3.5 w-3.5 text-primary" />}
                        {cmd.command === '/voice' && (isListening ? <MicOff className="h-3.5 w-3.5 text-destructive" /> : <Mic className="h-3.5 w-3.5 text-primary" />)}
                        {cmd.command === '/analyze' && <AlertTriangle className="h-3.5 w-3.5 text-primary" />}
                        {cmd.command === '/memory' && <Brain className="h-3.5 w-3.5 text-primary" />}
                        {cmd.command === '/search' && <SearchIcon className="h-3.5 w-3.5 text-primary" />}
                      </div>
                      <div className="flex-1">
                        <div className="font-mono text-xs font-medium">{cmd.command}</div>
                        <div className="text-[10px] text-muted-foreground">{cmd.description}</div>
                      </div>
                    </button>
                  ))}
                </div>
                <div className="px-3 py-1.5 border-t border-border bg-secondary/50 text-[10px] text-muted-foreground flex items-center gap-2">
                  <span>↑↓ Navigate</span>
                  <span>Enter Execute</span>
                  <span>Esc Close</span>
                </div>
              </div>
            )}
            
            {/* Autocomplete suggestions */}
            {showSuggestions && !isSlashCommand && suggestions.length > 0 && (
              <div 
                ref={suggestionsRef}
                className="absolute bottom-full left-0 right-0 mb-1 bg-popover border border-border rounded-lg shadow-lg overflow-hidden z-50 animate-fade-in"
              >
                <div className="py-1 max-h-48 overflow-y-auto">
                  {suggestions.map((suggestion, index) => (
                    <button
                      key={suggestion}
                      onClick={() => selectSuggestion(suggestion)}
                      className={cn(
                        "w-full px-3 py-2 text-left text-sm flex items-center gap-2 transition-colors",
                        index === selectedSuggestionIndex 
                          ? "bg-primary/10 text-foreground" 
                          : "hover:bg-secondary text-muted-foreground"
                      )}
                    >
                      {commandHistory.includes(suggestion) ? (
                        <History className="h-3 w-3 flex-shrink-0 text-muted-foreground" />
                      ) : (
                        <Sparkles className="h-3 w-3 flex-shrink-0 text-primary" />
                      )}
                      <span className="truncate">{suggestion}</span>
                    </button>
                  ))}
                </div>
                <div className="px-3 py-1.5 border-t border-border bg-secondary/50 text-[10px] text-muted-foreground flex items-center gap-2">
                  <span>↑↓ Navigate</span>
                  <span>Tab/Enter Select</span>
                  <span>Esc Close</span>
                </div>
              </div>
            )}
          </div>

          {/* Ultra Futuristic Send Button */}
          <button 
            type="button"
            onClick={(e) => {
              e.preventDefault();
              e.stopPropagation();
              handleSend();
            }}
            disabled={(!input.trim() && attachedFiles.length === 0 && attachedProjectFiles.length === 0) || isLoading || isLoadingProjectFiles} 
            className={cn(
              "h-16 w-16 rounded-2xl flex-shrink-0 relative overflow-visible",
              "flex items-center justify-center",
              "transition-all duration-500 ease-out transform",
              "disabled:opacity-50 disabled:cursor-not-allowed disabled:scale-100",
              "enabled:hover:scale-110 enabled:active:scale-95",
              "group"
            )}
          >
            {/* Outer animated ring */}
            <div className={cn(
              "absolute -inset-2 rounded-3xl opacity-0 group-hover:opacity-100 transition-all duration-700",
              "bg-gradient-to-r from-cyan-500 via-primary to-violet-500",
              "blur-md animate-pulse",
              (isLoading || isLoadingProjectFiles) && "opacity-100"
            )} />
            
            {/* Secondary glow layer */}
            <div className={cn(
              "absolute -inset-1 rounded-2xl opacity-0 group-hover:opacity-80 transition-all duration-500",
              "bg-gradient-to-br from-primary/60 via-cyan-400/40 to-violet-500/60",
              "blur-sm"
            )} />
            
            {/* Main button body */}
            <div className={cn(
              "absolute inset-0 rounded-2xl",
              "bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900",
              "border border-primary/30 group-hover:border-primary/60",
              "shadow-xl shadow-primary/20 group-hover:shadow-2xl group-hover:shadow-primary/40",
              "transition-all duration-500",
              "overflow-hidden"
            )}>
              {/* Animated gradient overlay */}
              <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-transparent to-cyan-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              
              {/* Scan line effect */}
              <div className="absolute inset-0 overflow-hidden opacity-30">
                <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/20 to-transparent translate-y-full group-hover:translate-y-0 transition-transform duration-1000 ease-out" 
                  style={{ animation: (isLoading || isLoadingProjectFiles) ? 'scan 1.5s linear infinite' : 'none' }} 
                />
              </div>
              
              {/* Corner accents */}
              <div className="absolute top-0 left-0 w-3 h-3 border-l-2 border-t-2 border-primary/50 rounded-tl-xl" />
              <div className="absolute top-0 right-0 w-3 h-3 border-r-2 border-t-2 border-primary/50 rounded-tr-xl" />
              <div className="absolute bottom-0 left-0 w-3 h-3 border-l-2 border-b-2 border-primary/50 rounded-bl-xl" />
              <div className="absolute bottom-0 right-0 w-3 h-3 border-r-2 border-b-2 border-primary/50 rounded-br-xl" />
            </div>
            
            {/* Icon container */}
            <div className="relative z-10 flex items-center justify-center">
              {isLoading || isLoadingProjectFiles ? (
                <div className="relative">
                  {/* Spinning loader */}
                  <div className="absolute inset-0 rounded-full border-2 border-transparent border-t-primary border-r-cyan-400 animate-spin" style={{ width: 32, height: 32, margin: -4 }} />
                  <Loader2 className="h-6 w-6 text-primary animate-pulse" />
                </div>
              ) : (
                <div className="relative">
                  {/* Icon glow */}
                  <div className="absolute inset-0 blur-md bg-primary/50 rounded-full scale-150 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  {/* Main icon */}
                  <Send className={cn(
                    "h-7 w-7 relative z-10 transition-all duration-300",
                    "text-primary group-hover:text-primary-foreground",
                    "group-hover:translate-x-0.5 group-hover:-translate-y-0.5",
                    "drop-shadow-[0_0_8px_rgba(var(--primary),0.5)]"
                  )} />
                </div>
              )}
            </div>
            
            {/* Particle effects on hover */}
            <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none">
              <div className="absolute top-1 left-1/2 w-1 h-1 bg-cyan-400 rounded-full animate-ping" style={{ animationDelay: '0s' }} />
              <div className="absolute bottom-2 right-1 w-1 h-1 bg-primary rounded-full animate-ping" style={{ animationDelay: '0.3s' }} />
              <div className="absolute top-1/2 left-1 w-0.5 h-0.5 bg-violet-400 rounded-full animate-ping" style={{ animationDelay: '0.6s' }} />
            </div>
          </button>

        </div>
        
        
        {/* Mode and Model Dropdowns */}
        <div className="flex items-center gap-2 mt-3">
          {/* Chat Mode Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="h-8 gap-1.5 text-xs bg-secondary/50 hover:bg-secondary">
                {chatModes.find(m => m.id === chatMode)?.name || 'Agent'}
                <ChevronDown className="h-3 w-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-48 bg-popover border-border">
              {chatModes.map((mode) => (
                <DropdownMenuItem
                  key={mode.id}
                  onClick={() => setChatMode(mode.id)}
                  className={cn(
                    "flex items-center justify-between cursor-pointer",
                    chatMode === mode.id && "bg-primary/10"
                  )}
                >
                  <div>
                    <span className="font-medium">{mode.name}</span>
                    <p className="text-[10px] text-muted-foreground">{mode.description}</p>
                  </div>
                  {chatMode === mode.id && <Check className="h-4 w-4 text-primary" />}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Model Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="h-8 gap-1.5 text-xs bg-secondary/50 hover:bg-secondary">
                {getDisplayModelName()}
                <ChevronDown className="h-3 w-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="w-56 bg-popover border-border max-h-80 overflow-y-auto">
              {llmProviders.map((provider) => (
                <div key={provider.id}>
                  <DropdownMenuLabel className="text-[10px] uppercase text-muted-foreground tracking-wider">
                    {provider.name}
                  </DropdownMenuLabel>
                  {provider.models.map((model) => (
                    <DropdownMenuItem
                      key={model.id}
                      onClick={async () => {
                        const result = await setModel(provider.id, model.id);
                        if (result?.success) {
                          toast.success(`Model set to ${result.modelName}`, {
                            description: 'Preference saved for future sessions'
                          });
                        }
                      }}
                      className={cn(
                        "flex items-center justify-between cursor-pointer",
                        selectedModel === model.id && "bg-primary/10"
                      )}
                    >
                      <div>
                        <span className="font-medium">{model.name}</span>
                        <p className="text-[10px] text-muted-foreground">{model.description}</p>
                      </div>
                      {selectedModel === model.id && <Check className="h-4 w-4 text-primary" />}
                    </DropdownMenuItem>
                  ))}
              {provider.id !== 'google' && <DropdownMenuSeparator />}
                </div>
              ))}
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={async () => {
                  const result = await resetModelPreference();
                  if (result.success) {
                    toast.success('Model preference reset', {
                      description: 'Using Auto (Recommended) as default'
                    });
                  }
                }}
                className="text-muted-foreground"
              >
                <RotateCcw className="h-3.5 w-3.5 mr-2" />
                Reset to default
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Meeting Notes Button */}
          <Button
            variant="ghost"
            size="sm"
            className="h-8 gap-1.5 text-xs"
            onClick={() => setShowMeetingNotesPanel(true)}
          >
            <Video className="h-3 w-3" />
            Meeting Notes
          </Button>

          {/* Branch indicator - next to model dropdown */}
          <Badge variant="outline" className="text-xs gap-1.5 h-8 px-3 ml-1">
            <GitBranch className="h-3 w-3" />
            main
          </Badge>

          {/* Attach files from computer - next to branch */}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => fileInputRef.current?.click()}
            className="h-8 gap-1.5 text-xs"
            title="Attach files from computer"
          >
            <FolderOpen className="h-3 w-3" />
            Attach Files
          </Button>

          {/* LLM Router Info */}
          {lastRouterInfo && (
            <Badge variant="secondary" className="text-[10px] gap-1 h-6 px-2 ml-auto">
              <Cpu className="h-3 w-3" />
              {lastRouterInfo.taskType.replace('_', ' ')} → {lastRouterInfo.modelName}
            </Badge>
          )}
        </div>
        
      </div>

      {/* Meeting Notes Panel */}
      <MeetingNotesPanel 
        isOpen={showMeetingNotesPanel} 
        onClose={() => setShowMeetingNotesPanel(false)} 
      />

      {/* Load Saved Chats Dialog */}
      <Dialog open={showLoadDialog} onOpenChange={setShowLoadDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FolderOpen className="h-5 w-5 text-primary" />
              Load Saved Conversation
            </DialogTitle>
          </DialogHeader>
          <ScrollArea className="max-h-[400px]">
            {savedChats.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Bookmark className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>No saved conversations</p>
                <p className="text-xs mt-1">Use /save to bookmark a chat</p>
              </div>
            ) : (
              <div className="space-y-2">
                {savedChats.map((chat) => (
                  <div 
                    key={chat.id} 
                    className="flex items-center justify-between p-3 rounded-lg border border-border hover:bg-secondary/50 transition-colors"
                  >
                    <button 
                      onClick={() => loadSavedChat(chat)}
                      className="flex-1 text-left"
                    >
                      <div className="font-medium text-sm">{chat.name}</div>
                      <div className="text-xs text-muted-foreground">
                        {chat.messages.length} messages • {new Date(chat.timestamp).toLocaleDateString()}
                      </div>
                    </button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => deleteSavedChat(chat.id)}
                      className="h-8 w-8 text-muted-foreground hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </DialogContent>
      </Dialog>

      {/* Memory Dialog */}
      <Dialog open={showMemoryDialog} onOpenChange={setShowMemoryDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Brain className="h-5 w-5 text-primary" />
              Memory Store
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            {/* Save to Memory */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Save Information</label>
              <textarea
                value={memoryInput}
                onChange={(e) => setMemoryInput(e.target.value)}
                placeholder="Enter important information you want NAVI to remember..."
                className="w-full h-24 px-3 py-2 text-sm rounded-md border border-border bg-background resize-none"
              />
              <Button 
                onClick={handleSaveToMemory} 
                disabled={!memoryInput.trim()}
                className="w-full"
                variant="ai"
              >
                <Plus className="h-4 w-4 mr-2" />
                Save to Memory
              </Button>
            </div>

            <div className="border-t border-border" />

            {/* Search Memories */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Search Knowledge Base</label>
              <div className="flex gap-2">
                <Input
                  value={memorySearchQuery}
                  onChange={(e) => setMemorySearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleMemorySearch()}
                  placeholder="Search your memories semantically..."
                  className="flex-1"
                />
                <Button 
                  onClick={handleMemorySearch} 
                  disabled={isSearchingMemory || !memorySearchQuery.trim()}
                  variant="secondary"
                >
                  {isSearchingMemory ? <Loader2 className="h-4 w-4 animate-spin" /> : <SearchIcon className="h-4 w-4" />}
                </Button>
              </div>

              {/* Search Results */}
              {memorySearchResults.length > 0 && (
                <ScrollArea className="h-48 rounded-md border border-border">
                  <div className="p-2 space-y-2">
                    {memorySearchResults.map((memory, index) => (
                      <div key={memory.id || index} className="p-2 rounded bg-secondary/50 text-sm">
                        {memory.title && (
                          <div className="font-medium text-xs mb-1">{memory.title}</div>
                        )}
                        <p className="text-muted-foreground text-xs line-clamp-3">
                          {memory.content}
                        </p>
                        {memory.similarity !== undefined && (
                          <Badge variant="outline" className="mt-1 text-[10px]">
                            {Math.round(memory.similarity * 100)}% match
                          </Badge>
                        )}
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Project Files Dialog */}
      <ProjectFilesDialog
        open={showProjectFilesDialog}
        onOpenChange={setShowProjectFilesDialog}
        onFilesSelect={(files) => {
          setAttachedProjectFiles(prev => [...prev, ...files]);
          toast.success(`Attached ${files.length} project file${files.length > 1 ? 's' : ''}`);
        }}
      />
      </div>
    </div>
  );
}
