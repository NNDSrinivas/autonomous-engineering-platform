import { 
  ChevronDown,
  Zap,
  PanelLeft,
  LogIn,
  LogOut,
  User
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { ThemeToggleCompact } from './ThemeToggle';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

function UserDropdown({ userName }: { userName: string }) {
  const navigate = useNavigate();
  const isGuest = userName === 'Sign In' || userName === 'Guest';

  const handleSignIn = () => {
    navigate('/auth');
  };

  const handleSignOut = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) {
      toast.error('Failed to sign out');
    } else {
      toast.success('Signed out successfully');
    }
  };

  if (isGuest) {
    return (
      <Button variant="ghost" size="sm" className="gap-2" onClick={handleSignIn}>
        <LogIn className="h-4 w-4" />
        <span className="text-sm">Sign In</span>
      </Button>
    );
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="sm" className="gap-2 transition-all duration-200 hover:bg-primary/10">
          <div className="h-7 w-7 rounded-full bg-primary/20 flex items-center justify-center text-xs font-medium">
            {userName.charAt(0).toUpperCase()}
          </div>
          <span className="text-sm">{userName}</span>
          <ChevronDown className="h-3 w-3" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-48 animate-fade-in-up bg-popover border-border">
        <DropdownMenuLabel className="text-xs">{userName}</DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem className="text-xs cursor-pointer">
          <User className="h-3 w-3 mr-2" />
          Profile
        </DropdownMenuItem>
        <DropdownMenuItem className="text-xs cursor-pointer">Preferences</DropdownMenuItem>
        <DropdownMenuItem className="text-xs cursor-pointer">Integrations</DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem className="text-xs text-destructive cursor-pointer" onClick={handleSignOut}>
          <LogOut className="h-3 w-3 mr-2" />
          Sign Out
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}

interface NaviHeaderProps {
  userName: string;
  userAvatar?: string;
  isSidebarCollapsed?: boolean;
  onToggleSidebar?: () => void;
}

export function NaviHeader({ 
  userName,
  isSidebarCollapsed,
  onToggleSidebar
}: NaviHeaderProps) {

  return (
    <header className="h-14 border-b border-border bg-background flex items-center px-4 gap-4 relative z-40">
      {/* Sidebar Toggle */}
      <Tooltip>
        <TooltipTrigger asChild>
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-8 w-8"
            onClick={onToggleSidebar}
          >
            <PanelLeft className="h-4 w-4" />
          </Button>
        </TooltipTrigger>
        <TooltipContent side="right">
          {isSidebarCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        </TooltipContent>
      </Tooltip>

      {/* Logo & Title */}
      <div className="flex items-center gap-3">
        <div className="h-8 w-8 rounded-lg gradient-ai flex items-center justify-center animate-glow-pulse">
          <Zap className="h-4 w-4 text-primary-foreground" />
        </div>
        <div>
          <h1 className="text-sm font-bold gradient-ai-text">NAVI</h1>
          <p className="text-[10px] text-muted-foreground">Autonomous Engineering Intelligence</p>
        </div>
      </div>

      {/* Spacer */}
      <div className="flex-1" />

      {/* Theme Toggle */}
      <ThemeToggleCompact />
      <UserDropdown userName={userName} />
    </header>
  );
}
