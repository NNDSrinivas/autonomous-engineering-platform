import { useState, useEffect, useMemo } from 'react';
import { 
  Bell, 
  AlertTriangle, 
  CheckCircle2, 
  MessageSquare, 
  GitBranch,
  RefreshCw,
  X,
  ExternalLink,
  Clock,
  Search,
  Filter
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

interface Notification {
  id: string;
  type: 'integration' | 'message' | 'sync' | 'alert';
  title: string;
  description: string;
  timestamp: Date;
  read: boolean;
  action?: {
    label: string;
    onClick: () => void;
  };
  integration?: string;
  severity?: 'info' | 'warning' | 'error' | 'success';
}

interface NotificationPanelProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: Notification[];
  onMarkAsRead: (id: string) => void;
  onMarkAllRead: () => void;
  onClearAll: () => void;
}

type FilterType = 'all' | 'integration' | 'message' | 'sync' | 'alert';

const filterOptions: { id: FilterType; label: string }[] = [
  { id: 'all', label: 'All' },
  { id: 'integration', label: 'Integrations' },
  { id: 'message', label: 'Messages' },
  { id: 'sync', label: 'Sync' },
  { id: 'alert', label: 'Alerts' },
];

const getIcon = (type: string, severity?: string) => {
  switch (type) {
    case 'integration':
      return severity === 'error' 
        ? <AlertTriangle className="h-4 w-4 text-destructive" />
        : <RefreshCw className="h-4 w-4 text-primary" />;
    case 'message':
      return <MessageSquare className="h-4 w-4 text-purple-400" />;
    case 'sync':
      return <GitBranch className="h-4 w-4 text-green-400" />;
    case 'alert':
      return severity === 'warning' 
        ? <AlertTriangle className="h-4 w-4 text-yellow-400" />
        : <CheckCircle2 className="h-4 w-4 text-green-400" />;
    default:
      return <Bell className="h-4 w-4" />;
  }
};

const formatTime = (date: Date) => {
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  const minutes = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days = Math.floor(diff / 86400000);

  if (minutes < 1) return 'Just now';
  if (minutes < 60) return `${minutes}m ago`;
  if (hours < 24) return `${hours}h ago`;
  return `${days}d ago`;
};

export function NotificationPanel({ 
  isOpen, 
  onClose, 
  notifications, 
  onMarkAsRead,
  onMarkAllRead,
  onClearAll 
}: NotificationPanelProps) {
  const [activeFilter, setActiveFilter] = useState<FilterType>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredNotifications = useMemo(() => {
    return notifications.filter(n => {
      // Type filter
      if (activeFilter !== 'all' && n.type !== activeFilter) return false;
      
      // Search filter
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        return (
          n.title.toLowerCase().includes(query) ||
          n.description.toLowerCase().includes(query) ||
          n.integration?.toLowerCase().includes(query)
        );
      }
      
      return true;
    });
  }, [notifications, activeFilter, searchQuery]);

  const unreadCount = notifications.filter(n => !n.read).length;

  if (!isOpen) return null;

  return (
    <div 
      className={cn(
        "absolute right-0 top-14 w-96 bg-card border border-border rounded-xl shadow-2xl z-50",
        "animate-in fade-in-0 slide-in-from-top-2 duration-200"
      )}
    >
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center gap-2">
          <Bell className="h-4 w-4 text-primary" />
          <h3 className="font-semibold text-sm">Notifications</h3>
          {unreadCount > 0 && (
            <Badge variant="default" className="h-5 px-1.5 text-[10px]">
              {unreadCount}
            </Badge>
          )}
        </div>
        <div className="flex items-center gap-1">
          {unreadCount > 0 && (
            <Button variant="ghost" size="xs" onClick={onMarkAllRead} className="text-xs text-muted-foreground">
              Mark all read
            </Button>
          )}
          <Button variant="ghost" size="icon" onClick={onClose} className="h-7 w-7">
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Search and Filter */}
      <div className="p-3 border-b border-border space-y-2">
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
          <Input
            placeholder="Search notifications..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="h-8 pl-8 text-xs"
          />
        </div>
        <div className="flex gap-1 flex-wrap">
          {filterOptions.map((filter) => (
            <Button
              key={filter.id}
              variant={activeFilter === filter.id ? 'default' : 'ghost'}
              size="xs"
              onClick={() => setActiveFilter(filter.id)}
              className={cn(
                "h-6 text-[10px] px-2",
                activeFilter === filter.id && "bg-primary text-primary-foreground"
              )}
            >
              {filter.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Notifications List */}
      <ScrollArea className="h-[350px]">
        {filteredNotifications.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
            <Bell className="h-8 w-8 mb-3 opacity-50" />
            <p className="text-sm">
              {searchQuery || activeFilter !== 'all' 
                ? 'No matching notifications' 
                : 'No notifications'}
            </p>
            <p className="text-xs">
              {searchQuery || activeFilter !== 'all'
                ? 'Try adjusting your filters'
                : "You're all caught up!"}
            </p>
          </div>
        ) : (
          <div className="p-2 space-y-1">
            {filteredNotifications.map((notification) => (
              <div
                key={notification.id}
                onClick={() => onMarkAsRead(notification.id)}
                className={cn(
                  "p-3 rounded-lg cursor-pointer transition-all duration-200",
                  "hover:bg-secondary/50 group",
                  !notification.read && "bg-primary/5 border-l-2 border-primary"
                )}
              >
                <div className="flex gap-3">
                  <div className="flex-shrink-0 mt-0.5">
                    {getIcon(notification.type, notification.severity)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <p className={cn(
                        "text-sm font-medium truncate",
                        !notification.read && "text-foreground",
                        notification.read && "text-muted-foreground"
                      )}>
                        {notification.title}
                      </p>
                      <span className="text-[10px] text-muted-foreground flex-shrink-0 flex items-center gap-1">
                        <Clock className="h-2.5 w-2.5" />
                        {formatTime(notification.timestamp)}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">
                      {notification.description}
                    </p>
                    {notification.integration && (
                      <Badge variant="outline" className="mt-2 text-[10px]">
                        {notification.integration}
                      </Badge>
                    )}
                    {notification.action && (
                      <Button 
                        variant="link" 
                        size="xs" 
                        onClick={(e) => {
                          e.stopPropagation();
                          notification.action?.onClick();
                        }}
                        className="mt-1.5 h-auto p-0 text-xs text-primary"
                      >
                        {notification.action.label}
                        <ExternalLink className="h-3 w-3 ml-1" />
                      </Button>
                    )}
                  </div>
                  {!notification.read && (
                    <div className="w-2 h-2 rounded-full bg-primary flex-shrink-0 mt-1" />
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </ScrollArea>

      {/* Footer */}
      {notifications.length > 0 && (
        <div className="p-3 border-t border-border">
          <Button variant="ghost" size="sm" onClick={onClearAll} className="w-full text-xs text-muted-foreground">
            Clear all notifications
          </Button>
        </div>
      )}
    </div>
  );
}

// Hook to manage notifications
export function useNotifications() {
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: '1',
      type: 'integration',
      title: 'GitHub connection needs attention',
      description: 'Your GitHub OAuth token is expiring soon. Please reconnect to continue syncing.',
      timestamp: new Date(Date.now() - 3600000),
      read: false,
      severity: 'warning',
      integration: 'GitHub',
      action: {
        label: 'Reconnect',
        onClick: () => {
          window.open('https://github.com/settings/applications', '_blank');
        },
      },
    },
    {
      id: '2',
      type: 'sync',
      title: 'Jira sync completed',
      description: '12 tasks synced from your Jira project.',
      timestamp: new Date(Date.now() - 7200000),
      read: false,
      severity: 'success',
      integration: 'Jira',
    },
    {
      id: '3',
      type: 'message',
      title: 'New Slack message',
      description: 'Sarah mentioned you in #engineering: "Can you review the PR?"',
      timestamp: new Date(Date.now() - 10800000),
      read: true,
      integration: 'Slack',
    },
  ]);

  const markAsRead = (id: string) => {
    setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
  };

  const markAllRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const clearAll = () => {
    setNotifications([]);
  };

  const addNotification = (notification: Omit<Notification, 'id' | 'timestamp' | 'read'>) => {
    setNotifications(prev => [{
      ...notification,
      id: Date.now().toString(),
      timestamp: new Date(),
      read: false,
    }, ...prev]);
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return {
    notifications,
    unreadCount,
    markAsRead,
    markAllRead,
    clearAll,
    addNotification,
  };
}
