import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from '@/components/ui/collapsible';
import { 
  BookOpen, 
  CheckCircle2, 
  ChevronDown, 
  ChevronRight,
  MessageSquare, 
  Plug, 
  Shield, 
  Brain,
  Workflow,
  Bell,
  Building2,
  Sparkles,
  GitBranch,
  Zap,
  HelpCircle,
  X
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';

interface OnboardingStep {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  category: 'getting-started' | 'integrations' | 'workflows' | 'advanced';
  details?: string[];
  completed?: boolean;
}

const onboardingSteps: OnboardingStep[] = [
  {
    id: 'chat',
    title: 'Chat with NAVI',
    description: 'Start conversations with your AI engineering assistant. NAVI understands your projects, tasks, and code.',
    icon: <MessageSquare className="h-5 w-5" />,
    category: 'getting-started',
    details: [
      'Type naturally to ask questions or request actions',
      'Use @mentions to reference Jira tickets or files',
      'NAVI remembers context from previous conversations',
      'Press ⌘/ to open the command palette for quick actions'
    ]
  },
  {
    id: 'integrations',
    title: 'Connect Your Tools',
    description: 'Link Jira, GitHub, Slack, Confluence, and more to give NAVI full context of your engineering environment.',
    icon: <Plug className="h-5 w-5" />,
    category: 'integrations',
    details: [
      'Go to Settings → Integrations to connect your accounts',
      'Each integration is securely authenticated via OAuth',
      'NAVI syncs data automatically after connection',
      'Admins can configure organization-wide OAuth apps in Connectors'
    ]
  },
  {
    id: 'oauth-setup',
    title: 'Configure OAuth Apps (Admins)',
    description: 'Organization admins can set up OAuth credentials so team members can connect their accounts.',
    icon: <Building2 className="h-5 w-5" />,
    category: 'integrations',
    details: [
      'Go to Settings → Connectors tab',
      'Create OAuth apps in GitHub, Slack, Atlassian, etc.',
      'Copy the callback URL provided and add it to your OAuth app',
      'Enter Client ID and Secret for each provider',
      'Team members can then connect via Settings → Integrations'
    ]
  },
  {
    id: 'workflows',
    title: 'Automated Workflows',
    description: 'Let NAVI execute complete engineering tasks from start to finish with approval at each step.',
    icon: <Workflow className="h-5 w-5" />,
    category: 'workflows',
    details: [
      'Select a Jira task and click "Start Workflow"',
      'Choose from workflow templates or create custom ones',
      'NAVI analyzes the task, generates code, creates branches, and opens PRs',
      'Review and approve each step before NAVI proceeds',
      'Track all workflow runs in Workflow History'
    ]
  },
  {
    id: 'approvals',
    title: 'Approval Settings',
    description: 'Control which actions require your approval before NAVI executes them.',
    icon: <Shield className="h-5 w-5" />,
    category: 'advanced',
    details: [
      'Go to Settings → Approvals tab',
      'Enable/disable approval requirements per integration',
      'High-risk actions (deployments, merges) always require approval',
      'View pending approvals from the sidebar'
    ]
  },
  {
    id: 'memory',
    title: 'Memory & Context',
    description: 'NAVI remembers your preferences, past conversations, and project context across sessions.',
    icon: <Brain className="h-5 w-5" />,
    category: 'advanced',
    details: [
      'Preferences are automatically saved to the memory engine',
      'Sync preferences manually via Settings → Profile → Memory Engine',
      'NAVI uses RAG to retrieve relevant context from your workspace',
      'Memory improves over time as you interact with NAVI'
    ]
  },
  {
    id: 'notifications',
    title: 'Smart Notifications',
    description: 'Get alerted about important events across all your integrations.',
    icon: <Bell className="h-5 w-5" />,
    category: 'getting-started',
    details: [
      'Configure notification preferences in Settings → Notifications',
      'Choose notification sounds and volume',
      'Enable/disable email digests and push notifications',
      'Click the bell icon to view recent notifications'
    ]
  },
  {
    id: 'keyboard',
    title: 'Keyboard Shortcuts',
    description: 'Navigate NAVI quickly with keyboard shortcuts.',
    icon: <Zap className="h-5 w-5" />,
    category: 'getting-started',
    details: [
      '⌘K - Open search',
      '⌘/ - Command palette',
      '⌘T - Tasks panel',
      '⌘N - Notifications',
      '⌘, - Settings',
      '⌘⇧W - Start workflow on selected task',
      'Escape - Close panels'
    ]
  },
  {
    id: 'ai-models',
    title: 'AI Model Selection',
    description: 'Choose which AI model powers NAVI based on your needs.',
    icon: <Sparkles className="h-5 w-5" />,
    category: 'advanced',
    details: [
      'Go to Settings → Profile → AI Preferences',
      'Gemini Flash is fast and balanced (default)',
      'Gemini Pro offers best reasoning for complex tasks',
      'GPT-5 provides maximum capability',
      'Model selection is saved to your preferences'
    ]
  },
  {
    id: 'cicd',
    title: 'CI/CD Monitoring',
    description: 'NAVI monitors your build pipelines and can help fix failures.',
    icon: <GitBranch className="h-5 w-5" />,
    category: 'workflows',
    details: [
      'Connect GitHub to enable CI/CD monitoring',
      'NAVI fetches pipeline runs and test results',
      'Get explanations for build failures',
      'NAVI can suggest and apply fixes with approval'
    ]
  }
];

const categories = [
  { id: 'getting-started', title: 'Getting Started', icon: <BookOpen className="h-4 w-4" /> },
  { id: 'integrations', title: 'Integrations', icon: <Plug className="h-4 w-4" /> },
  { id: 'workflows', title: 'Workflows', icon: <Workflow className="h-4 w-4" /> },
  { id: 'advanced', title: 'Advanced', icon: <Sparkles className="h-4 w-4" /> },
];

export function OnboardingGuide() {
  const [open, setOpen] = useState(false);
  const [completedSteps, setCompletedSteps] = useState<string[]>([]);
  const [expandedSteps, setExpandedSteps] = useState<string[]>([]);
  const [showOnboarding, setShowOnboarding] = useState(false);

  useEffect(() => {
    checkOnboardingStatus();
  }, []);

  const checkOnboardingStatus = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const { data } = await supabase
        .from('user_preferences')
        .select('preference_value')
        .eq('user_id', session.user.id)
        .eq('preference_key', 'onboarding_completed')
        .maybeSingle();

      if (!data) {
        // First time user
        setShowOnboarding(true);
      } else {
        const value = data.preference_value as { completed: string[], dismissed: boolean };
        setCompletedSteps(value?.completed || []);
      }
    } catch (error) {
      console.error('Error checking onboarding status:', error);
    }
  };

  const markStepComplete = async (stepId: string) => {
    const newCompleted = [...completedSteps, stepId];
    setCompletedSteps(newCompleted);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      await supabase
        .from('user_preferences')
        .upsert({
          user_id: session.user.id,
          preference_key: 'onboarding_completed',
          preference_value: { completed: newCompleted, dismissed: false }
        }, {
          onConflict: 'user_id,preference_key'
        });
    } catch (error) {
      console.error('Error saving onboarding progress:', error);
    }
  };

  const toggleStepExpanded = (stepId: string) => {
    setExpandedSteps(prev => 
      prev.includes(stepId) 
        ? prev.filter(id => id !== stepId)
        : [...prev, stepId]
    );
  };

  const progress = Math.round((completedSteps.length / onboardingSteps.length) * 100);

  return (
    <>
      {/* Floating Help Button - positioned at top right of viewport */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          <Button
            variant="outline"
            size="icon"
            className="fixed top-20 right-6 z-40 h-10 w-10 rounded-full shadow-lg bg-background hover:bg-primary hover:text-primary-foreground transition-all"
          >
            <HelpCircle className="h-4 w-4" />
          </Button>
        </DialogTrigger>
        <DialogContent className="max-w-2xl h-[80vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <BookOpen className="h-5 w-5 text-primary" />
              NAVI Guide
            </DialogTitle>
            <DialogDescription>
              Learn how to get the most out of your AI engineering assistant
            </DialogDescription>
          </DialogHeader>
          
          <div className="flex items-center gap-3 py-3 border-b border-border">
            <Progress value={progress} className="flex-1" />
            <span className="text-sm text-muted-foreground whitespace-nowrap">
              {completedSteps.length} / {onboardingSteps.length} completed
            </span>
          </div>

          <ScrollArea className="flex-1 -mx-6 px-6 overflow-y-auto">
            <div className="space-y-6 py-4">
              {categories.map(category => {
                const categorySteps = onboardingSteps.filter(s => s.category === category.id);
                
                return (
                  <div key={category.id} className="space-y-3">
                    <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                      {category.icon}
                      {category.title}
                    </div>
                    
                    <div className="space-y-2">
                      {categorySteps.map(step => {
                        const isCompleted = completedSteps.includes(step.id);
                        const isExpanded = expandedSteps.includes(step.id);
                        
                        return (
                          <Collapsible
                            key={step.id}
                            open={isExpanded}
                            onOpenChange={() => toggleStepExpanded(step.id)}
                          >
                            <Card className={cn(
                              "transition-all",
                              isCompleted && "bg-primary/5 border-primary/20"
                            )}>
                              <CollapsibleTrigger asChild>
                                <CardHeader className="p-4 cursor-pointer hover:bg-muted/50 transition-colors">
                                  <div className="flex items-center gap-3">
                                    <div className={cn(
                                      "p-2 rounded-lg",
                                      isCompleted ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"
                                    )}>
                                      {step.icon}
                                    </div>
                                    <div className="flex-1">
                                      <CardTitle className="text-sm flex items-center gap-2">
                                        {step.title}
                                        {isCompleted && (
                                          <CheckCircle2 className="h-4 w-4 text-primary" />
                                        )}
                                      </CardTitle>
                                      <CardDescription className="text-xs mt-0.5">
                                        {step.description}
                                      </CardDescription>
                                    </div>
                                    {isExpanded ? (
                                      <ChevronDown className="h-4 w-4 text-muted-foreground" />
                                    ) : (
                                      <ChevronRight className="h-4 w-4 text-muted-foreground" />
                                    )}
                                  </div>
                                </CardHeader>
                              </CollapsibleTrigger>
                              
                              <CollapsibleContent>
                                <CardContent className="pt-0 pb-4 px-4">
                                  {step.details && (
                                    <ul className="space-y-2 mb-4">
                                      {step.details.map((detail, i) => (
                                        <li key={i} className="flex items-start gap-2 text-xs text-muted-foreground">
                                          <div className="h-1.5 w-1.5 rounded-full bg-primary mt-1.5 shrink-0" />
                                          {detail}
                                        </li>
                                      ))}
                                    </ul>
                                  )}
                                  
                                  {!isCompleted && (
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => markStepComplete(step.id)}
                                    >
                                      <CheckCircle2 className="h-3.5 w-3.5 mr-1.5" />
                                      Mark as complete
                                    </Button>
                                  )}
                                </CardContent>
                              </CollapsibleContent>
                            </Card>
                          </Collapsible>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </ScrollArea>
        </DialogContent>
      </Dialog>

      {/* First-time User Welcome Modal */}
      {showOnboarding && (
        <Dialog open={showOnboarding} onOpenChange={setShowOnboarding}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2 text-xl">
                <Sparkles className="h-6 w-6 text-primary" />
                Welcome to NAVI
              </DialogTitle>
              <DialogDescription className="text-base">
                Your autonomous engineering intelligence system
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              <p className="text-sm text-muted-foreground">
                NAVI is more than a chat assistant — it's a full-stack autonomous engineering system that:
              </p>
              
              <ul className="space-y-3">
                {[
                  { icon: <Plug className="h-4 w-4" />, text: 'Connects to Jira, GitHub, Slack, Confluence, and more' },
                  { icon: <Brain className="h-4 w-4" />, text: 'Understands your entire engineering environment' },
                  { icon: <Workflow className="h-4 w-4" />, text: 'Executes complete engineering workflows end-to-end' },
                  { icon: <Shield className="h-4 w-4" />, text: 'Asks permission before changing anything' },
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3 text-sm">
                    <div className="p-1.5 rounded-md bg-primary/10 text-primary">
                      {item.icon}
                    </div>
                    {item.text}
                  </li>
                ))}
              </ul>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <Button 
                className="flex-1" 
                onClick={() => {
                  setShowOnboarding(false);
                  setOpen(true);
                }}
              >
                <BookOpen className="h-4 w-4 mr-2" />
                View Guide
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setShowOnboarding(false)}
              >
                Get Started
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}
