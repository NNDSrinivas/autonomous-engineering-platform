import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';
import { 
  Building2, 
  Users, 
  UserPlus, 
  Crown, 
  Shield, 
  User,
  Loader2,
  Trash2,
  Check,
  ChevronDown
} from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface Organization {
  id: string;
  name: string;
  slug: string;
}

interface Member {
  id: string;
  user_id: string;
  role: 'owner' | 'admin' | 'member';
  created_at: string;
  email?: string;
}

const roleIcons: Record<string, React.ReactNode> = {
  owner: <Crown className="h-3 w-3" />,
  admin: <Shield className="h-3 w-3" />,
  member: <User className="h-3 w-3" />,
};

const roleColors: Record<string, string> = {
  owner: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
  admin: 'bg-blue-500/10 text-blue-400 border-blue-500/30',
  member: 'bg-muted text-muted-foreground border-border',
};

export function OrganizationTab() {
  const [organizations, setOrganizations] = useState<Organization[]>([]);
  const [currentOrg, setCurrentOrg] = useState<Organization | null>(null);
  const [members, setMembers] = useState<Member[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isInviting, setIsInviting] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState<'admin' | 'member'>('member');
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [currentUserRole, setCurrentUserRole] = useState<string | null>(null);
  const [newOrgName, setNewOrgName] = useState('');
  const [isCreatingOrg, setIsCreatingOrg] = useState(false);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      setCurrentUserId(session.user.id);

      // Get all organizations user is a member of
      const { data: memberships } = await supabase
        .from('organization_members')
        .select('organization_id, role')
        .eq('user_id', session.user.id);

      if (!memberships || memberships.length === 0) {
        setIsLoading(false);
        return;
      }

      const orgIds = memberships.map(m => m.organization_id);
      
      const { data: orgs } = await supabase
        .from('organizations')
        .select('*')
        .in('id', orgIds);

      setOrganizations(orgs || []);

      // Get current org from profile
      const { data: profile } = await supabase
        .from('profiles')
        .select('current_organization_id')
        .eq('user_id', session.user.id)
        .maybeSingle();

      let activeOrg = orgs?.find(o => o.id === profile?.current_organization_id) || orgs?.[0];
      
      if (activeOrg) {
        setCurrentOrg(activeOrg);
        const membership = memberships.find(m => m.organization_id === activeOrg!.id);
        setCurrentUserRole(membership?.role || null);
        await fetchMembers(activeOrg.id);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchMembers = async (orgId: string) => {
    const { data: memberData } = await supabase
      .from('organization_members')
      .select('*')
      .eq('organization_id', orgId)
      .order('created_at', { ascending: true });

    // Get user emails from auth - we'll show user_id as fallback
    const membersWithInfo = (memberData || []).map(m => ({
      ...m,
      email: `User ${m.user_id.slice(0, 8)}...`,
    }));

    setMembers(membersWithInfo as Member[]);
  };

  const switchOrganization = async (org: Organization) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      await supabase
        .from('profiles')
        .update({ current_organization_id: org.id })
        .eq('user_id', session.user.id);

      setCurrentOrg(org);
      
      // Get user's role in this org
      const { data: membership } = await supabase
        .from('organization_members')
        .select('role')
        .eq('organization_id', org.id)
        .eq('user_id', session.user.id)
        .single();

      setCurrentUserRole(membership?.role || null);
      await fetchMembers(org.id);
      toast.success(`Switched to ${org.name}`);
    } catch (error) {
      console.error('Error switching org:', error);
      toast.error('Failed to switch organization');
    }
  };

  const createOrganization = async () => {
    if (!newOrgName.trim()) {
      toast.error('Please enter an organization name');
      return;
    }

    setIsCreatingOrg(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const slug = newOrgName.toLowerCase().replace(/[^a-z0-9]/g, '-') + '-' + Date.now();

      const { data: org, error: orgError } = await supabase
        .from('organizations')
        .insert({ name: newOrgName, slug })
        .select()
        .single();

      if (orgError) throw orgError;

      const { error: memberError } = await supabase
        .from('organization_members')
        .insert({
          organization_id: org.id,
          user_id: session.user.id,
          role: 'owner',
        });

      if (memberError) throw memberError;

      await supabase
        .from('profiles')
        .update({ current_organization_id: org.id })
        .eq('user_id', session.user.id);

      setNewOrgName('');
      toast.success('Organization created');
      await fetchData();
    } catch (error) {
      console.error('Error creating org:', error);
      toast.error('Failed to create organization');
    } finally {
      setIsCreatingOrg(false);
    }
  };

  const inviteMember = async () => {
    if (!currentOrg || !inviteEmail.trim()) {
      toast.error('Please enter an email address');
      return;
    }

    setIsInviting(true);
    try {
      // Note: In a real app, you'd send an invite email and handle this differently
      // For now, we'll show a message about how invites would work
      toast.info(`Invite system: In production, an email would be sent to ${inviteEmail} with a link to join ${currentOrg.name} as ${inviteRole}`);
      setInviteEmail('');
    } catch (error) {
      console.error('Error inviting member:', error);
      toast.error('Failed to send invite');
    } finally {
      setIsInviting(false);
    }
  };

  const updateMemberRole = async (memberId: string, newRole: 'admin' | 'member') => {
    if (!currentOrg) return;

    try {
      const { error } = await supabase
        .from('organization_members')
        .update({ role: newRole })
        .eq('id', memberId);

      if (error) throw error;

      await fetchMembers(currentOrg.id);
      toast.success('Role updated');
    } catch (error) {
      console.error('Error updating role:', error);
      toast.error('Failed to update role');
    }
  };

  const removeMember = async (memberId: string, userId: string) => {
    if (!currentOrg || userId === currentUserId) {
      toast.error("You can't remove yourself");
      return;
    }

    try {
      const { error } = await supabase
        .from('organization_members')
        .delete()
        .eq('id', memberId);

      if (error) throw error;

      await fetchMembers(currentOrg.id);
      toast.success('Member removed');
    } catch (error) {
      console.error('Error removing member:', error);
      toast.error('Failed to remove member');
    }
  };

  const isAdmin = currentUserRole === 'owner' || currentUserRole === 'admin';
  const isOwner = currentUserRole === 'owner';

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Organization Switcher */}
      <div className="rounded-xl border border-border bg-card p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-medium flex items-center gap-2">
            <Building2 className="h-4 w-4" />
            Organizations
          </h3>
          {organizations.length > 1 && currentOrg && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="gap-2">
                  {currentOrg.name}
                  <ChevronDown className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {organizations.map(org => (
                  <DropdownMenuItem
                    key={org.id}
                    onClick={() => switchOrganization(org)}
                    className="gap-2"
                  >
                    {org.id === currentOrg.id && <Check className="h-4 w-4" />}
                    {org.id !== currentOrg.id && <div className="w-4" />}
                    {org.name}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>

        {currentOrg ? (
          <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
            <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Building2 className="h-5 w-5 text-primary" />
            </div>
            <div className="flex-1">
              <p className="font-medium">{currentOrg.name}</p>
              <p className="text-xs text-muted-foreground">{members.length} member{members.length !== 1 ? 's' : ''}</p>
            </div>
            <Badge variant="outline" className={cn("gap-1", roleColors[currentUserRole || 'member'])}>
              {roleIcons[currentUserRole || 'member']}
              {currentUserRole}
            </Badge>
          </div>
        ) : (
          <div className="text-center py-4 text-muted-foreground">
            <p className="text-sm">No organization yet</p>
          </div>
        )}

        {/* Create new organization */}
        <div className="pt-4 border-t border-border space-y-3">
          <Label className="text-xs text-muted-foreground">Create new organization</Label>
          <div className="flex gap-2">
            <Input
              value={newOrgName}
              onChange={(e) => setNewOrgName(e.target.value)}
              placeholder="Organization name"
              className="flex-1"
            />
            <Button onClick={createOrganization} disabled={isCreatingOrg}>
              {isCreatingOrg ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Create'}
            </Button>
          </div>
        </div>
      </div>

      {/* Team Members */}
      {currentOrg && (
        <div className="rounded-xl border border-border bg-card p-6 space-y-4">
          <h3 className="font-medium flex items-center gap-2">
            <Users className="h-4 w-4" />
            Team Members
          </h3>

          <ScrollArea className="h-[200px]">
            <div className="space-y-2">
              {members.map(member => (
                <div key={member.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-3">
                    <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                      <User className="h-4 w-4 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm font-medium">{member.email}</p>
                      <p className="text-xs text-muted-foreground">
                        Joined {new Date(member.created_at).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {isOwner && member.role !== 'owner' && member.user_id !== currentUserId ? (
                      <Select
                        value={member.role}
                        onValueChange={(value: 'admin' | 'member') => updateMemberRole(member.id, value)}
                      >
                        <SelectTrigger className="w-24 h-8">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="admin">Admin</SelectItem>
                          <SelectItem value="member">Member</SelectItem>
                        </SelectContent>
                      </Select>
                    ) : (
                      <Badge variant="outline" className={cn("gap-1", roleColors[member.role])}>
                        {roleIcons[member.role]}
                        {member.role}
                      </Badge>
                    )}
                    {isOwner && member.role !== 'owner' && member.user_id !== currentUserId && (
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => removeMember(member.id, member.user_id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>

          {/* Invite Member */}
          {isAdmin && (
            <div className="pt-4 border-t border-border space-y-3">
              <Label className="text-xs text-muted-foreground flex items-center gap-1">
                <UserPlus className="h-3 w-3" />
                Invite team member
              </Label>
              <div className="flex gap-2">
                <Input
                  type="email"
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e.target.value)}
                  placeholder="Email address"
                  className="flex-1"
                />
                <Select value={inviteRole} onValueChange={(v: 'admin' | 'member') => setInviteRole(v)}>
                  <SelectTrigger className="w-24">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="admin">Admin</SelectItem>
                    <SelectItem value="member">Member</SelectItem>
                  </SelectContent>
                </Select>
                <Button onClick={inviteMember} disabled={isInviting}>
                  {isInviting ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Invite'}
                </Button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
