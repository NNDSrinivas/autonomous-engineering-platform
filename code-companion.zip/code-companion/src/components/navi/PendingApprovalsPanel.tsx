import { useApprovalGate } from '@/hooks/useApprovalGate';
import { ApprovalDialog } from './ApprovalDialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  Shield, 
  CheckCircle2, 
  XCircle,
  Clock,
  AlertTriangle,
  ChevronRight
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';
import { useState } from 'react';
import type { PendingAction, RiskLevel } from '@/hooks/useApprovalGate';

const riskColors: Record<RiskLevel, string> = {
  low: 'bg-status-success/20 text-status-success border-status-success/30',
  medium: 'bg-status-warning/20 text-status-warning border-status-warning/30',
  high: 'bg-status-error/20 text-status-error border-status-error/30',
  critical: 'bg-destructive/20 text-destructive border-destructive/30',
};

export function PendingApprovalsPanel() {
  const { pendingActions, approveAction, rejectAction, getActionLabel } = useApprovalGate();
  const [selectedAction, setSelectedAction] = useState<PendingAction | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  const handleOpenAction = (action: PendingAction) => {
    setSelectedAction(action);
    setDialogOpen(true);
  };

  const handleApprove = async (action: PendingAction) => {
    approveAction(action.id);
  };

  const handleReject = (action: PendingAction) => {
    rejectAction(action.id);
  };

  if (pendingActions.length === 0) {
    return (
      <div className="p-6 text-center space-y-3">
        <Shield className="h-12 w-12 mx-auto text-muted-foreground/50" />
        <div>
          <h3 className="font-medium">No Pending Approvals</h3>
          <p className="text-sm text-muted-foreground mt-1">
            All actions are up to date. New actions requiring approval will appear here.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between p-3 border-b border-border">
        <div className="flex items-center gap-2">
          <Shield className="h-4 w-4 text-primary" />
          <span className="font-medium text-sm">Pending Approvals</span>
          <Badge variant="outline" className="text-[10px]">
            {pendingActions.length}
          </Badge>
        </div>
        {pendingActions.length > 1 && (
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => pendingActions.forEach(a => rejectAction(a.id))}
              className="h-7 text-xs gap-1"
            >
              <XCircle className="h-3 w-3" />
              Reject All
            </Button>
          </div>
        )}
      </div>

      <ScrollArea className="flex-1">
        <div className="p-2 space-y-2">
          {pendingActions.map((action) => (
            <div
              key={action.id}
              className="p-3 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors space-y-2"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-sm truncate">
                      {getActionLabel(action.type)}
                    </span>
                    <Badge 
                      variant="outline" 
                      className={cn("text-[10px] uppercase flex-shrink-0", riskColors[action.risk])}
                    >
                      {action.risk}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1 truncate">
                    {action.title}
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <div className="flex items-center gap-1">
                  <Clock className="h-3 w-3" />
                  <span>{formatDistanceToNow(action.createdAt, { addSuffix: true })}</span>
                </div>
                {action.expiresAt && (
                  <div className="flex items-center gap-1">
                    <AlertTriangle className="h-3 w-3" />
                    <span>Expires {formatDistanceToNow(action.expiresAt, { addSuffix: true })}</span>
                  </div>
                )}
              </div>

              <div className="flex items-center gap-2 pt-1">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => handleReject(action)}
                  className="h-7 text-xs gap-1 flex-1"
                >
                  <XCircle className="h-3 w-3" />
                  Reject
                </Button>
                <Button
                  size="sm"
                  onClick={() => handleOpenAction(action)}
                  className="h-7 text-xs gap-1 flex-1"
                >
                  <CheckCircle2 className="h-3 w-3" />
                  Review
                  <ChevronRight className="h-3 w-3" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>

      <ApprovalDialog
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        action={selectedAction}
        onApprove={handleApprove}
        onReject={handleReject}
      />
    </div>
  );
}
