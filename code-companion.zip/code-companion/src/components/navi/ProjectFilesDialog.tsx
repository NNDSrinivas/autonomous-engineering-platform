import { useState, useMemo } from 'react';
import { 
  ChevronRight, 
  ChevronDown, 
  File, 
  Folder, 
  FolderOpen,
  FileCode,
  FileJson,
  FileText,
  Image,
  FileType,
  Search,
  Check,
  X
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';

interface FileItem {
  id: string;
  name: string;
  path: string;
  type: 'file' | 'folder';
  children?: FileItem[];
  language?: string;
}

// Mock file structure - in a real app this would come from an API
const mockFileTree: FileItem[] = [
  {
    id: 'src',
    name: 'src',
    path: 'src',
    type: 'folder',
    children: [
      {
        id: 'components',
        name: 'components',
        path: 'src/components',
        type: 'folder',
        children: [
          {
            id: 'navi',
            name: 'navi',
            path: 'src/components/navi',
            type: 'folder',
            children: [
              { id: 'NaviChat.tsx', name: 'NaviChat.tsx', path: 'src/components/navi/NaviChat.tsx', type: 'file', language: 'typescript' },
              { id: 'NaviHeader.tsx', name: 'NaviHeader.tsx', path: 'src/components/navi/NaviHeader.tsx', type: 'file', language: 'typescript' },
              { id: 'FileExplorer.tsx', name: 'FileExplorer.tsx', path: 'src/components/navi/FileExplorer.tsx', type: 'file', language: 'typescript' },
              { id: 'SettingsPanel.tsx', name: 'SettingsPanel.tsx', path: 'src/components/navi/SettingsPanel.tsx', type: 'file', language: 'typescript' },
              { id: 'IntegrationsSidebar.tsx', name: 'IntegrationsSidebar.tsx', path: 'src/components/navi/IntegrationsSidebar.tsx', type: 'file', language: 'typescript' },
            ]
          },
          {
            id: 'ui',
            name: 'ui',
            path: 'src/components/ui',
            type: 'folder',
            children: [
              { id: 'button.tsx', name: 'button.tsx', path: 'src/components/ui/button.tsx', type: 'file', language: 'typescript' },
              { id: 'input.tsx', name: 'input.tsx', path: 'src/components/ui/input.tsx', type: 'file', language: 'typescript' },
              { id: 'dialog.tsx', name: 'dialog.tsx', path: 'src/components/ui/dialog.tsx', type: 'file', language: 'typescript' },
            ]
          }
        ]
      },
      {
        id: 'hooks',
        name: 'hooks',
        path: 'src/hooks',
        type: 'folder',
        children: [
          { id: 'useNaviChat.ts', name: 'useNaviChat.ts', path: 'src/hooks/useNaviChat.ts', type: 'file', language: 'typescript' },
          { id: 'useTheme.ts', name: 'useTheme.ts', path: 'src/hooks/useTheme.ts', type: 'file', language: 'typescript' },
          { id: 'useSidebarPins.ts', name: 'useSidebarPins.ts', path: 'src/hooks/useSidebarPins.ts', type: 'file', language: 'typescript' },
        ]
      },
      {
        id: 'pages',
        name: 'pages',
        path: 'src/pages',
        type: 'folder',
        children: [
          { id: 'Index.tsx', name: 'Index.tsx', path: 'src/pages/Index.tsx', type: 'file', language: 'typescript' },
          { id: 'Auth.tsx', name: 'Auth.tsx', path: 'src/pages/Auth.tsx', type: 'file', language: 'typescript' },
        ]
      },
      { id: 'App.tsx', name: 'App.tsx', path: 'src/App.tsx', type: 'file', language: 'typescript' },
      { id: 'main.tsx', name: 'main.tsx', path: 'src/main.tsx', type: 'file', language: 'typescript' },
      { id: 'index.css', name: 'index.css', path: 'src/index.css', type: 'file', language: 'css' },
    ]
  },
  {
    id: 'public',
    name: 'public',
    path: 'public',
    type: 'folder',
    children: [
      { id: 'favicon.ico', name: 'favicon.ico', path: 'public/favicon.ico', type: 'file', language: 'image' },
      { id: 'robots.txt', name: 'robots.txt', path: 'public/robots.txt', type: 'file', language: 'text' },
    ]
  },
  { id: 'package.json', name: 'package.json', path: 'package.json', type: 'file', language: 'json' },
  { id: 'tsconfig.json', name: 'tsconfig.json', path: 'tsconfig.json', type: 'file', language: 'json' },
  { id: 'vite.config.ts', name: 'vite.config.ts', path: 'vite.config.ts', type: 'file', language: 'typescript' },
  { id: 'tailwind.config.ts', name: 'tailwind.config.ts', path: 'tailwind.config.ts', type: 'file', language: 'typescript' },
  { id: 'README.md', name: 'README.md', path: 'README.md', type: 'file', language: 'markdown' },
];

function getFileIcon(language?: string) {
  switch (language) {
    case 'typescript':
    case 'javascript':
      return <FileCode className="h-4 w-4 text-blue-400" />;
    case 'json':
      return <FileJson className="h-4 w-4 text-yellow-400" />;
    case 'css':
      return <FileCode className="h-4 w-4 text-purple-400" />;
    case 'markdown':
      return <FileText className="h-4 w-4 text-muted-foreground" />;
    case 'image':
      return <Image className="h-4 w-4 text-green-400" />;
    case 'text':
      return <FileType className="h-4 w-4 text-muted-foreground" />;
    default:
      return <File className="h-4 w-4 text-muted-foreground" />;
  }
}

interface FileTreeItemProps {
  item: FileItem;
  depth: number;
  selectedFiles: string[];
  onFileToggle: (path: string) => void;
  expandedFolders: Set<string>;
  onToggleFolder: (folderId: string) => void;
  searchQuery: string;
}

function FileTreeItem({ 
  item, 
  depth, 
  selectedFiles,
  onFileToggle,
  expandedFolders,
  onToggleFolder,
  searchQuery
}: FileTreeItemProps) {
  const isExpanded = expandedFolders.has(item.id);
  const isFolder = item.type === 'folder';
  const isSelected = selectedFiles.includes(item.path);
  
  // Filter logic for search
  const matchesSearch = searchQuery 
    ? item.name.toLowerCase().includes(searchQuery.toLowerCase())
    : true;
  
  // For folders, check if any child matches
  const hasMatchingChildren = useMemo(() => {
    if (!searchQuery || !item.children) return false;
    const checkChildren = (children: FileItem[]): boolean => {
      return children.some(child => {
        if (child.name.toLowerCase().includes(searchQuery.toLowerCase())) return true;
        if (child.children) return checkChildren(child.children);
        return false;
      });
    };
    return checkChildren(item.children);
  }, [item.children, searchQuery]);

  // Hide if doesn't match and no matching children
  if (searchQuery && !matchesSearch && !hasMatchingChildren && !isFolder) {
    return null;
  }

  const handleClick = () => {
    if (isFolder) {
      onToggleFolder(item.id);
    } else {
      onFileToggle(item.path);
    }
  };

  return (
    <div>
      <button
        onClick={handleClick}
        className={cn(
          "w-full flex items-center gap-1.5 px-2 py-1.5 text-xs rounded-md transition-colors text-left",
          "hover:bg-secondary/50",
          isSelected && "bg-primary/10 text-primary ring-1 ring-primary/30"
        )}
        style={{ paddingLeft: `${depth * 12 + 8}px` }}
      >
        {isFolder ? (
          <>
            {isExpanded ? (
              <ChevronDown className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />
            ) : (
              <ChevronRight className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />
            )}
            {isExpanded ? (
              <FolderOpen className="h-4 w-4 text-amber-400 flex-shrink-0" />
            ) : (
              <Folder className="h-4 w-4 text-amber-400 flex-shrink-0" />
            )}
          </>
        ) : (
          <>
            {isSelected ? (
              <Check className="h-3.5 w-3.5 text-primary flex-shrink-0" />
            ) : (
              <span className="w-3.5" />
            )}
            {getFileIcon(item.language)}
          </>
        )}
        <span className="truncate flex-1">{item.name}</span>
        {isSelected && (
          <Badge variant="secondary" className="h-5 text-[10px]">Selected</Badge>
        )}
      </button>
      
      {isFolder && (isExpanded || (searchQuery && hasMatchingChildren)) && item.children && (
        <div className="animate-fade-in">
          {item.children.map((child) => (
            <FileTreeItem
              key={child.id}
              item={child}
              depth={depth + 1}
              selectedFiles={selectedFiles}
              onFileToggle={onFileToggle}
              expandedFolders={expandedFolders}
              onToggleFolder={onToggleFolder}
              searchQuery={searchQuery}
            />
          ))}
        </div>
      )}
    </div>
  );
}

interface ProjectFilesDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onFilesSelect: (files: { name: string; path: string }[]) => void;
}

export function ProjectFilesDialog({ open, onOpenChange, onFilesSelect }: ProjectFilesDialogProps) {
  const [selectedFiles, setSelectedFiles] = useState<string[]>([]);
  const [expandedFolders, setExpandedFolders] = useState<Set<string>>(new Set(['src', 'components', 'navi']));
  const [searchQuery, setSearchQuery] = useState('');

  const handleFileToggle = (path: string) => {
    setSelectedFiles(prev => {
      if (prev.includes(path)) {
        return prev.filter(p => p !== path);
      }
      return [...prev, path];
    });
  };

  const handleToggleFolder = (folderId: string) => {
    setExpandedFolders(prev => {
      const next = new Set(prev);
      if (next.has(folderId)) {
        next.delete(folderId);
      } else {
        next.add(folderId);
      }
      return next;
    });
  };

  const handleAttach = () => {
    const files = selectedFiles.map(path => ({
      name: path.split('/').pop() || path,
      path
    }));
    onFilesSelect(files);
    setSelectedFiles([]);
    setSearchQuery('');
    onOpenChange(false);
  };

  const handleClear = () => {
    setSelectedFiles([]);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FolderOpen className="h-5 w-5 text-primary" />
            Attach Project Files
          </DialogTitle>
        </DialogHeader>

        <div className="relative mb-3">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search files..."
            className="pl-9"
          />
        </div>

        {selectedFiles.length > 0 && (
          <div className="flex items-center gap-2 mb-3 flex-wrap">
            <span className="text-xs text-muted-foreground">Selected:</span>
            {selectedFiles.map(path => (
              <Badge 
                key={path} 
                variant="secondary" 
                className="gap-1 cursor-pointer hover:bg-destructive/20"
                onClick={() => handleFileToggle(path)}
              >
                {path.split('/').pop()}
                <X className="h-3 w-3" />
              </Badge>
            ))}
            <Button variant="ghost" size="sm" onClick={handleClear} className="h-6 text-xs">
              Clear all
            </Button>
          </div>
        )}

        <ScrollArea className="flex-1 min-h-[300px] border rounded-lg">
          <div className="py-2">
            {mockFileTree.map((item) => (
              <FileTreeItem
                key={item.id}
                item={item}
                depth={0}
                selectedFiles={selectedFiles}
                onFileToggle={handleFileToggle}
                expandedFolders={expandedFolders}
                onToggleFolder={handleToggleFolder}
                searchQuery={searchQuery}
              />
            ))}
          </div>
        </ScrollArea>

        <DialogFooter className="mt-4">
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleAttach} disabled={selectedFiles.length === 0}>
            <FileCode className="h-4 w-4 mr-2" />
            Attach {selectedFiles.length > 0 ? `(${selectedFiles.length})` : ''}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
