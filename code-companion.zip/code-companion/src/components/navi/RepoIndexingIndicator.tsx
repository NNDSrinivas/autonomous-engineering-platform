import { useState } from 'react';
import { 
  Database, 
  RefreshCw, 
  Check, 
  AlertCircle, 
  ChevronDown, 
  ChevronUp,
  FileCode,
  Folder,
  Clock
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { HoverCard, HoverCardContent, HoverCardTrigger } from '@/components/ui/hover-card';
import { cn } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';

interface RepoIndex {
  owner: string;
  repo: string;
  branch: string;
  totalFiles: number;
  lastFullScan: string;
  files?: Array<{ path: string; language?: string }>;
}

interface RepoIndexingIndicatorProps {
  isIndexing: boolean;
  indexProgress: number;
  repoIndex: RepoIndex | null;
  onRefresh?: () => void;
  isCollapsed?: boolean;
}

export function RepoIndexingIndicator({
  isIndexing,
  indexProgress,
  repoIndex,
  onRefresh,
  isCollapsed = false,
}: RepoIndexingIndicatorProps) {
  const [expanded, setExpanded] = useState(false);

  // Compute file type stats
  const fileTypeStats = repoIndex?.files?.reduce((acc, file) => {
    const lang = file.language || 'other';
    acc[lang] = (acc[lang] || 0) + 1;
    return acc;
  }, {} as Record<string, number>) || {};

  const topLanguages = Object.entries(fileTypeStats)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5);

  if (isCollapsed) {
    return null;
  }

  // Indexing in progress
  if (isIndexing) {
    return (
      <div className="px-2 py-2">
        <div className="bg-primary/10 rounded-lg p-2 border border-primary/20">
          <div className="flex items-center gap-2 mb-2">
            <RefreshCw className="h-4 w-4 text-primary animate-spin" />
            <span className="text-xs font-medium text-primary">Indexing...</span>
          </div>
          <Progress value={indexProgress} className="h-1.5" />
          <div className="flex justify-between mt-1">
            <span className="text-[10px] text-muted-foreground">Scanning files</span>
            <span className="text-[10px] text-primary font-medium">{indexProgress}%</span>
          </div>
        </div>
      </div>
    );
  }

  // No index available
  if (!repoIndex) {
    return (
      <div className="px-2 py-2">
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="w-full h-9 justify-start gap-2 text-muted-foreground hover:text-foreground"
              onClick={onRefresh}
            >
              <Database className="h-4 w-4" />
              <span className="text-xs">Index Repository</span>
            </Button>
          </TooltipTrigger>
          <TooltipContent side="right">
            Scan and index repository for faster context retrieval
          </TooltipContent>
        </Tooltip>
      </div>
    );
  }

  // Index available - show status
  const lastScanDate = new Date(repoIndex.lastFullScan);
  const isStale = Date.now() - lastScanDate.getTime() > 24 * 60 * 60 * 1000; // 24 hours

  return (
    <div className="px-2 py-2">
      <HoverCard openDelay={200}>
        <HoverCardTrigger asChild>
          <button
            className={cn(
              "w-full rounded-lg p-2 text-left transition-all",
              "bg-secondary/50 hover:bg-secondary/80 border border-border/50",
              expanded && "bg-secondary"
            )}
            onClick={() => setExpanded(!expanded)}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className={cn(
                  "h-6 w-6 rounded-md flex items-center justify-center",
                  isStale ? "bg-yellow-500/20" : "bg-green-500/20"
                )}>
                  {isStale ? (
                    <AlertCircle className="h-3.5 w-3.5 text-yellow-400" />
                  ) : (
                    <Check className="h-3.5 w-3.5 text-green-400" />
                  )}
                </div>
                <div className="flex flex-col">
                  <span className="text-xs font-medium truncate max-w-[100px]">
                    {repoIndex.repo}
                  </span>
                  <span className="text-[10px] text-muted-foreground">
                    {repoIndex.totalFiles} files indexed
                  </span>
                </div>
              </div>
              {expanded ? (
                <ChevronUp className="h-4 w-4 text-muted-foreground" />
              ) : (
                <ChevronDown className="h-4 w-4 text-muted-foreground" />
              )}
            </div>

            {/* Expanded Details */}
            {expanded && (
              <div className="mt-3 pt-3 border-t border-border/50 space-y-2">
                {/* Last Scan */}
                <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
                  <Clock className="h-3 w-3" />
                  <span>
                    Last scan: {formatDistanceToNow(lastScanDate, { addSuffix: true })}
                  </span>
                </div>

                {/* Language Breakdown */}
                {topLanguages.length > 0 && (
                  <div className="space-y-1">
                    <span className="text-[10px] text-muted-foreground">Languages:</span>
                    <div className="flex flex-wrap gap-1">
                      {topLanguages.map(([lang, count]) => (
                        <Badge
                          key={lang}
                          variant="secondary"
                          className="text-[9px] px-1.5 py-0 h-4"
                        >
                          {lang}: {count}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Refresh Button */}
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full h-7 text-xs mt-2"
                  onClick={(e) => {
                    e.stopPropagation();
                    onRefresh?.();
                  }}
                >
                  <RefreshCw className="h-3 w-3 mr-1" />
                  Re-scan Repository
                </Button>
              </div>
            )}
          </button>
        </HoverCardTrigger>
        
        <HoverCardContent side="right" align="start" className="w-64 p-0">
          <div className="p-3 border-b border-border">
            <div className="flex items-center gap-2">
              <Database className="h-4 w-4 text-primary" />
              <span className="font-semibold text-sm">Repository Index</span>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {repoIndex.owner}/{repoIndex.repo}
            </p>
          </div>
          <div className="p-3 space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-muted-foreground">Files Indexed</span>
              <span className="font-medium">{repoIndex.totalFiles}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-muted-foreground">Branch</span>
              <span className="font-medium">{repoIndex.branch}</span>
            </div>
            <div className="flex justify-between text-xs">
              <span className="text-muted-foreground">Last Updated</span>
              <span className="font-medium">
                {formatDistanceToNow(lastScanDate, { addSuffix: true })}
              </span>
            </div>
            {isStale && (
              <div className="pt-2 border-t border-border">
                <p className="text-[10px] text-yellow-400">
                  Index is more than 24 hours old. Consider refreshing.
                </p>
              </div>
            )}
          </div>
        </HoverCardContent>
      </HoverCard>
    </div>
  );
}
