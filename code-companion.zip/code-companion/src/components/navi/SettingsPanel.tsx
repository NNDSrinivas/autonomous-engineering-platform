import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';
import { 
  User, 
  Bell, 
  Clock, 
  RefreshCw, 
  CheckCircle2, 
  XCircle, 
  Loader2,
  LogOut,
  Save,
  Plug,
  Building2,
  Palette,
  Brain,
  Sparkles,
  BarChart3,
  Users,
  Volume2,
  ShieldCheck,
  LayoutPanelLeft,
  Key
} from 'lucide-react';
import { FeedbackAnalyticsDashboard } from './FeedbackAnalyticsDashboard';
import { AdminRoleManager } from './AdminRoleManager';
import { useIntegrations } from '@/hooks/useIntegrations';
import { useMemory } from '@/hooks/useMemory';
import { cn } from '@/lib/utils';
import { ConnectorsTab } from './ConnectorsTab';
import { OrganizationTab } from './OrganizationTab';
import { ThemeToggle } from './ThemeToggle';
import { ApprovalSettingsPanel } from './ApprovalSettingsPanel';
import { SidebarCustomization } from './SidebarCustomization';
import { useNotificationSoundPreference, useNotificationSound, SOUND_OPTIONS, SoundType } from '@/hooks/useNotificationSound';

const LLM_MODELS = [
  { value: 'google/gemini-2.5-flash', label: 'Gemini 2.5 Flash', description: 'Fast & balanced' },
  { value: 'google/gemini-2.5-pro', label: 'Gemini 2.5 Pro', description: 'Best reasoning' },
  { value: 'google/gemini-2.5-flash-lite', label: 'Gemini 2.5 Flash Lite', description: 'Fastest' },
  { value: 'openai/gpt-5', label: 'GPT-5', description: 'Most capable' },
  { value: 'openai/gpt-5-mini', label: 'GPT-5 Mini', description: 'Cost effective' },
  { value: 'openai/gpt-5-nano', label: 'GPT-5 Nano', description: 'Ultra fast' },
];

interface Profile {
  display_name: string | null;
  timezone: string;
  theme: string;
  notification_preferences: {
    email_notifications: boolean;
    push_notifications: boolean;
    integration_alerts: boolean;
    daily_digest: boolean;
    weekly_summary: boolean;
    in_app_toasts: boolean;
    toast_important_only: boolean;
  };
}

interface SyncHistoryItem {
  id: string;
  provider: string;
  sync_type: string;
  status: string;
  items_synced: number;
  error_message: string | null;
  started_at: string;
  completed_at: string | null;
}

const timezones = [
  'UTC',
  'America/New_York',
  'America/Los_Angeles',
  'America/Chicago',
  'Europe/London',
  'Europe/Paris',
  'Europe/Berlin',
  'Asia/Tokyo',
  'Asia/Shanghai',
  'Asia/Singapore',
  'Australia/Sydney',
];

export function SettingsPanel() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [syncHistory, setSyncHistory] = useState<SyncHistoryItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [defaultModel, setDefaultModel] = useState('google/gemini-2.5-flash');
  const [isSyncingToMemory, setIsSyncingToMemory] = useState(false);
  const { integrations, disconnect, refresh: refreshIntegrations } = useIntegrations();
  const { setPreference, getPreferences } = useMemory();
  const { soundEnabled, toggleSound, soundType, changeSoundType, volume, changeVolume } = useNotificationSoundPreference();
  const { playPreview } = useNotificationSound(0, false, soundType, volume);

  useEffect(() => {
    fetchProfile();
    fetchSyncHistory();
    loadMemoryPreferences();
  }, []);

  const loadMemoryPreferences = async () => {
    try {
      const prefs = await getPreferences();
      if (prefs?.llm_preferences?.default_model) {
        setDefaultModel(prefs.llm_preferences.default_model);
      }
    } catch (error) {
      console.error('Error loading memory preferences:', error);
    }
  };

  const fetchProfile = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', session.user.id)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching profile:', error);
        return;
      }

      if (data) {
        const notifPrefs = data.notification_preferences as Profile['notification_preferences'] | null;
        setProfile({
          display_name: data.display_name,
          timezone: data.timezone || 'UTC',
          theme: data.theme || 'dark',
          notification_preferences: {
            email_notifications: notifPrefs?.email_notifications ?? true,
            push_notifications: notifPrefs?.push_notifications ?? true,
            integration_alerts: notifPrefs?.integration_alerts ?? true,
            daily_digest: notifPrefs?.daily_digest ?? false,
            weekly_summary: notifPrefs?.weekly_summary ?? true,
            in_app_toasts: notifPrefs?.in_app_toasts ?? true,
            toast_important_only: notifPrefs?.toast_important_only ?? false,
          },
        });
      }
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchSyncHistory = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const { data, error } = await supabase
        .from('sync_history')
        .select('*')
        .eq('user_id', session.user.id)
        .order('started_at', { ascending: false })
        .limit(20);

      if (error) {
        console.error('Error fetching sync history:', error);
        return;
      }

      setSyncHistory(data || []);
    } catch (error) {
      console.error('Error:', error);
    }
  };

  const saveProfile = async () => {
    if (!profile) return;

    setIsSaving(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error('Please sign in to save settings');
        return;
      }

      const { error } = await supabase
        .from('profiles')
        .update({
          display_name: profile.display_name,
          timezone: profile.timezone,
          theme: profile.theme,
          notification_preferences: profile.notification_preferences,
        })
        .eq('user_id', session.user.id);

      if (error) {
        toast.error('Failed to save settings');
        console.error('Save error:', error);
      } else {
        toast.success('Settings saved successfully');
      }
    } catch (error) {
      toast.error('An error occurred');
    } finally {
      setIsSaving(false);
    }
  };

  const syncPreferencesToMemory = async () => {
    setIsSyncingToMemory(true);
    try {
      await setPreference('llm_preferences', { default_model: defaultModel });
      await setPreference('ui_preferences', { theme: profile?.theme || 'dark' });
      await setPreference('timezone', profile?.timezone || 'UTC');
      await setPreference('notification_preferences', profile?.notification_preferences);
      await setPreference('display_name', profile?.display_name);
      toast.success('Preferences synced to memory engine');
    } catch (error) {
      console.error('Error syncing to memory:', error);
      toast.error('Failed to sync preferences');
    } finally {
      setIsSyncingToMemory(false);
    }
  };

  const handleModelChange = async (model: string) => {
    setDefaultModel(model);
    try {
      await setPreference('llm_preferences', { default_model: model });
      toast.success('Default model updated');
    } catch (error) {
      console.error('Error saving model preference:', error);
    }
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    toast.success('Signed out successfully');
  };

  const updateNotificationPref = (key: keyof Profile['notification_preferences'], value: boolean) => {
    if (!profile) return;
    setProfile({
      ...profile,
      notification_preferences: {
        ...profile.notification_preferences,
        [key]: value,
      },
    });
  };

  if (isLoading) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <ScrollArea className="flex-1 h-full">
      <div className="p-6">
        <div className="max-w-3xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-lg font-semibold">Settings</h2>
            <p className="text-sm text-muted-foreground">Manage your account and preferences</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={handleSignOut}>
              <LogOut className="h-4 w-4 mr-2" />
              Sign Out
            </Button>
            <Button size="sm" onClick={saveProfile} disabled={isSaving}>
              {isSaving ? (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              ) : (
                <Save className="h-4 w-4 mr-2" />
              )}
              Save Changes
            </Button>
          </div>
        </div>

        <Tabs defaultValue="profile" className="space-y-6">
          <TabsList className="flex-wrap h-auto gap-1">
            <TabsTrigger value="profile" className="gap-2">
              <User className="h-4 w-4" />
              Profile
            </TabsTrigger>
            <TabsTrigger value="sidebar" className="gap-2">
              <LayoutPanelLeft className="h-4 w-4" />
              Sidebar
            </TabsTrigger>
            <TabsTrigger value="notifications" className="gap-2">
              <Bell className="h-4 w-4" />
              Notifications
            </TabsTrigger>
            <TabsTrigger value="integrations" className="gap-2">
              <RefreshCw className="h-4 w-4" />
              Integrations
            </TabsTrigger>
            <TabsTrigger value="connectors" className="gap-2">
              <Plug className="h-4 w-4" />
              Connectors
            </TabsTrigger>
            <TabsTrigger value="organization" className="gap-2">
              <Building2 className="h-4 w-4" />
              Organization
            </TabsTrigger>
            <TabsTrigger value="sync" className="gap-2">
              <Clock className="h-4 w-4" />
              Sync History
            </TabsTrigger>
            <TabsTrigger value="analytics" className="gap-2">
              <BarChart3 className="h-4 w-4" />
              Analytics
            </TabsTrigger>
            <TabsTrigger value="admins" className="gap-2">
              <Users className="h-4 w-4" />
              Admins
            </TabsTrigger>
            <TabsTrigger value="approvals" className="gap-2">
              <ShieldCheck className="h-4 w-4" />
              Approvals
            </TabsTrigger>
          </TabsList>

          <TabsContent value="sidebar">
            <div className="rounded-xl border border-border bg-card p-6">
              <SidebarCustomization />
            </div>
          </TabsContent>

          <TabsContent value="profile" className="space-y-6">
            <div className="rounded-xl border border-border bg-card p-6 space-y-4">
              <h3 className="font-medium flex items-center gap-2">
                <User className="h-4 w-4" />
                Profile Information
              </h3>
              <div className="grid gap-4">
                <div className="space-y-2">
                  <Label>Display Name</Label>
                  <Input
                    value={profile?.display_name || ''}
                    onChange={(e) => setProfile(prev => prev ? { ...prev, display_name: e.target.value } : null)}
                    placeholder="Your name"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Timezone</Label>
                  <Select
                    value={profile?.timezone}
                    onValueChange={(value) => setProfile(prev => prev ? { ...prev, timezone: value } : null)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {timezones.map(tz => (
                        <SelectItem key={tz} value={tz}>{tz}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    <Palette className="h-4 w-4" />
                    Theme
                  </Label>
                  <p className="text-xs text-muted-foreground mb-3">Choose your preferred color scheme</p>
                  <ThemeToggle />
                </div>
              </div>
            </div>

            {/* AI Preferences */}
            <div className="rounded-xl border border-border bg-card p-6 space-y-4">
              <h3 className="font-medium flex items-center gap-2">
                <Sparkles className="h-4 w-4" />
                AI Preferences
              </h3>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label>Default LLM Model</Label>
                  <p className="text-xs text-muted-foreground">Choose your preferred AI model for NAVI</p>
                  <Select value={defaultModel} onValueChange={handleModelChange}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {LLM_MODELS.map(model => (
                        <SelectItem key={model.value} value={model.value}>
                          <div className="flex items-center gap-2">
                            <span>{model.label}</span>
                            <span className="text-xs text-muted-foreground">- {model.description}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* BYOK - Bring Your Own Key */}
            <div className="rounded-xl border border-amber-500/20 bg-amber-500/5 p-6 space-y-4">
              <h3 className="font-medium flex items-center gap-2">
                <Key className="h-4 w-4 text-amber-500" />
                Bring Your Own Key (BYOK)
              </h3>
              <p className="text-sm text-muted-foreground">
                Use your own API keys for LLM providers. Keys are encrypted and stored securely.
              </p>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="openai-key" className="flex items-center gap-2">
                    <span className="h-4 w-4 rounded bg-emerald-500/20 flex items-center justify-center text-[8px] font-bold text-emerald-400">O</span>
                    OpenAI API Key
                  </Label>
                  <Input
                    id="openai-key"
                    type="password"
                    placeholder="sk-..."
                    className="font-mono text-xs"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="anthropic-key" className="flex items-center gap-2">
                    <span className="h-4 w-4 rounded bg-orange-500/20 flex items-center justify-center text-[8px] font-bold text-orange-400">A</span>
                    Anthropic API Key
                  </Label>
                  <Input
                    id="anthropic-key"
                    type="password"
                    placeholder="sk-ant-..."
                    className="font-mono text-xs"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="google-key" className="flex items-center gap-2">
                    <span className="h-4 w-4 rounded bg-blue-500/20 flex items-center justify-center text-[8px] font-bold text-blue-400">G</span>
                    Google AI API Key
                  </Label>
                  <Input
                    id="google-key"
                    type="password"
                    placeholder="AIza..."
                    className="font-mono text-xs"
                  />
                </div>
                <Button variant="outline" className="w-full">
                  <Save className="h-4 w-4 mr-2" />
                  Save API Keys
                </Button>
              </div>
              <p className="text-[10px] text-muted-foreground/70">
                Note: Using your own keys bypasses Lovable AI usage limits. Keys are encrypted at rest.
              </p>
            </div>

            {/* Memory Engine Sync */}
            <div className="rounded-xl border border-primary/20 bg-primary/5 p-6 space-y-4">
              <h3 className="font-medium flex items-center gap-2">
                <Brain className="h-4 w-4 text-primary" />
                Memory Engine
              </h3>
              <p className="text-sm text-muted-foreground">
                Sync your preferences to the memory engine so NAVI remembers them across sessions.
              </p>
              <Button 
                onClick={syncPreferencesToMemory} 
                disabled={isSyncingToMemory}
                variant="outline"
                className="w-full"
              >
                {isSyncingToMemory ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Brain className="h-4 w-4 mr-2" />
                )}
                Sync Preferences to Memory
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="notifications" className="space-y-6">
            <div className="rounded-xl border border-border bg-card p-6 space-y-4">
              <h3 className="font-medium flex items-center gap-2">
                <Bell className="h-4 w-4" />
                Notification Preferences
              </h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Notification Sound</Label>
                    <p className="text-xs text-muted-foreground">Play a sound when new notifications arrive</p>
                  </div>
                  <Switch
                    checked={soundEnabled}
                    onCheckedChange={toggleSound}
                  />
                </div>
                {soundEnabled && (
                  <div className="space-y-4 pl-4 border-l-2 border-primary/20">
                    <div className="flex items-center justify-between">
                      <div>
                        <Label className="flex items-center gap-2">
                          <Volume2 className="h-3.5 w-3.5" />
                          Sound Type
                        </Label>
                        <p className="text-xs text-muted-foreground">Choose your preferred notification sound</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Select
                          value={soundType}
                          onValueChange={(value) => {
                            changeSoundType(value as SoundType);
                            playPreview(value as SoundType);
                          }}
                        >
                          <SelectTrigger className="w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {SOUND_OPTIONS.map(option => (
                              <SelectItem key={option.value} value={option.value}>
                                <div className="flex flex-col">
                                  <span>{option.label}</span>
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8"
                          onClick={() => playPreview(soundType)}
                        >
                          <Volume2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <Label>Volume</Label>
                        <p className="text-xs text-muted-foreground">Adjust notification sound volume</p>
                      </div>
                      <div className="flex items-center gap-3 w-40">
                        <span className="text-xs text-muted-foreground">{Math.round(volume * 100)}%</span>
                        <input
                          type="range"
                          min="0"
                          max="100"
                          value={volume * 100}
                          onChange={(e) => {
                            const newVolume = parseInt(e.target.value) / 100;
                            changeVolume(newVolume);
                          }}
                          onMouseUp={() => playPreview(soundType)}
                          onTouchEnd={() => playPreview(soundType)}
                          className="w-full h-2 bg-secondary rounded-lg appearance-none cursor-pointer accent-primary"
                        />
                      </div>
                    </div>
                  </div>
                )}
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Email Notifications</Label>
                    <p className="text-xs text-muted-foreground">Receive notifications via email</p>
                  </div>
                  <Switch
                    checked={profile?.notification_preferences.email_notifications}
                    onCheckedChange={(checked) => updateNotificationPref('email_notifications', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Push Notifications</Label>
                    <p className="text-xs text-muted-foreground">Browser push notifications</p>
                  </div>
                  <Switch
                    checked={profile?.notification_preferences.push_notifications}
                    onCheckedChange={(checked) => updateNotificationPref('push_notifications', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Integration Alerts</Label>
                    <p className="text-xs text-muted-foreground">Alerts when integrations need attention</p>
                  </div>
                  <Switch
                    checked={profile?.notification_preferences.integration_alerts}
                    onCheckedChange={(checked) => updateNotificationPref('integration_alerts', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Daily Digest</Label>
                    <p className="text-xs text-muted-foreground">Summary of daily activity</p>
                  </div>
                  <Switch
                    checked={profile?.notification_preferences.daily_digest}
                    onCheckedChange={(checked) => updateNotificationPref('daily_digest', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Weekly Summary</Label>
                    <p className="text-xs text-muted-foreground">Weekly productivity insights</p>
                  </div>
                  <Switch
                    checked={profile?.notification_preferences.weekly_summary}
                    onCheckedChange={(checked) => updateNotificationPref('weekly_summary', checked)}
                  />
                </div>
              </div>
            </div>

            {/* In-App Toast Settings */}
            <div className="rounded-xl border border-border bg-card p-6 space-y-4">
              <h3 className="font-medium flex items-center gap-2">
                <Bell className="h-4 w-4" />
                In-App Toast Notifications
              </h3>
              <p className="text-sm text-muted-foreground">
                Control toast popups that appear in the bottom of the screen
              </p>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Enable Toast Notifications</Label>
                    <p className="text-xs text-muted-foreground">Show toast popups for events</p>
                  </div>
                  <Switch
                    checked={profile?.notification_preferences.in_app_toasts ?? true}
                    onCheckedChange={(checked) => updateNotificationPref('in_app_toasts', checked)}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Important Events Only</Label>
                    <p className="text-xs text-muted-foreground">
                      Only show toasts for errors and critical actions (hide success/info toasts)
                    </p>
                  </div>
                  <Switch
                    checked={profile?.notification_preferences.toast_important_only ?? false}
                    onCheckedChange={(checked) => updateNotificationPref('toast_important_only', checked)}
                    disabled={!profile?.notification_preferences.in_app_toasts}
                  />
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="integrations" className="space-y-6">
            <div className="rounded-xl border border-border bg-card p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-medium flex items-center gap-2">
                  <RefreshCw className="h-4 w-4" />
                  Connected Integrations
                </h3>
                <Button variant="ghost" size="sm" onClick={refreshIntegrations}>
                  <RefreshCw className="h-4 w-4" />
                </Button>
              </div>
              <div className="space-y-3">
                {integrations.map(integration => (
                  <div key={integration.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                    <div className="flex items-center gap-3">
                      <div className={cn(
                        "h-2 w-2 rounded-full",
                        integration.status === 'connected' ? 'bg-green-400' : 'bg-muted-foreground'
                      )} />
                      <div>
                        <p className="text-sm font-medium">{integration.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {integration.status === 'connected' 
                            ? `Connected${integration.displayName ? ` as ${integration.displayName}` : ''}`
                            : 'Not connected'
                          }
                        </p>
                      </div>
                    </div>
                    {integration.status === 'connected' && (
                      <Button 
                        variant="ghost" 
                        size="sm"
                        onClick={() => disconnect(integration.type)}
                      >
                        Disconnect
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="connectors">
            <ConnectorsTab />
          </TabsContent>

          <TabsContent value="organization">
            <OrganizationTab />
          </TabsContent>

          <TabsContent value="sync" className="space-y-6">
            <div className="rounded-xl border border-border bg-card p-6 space-y-4">
              <h3 className="font-medium flex items-center gap-2">
                <Clock className="h-4 w-4" />
                Sync History
              </h3>
              <ScrollArea className="h-[400px]">
                {syncHistory.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <Clock className="h-8 w-8 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">No sync history yet</p>
                    <p className="text-xs">Syncs will appear here once integrations are connected</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {syncHistory.map(item => (
                      <div key={item.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                        <div className="flex items-center gap-3">
                          {item.status === 'completed' ? (
                            <CheckCircle2 className="h-4 w-4 text-green-400" />
                          ) : item.status === 'failed' ? (
                            <XCircle className="h-4 w-4 text-red-400" />
                          ) : (
                            <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                          )}
                          <div>
                            <p className="text-sm font-medium capitalize">{item.provider}</p>
                            <p className="text-xs text-muted-foreground">
                              {new Date(item.started_at).toLocaleString()}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge variant={item.status === 'completed' ? 'default' : item.status === 'failed' ? 'destructive' : 'secondary'}>
                            {item.status}
                          </Badge>
                          {item.items_synced > 0 && (
                            <p className="text-xs text-muted-foreground mt-1">
                              {item.items_synced} items
                            </p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <FeedbackAnalyticsDashboard />
          </TabsContent>

          <TabsContent value="admins" className="space-y-6">
            <AdminRoleManager />
          </TabsContent>

          <TabsContent value="approvals" className="space-y-6">
            <ApprovalSettingsPanel />
          </TabsContent>
        </Tabs>
        </div>
      </div>
    </ScrollArea>
  );
}
