import { 
  Pin, 
  PinOff, 
  RotateCcw,
  Sun,
  FolderTree,
  LayoutGrid,
  Search,
  Activity,
  Play,
  Zap,
  ListOrdered,
  BarChart3,
  ClipboardList,
  Calendar,
  Github,
  MessageSquare,
  Users,
  Video,
  FileText,
  Brain,
  GripVertical
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useSidebarPins, ALL_SIDEBAR_ITEMS, type SidebarItemId } from '@/hooks/useSidebarPins';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

const ICON_MAP: Record<string, React.ReactNode> = {
  Sun: <Sun className="h-4 w-4" />,
  FolderTree: <FolderTree className="h-4 w-4" />,
  LayoutGrid: <LayoutGrid className="h-4 w-4" />,
  Search: <Search className="h-4 w-4" />,
  Activity: <Activity className="h-4 w-4" />,
  Play: <Play className="h-4 w-4" />,
  Zap: <Zap className="h-4 w-4" />,
  ListOrdered: <ListOrdered className="h-4 w-4" />,
  BarChart3: <BarChart3 className="h-4 w-4" />,
  ClipboardList: <ClipboardList className="h-4 w-4" />,
  Calendar: <Calendar className="h-4 w-4" />,
  Github: <Github className="h-4 w-4" />,
  MessageSquare: <MessageSquare className="h-4 w-4" />,
  Users: <Users className="h-4 w-4" />,
  Video: <Video className="h-4 w-4" />,
  FileText: <FileText className="h-4 w-4" />,
  Brain: <Brain className="h-4 w-4" />,
};

interface SortableItemProps {
  item: typeof ALL_SIDEBAR_ITEMS[number];
  isPinned: boolean;
  onToggle: () => void;
}

function SortableItem({ item, isPinned, onToggle }: SortableItemProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: item.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  return (
    <div 
      ref={setNodeRef}
      style={style}
      className={cn(
        "flex items-center justify-between p-3 rounded-lg border transition-all",
        isPinned 
          ? "bg-primary/5 border-primary/20" 
          : "bg-card border-border hover:border-muted-foreground/30",
        isDragging && "opacity-50 shadow-lg z-50"
      )}
    >
      {/* Drag handle */}
      <button
        {...attributes}
        {...listeners}
        className="p-1 -ml-1 mr-2 text-muted-foreground hover:text-foreground cursor-grab active:cursor-grabbing"
      >
        <GripVertical className="h-4 w-4" />
      </button>
      
      <div className="flex items-center gap-3 flex-1">
        <div className={cn(
          "h-8 w-8 rounded-lg flex items-center justify-center",
          isPinned ? "bg-primary/10 text-primary" : "bg-secondary text-muted-foreground"
        )}>
          {ICON_MAP[item.icon]}
        </div>
        <div>
          <span className="text-sm font-medium">{item.name}</span>
          {item.defaultPinned && (
            <span className="ml-2 text-[10px] text-muted-foreground">(default)</span>
          )}
        </div>
      </div>
      <div className="flex items-center gap-2">
        {isPinned ? (
          <Pin className="h-3.5 w-3.5 text-primary" />
        ) : (
          <PinOff className="h-3.5 w-3.5 text-muted-foreground" />
        )}
        <Switch
          checked={isPinned}
          onCheckedChange={onToggle}
        />
      </div>
    </div>
  );
}

export function SidebarCustomization() {
  const { isPinned, togglePin, resetToDefaults, itemOrder, reorderItems, pinnedItems } = useSidebarPins();

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const handleToggle = (itemId: SidebarItemId) => {
    togglePin(itemId);
    const item = ALL_SIDEBAR_ITEMS.find(i => i.id === itemId);
    const wasPinned = isPinned(itemId);
    toast.success(wasPinned ? `Unpinned ${item?.name}` : `Pinned ${item?.name} to sidebar`);
  };

  const handleReset = () => {
    resetToDefaults();
    toast.success('Sidebar reset to defaults');
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    
    if (over && active.id !== over.id) {
      const oldIndex = itemOrder.indexOf(active.id as SidebarItemId);
      const newIndex = itemOrder.indexOf(over.id as SidebarItemId);
      const newOrder = arrayMove(itemOrder, oldIndex, newIndex);
      reorderItems(newOrder);
      toast.success('Sidebar order updated');
    }
  };

  // Get items in the current order
  const orderedItems = itemOrder
    .map(id => ALL_SIDEBAR_ITEMS.find(item => item.id === id)!)
    .filter(Boolean);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="font-medium flex items-center gap-2">
            <Pin className="h-4 w-4" />
            Sidebar Customization
          </h3>
          <p className="text-xs text-muted-foreground mt-1">
            Drag to reorder, toggle to pin/unpin items
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={handleReset}>
          <RotateCcw className="h-3.5 w-3.5 mr-1.5" />
          Reset
        </Button>
      </div>

      <ScrollArea className="h-[400px] pr-4">
        <DndContext
          sensors={sensors}
          collisionDetection={closestCenter}
          onDragEnd={handleDragEnd}
        >
          <SortableContext
            items={orderedItems.map(item => item.id)}
            strategy={verticalListSortingStrategy}
          >
            <div className="space-y-2">
              {orderedItems.map((item) => (
                <SortableItem
                  key={item.id}
                  item={item}
                  isPinned={isPinned(item.id)}
                  onToggle={() => handleToggle(item.id)}
                />
              ))}
            </div>
          </SortableContext>
        </DndContext>
      </ScrollArea>
    </div>
  );
}
