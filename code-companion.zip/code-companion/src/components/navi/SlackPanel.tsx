import { useState, useEffect } from 'react';
import { MessageSquare, Hash, Users, Loader2, RefreshCw, Search, Bell, MessageCircle, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { useSlackIntegration, SlackMessageData, SlackChannelData } from '@/hooks/useSlackIntegration';
import { useSlackRealtime, SlackRealtimeMessage, ThreadSummary } from '@/hooks/useSlackRealtime';
import { useIntegrations } from '@/hooks/useIntegrations';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface SlackPanelProps {
  onMessageSelect?: (message: SlackMessageData) => void;
}

export function SlackPanel({ onMessageSelect }: SlackPanelProps) {
  const [activeTab, setActiveTab] = useState<'messages' | 'channels' | 'threads'>('messages');
  const [searchQuery, setSearchQuery] = useState('');
  
  const { integrations, isAuthenticated } = useIntegrations();
  const { 
    isLoading: isInitialLoading, 
    channels, 
    users,
    syncAll,
    fetchChannels,
  } = useSlackIntegration();

  // Real-time polling
  const {
    isPolling,
    messages: realtimeMessages,
    threads,
    lastPollTime,
    unreadCount,
    markAsRead,
    refresh: refreshRealtime,
  } = useSlackRealtime({ 
    enabled: integrations.find(i => i.type === 'slack')?.status === 'connected' && isAuthenticated,
    pollInterval: 30000, // 30 seconds
  });

  const slackConnected = integrations.find(i => i.type === 'slack')?.status === 'connected';

  useEffect(() => {
    if (slackConnected && isAuthenticated) {
      syncAll();
    }
  }, [slackConnected, isAuthenticated]);

  const handleRefresh = () => {
    syncAll();
    refreshRealtime();
  };

  const formatTime = (date: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return date.toLocaleDateString();
  };

  const getUserName = (userId: string) => {
    const user = users.get(userId);
    return user?.real_name || user?.profile?.display_name || userId;
  };

  const filteredMessages = realtimeMessages.filter(msg =>
    msg.text.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (msg.channelName || '').toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredChannels = channels.filter(channel =>
    channel.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredThreads = threads.filter(thread =>
    thread.lastMessage.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (thread.channelName || '').toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (!isAuthenticated) {
    return (
      <div className="flex flex-col h-full bg-sidebar">
        <div className="px-4 py-3 border-b border-border">
          <h2 className="font-semibold text-sm flex items-center gap-2">
            <div className="h-5 w-5 rounded bg-purple-500/20 flex items-center justify-center">
              <MessageSquare className="h-3 w-3 text-purple-400" />
            </div>
            Slack
          </h2>
        </div>
        <div className="flex-1 flex items-center justify-center px-4 text-center">
          <div>
            <MessageSquare className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">Sign in to connect Slack</p>
          </div>
        </div>
      </div>
    );
  }

  const handleConnectSlack = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error('Please sign in first');
        return;
      }
      
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/oauth?provider=slack`,
        {
          headers: {
            Authorization: `Bearer ${session.access_token}`,
          },
        }
      );
      
      const result = await response.json();
      if (result.authUrl) {
        window.open(result.authUrl, '_blank', 'width=600,height=700');
      } else {
        toast.error('Failed to initiate Slack connection');
      }
    } catch (error) {
      console.error('Failed to connect Slack:', error);
      toast.error('Failed to connect to Slack');
    }
  };

  if (!slackConnected) {
    return (
      <div className="flex flex-col h-full bg-sidebar">
        <div className="px-4 py-3 border-b border-border">
          <h2 className="font-semibold text-sm flex items-center gap-2">
            <div className="h-5 w-5 rounded bg-purple-500/20 flex items-center justify-center">
              <MessageSquare className="h-3 w-3 text-purple-400" />
            </div>
            Slack
          </h2>
        </div>
        <div className="flex-1 flex flex-col items-center justify-center px-4 text-center">
          <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center mb-3">
            <MessageSquare className="h-6 w-6 text-muted-foreground" />
          </div>
          <h3 className="text-sm font-medium mb-1">Connect Slack</h3>
          <p className="text-xs text-muted-foreground mb-4">
            Connect your Slack workspace to sync team discussions.
          </p>
          <Button onClick={handleConnectSlack} variant="default" size="sm">
            <MessageSquare className="h-4 w-4 mr-2" />
            Connect Slack
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-sidebar">
      {/* Header */}
      <div className="px-4 py-3 border-b border-border">
        <div className="flex items-center justify-between mb-2">
          <h2 className="font-semibold text-sm flex items-center gap-2">
            <div className="h-5 w-5 rounded bg-purple-500/20 flex items-center justify-center">
              <MessageSquare className="h-3 w-3 text-purple-400" />
            </div>
            Slack
            {unreadCount > 0 && (
              <Badge variant="destructive" className="h-5 min-w-5 text-[10px] px-1.5">
                {unreadCount}
              </Badge>
            )}
          </h2>
          <div className="flex items-center gap-1">
            {isPolling && (
              <div className="h-2 w-2 rounded-full bg-status-success animate-pulse" />
            )}
            <Button 
              variant="ghost" 
              size="icon" 
              className="h-7 w-7"
              onClick={handleRefresh}
              disabled={isInitialLoading}
            >
              <RefreshCw className={cn("h-4 w-4", isInitialLoading && "animate-spin")} />
            </Button>
          </div>
        </div>
        
        {/* Tabs */}
        <div className="flex gap-1 mb-2">
          <button
            onClick={() => { setActiveTab('messages'); markAsRead(); }}
            className={cn(
              "px-2 py-1 text-xs rounded transition-colors flex items-center gap-1",
              activeTab === 'messages' 
                ? "bg-primary/20 text-primary" 
                : "text-muted-foreground hover:bg-sidebar-hover"
            )}
          >
            Messages
            {unreadCount > 0 && activeTab !== 'messages' && (
              <span className="h-1.5 w-1.5 rounded-full bg-destructive" />
            )}
          </button>
          <button
            onClick={() => setActiveTab('threads')}
            className={cn(
              "px-2 py-1 text-xs rounded transition-colors flex items-center gap-1",
              activeTab === 'threads' 
                ? "bg-primary/20 text-primary" 
                : "text-muted-foreground hover:bg-sidebar-hover"
            )}
          >
            <MessageCircle className="h-3 w-3" />
            Threads ({threads.length})
          </button>
          <button
            onClick={() => setActiveTab('channels')}
            className={cn(
              "px-2 py-1 text-xs rounded transition-colors",
              activeTab === 'channels' 
                ? "bg-primary/20 text-primary" 
                : "text-muted-foreground hover:bg-sidebar-hover"
            )}
          >
            Channels ({channels.length})
          </button>
        </div>

        {/* Last poll indicator */}
        {lastPollTime && (
          <p className="text-[10px] text-muted-foreground mb-2">
            Last updated: {formatTime(lastPollTime)}
          </p>
        )}

        {/* Search */}
        <div className="relative">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder={`Search ${activeTab}...`}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 h-8 text-sm"
          />
        </div>
      </div>

      {/* Content */}
      <ScrollArea className="flex-1">
        {isInitialLoading ? (
          <div className="flex items-center justify-center h-32">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : activeTab === 'messages' ? (
          filteredMessages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-32 px-4 text-center">
              <MessageSquare className="h-8 w-8 text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">
                {searchQuery ? 'No messages match your search' : 'No messages found'}
              </p>
            </div>
          ) : (
            <div className="p-2 space-y-1">
              {filteredMessages.map((msg) => (
                <button
                  key={msg.id}
                  onClick={() => onMessageSelect?.({
                    ts: msg.ts,
                    text: msg.text,
                    user: msg.user,
                    channel: msg.channel,
                    channel_name: msg.channelName,
                    thread_ts: msg.threadTs,
                    reply_count: msg.replyCount,
                  })}
                  className={cn(
                    "w-full px-3 py-2.5 rounded-lg text-left hover:bg-sidebar-hover transition-colors group",
                    msg.isNew && "bg-primary/5 border-l-2 border-primary"
                  )}
                >
                  <div className="flex items-start gap-2">
                    <div className="h-6 w-6 rounded-full bg-purple-500/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-[10px] text-purple-400 font-medium">
                        {(msg.userName || msg.user).charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-medium text-foreground truncate">
                          {msg.userName || msg.user}
                        </span>
                        {msg.isNew && (
                          <Badge variant="destructive" className="text-[9px] h-4 px-1">
                            New
                          </Badge>
                        )}
                        <span className="text-[10px] text-muted-foreground ml-auto">
                          {formatTime(msg.timestamp)}
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">
                        {msg.text}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        <div className="flex items-center gap-1">
                          <Hash className="h-3 w-3 text-muted-foreground" />
                          <span className="text-[10px] text-muted-foreground">
                            {msg.channelName || msg.channel}
                          </span>
                        </div>
                        {msg.replyCount && msg.replyCount > 0 && (
                          <div className="flex items-center gap-1">
                            <MessageCircle className="h-3 w-3 text-muted-foreground" />
                            <span className="text-[10px] text-muted-foreground">
                              {msg.replyCount} replies
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )
        ) : activeTab === 'threads' ? (
          filteredThreads.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-32 px-4 text-center">
              <MessageCircle className="h-8 w-8 text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">
                {searchQuery ? 'No threads match your search' : 'No active threads'}
              </p>
            </div>
          ) : (
            <div className="p-2 space-y-1">
              {filteredThreads.map((thread) => (
                <div
                  key={`${thread.channel}-${thread.threadTs}`}
                  className="px-3 py-2.5 rounded-lg hover:bg-sidebar-hover transition-colors"
                >
                  <div className="flex items-start gap-2">
                    <div className="h-6 w-6 rounded-full bg-blue-500/20 flex items-center justify-center flex-shrink-0">
                      <MessageCircle className="h-3 w-3 text-blue-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <Hash className="h-3 w-3 text-muted-foreground" />
                        <span className="text-xs font-medium text-foreground">
                          {thread.channelName || thread.channel}
                        </span>
                        <span className="text-[10px] text-muted-foreground ml-auto">
                          {formatTime(thread.lastActivity)}
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">
                        {thread.summary || thread.lastMessage}
                      </p>
                      <div className="flex items-center gap-2 mt-1.5">
                        <Badge variant="secondary" className="text-[10px] h-5">
                          {thread.messageCount} messages
                        </Badge>
                        <div className="flex -space-x-1">
                          {thread.participants.slice(0, 3).map((p, i) => (
                            <div
                              key={i}
                              className="h-4 w-4 rounded-full bg-muted flex items-center justify-center text-[8px] font-medium border border-background"
                            >
                              {p.charAt(0).toUpperCase()}
                            </div>
                          ))}
                          {thread.participants.length > 3 && (
                            <div className="h-4 w-4 rounded-full bg-muted flex items-center justify-center text-[8px] font-medium border border-background">
                              +{thread.participants.length - 3}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  </div>
                </div>
              ))}
            </div>
          )
        ) : (
          filteredChannels.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-32 px-4 text-center">
              <Hash className="h-8 w-8 text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">
                {searchQuery ? 'No channels match your search' : 'No channels found'}
              </p>
            </div>
          ) : (
            <div className="p-2 space-y-1">
              {filteredChannels.map((channel) => (
                <div
                  key={channel.id}
                  className="px-3 py-2.5 rounded-lg hover:bg-sidebar-hover transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <Hash className="h-4 w-4 text-purple-400" />
                    <span className="text-sm font-medium text-foreground flex-1">
                      {channel.name}
                    </span>
                    {channel.is_private && (
                      <Badge variant="outline" className="text-[10px]">Private</Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Users className="h-3 w-3" />
                      {channel.num_members} members
                    </span>
                  </div>
                  {channel.purpose?.value && (
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-1">
                      {channel.purpose.value}
                    </p>
                  )}
                </div>
              ))}
            </div>
          )
        )}
      </ScrollArea>
    </div>
  );
}
