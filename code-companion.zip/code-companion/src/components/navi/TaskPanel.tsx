import { useState, useEffect, useCallback } from 'react';
import { 
  ChevronRight, 
  ExternalLink, 
  MessageSquare, 
  FileText, 
  Video,
  GitBranch,
  Clock,
  Flag,
  Loader2,
  RefreshCw,
  Inbox,
  AlertCircle,
  Brain,
  Zap,
  Play
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { useIntegrations } from '@/hooks/useIntegrations';
import { useIntegrationData, JiraIssue } from '@/hooks/useIntegrationData';
import { useMemory } from '@/hooks/useMemory';
import { useActiveWorkflows } from '@/hooks/useActiveWorkflows';
import { toast } from 'sonner';
import type { JiraTask } from '@/types';
import { WorkflowProgressIndicator } from './WorkflowProgressIndicator';

const mapJiraStatusToLocal = (status: string): JiraTask['status'] => {
  const statusLower = status.toLowerCase();
  if (statusLower.includes('done') || statusLower.includes('complete')) return 'done';
  if (statusLower.includes('progress') || statusLower.includes('development')) return 'in_progress';
  if (statusLower.includes('review') || statusLower.includes('testing')) return 'in_review';
  if (statusLower.includes('blocked')) return 'blocked';
  return 'todo';
};

const mapJiraPriorityToLocal = (priority: string): JiraTask['priority'] => {
  const priorityLower = priority.toLowerCase();
  if (priorityLower.includes('critical') || priorityLower.includes('highest')) return 'critical';
  if (priorityLower.includes('high')) return 'high';
  if (priorityLower.includes('medium') || priorityLower.includes('normal')) return 'medium';
  return 'low';
};

const getStatusColor = (status: JiraTask['status']) => {
  switch (status) {
    case 'todo': return 'bg-muted text-muted-foreground';
    case 'in_progress': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
    case 'in_review': return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
    case 'done': return 'bg-green-500/20 text-green-400 border-green-500/30';
    case 'blocked': return 'bg-red-500/20 text-red-400 border-red-500/30';
    default: return 'bg-muted text-muted-foreground';
  }
};

const getPriorityIcon = (priority: JiraTask['priority']) => {
  const colors = {
    low: 'text-muted-foreground',
    medium: 'text-yellow-400',
    high: 'text-orange-400',
    critical: 'text-red-400',
  };
  return <Flag className={cn("h-3.5 w-3.5", colors[priority])} />;
};

interface TaskPanelProps {
  onTaskSelect: (task: JiraTask) => void;
  selectedTask: JiraTask | null;
  onStartWorkflow?: (task: JiraTask) => void;
}

export function TaskPanel({ onTaskSelect, selectedTask, onStartWorkflow }: TaskPanelProps) {
  const [expandedTask, setExpandedTask] = useState<string | null>(null);
  const [tasks, setTasks] = useState<JiraTask[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncError, setSyncError] = useState<string | null>(null);
  
  const { integrations, isAuthenticated } = useIntegrations();
  const { fetchJiraIssues, isLoading: isFetching } = useIntegrationData();
  const { storeTask } = useMemory();
  const { hasActiveWorkflow, getWorkflowForTask } = useActiveWorkflows();
  
  const jiraConnected = integrations.find(i => i.type === 'jira')?.status === 'connected';

  // Transform Jira API response to local JiraTask format
  const transformJiraIssue = (issue: any): JiraTask => ({
    id: issue.id,
    key: issue.key,
    title: issue.fields?.summary || 'Untitled',
    description: issue.fields?.description || '',
    status: mapJiraStatusToLocal(issue.fields?.status?.name || 'To Do'),
    priority: mapJiraPriorityToLocal(issue.fields?.priority?.name || 'Medium'),
    storyPoints: issue.fields?.storyPoints || null,
    sprint: issue.fields?.sprint || null,
    assignee: issue.fields?.assignee?.displayName || null,
    project: issue.fields?.project?.key || null,
    labels: issue.fields?.labels || [],
    acceptanceCriteria: issue.fields?.acceptanceCriteria 
      ? [issue.fields.acceptanceCriteria]
      : [],
    relatedDocs: [],
    relatedMessages: [],
    relatedMeetings: [],
    linkedPRs: [],
  });

  // Sync task to memory for RAG context
  const syncTaskToMemory = useCallback(async (task: JiraTask) => {
    try {
      await storeTask({
        task_id: task.id,
        task_key: task.key,
        title: task.title,
        description: task.description,
        status: task.status,
        priority: task.priority,
        assignee: task.assignee || undefined,
        related_content: [
          ...task.relatedDocs.map(d => ({ type: 'doc', ...d })),
          ...task.relatedMessages.map(m => ({ type: 'message', ...m })),
        ],
      });
    } catch (err) {
      console.error('Failed to sync task to memory:', err);
    }
  }, [storeTask]);

  // Fetch tasks from Jira API
  const fetchTasks = useCallback(async () => {
    if (!jiraConnected || !isAuthenticated) {
      setIsLoading(false);
      return;
    }

    setIsSyncing(true);
    setSyncError(null);

    try {
      const jiraIssues = await fetchJiraIssues();
      
      if (jiraIssues) {
        const transformedTasks = jiraIssues.map(transformJiraIssue);
        setTasks(transformedTasks);
        
        // Sync all tasks to memory for RAG
        for (const task of transformedTasks.slice(0, 10)) {
          await syncTaskToMemory(task);
        }
        
        toast.success(`Synced ${transformedTasks.length} tasks from Jira`);
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to fetch tasks';
      setSyncError(message);
      console.error('Jira fetch error:', err);
    } finally {
      setIsLoading(false);
      setIsSyncing(false);
    }
  }, [jiraConnected, isAuthenticated, fetchJiraIssues, syncTaskToMemory]);

  // Initial fetch
  useEffect(() => {
    if (jiraConnected && isAuthenticated) {
      fetchTasks();
    } else {
      setIsLoading(false);
    }
  }, [jiraConnected, isAuthenticated]);

  const handleSync = () => {
    fetchTasks();
  };

  if (isLoading) {
    return (
      <div className="w-80 bg-sidebar border-r border-border flex flex-col h-full">
        <div className="px-4 py-3 border-b border-border">
          <h2 className="font-semibold text-sm flex items-center gap-2">
            <div className="h-5 w-5 rounded bg-blue-500/20 flex items-center justify-center">
              <span className="text-blue-400 text-xs font-bold">J</span>
            </div>
            My Jira Tasks
          </h2>
        </div>
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">Loading tasks...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="w-80 bg-sidebar border-r border-border flex flex-col h-full">
      {/* Header */}
      <div className="px-4 py-3 border-b border-border">
        <div className="flex items-center justify-between">
          <h2 className="font-semibold text-sm flex items-center gap-2">
            <div className="h-5 w-5 rounded bg-blue-500/20 flex items-center justify-center">
              <span className="text-blue-400 text-xs font-bold">J</span>
            </div>
            My Jira Tasks
          </h2>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button 
                variant="ghost" 
                size="icon" 
                className="h-7 w-7"
                onClick={handleSync}
                disabled={!jiraConnected || isSyncing || !isAuthenticated}
              >
                <RefreshCw className={cn("h-4 w-4", isSyncing && "animate-spin")} />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              {jiraConnected ? 'Sync tasks from Jira' : 'Connect Jira to sync tasks'}
            </TooltipContent>
          </Tooltip>
        </div>
        <p className="text-xs text-muted-foreground mt-1">
          {jiraConnected ? (
            isSyncing ? 'Syncing from Jira...' : `${tasks.length} tasks synced`
          ) : (
            'Connect Jira to see your tasks'
          )}
        </p>
        {tasks.length > 0 && (
          <div className="flex items-center gap-1 mt-1">
            <Brain className="h-3 w-3 text-primary" />
            <span className="text-[10px] text-primary">Tasks synced to memory</span>
          </div>
        )}
      </div>

      {/* Error State */}
      {syncError && (
        <div className="px-4 py-2 bg-destructive/10 border-b border-destructive/20">
          <div className="flex items-center gap-2 text-xs text-destructive">
            <AlertCircle className="h-3.5 w-3.5" />
            <span>{syncError}</span>
          </div>
        </div>
      )}

      {/* Task List or Empty State */}
      <div className="flex-1 overflow-y-auto">
        {!isAuthenticated ? (
          <div className="flex flex-col items-center justify-center h-full px-4 text-center">
            <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center mb-3">
              <Inbox className="h-6 w-6 text-muted-foreground" />
            </div>
            <h3 className="text-sm font-medium mb-1">Sign In Required</h3>
            <p className="text-xs text-muted-foreground mb-4">
              Sign in to connect your Jira account and see your tasks.
            </p>
          </div>
        ) : !jiraConnected ? (
          <div className="flex flex-col items-center justify-center h-full px-4 text-center">
            <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center mb-3">
              <Inbox className="h-6 w-6 text-muted-foreground" />
            </div>
            <h3 className="text-sm font-medium mb-1">No Jira Connected</h3>
            <p className="text-xs text-muted-foreground mb-4">
              Connect your Jira account to see your assigned tasks here.
            </p>
            <Badge variant="outline" className="text-xs">
              Go to Integrations to connect
            </Badge>
          </div>
        ) : tasks.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full px-4 text-center">
            <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center mb-3">
              <Inbox className="h-6 w-6 text-muted-foreground" />
            </div>
            <h3 className="text-sm font-medium mb-1">No Tasks Assigned</h3>
            <p className="text-xs text-muted-foreground">
              You don't have any Jira tasks assigned to you.
            </p>
            <Button 
              variant="outline" 
              size="sm" 
              className="mt-4"
              onClick={handleSync}
              disabled={isSyncing}
            >
              {isSyncing ? <Loader2 className="h-3 w-3 animate-spin mr-1" /> : null}
              Refresh
            </Button>
          </div>
        ) : (
          tasks.map((task) => {
            const activeWorkflow = getWorkflowForTask(task.id);
            const hasWorkflow = hasActiveWorkflow(task.id);
            
            return (
              <div
                key={task.id}
                className={cn(
                  "border-b border-border transition-colors",
                  selectedTask?.id === task.id && "bg-primary/5",
                  hasWorkflow && "bg-primary/5 border-l-2 border-l-primary"
                )}
              >
                <button
                  onClick={() => {
                    onTaskSelect(task);
                    setExpandedTask(expandedTask === task.id ? null : task.id);
                  }}
                  className="w-full px-4 py-3 text-left hover:bg-sidebar-hover transition-colors"
                >
                  <div className="flex items-start gap-3">
                    <div className="flex-shrink-0 mt-0.5">
                      {getPriorityIcon(task.priority)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs font-mono text-primary">{task.key}</span>
                        <Badge variant="outline" className={cn("text-[10px] px-1.5 py-0", getStatusColor(task.status))}>
                          {task.status.replace('_', ' ')}
                        </Badge>
                        {activeWorkflow && (
                          <WorkflowProgressIndicator 
                            workflow={activeWorkflow} 
                            variant="badge"
                          />
                        )}
                      </div>
                      <h3 className="text-sm font-medium text-foreground truncate">{task.title}</h3>
                      
                      {/* Inline workflow progress */}
                      {activeWorkflow && (
                        <WorkflowProgressIndicator 
                          workflow={activeWorkflow} 
                          variant="inline"
                          className="mt-2"
                        />
                      )}
                      
                      <div className="flex items-center gap-3 mt-1.5 text-xs text-muted-foreground">
                        {task.storyPoints && (
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {task.storyPoints}pts
                          </span>
                        )}
                        {task.sprint && (
                          <span className="flex items-center gap-1 truncate max-w-[100px]">
                            {task.sprint}
                          </span>
                        )}
                        {task.linkedPRs && task.linkedPRs.length > 0 && (
                          <span className="flex items-center gap-1">
                            <GitBranch className="h-3 w-3" />
                            {task.linkedPRs.length} PR
                          </span>
                        )}
                      </div>
                    </div>
                    <ChevronRight className={cn(
                      "h-4 w-4 text-muted-foreground transition-transform",
                      expandedTask === task.id && "rotate-90"
                    )} />
                  </div>
                </button>

              {/* Expanded Content */}
              {expandedTask === task.id && (
                <div className="px-4 pb-3 animate-fade-in">
                  <p className="text-xs text-muted-foreground mb-3 line-clamp-3">
                    {task.description || 'No description available.'}
                  </p>

                  {/* Labels */}
                  {task.labels && task.labels.length > 0 && (
                    <div className="flex flex-wrap gap-1 mb-3">
                      {task.labels.map((label, i) => (
                        <Badge key={i} variant="secondary" className="text-[10px]">
                          {label}
                        </Badge>
                      ))}
                    </div>
                  )}

                  {/* Related Sources */}
                  <div className="space-y-2">
                    {task.relatedDocs && task.relatedDocs.length > 0 && (
                      <div>
                        <span className="text-[10px] uppercase text-muted-foreground tracking-wider">Documentation</span>
                        {task.relatedDocs.map((doc, i) => (
                          <a
                            key={i}
                            href={doc.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-2 mt-1 px-2 py-1.5 rounded bg-card hover:bg-secondary transition-colors group"
                          >
                            <FileText className="h-3 w-3 text-blue-400" />
                            <span className="text-xs truncate flex-1">{doc.title}</span>
                            <ExternalLink className="h-3 w-3 text-muted-foreground opacity-0 group-hover:opacity-100" />
                          </a>
                        ))}
                      </div>
                    )}

                    {task.relatedMessages && task.relatedMessages.length > 0 && (
                      <div>
                        <span className="text-[10px] uppercase text-muted-foreground tracking-wider">Discussions</span>
                        {task.relatedMessages.map((msg, i) => (
                          <a
                            key={i}
                            href={msg.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-2 mt-1 px-2 py-1.5 rounded bg-card hover:bg-secondary transition-colors group"
                          >
                            <MessageSquare className={cn(
                              "h-3 w-3",
                              msg.type === 'slack' ? "text-purple-400" : "text-violet-400"
                            )} />
                            <span className="text-xs truncate flex-1">{msg.title}</span>
                            <ExternalLink className="h-3 w-3 text-muted-foreground opacity-0 group-hover:opacity-100" />
                          </a>
                        ))}
                      </div>
                    )}

                    {task.relatedMeetings && task.relatedMeetings.length > 0 && (
                      <div>
                        <span className="text-[10px] uppercase text-muted-foreground tracking-wider">Meetings</span>
                        {task.relatedMeetings.map((meeting, i) => (
                          <div
                            key={i}
                            className="mt-1 px-2 py-1.5 rounded bg-card"
                          >
                            <div className="flex items-center gap-2">
                              <Video className="h-3 w-3 text-sky-400" />
                              <span className="text-xs truncate flex-1">{meeting.title}</span>
                            </div>
                            <p className="text-[10px] text-muted-foreground mt-1 line-clamp-2">
                              {meeting.summary}
                            </p>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  <div className="flex gap-2 mt-3">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1 text-xs"
                      onClick={(e) => {
                        e.stopPropagation();
                        onTaskSelect(task);
                        syncTaskToMemory(task);
                      }}
                    >
                      Work on this task
                    </Button>
                    <Button
                      variant="ai"
                      size="sm"
                      className="text-xs gap-1"
                      onClick={(e) => {
                        e.stopPropagation();
                        onStartWorkflow?.(task);
                      }}
                      disabled={hasWorkflow}
                    >
                      <Zap className="h-3 w-3" />
                      {hasWorkflow ? 'In Progress' : 'Auto Workflow'}
                    </Button>
                  </div>
                </div>
              )}
            </div>
          );
        })
        )}
      </div>
    </div>
  );
}
