import { useState, useEffect, useCallback } from 'react';
import { MessageSquare, Hash, Users, Loader2, RefreshCw, Search, ChevronRight, Send, Video, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';
import { useIntegrations } from '@/hooks/useIntegrations';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { formatDistanceToNow } from 'date-fns';

interface TeamsChannel {
  id: string;
  displayName: string;
  description?: string;
  membershipType: 'standard' | 'private' | 'shared';
  webUrl: string;
}

interface TeamsMessage {
  id: string;
  body: {
    content: string;
    contentType: string;
  };
  from?: {
    user?: {
      displayName: string;
      id: string;
    };
  };
  createdDateTime: string;
  channelIdentity?: {
    channelId: string;
    teamId: string;
  };
  replyCount?: number;
  importance: 'normal' | 'high' | 'urgent';
}

interface TeamsChat {
  id: string;
  topic?: string;
  chatType: 'oneOnOne' | 'group' | 'meeting';
  lastUpdatedDateTime: string;
  members?: {
    displayName: string;
    userId: string;
  }[];
}

interface TeamsPanelProps {
  onMessageSelect?: (message: TeamsMessage) => void;
}

export function TeamsPanel({ onMessageSelect }: TeamsPanelProps) {
  const [activeTab, setActiveTab] = useState<'messages' | 'channels' | 'chats'>('messages');
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [channels, setChannels] = useState<TeamsChannel[]>([]);
  const [messages, setMessages] = useState<TeamsMessage[]>([]);
  const [chats, setChats] = useState<TeamsChat[]>([]);

  const { integrations, isAuthenticated } = useIntegrations();
  const teamsConnected = integrations.find(i => i.type === 'teams')?.status === 'connected';

  const fetchTeamsData = useCallback(async (action: string) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return null;

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/integration-data`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ provider: 'teams', action }),
        }
      );

      const result = await response.json();
      if (!response.ok) {
        console.error('Teams API error:', result);
        return null;
      }
      return result.data;
    } catch (error) {
      console.error('Failed to fetch Teams data:', error);
      return null;
    }
  }, []);

  const loadData = useCallback(async () => {
    if (!teamsConnected || !isAuthenticated) return;
    
    setIsLoading(true);
    try {
      const [channelsData, messagesData, chatsData] = await Promise.all([
        fetchTeamsData('channels'),
        fetchTeamsData('messages'),
        fetchTeamsData('chats'),
      ]);

      if (channelsData) setChannels(channelsData);
      if (messagesData) setMessages(messagesData);
      if (chatsData) setChats(chatsData);
    } finally {
      setIsLoading(false);
    }
  }, [teamsConnected, isAuthenticated, fetchTeamsData]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await loadData();
    setIsRefreshing(false);
    toast.success('Teams data refreshed');
  };

  const postMessage = useCallback(async (channelId: string, teamId: string, content: string) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error('Please sign in to post messages');
        return false;
      }

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/integration-data`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            provider: 'teams',
            action: 'post_message',
            params: { channelId, teamId, content },
          }),
        }
      );

      const result = await response.json();
      if (!response.ok) {
        throw new Error(result.error || 'Failed to post message');
      }

      toast.success('Message posted successfully');
      await loadData();
      return true;
    } catch (error) {
      toast.error('Failed to post message');
      return false;
    }
  }, [loadData]);

  const formatTime = (dateString: string) => {
    return formatDistanceToNow(new Date(dateString), { addSuffix: true });
  };

  const stripHtml = (html: string) => {
    const doc = new DOMParser().parseFromString(html, 'text/html');
    return doc.body.textContent || '';
  };

  const filteredChannels = channels.filter(c =>
    c.displayName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredMessages = messages.filter(m =>
    stripHtml(m.body.content).toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredChats = chats.filter(c =>
    (c.topic || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.members?.some(m => m.displayName.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  if (!isAuthenticated) {
    return (
      <div className="flex flex-col h-full bg-sidebar">
        <div className="px-4 py-3 border-b border-border">
          <h2 className="font-semibold text-sm flex items-center gap-2">
            <div className="h-5 w-5 rounded bg-violet-500/20 flex items-center justify-center">
              <MessageSquare className="h-3 w-3 text-violet-400" />
            </div>
            Microsoft Teams
          </h2>
        </div>
        <div className="flex-1 flex items-center justify-center px-4 text-center">
          <div>
            <MessageSquare className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">Sign in to connect Teams</p>
          </div>
        </div>
      </div>
    );
  }

  const handleConnectTeams = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error('Please sign in first');
        return;
      }
      
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/oauth?provider=teams`,
        {
          headers: {
            Authorization: `Bearer ${session.access_token}`,
          },
        }
      );
      
      const result = await response.json();
      if (result.authUrl) {
        window.open(result.authUrl, '_blank', 'width=600,height=700');
      } else {
        toast.error('Failed to initiate Teams connection');
      }
    } catch (error) {
      console.error('Failed to connect Teams:', error);
      toast.error('Failed to connect to Microsoft Teams');
    }
  };

  if (!teamsConnected) {
    return (
      <div className="flex flex-col h-full bg-sidebar">
        <div className="px-4 py-3 border-b border-border">
          <h2 className="font-semibold text-sm flex items-center gap-2">
            <div className="h-5 w-5 rounded bg-violet-500/20 flex items-center justify-center">
              <MessageSquare className="h-3 w-3 text-violet-400" />
            </div>
            Microsoft Teams
          </h2>
        </div>
        <div className="flex-1 flex flex-col items-center justify-center px-4 text-center">
          <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center mb-3">
            <MessageSquare className="h-6 w-6 text-muted-foreground" />
          </div>
          <h3 className="text-sm font-medium mb-1">Connect Microsoft Teams</h3>
          <p className="text-xs text-muted-foreground mb-4">
            Connect your Teams workspace to sync team discussions.
          </p>
          <Button onClick={handleConnectTeams} variant="default" size="sm">
            <MessageSquare className="h-4 w-4 mr-2" />
            Connect Teams
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-sidebar">
      {/* Header */}
      <div className="px-4 py-3 border-b border-border">
        <div className="flex items-center justify-between mb-2">
          <h2 className="font-semibold text-sm flex items-center gap-2">
            <div className="h-5 w-5 rounded bg-violet-500/20 flex items-center justify-center">
              <MessageSquare className="h-3 w-3 text-violet-400" />
            </div>
            Microsoft Teams
          </h2>
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-7 w-7"
            onClick={handleRefresh}
            disabled={isRefreshing}
          >
            <RefreshCw className={cn("h-4 w-4", isRefreshing && "animate-spin")} />
          </Button>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as typeof activeTab)} className="w-full">
          <TabsList className="h-8 w-full">
            <TabsTrigger value="messages" className="text-xs flex-1">
              Messages
            </TabsTrigger>
            <TabsTrigger value="channels" className="text-xs flex-1">
              Channels ({channels.length})
            </TabsTrigger>
            <TabsTrigger value="chats" className="text-xs flex-1">
              Chats ({chats.length})
            </TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Search */}
        <div className="relative mt-2">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder={`Search ${activeTab}...`}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 h-8 text-sm"
          />
        </div>
      </div>

      {/* Content */}
      <ScrollArea className="flex-1">
        {isLoading ? (
          <div className="flex items-center justify-center h-32">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : activeTab === 'messages' ? (
          filteredMessages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-32 px-4 text-center">
              <MessageSquare className="h-8 w-8 text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">
                {searchQuery ? 'No messages match your search' : 'No messages found'}
              </p>
            </div>
          ) : (
            <div className="p-2 space-y-1">
              {filteredMessages.map((msg) => (
                <button
                  key={msg.id}
                  onClick={() => onMessageSelect?.(msg)}
                  className={cn(
                    "w-full px-3 py-2.5 rounded-lg text-left hover:bg-sidebar-hover transition-colors",
                    msg.importance === 'high' && "border-l-2 border-status-warning",
                    msg.importance === 'urgent' && "border-l-2 border-status-error"
                  )}
                >
                  <div className="flex items-start gap-2">
                    <div className="h-6 w-6 rounded-full bg-violet-500/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-[10px] text-violet-400 font-medium">
                        {(msg.from?.user?.displayName || 'U').charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-medium text-foreground truncate">
                          {msg.from?.user?.displayName || 'Unknown'}
                        </span>
                        {msg.importance !== 'normal' && (
                          <Badge 
                            variant={msg.importance === 'urgent' ? 'destructive' : 'secondary'} 
                            className="text-[9px] h-4 px-1"
                          >
                            {msg.importance}
                          </Badge>
                        )}
                        <span className="text-[10px] text-muted-foreground ml-auto">
                          {formatTime(msg.createdDateTime)}
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">
                        {stripHtml(msg.body.content)}
                      </p>
                      {msg.replyCount && msg.replyCount > 0 && (
                        <div className="flex items-center gap-1 mt-1">
                          <MessageSquare className="h-3 w-3 text-muted-foreground" />
                          <span className="text-[10px] text-muted-foreground">
                            {msg.replyCount} replies
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )
        ) : activeTab === 'channels' ? (
          filteredChannels.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-32 px-4 text-center">
              <Hash className="h-8 w-8 text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">
                {searchQuery ? 'No channels match your search' : 'No channels found'}
              </p>
            </div>
          ) : (
            <div className="p-2 space-y-1">
              {filteredChannels.map((channel) => (
                <Card key={channel.id} className="bg-secondary/30 border-none hover:bg-secondary/50 transition-colors">
                  <CardContent className="p-3">
                    <div className="flex items-center gap-3">
                      <div className="h-8 w-8 rounded-lg bg-violet-500/20 flex items-center justify-center">
                        <Hash className="h-4 w-4 text-violet-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-medium text-sm truncate">{channel.displayName}</div>
                        {channel.description && (
                          <p className="text-xs text-muted-foreground truncate mt-0.5">
                            {channel.description}
                          </p>
                        )}
                      </div>
                      {channel.membershipType !== 'standard' && (
                        <Badge variant="outline" className="text-[10px]">
                          {channel.membershipType}
                        </Badge>
                      )}
                      <ChevronRight className="h-4 w-4 text-muted-foreground" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )
        ) : (
          filteredChats.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-32 px-4 text-center">
              <Users className="h-8 w-8 text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">
                {searchQuery ? 'No chats match your search' : 'No chats found'}
              </p>
            </div>
          ) : (
            <div className="p-2 space-y-1">
              {filteredChats.map((chat) => (
                <Card key={chat.id} className="bg-secondary/30 border-none hover:bg-secondary/50 transition-colors">
                  <CardContent className="p-3">
                    <div className="flex items-center gap-3">
                      <div className={cn(
                        "h-8 w-8 rounded-lg flex items-center justify-center",
                        chat.chatType === 'meeting' ? "bg-blue-500/20" : "bg-violet-500/20"
                      )}>
                        {chat.chatType === 'meeting' ? (
                          <Video className="h-4 w-4 text-blue-400" />
                        ) : chat.chatType === 'oneOnOne' ? (
                          <Phone className="h-4 w-4 text-violet-400" />
                        ) : (
                          <Users className="h-4 w-4 text-violet-400" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-medium text-sm truncate">
                          {chat.topic || chat.members?.map(m => m.displayName).join(', ') || 'Chat'}
                        </div>
                        <div className="flex items-center gap-2 mt-0.5">
                          <Badge variant="outline" className="text-[10px]">
                            {chat.chatType}
                          </Badge>
                          <span className="text-[10px] text-muted-foreground">
                            {formatTime(chat.lastUpdatedDateTime)}
                          </span>
                        </div>
                      </div>
                      <ChevronRight className="h-4 w-4 text-muted-foreground" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )
        )}
      </ScrollArea>
    </div>
  );
}
