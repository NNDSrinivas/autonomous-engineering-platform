import { useState, useEffect, useRef } from 'react';
import { 
  Terminal, 
  X, 
  Maximize2, 
  Minimize2,
  ChevronUp,
  ChevronDown,
  Trash2,
  Circle
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';

interface LogEntry {
  id: string;
  type: 'info' | 'warn' | 'error' | 'success' | 'command';
  message: string;
  timestamp: Date;
}

// Mock log entries
const initialLogs: LogEntry[] = [
  { id: '1', type: 'info', message: 'NAVI Terminal v1.0.0', timestamp: new Date() },
  { id: '2', type: 'success', message: 'Connected to Lovable Cloud', timestamp: new Date() },
  { id: '3', type: 'info', message: 'Watching for file changes...', timestamp: new Date() },
  { id: '4', type: 'command', message: '$ npm run dev', timestamp: new Date() },
  { id: '5', type: 'success', message: 'Vite dev server running at http://localhost:5173', timestamp: new Date() },
  { id: '6', type: 'info', message: 'HMR enabled', timestamp: new Date() },
];

interface TerminalPanelProps {
  isExpanded: boolean;
  onToggleExpand: () => void;
  onClose?: () => void;
}

export function TerminalPanel({ isExpanded, onToggleExpand, onClose }: TerminalPanelProps) {
  const [logs, setLogs] = useState<LogEntry[]>(initialLogs);
  const [isMaximized, setIsMaximized] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom on new logs
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  // Simulate incoming logs
  useEffect(() => {
    const interval = setInterval(() => {
      const randomLogs = [
        { type: 'info' as const, message: 'File changed: src/components/navi/NaviChat.tsx' },
        { type: 'success' as const, message: 'Build completed in 245ms' },
        { type: 'warn' as const, message: 'React DevTools extension detected' },
        { type: 'info' as const, message: 'Hot Module Replacement active' },
      ];
      
      if (Math.random() > 0.7) {
        const randomLog = randomLogs[Math.floor(Math.random() * randomLogs.length)];
        setLogs(prev => [...prev.slice(-50), {
          id: Date.now().toString(),
          ...randomLog,
          timestamp: new Date(),
        }]);
      }
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const clearLogs = () => {
    setLogs([{
      id: Date.now().toString(),
      type: 'info',
      message: 'Terminal cleared',
      timestamp: new Date(),
    }]);
  };

  const getLogColor = (type: LogEntry['type']) => {
    switch (type) {
      case 'error': return 'text-red-400';
      case 'warn': return 'text-yellow-400';
      case 'success': return 'text-green-400';
      case 'command': return 'text-cyan-400';
      default: return 'text-muted-foreground';
    }
  };

  const getLogIcon = (type: LogEntry['type']) => {
    switch (type) {
      case 'error': return <Circle className="h-2 w-2 fill-red-400 text-red-400" />;
      case 'warn': return <Circle className="h-2 w-2 fill-yellow-400 text-yellow-400" />;
      case 'success': return <Circle className="h-2 w-2 fill-green-400 text-green-400" />;
      case 'command': return <span className="text-cyan-400 text-xs font-bold">$</span>;
      default: return <Circle className="h-2 w-2 fill-muted-foreground text-muted-foreground" />;
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { 
      hour12: false, 
      hour: '2-digit', 
      minute: '2-digit', 
      second: '2-digit' 
    });
  };

  if (!isExpanded) {
    return (
      <div className="h-8 flex items-center justify-between px-3 bg-terminal border-t border-border">
        <div className="flex items-center gap-2 cursor-pointer flex-1" onClick={onToggleExpand}>
          <Terminal className="h-3.5 w-3.5 text-muted-foreground" />
          <span className="text-xs text-muted-foreground">Terminal</span>
          {logs.length > 0 && (
            <span className="text-[10px] text-muted-foreground/50">
              {logs.length} logs
            </span>
          )}
        </div>
        <div className="flex items-center gap-1 relative z-10" onClick={(e) => e.stopPropagation()}>
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-6 w-6 hover:bg-secondary/80" 
            onClick={clearLogs}
            title="Clear logs"
          >
            <Trash2 className="h-3 w-3" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-6 w-6 hover:bg-secondary/80" 
            onClick={() => {
              setIsMaximized(!isMaximized);
              if (!isMaximized) onToggleExpand();
            }}
            title="Maximize"
          >
            <Maximize2 className="h-3 w-3" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-6 w-6 hover:bg-secondary/80" 
            onClick={onToggleExpand}
            title="Expand"
          >
            <ChevronUp className="h-3 w-3" />
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className={cn(
      "flex flex-col bg-terminal border-t border-border",
      isMaximized ? "fixed inset-0 z-50" : "h-48"
    )}>
      {/* Header */}
      <div className="h-8 flex items-center justify-between px-3 border-b border-border/50 bg-secondary/20">
        <div className="flex items-center gap-2">
          <Terminal className="h-3.5 w-3.5 text-muted-foreground" />
          <span className="text-xs font-medium">Terminal</span>
          <div className="flex items-center gap-1.5">
            <Circle className="h-2 w-2 fill-green-400 text-green-400" />
            <span className="text-[10px] text-green-400">Running</span>
          </div>
        </div>
        <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-6 w-6 hover:bg-secondary z-10" 
            onClick={(e) => {
              e.stopPropagation();
              clearLogs();
            }}
          >
            <Trash2 className="h-3 w-3" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-6 w-6 hover:bg-secondary z-10" 
            onClick={(e) => {
              e.stopPropagation();
              setIsMaximized(!isMaximized);
            }}
          >
            {isMaximized ? <Minimize2 className="h-3 w-3" /> : <Maximize2 className="h-3 w-3" />}
          </Button>
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-6 w-6 hover:bg-secondary z-10" 
            onClick={(e) => {
              e.stopPropagation();
              onToggleExpand();
            }}
          >
            <ChevronDown className="h-3 w-3" />
          </Button>
          {onClose && (
            <Button variant="ghost" size="icon" className="h-6 w-6" onClick={onClose}>
              <X className="h-3 w-3" />
            </Button>
          )}
        </div>
      </div>

      {/* Log content */}
      <ScrollArea className="flex-1" ref={scrollRef}>
        <div className="p-2 space-y-0.5 font-mono text-xs">
          {logs.map((log) => (
            <div key={log.id} className="flex items-start gap-2 py-0.5 hover:bg-secondary/20 px-1 rounded">
              <span className="text-muted-foreground/40 w-16 flex-shrink-0">
                {formatTime(log.timestamp)}
              </span>
              <span className="w-4 flex-shrink-0 flex items-center justify-center">
                {getLogIcon(log.type)}
              </span>
              <span className={cn("flex-1", getLogColor(log.type))}>
                {log.message}
              </span>
            </div>
          ))}
        </div>
      </ScrollArea>
    </div>
  );
}