import { Moon, Sun, Monitor } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { useTheme } from '@/hooks/useTheme';

export function ThemeToggle() {
  const { theme, setTheme } = useTheme();

  const themes = [
    { id: 'light' as const, icon: Sun, label: 'Light' },
    { id: 'dark' as const, icon: Moon, label: 'Dark' },
    { id: 'system' as const, icon: Monitor, label: 'System' },
  ];

  return (
    <div className="flex items-center gap-1 p-1 rounded-lg bg-secondary/50">
      {themes.map(({ id, icon: Icon, label }) => (
        <Button
          key={id}
          variant="ghost"
          size="sm"
          onClick={() => setTheme(id)}
          className={cn(
            "h-8 px-3 gap-2 transition-all duration-300",
            theme === id 
              ? "bg-primary text-primary-foreground shadow-lg" 
              : "hover:bg-secondary"
          )}
        >
          <Icon className={cn(
            "h-4 w-4 transition-transform duration-300",
            theme === id && "scale-110"
          )} />
          <span className="text-xs">{label}</span>
        </Button>
      ))}
    </div>
  );
}

export function ThemeToggleCompact() {
  const { theme, toggleTheme, resolvedTheme } = useTheme();

  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={toggleTheme}
      className="relative h-9 w-9 overflow-hidden transition-all duration-300 hover:bg-secondary"
    >
      <Sun className={cn(
        "h-4 w-4 absolute transition-all duration-500",
        resolvedTheme === 'dark' 
          ? "rotate-90 scale-0 opacity-0" 
          : "rotate-0 scale-100 opacity-100"
      )} />
      <Moon className={cn(
        "h-4 w-4 absolute transition-all duration-500",
        resolvedTheme === 'dark' 
          ? "rotate-0 scale-100 opacity-100" 
          : "-rotate-90 scale-0 opacity-0"
      )} />
      <span className="sr-only">Toggle theme</span>
    </Button>
  );
}
