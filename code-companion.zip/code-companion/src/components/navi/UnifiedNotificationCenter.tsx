import { useState, useEffect } from 'react';
import { 
  Bell, 
  X, 
  Check,
  CheckCheck,
  ExternalLink,
  Filter,
  Search,
  Clock,
  AlertTriangle,
  CheckCircle2,
  Info,
  XCircle,
  Trash2,
  RefreshCw,
  GitBranch,
  MessageSquare,
  Video,
  FileText,
  Github,
  Calendar
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuCheckboxItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuLabel,
} from '@/components/ui/dropdown-menu';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import { 
  useUnifiedNotifications, 
  type UnifiedNotification, 
  type NotificationSource,
  type NotificationPriority 
} from '@/hooks/useUnifiedNotifications';
import { format, formatDistanceToNow } from 'date-fns';

interface UnifiedNotificationCenterProps {
  isOpen?: boolean;
  onClose?: () => void;
}

const sourceIcons: Record<NotificationSource, React.ReactNode> = {
  cicd: <GitBranch className="h-4 w-4" />,
  slack: <MessageSquare className="h-4 w-4" />,
  teams: <MessageSquare className="h-4 w-4" />,
  jira: <FileText className="h-4 w-4" />,
  confluence: <FileText className="h-4 w-4" />,
  github: <Github className="h-4 w-4" />,
  zoom: <Video className="h-4 w-4" />,
  calendar: <Calendar className="h-4 w-4" />,
  system: <Bell className="h-4 w-4" />,
};

const sourceColors: Record<NotificationSource, string> = {
  cicd: 'text-green-400 bg-green-500/10',
  slack: 'text-purple-400 bg-purple-500/10',
  teams: 'text-blue-400 bg-blue-500/10',
  jira: 'text-blue-500 bg-blue-500/10',
  confluence: 'text-blue-400 bg-blue-500/10',
  github: 'text-gray-400 bg-gray-500/10',
  zoom: 'text-blue-500 bg-blue-500/10',
  calendar: 'text-orange-400 bg-orange-500/10',
  system: 'text-muted-foreground bg-muted',
};

const typeIcons: Record<UnifiedNotification['type'], React.ReactNode> = {
  info: <Info className="h-4 w-4 text-blue-400" />,
  warning: <AlertTriangle className="h-4 w-4 text-yellow-400" />,
  error: <XCircle className="h-4 w-4 text-destructive" />,
  success: <CheckCircle2 className="h-4 w-4 text-green-400" />,
};

const priorityColors: Record<NotificationPriority, string> = {
  low: 'bg-muted text-muted-foreground',
  normal: 'bg-secondary text-secondary-foreground',
  high: 'bg-orange-500/20 text-orange-400',
  urgent: 'bg-destructive/20 text-destructive',
};

const allSources: NotificationSource[] = [
  'cicd', 'slack', 'teams', 'jira', 'confluence', 'github', 'zoom', 'calendar', 'system'
];

export function UnifiedNotificationCenter({ isOpen = true, onClose }: UnifiedNotificationCenterProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSources, setSelectedSources] = useState<NotificationSource[]>([]);
  const [activeTab, setActiveTab] = useState<'all' | 'unread'>('all');

  const {
    notifications,
    allNotifications,
    unreadCount,
    isLoading,
    markAsRead,
    markAllAsRead,
    clearAll,
    fetchNotifications,
    startPolling,
    stopPolling,
    getUnreadCountBySource,
  } = useUnifiedNotifications();

  // Start polling when panel opens
  useEffect(() => {
    if (isOpen) {
      startPolling(30000); // Poll every 30 seconds
    } else {
      stopPolling();
    }
    return () => stopPolling();
  }, [isOpen, startPolling, stopPolling]);

  // Filter notifications
  const filteredNotifications = notifications.filter(n => {
    // Tab filter
    if (activeTab === 'unread' && n.read) return false;
    
    // Source filter
    if (selectedSources.length > 0 && !selectedSources.includes(n.source)) return false;
    
    // Search filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      return (
        n.title.toLowerCase().includes(query) ||
        n.description.toLowerCase().includes(query) ||
        n.source.toLowerCase().includes(query)
      );
    }
    
    return true;
  });

  // Group notifications by date
  const groupedNotifications = filteredNotifications.reduce((acc, notification) => {
    const date = format(notification.timestamp, 'yyyy-MM-dd');
    if (!acc[date]) {
      acc[date] = [];
    }
    acc[date].push(notification);
    return acc;
  }, {} as Record<string, UnifiedNotification[]>);

  const formatGroupDate = (dateStr: string) => {
    const date = new Date(dateStr);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (format(date, 'yyyy-MM-dd') === format(today, 'yyyy-MM-dd')) {
      return 'Today';
    }
    if (format(date, 'yyyy-MM-dd') === format(yesterday, 'yyyy-MM-dd')) {
      return 'Yesterday';
    }
    return format(date, 'EEEE, MMMM d');
  };

  const handleActionClick = (action: { action: string }) => {
    if (action.action.startsWith('http')) {
      window.open(action.action, '_blank');
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-y-0 right-0 w-[420px] bg-background border-l border-border shadow-2xl z-50 flex flex-col animate-in slide-in-from-right duration-200">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-border">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-lg bg-primary/10">
            <Bell className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h2 className="font-semibold">Notification Center</h2>
            <p className="text-xs text-muted-foreground">
              {unreadCount > 0 ? `${unreadCount} unread` : 'All caught up!'}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={fetchNotifications}
            disabled={isLoading}
            className="h-8 w-8"
          >
            <RefreshCw className={cn("h-4 w-4", isLoading && "animate-spin")} />
          </Button>
          <Button variant="ghost" size="icon" onClick={onClose} className="h-8 w-8">
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="p-3 border-b border-border space-y-3">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search notifications..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 h-9"
            />
          </div>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon" className="h-9 w-9">
                <Filter className="h-4 w-4" />
                {selectedSources.length > 0 && (
                  <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-primary text-[10px] text-primary-foreground flex items-center justify-center">
                    {selectedSources.length}
                  </span>
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuLabel>Filter by Source</DropdownMenuLabel>
              <DropdownMenuSeparator />
              {allSources.map((source) => (
                <DropdownMenuCheckboxItem
                  key={source}
                  checked={selectedSources.includes(source)}
                  onCheckedChange={(checked) => {
                    setSelectedSources(prev =>
                      checked 
                        ? [...prev, source]
                        : prev.filter(s => s !== source)
                    );
                  }}
                >
                  <div className="flex items-center gap-2">
                    <div className={cn("p-1 rounded", sourceColors[source])}>
                      {sourceIcons[source]}
                    </div>
                    <span className="capitalize">{source}</span>
                    {getUnreadCountBySource(source) > 0 && (
                      <Badge variant="secondary" className="ml-auto text-[10px] h-4">
                        {getUnreadCountBySource(source)}
                      </Badge>
                    )}
                  </div>
                </DropdownMenuCheckboxItem>
              ))}
              {selectedSources.length > 0 && (
                <>
                  <DropdownMenuSeparator />
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="w-full text-xs"
                    onClick={() => setSelectedSources([])}
                  >
                    Clear filters
                  </Button>
                </>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Source chips */}
        <div className="flex gap-1 flex-wrap">
          {allSources.slice(0, 6).map((source) => {
            const count = getUnreadCountBySource(source);
            return (
              <Button
                key={source}
                variant={selectedSources.includes(source) ? 'default' : 'ghost'}
                size="xs"
                onClick={() => {
                  setSelectedSources(prev =>
                    prev.includes(source)
                      ? prev.filter(s => s !== source)
                      : [...prev, source]
                  );
                }}
                className={cn(
                  "h-7 gap-1.5",
                  !selectedSources.includes(source) && sourceColors[source]
                )}
              >
                {sourceIcons[source]}
                <span className="capitalize text-xs">{source}</span>
                {count > 0 && (
                  <Badge variant="secondary" className="ml-0.5 h-4 px-1 text-[10px]">
                    {count}
                  </Badge>
                )}
              </Button>
            );
          })}
        </div>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as 'all' | 'unread')} className="flex-1 flex flex-col">
        <div className="flex items-center justify-between px-3 py-2 border-b border-border">
          <TabsList className="h-8">
            <TabsTrigger value="all" className="text-xs h-7 px-3">
              All ({allNotifications.length})
            </TabsTrigger>
            <TabsTrigger value="unread" className="text-xs h-7 px-3">
              Unread ({unreadCount})
            </TabsTrigger>
          </TabsList>
          <div className="flex items-center gap-1">
            {unreadCount > 0 && (
              <Button 
                variant="ghost" 
                size="xs" 
                onClick={markAllAsRead}
                className="text-xs text-muted-foreground"
              >
                <CheckCheck className="h-3.5 w-3.5 mr-1" />
                Mark all read
              </Button>
            )}
            {allNotifications.length > 0 && (
              <Button 
                variant="ghost" 
                size="xs" 
                onClick={clearAll}
                className="text-xs text-muted-foreground"
              >
                <Trash2 className="h-3.5 w-3.5 mr-1" />
                Clear
              </Button>
            )}
          </div>
        </div>

        <ScrollArea className="flex-1">
          <TabsContent value="all" className="m-0 p-0">
            <NotificationList 
              groupedNotifications={groupedNotifications}
              formatGroupDate={formatGroupDate}
              onMarkAsRead={markAsRead}
              onActionClick={handleActionClick}
              isLoading={isLoading}
            />
          </TabsContent>
          <TabsContent value="unread" className="m-0 p-0">
            <NotificationList 
              groupedNotifications={groupedNotifications}
              formatGroupDate={formatGroupDate}
              onMarkAsRead={markAsRead}
              onActionClick={handleActionClick}
              isLoading={isLoading}
            />
          </TabsContent>
        </ScrollArea>
      </Tabs>
    </div>
  );
}

interface NotificationListProps {
  groupedNotifications: Record<string, UnifiedNotification[]>;
  formatGroupDate: (date: string) => string;
  onMarkAsRead: (id: string) => void;
  onActionClick: (action: { action: string }) => void;
  isLoading: boolean;
}

function NotificationList({ 
  groupedNotifications, 
  formatGroupDate, 
  onMarkAsRead,
  onActionClick,
  isLoading 
}: NotificationListProps) {
  const dates = Object.keys(groupedNotifications).sort((a, b) => b.localeCompare(a));

  if (isLoading && dates.length === 0) {
    return (
      <div className="p-4 space-y-3">
        {[1, 2, 3].map((i) => (
          <div key={i} className="space-y-2">
            <Skeleton className="h-4 w-24" />
            <Skeleton className="h-20 w-full" />
            <Skeleton className="h-20 w-full" />
          </div>
        ))}
      </div>
    );
  }

  if (dates.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
        <Bell className="h-12 w-12 mb-4 opacity-30" />
        <p className="text-sm font-medium">No notifications</p>
        <p className="text-xs">You're all caught up!</p>
      </div>
    );
  }

  return (
    <div className="p-2">
      {dates.map((date) => (
        <div key={date} className="mb-4">
          <div className="sticky top-0 bg-background/95 backdrop-blur-sm px-2 py-1.5 text-xs font-medium text-muted-foreground">
            {formatGroupDate(date)}
          </div>
          <div className="space-y-1">
            {groupedNotifications[date].map((notification) => (
              <div
                key={notification.id}
                onClick={() => onMarkAsRead(notification.id)}
                className={cn(
                  "p-3 rounded-lg cursor-pointer transition-all duration-200 group",
                  "hover:bg-secondary/50",
                  !notification.read && "bg-primary/5 border-l-2 border-primary"
                )}
              >
                <div className="flex gap-3">
                  {/* Source Icon */}
                  <div className={cn(
                    "flex-shrink-0 p-1.5 rounded-lg",
                    sourceColors[notification.source]
                  )}>
                    {sourceIcons[notification.source]}
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2">
                        {typeIcons[notification.type]}
                        <p className={cn(
                          "text-sm font-medium truncate",
                          notification.read && "text-muted-foreground"
                        )}>
                          {notification.title}
                        </p>
                      </div>
                      <div className="flex items-center gap-1 flex-shrink-0">
                        <Clock className="h-3 w-3 text-muted-foreground" />
                        <span className="text-[10px] text-muted-foreground">
                          {formatDistanceToNow(notification.timestamp, { addSuffix: true })}
                        </span>
                      </div>
                    </div>
                    
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                      {notification.description}
                    </p>

                    <div className="flex items-center gap-2 mt-2">
                      <Badge 
                        variant="outline" 
                        className={cn("text-[10px] capitalize", priorityColors[notification.priority])}
                      >
                        {notification.priority}
                      </Badge>
                      <Badge variant="outline" className="text-[10px] capitalize">
                        {notification.source}
                      </Badge>
                      
                      {notification.actions && notification.actions.length > 0 && (
                        <div className="flex gap-1 ml-auto">
                          {notification.actions.map((action, idx) => (
                            <Button
                              key={idx}
                              variant={action.primary ? 'default' : 'ghost'}
                              size="xs"
                              className="h-6 text-[10px]"
                              onClick={(e) => {
                                e.stopPropagation();
                                onActionClick(action);
                              }}
                            >
                              {action.label}
                              <ExternalLink className="h-3 w-3 ml-1" />
                            </Button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Unread indicator */}
                  {!notification.read && (
                    <div className="w-2 h-2 rounded-full bg-primary flex-shrink-0 mt-2" />
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
