import { useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { 
  ChartContainer, 
  ChartTooltip, 
  ChartTooltipContent,
  type ChartConfig 
} from '@/components/ui/chart';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  CartesianGrid,
  Legend,
  Area,
  AreaChart,
} from 'recharts';
import { 
  Activity, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  TrendingUp,
  AlertTriangle,
  BarChart3,
  RefreshCw,
  Zap,
  Target,
} from 'lucide-react';
import { useWorkflowAnalytics } from '@/hooks/useWorkflowAnalytics';
import { cn } from '@/lib/utils';

interface WorkflowAnalyticsDashboardProps {
  className?: string;
}

const chartConfig: ChartConfig = {
  completed: {
    label: 'Completed',
    color: 'hsl(var(--status-success))',
  },
  failed: {
    label: 'Failed',
    color: 'hsl(var(--status-error))',
  },
  cancelled: {
    label: 'Cancelled',
    color: 'hsl(var(--status-warning))',
  },
};

const COLORS = [
  'hsl(var(--primary))',
  'hsl(var(--accent))',
  'hsl(var(--status-success))',
  'hsl(var(--status-warning))',
  'hsl(var(--status-info))',
];

function formatDuration(ms: number): string {
  if (ms < 1000) return `${ms}ms`;
  if (ms < 60000) return `${Math.round(ms / 1000)}s`;
  if (ms < 3600000) return `${Math.round(ms / 60000)}m`;
  return `${(ms / 3600000).toFixed(1)}h`;
}

export function WorkflowAnalyticsDashboard({ className }: WorkflowAnalyticsDashboardProps) {
  const { analytics, isLoading, error, refresh, formattedDuration } = useWorkflowAnalytics();

  const statusData = useMemo(() => {
    if (!analytics) return [];
    return [
      { name: 'Completed', value: analytics.completedWorkflows, color: COLORS[2] },
      { name: 'Failed', value: analytics.failedWorkflows, color: 'hsl(var(--status-error))' },
      { name: 'Cancelled', value: analytics.cancelledWorkflows, color: COLORS[3] },
      { name: 'In Progress', value: analytics.inProgressWorkflows, color: COLORS[0] },
    ].filter(d => d.value > 0);
  }, [analytics]);

  const dailyChartData = useMemo(() => {
    if (!analytics?.dailyStats) return [];
    return analytics.dailyStats.map(d => ({
      date: new Date(d.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      completed: d.completed,
      failed: d.failed,
      cancelled: d.cancelled,
    }));
  }, [analytics]);

  if (isLoading) {
    return (
      <div className={cn("flex items-center justify-center h-64", className)}>
        <RefreshCw className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (error) {
    return (
      <div className={cn("flex flex-col items-center justify-center h-64 gap-4", className)}>
        <AlertTriangle className="w-8 h-8 text-status-error" />
        <p className="text-muted-foreground">{error}</p>
        <Button variant="outline" size="sm" onClick={refresh}>
          <RefreshCw className="w-4 h-4 mr-2" />
          Retry
        </Button>
      </div>
    );
  }

  if (!analytics || analytics.totalWorkflows === 0) {
    return (
      <div className={cn("flex flex-col items-center justify-center h-64 gap-4", className)}>
        <BarChart3 className="w-12 h-12 text-muted-foreground/50" />
        <div className="text-center">
          <p className="text-muted-foreground">No workflow data yet</p>
          <p className="text-sm text-muted-foreground/70">Run some workflows to see analytics</p>
        </div>
      </div>
    );
  }

  return (
    <div className={cn("space-y-6", className)}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold">Workflow Analytics</h2>
          <p className="text-sm text-muted-foreground">Track performance and identify bottlenecks</p>
        </div>
        <Button variant="outline" size="sm" onClick={refresh}>
          <RefreshCw className="w-4 h-4 mr-2" />
          Refresh
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-card/50">
          <CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <Activity className="w-5 h-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{analytics.totalWorkflows}</p>
                <p className="text-xs text-muted-foreground">Total Workflows</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card/50">
          <CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-status-success/10">
                <Target className="w-5 h-5 text-status-success" />
              </div>
              <div>
                <p className="text-2xl font-bold">{analytics.successRate}%</p>
                <p className="text-xs text-muted-foreground">Success Rate</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card/50">
          <CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-accent/10">
                <Clock className="w-5 h-5 text-accent" />
              </div>
              <div>
                <p className="text-2xl font-bold">{formattedDuration}</p>
                <p className="text-xs text-muted-foreground">Avg Duration</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card/50">
          <CardContent className="pt-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-status-info/10">
                <Zap className="w-5 h-5 text-status-info" />
              </div>
              <div>
                <p className="text-2xl font-bold">{analytics.averagePhaseCount}</p>
                <p className="text-xs text-muted-foreground">Avg Phases</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList className="bg-muted/50">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="trends">Trends</TabsTrigger>
          <TabsTrigger value="failures">Failure Analysis</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Status Distribution */}
            <Card className="bg-card/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Status Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[200px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={statusData}
                        cx="50%"
                        cy="50%"
                        innerRadius={50}
                        outerRadius={80}
                        paddingAngle={2}
                        dataKey="value"
                      >
                        {statusData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Legend />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Completion Stats */}
            <Card className="bg-card/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Completion Breakdown</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-status-success" />
                      <span>Completed</span>
                    </div>
                    <span className="font-medium">{analytics.completedWorkflows}</span>
                  </div>
                  <Progress 
                    value={(analytics.completedWorkflows / analytics.totalWorkflows) * 100} 
                    className="h-2 bg-muted"
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <XCircle className="w-4 h-4 text-status-error" />
                      <span>Failed</span>
                    </div>
                    <span className="font-medium">{analytics.failedWorkflows}</span>
                  </div>
                  <Progress 
                    value={(analytics.failedWorkflows / analytics.totalWorkflows) * 100} 
                    className="h-2 bg-muted [&>div]:bg-status-error"
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-status-warning" />
                      <span>Cancelled</span>
                    </div>
                    <span className="font-medium">{analytics.cancelledWorkflows}</span>
                  </div>
                  <Progress 
                    value={(analytics.cancelledWorkflows / analytics.totalWorkflows) * 100} 
                    className="h-2 bg-muted [&>div]:bg-status-warning"
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-status-info" />
                      <span>In Progress</span>
                    </div>
                    <span className="font-medium">{analytics.inProgressWorkflows}</span>
                  </div>
                  <Progress 
                    value={(analytics.inProgressWorkflows / analytics.totalWorkflows) * 100} 
                    className="h-2 bg-muted [&>div]:bg-status-info"
                  />
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="trends" className="space-y-4">
          <Card className="bg-card/50">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Daily Workflow Activity (Last 30 Days)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ChartContainer config={chartConfig}>
                  <AreaChart data={dailyChartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis 
                      dataKey="date" 
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={12}
                    />
                    <YAxis 
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={12}
                    />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Area 
                      type="monotone" 
                      dataKey="completed" 
                      stackId="1"
                      stroke="hsl(var(--status-success))" 
                      fill="hsl(var(--status-success) / 0.3)"
                    />
                    <Area 
                      type="monotone" 
                      dataKey="failed" 
                      stackId="1"
                      stroke="hsl(var(--status-error))" 
                      fill="hsl(var(--status-error) / 0.3)"
                    />
                    <Area 
                      type="monotone" 
                      dataKey="cancelled" 
                      stackId="1"
                      stroke="hsl(var(--status-warning))" 
                      fill="hsl(var(--status-warning) / 0.3)"
                    />
                    <Legend />
                  </AreaChart>
                </ChartContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="failures" className="space-y-4">
          <Card className="bg-card/50">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Common Failure Points</CardTitle>
              <CardDescription>Most frequent errors by phase</CardDescription>
            </CardHeader>
            <CardContent>
              {analytics.failurePoints.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <CheckCircle2 className="w-8 h-8 text-status-success mb-2" />
                  <p className="text-muted-foreground">No failures recorded</p>
                  <p className="text-sm text-muted-foreground/70">Great job!</p>
                </div>
              ) : (
                <ScrollArea className="h-[300px]">
                  <div className="space-y-3">
                    {analytics.failurePoints.map((fp, index) => (
                      <div 
                        key={index} 
                        className="p-3 rounded-lg bg-muted/30 border border-border/50"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <Badge variant="outline" className="text-xs capitalize">
                                {fp.phase}
                              </Badge>
                              <Badge variant="destructive" className="text-xs">
                                {fp.count} failures
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground truncate">
                              {fp.errorMessage}
                            </p>
                          </div>
                        </div>
                        <p className="text-xs text-muted-foreground/70 mt-2">
                          Last occurred: {fp.lastOccurred.toLocaleDateString()}
                        </p>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              )}
            </CardContent>
          </Card>

          <Card className="bg-card/50">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Phase Success Rates</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart 
                    data={analytics.phaseStats.map(p => ({
                      phase: p.phase,
                      success: p.successCount,
                      failure: p.failureCount,
                    }))}
                    layout="vertical"
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis type="number" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                    <YAxis 
                      type="category" 
                      dataKey="phase" 
                      stroke="hsl(var(--muted-foreground))" 
                      fontSize={12}
                      width={100}
                    />
                    <ChartTooltip content={<ChartTooltipContent />} />
                    <Bar dataKey="success" fill="hsl(var(--status-success))" stackId="a" />
                    <Bar dataKey="failure" fill="hsl(var(--status-error))" stackId="a" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="templates" className="space-y-4">
          <Card className="bg-card/50">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Template Usage</CardTitle>
              <CardDescription>Which workflow templates are used most</CardDescription>
            </CardHeader>
            <CardContent>
              {analytics.templateUsage.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <Zap className="w-8 h-8 text-muted-foreground/50 mb-2" />
                  <p className="text-muted-foreground">No template data</p>
                </div>
              ) : (
                <div className="h-[250px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={analytics.templateUsage}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis 
                        dataKey="templateName" 
                        stroke="hsl(var(--muted-foreground))"
                        fontSize={12}
                        angle={-45}
                        textAnchor="end"
                        height={80}
                      />
                      <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                      <ChartTooltip content={<ChartTooltipContent />} />
                      <Bar 
                        dataKey="count" 
                        fill="hsl(var(--primary))"
                        radius={[4, 4, 0, 0]}
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
