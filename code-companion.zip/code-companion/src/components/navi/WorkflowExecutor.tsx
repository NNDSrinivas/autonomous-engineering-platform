import { useState, useEffect } from 'react';
import { useWorkflowEngine } from '@/hooks/useWorkflowEngine';
import { WorkflowTemplate, WorkflowStep, WorkflowStatus } from '@/types/workflow';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { AgentActivityPanel } from './AgentActivityPanel';
import { useAgentActivity } from '@/hooks/useAgentActivity';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Play,
  Pause,
  Square,
  RotateCcw,
  CheckCircle2,
  XCircle,
  Clock,
  Loader2,
  AlertTriangle,
  ChevronRight,
  GitBranch,
  GitPullRequest,
  FileCode,
  TestTube,
  Rocket,
  MessageSquare,
  CheckSquare,
  Zap,
  SkipForward,
} from 'lucide-react';
import { cn } from '@/lib/utils';

const stepIcons: Record<string, React.ReactNode> = {
  create_branch: <GitBranch className="h-4 w-4" />,
  create_pr: <GitPullRequest className="h-4 w-4" />,
  update_file: <FileCode className="h-4 w-4" />,
  commit_changes: <CheckSquare className="h-4 w-4" />,
  run_tests: <TestTube className="h-4 w-4" />,
  run_build: <Zap className="h-4 w-4" />,
  merge_pr: <GitPullRequest className="h-4 w-4" />,
  deploy: <Rocket className="h-4 w-4" />,
  notify_slack: <MessageSquare className="h-4 w-4" />,
  update_jira: <CheckSquare className="h-4 w-4" />,
  custom: <Zap className="h-4 w-4" />,
};

const statusColors: Record<string, string> = {
  pending: 'bg-muted text-muted-foreground',
  awaiting_approval: 'bg-status-warning/20 text-status-warning border-status-warning/30',
  approved: 'bg-primary/20 text-primary border-primary/30',
  executing: 'bg-primary/20 text-primary border-primary/30',
  completed: 'bg-status-success/20 text-status-success border-status-success/30',
  failed: 'bg-status-error/20 text-status-error border-status-error/30',
  skipped: 'bg-muted text-muted-foreground',
};

const workflowStatusColors: Record<WorkflowStatus, string> = {
  idle: 'bg-muted',
  running: 'bg-primary',
  paused: 'bg-status-warning',
  completed: 'bg-status-success',
  failed: 'bg-status-error',
  cancelled: 'bg-muted',
};

interface WorkflowExecutorProps {
  className?: string;
  onClose?: () => void;
}

export function WorkflowExecutor({ className, onClose }: WorkflowExecutorProps) {
  const [showTemplateSelector, setShowTemplateSelector] = useState(true);
  const [approvalDialogOpen, setApprovalDialogOpen] = useState(false);
  
  // Agent activity for visual feedback
  const agentActivity = useAgentActivity();
  
  const {
    workflow,
    isExecuting,
    pendingApprovalStep,
    templates,
    createWorkflow,
    startWorkflow,
    pauseWorkflow,
    resumeWorkflow,
    cancelWorkflow,
    resetWorkflow,
    approveStep,
    rejectStep,
    getProgress,
  } = useWorkflowEngine({
    onStepApprovalRequired: () => {
      setApprovalDialogOpen(true);
    },
    onWorkflowCompleted: () => {
      agentActivity.completeActivity();
    },
  });

  // Sync agent activity with workflow state
  useEffect(() => {
    agentActivity.syncWithWorkflow(workflow);
  }, [workflow]);

  const handleSelectTemplate = (template: WorkflowTemplate) => {
    createWorkflow(template, {
      taskKey: 'NAVI-123',
      repoOwner: 'your-org',
      repoName: 'your-repo',
      branch: `feature/navi-${Date.now()}`,
      targetBranch: 'main',
    });
    setShowTemplateSelector(false);
  };

  const handleApprove = async () => {
    if (pendingApprovalStep) {
      await approveStep(pendingApprovalStep.id);
      setApprovalDialogOpen(false);
    }
  };

  const handleReject = () => {
    if (pendingApprovalStep) {
      rejectStep(pendingApprovalStep.id);
      setApprovalDialogOpen(false);
    }
  };

  const handleReset = () => {
    resetWorkflow();
    agentActivity.resetActivity();
    setShowTemplateSelector(true);
  };

  const handleStart = () => {
    agentActivity.startActivity(`Starting workflow: ${workflow?.name}`);
    startWorkflow();
  };

  const getStepStatusIcon = (step: WorkflowStep) => {
    switch (step.status) {
      case 'completed':
        return <CheckCircle2 className="h-4 w-4 text-status-success" />;
      case 'failed':
        return <XCircle className="h-4 w-4 text-status-error" />;
      case 'executing':
        return <Loader2 className="h-4 w-4 text-primary animate-spin" />;
      case 'awaiting_approval':
        return <AlertTriangle className="h-4 w-4 text-status-warning" />;
      case 'skipped':
        return <SkipForward className="h-4 w-4 text-muted-foreground" />;
      default:
        return <Clock className="h-4 w-4 text-muted-foreground" />;
    }
  };

  if (showTemplateSelector) {
    return (
      <Card className={cn("border-border/50", className)}>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Zap className="h-5 w-5 text-primary" />
            Autonomous Workflow Engine
          </CardTitle>
          <CardDescription>
            Select a workflow template to automate engineering tasks
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3">
            {templates.map((template) => (
              <button
                key={template.id}
                onClick={() => handleSelectTemplate(template)}
                className="w-full text-left p-4 rounded-lg border border-border/50 hover:border-primary/50 hover:bg-secondary/50 transition-all group"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{template.name}</span>
                      <Badge variant="outline" className="text-[10px] capitalize">
                        {template.category}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">
                      {template.description}
                    </p>
                    <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground">
                      <span>{template.steps.length} steps</span>
                      <span>•</span>
                      <span>
                        {template.steps.filter(s => s.requiresApproval).length} approval checkpoints
                      </span>
                    </div>
                  </div>
                  <ChevronRight className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors" />
                </div>
              </button>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card className={cn("border-border/50", className)}>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg flex items-center gap-2">
                <Zap className="h-5 w-5 text-primary" />
                {workflow?.name || 'Workflow'}
              </CardTitle>
              <CardDescription className="mt-1">
                {workflow?.description}
              </CardDescription>
            </div>
            {workflow && (
              <Badge 
                variant="outline" 
                className={cn(
                  "text-[10px] uppercase",
                  workflow.status === 'running' && 'bg-primary/20 text-primary border-primary/30',
                  workflow.status === 'completed' && 'bg-status-success/20 text-status-success border-status-success/30',
                  workflow.status === 'failed' && 'bg-status-error/20 text-status-error border-status-error/30',
                  workflow.status === 'paused' && 'bg-status-warning/20 text-status-warning border-status-warning/30',
                )}
              >
                {workflow.status}
              </Badge>
            )}
          </div>
        </CardHeader>
        
        <CardContent className="space-y-4">
          {/* Progress bar */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Progress</span>
              <span className="font-medium">{getProgress()}%</span>
            </div>
            <Progress value={getProgress()} className="h-2" />
          </div>

          <Separator />

          {/* Steps list */}
          <ScrollArea className="h-[300px] pr-4">
            <div className="space-y-2">
              {workflow?.steps.map((step, index) => (
                <div
                  key={step.id}
                  className={cn(
                    "p-3 rounded-lg border transition-all",
                    step.status === 'executing' && 'border-primary bg-primary/5',
                    step.status === 'awaiting_approval' && 'border-status-warning bg-status-warning/5',
                    step.status === 'completed' && 'border-status-success/30 bg-status-success/5',
                    step.status === 'failed' && 'border-status-error/30 bg-status-error/5',
                    step.status === 'pending' && 'border-border/50 opacity-60',
                    step.status === 'skipped' && 'border-border/30 opacity-50',
                  )}
                >
                  <div className="flex items-start gap-3">
                    <div className="mt-0.5 h-8 w-8 rounded-full bg-secondary flex items-center justify-center flex-shrink-0">
                      {stepIcons[step.actionType]}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-sm">{step.name}</span>
                        {step.requiresApproval && (
                          <Badge variant="outline" className="text-[9px] px-1.5">
                            Approval
                          </Badge>
                        )}
                        <Badge 
                          variant="outline" 
                          className={cn("text-[9px] px-1.5 ml-auto", statusColors[step.status])}
                        >
                          {step.status.replace('_', ' ')}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground mt-0.5">
                        {step.description}
                      </p>
                      {step.result && (
                        <p className={cn(
                          "text-xs mt-1",
                          step.result.success ? 'text-status-success' : 'text-status-error'
                        )}>
                          {step.result.message}
                        </p>
                      )}
                    </div>
                    <div className="flex-shrink-0">
                      {getStepStatusIcon(step)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>

          <Separator />

          {/* Agent Activity Panel */}
          {(workflow?.status === 'running' || workflow?.status === 'paused') && (
            <AgentActivityPanel
              isActive={agentActivity.isActive}
              phase={agentActivity.phase}
              currentThought={agentActivity.currentThought}
              files={agentActivity.files}
              steps={agentActivity.steps}
              totalEdits={agentActivity.totalEdits}
              linesChanged={agentActivity.linesChanged}
              tokensProcessed={agentActivity.tokensProcessed}
              onDismiss={() => agentActivity.resetActivity()}
            />
          )}

          {/* Control buttons */}
          <div className="flex items-center gap-2">
            {workflow?.status === 'idle' && (
              <Button onClick={handleStart} className="gap-2 flex-1">
                <Play className="h-4 w-4" />
                Start Workflow
              </Button>
            )}
            
            {workflow?.status === 'running' && !pendingApprovalStep && (
              <Button onClick={pauseWorkflow} variant="outline" className="gap-2 flex-1">
                <Pause className="h-4 w-4" />
                Pause
              </Button>
            )}
            
            {workflow?.status === 'paused' && (
              <Button onClick={resumeWorkflow} className="gap-2 flex-1">
                <Play className="h-4 w-4" />
                Resume
              </Button>
            )}
            
            {(workflow?.status === 'running' || workflow?.status === 'paused') && (
              <Button onClick={cancelWorkflow} variant="destructive" className="gap-2">
                <Square className="h-4 w-4" />
                Cancel
              </Button>
            )}
            
            {(workflow?.status === 'completed' || workflow?.status === 'failed' || workflow?.status === 'cancelled') && (
              <Button onClick={handleReset} variant="outline" className="gap-2 flex-1">
                <RotateCcw className="h-4 w-4" />
                New Workflow
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Approval Dialog */}
      <Dialog open={approvalDialogOpen} onOpenChange={setApprovalDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-status-warning" />
              Approval Required
            </DialogTitle>
            <DialogDescription>
              NAVI needs your approval to proceed with this action
            </DialogDescription>
          </DialogHeader>

          {pendingApprovalStep && (
            <div className="space-y-4 py-4">
              <div className="p-4 rounded-lg bg-secondary/50 space-y-2">
                <div className="flex items-center gap-2">
                  <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                    {stepIcons[pendingApprovalStep.actionType]}
                  </div>
                  <div>
                    <h4 className="font-medium">{pendingApprovalStep.name}</h4>
                    <p className="text-xs text-muted-foreground">
                      {pendingApprovalStep.description}
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Badge 
                  variant="outline" 
                  className={cn(
                    "text-[10px]",
                    pendingApprovalStep.riskLevel === 'high' && 'bg-status-error/20 text-status-error border-status-error/30',
                    pendingApprovalStep.riskLevel === 'medium' && 'bg-status-warning/20 text-status-warning border-status-warning/30',
                    pendingApprovalStep.riskLevel === 'low' && 'bg-status-success/20 text-status-success border-status-success/30',
                  )}
                >
                  {pendingApprovalStep.riskLevel} risk
                </Badge>
                <span className="text-xs text-muted-foreground">
                  Step {(workflow?.steps.findIndex(s => s.id === pendingApprovalStep.id) ?? 0) + 1} of {workflow?.steps.length}
                </span>
              </div>

              {pendingApprovalStep.riskLevel === 'high' && (
                <div className="flex items-start gap-2 p-3 rounded-lg bg-status-warning/10 border border-status-warning/30">
                  <AlertTriangle className="h-4 w-4 text-status-warning flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-status-warning">
                    This action has high risk. Please review carefully before approving.
                  </p>
                </div>
              )}
            </div>
          )}

          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={handleReject} className="gap-2">
              <SkipForward className="h-4 w-4" />
              Skip
            </Button>
            <Button onClick={handleApprove} className="gap-2">
              <CheckCircle2 className="h-4 w-4" />
              Approve & Execute
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
