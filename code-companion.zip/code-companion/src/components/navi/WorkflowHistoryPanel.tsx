import { useState } from 'react';
import { 
  History, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Loader2,
  GitPullRequest,
  GitBranch,
  ExternalLink,
  BarChart3,
  Timer,
  TrendingUp,
  AlertTriangle,
  Play,
  RefreshCw,
  ChevronDown,
  ChevronRight
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { useWorkflowHistory, WorkflowHistoryEntry } from '@/hooks/useWorkflowHistory';
import { cn } from '@/lib/utils';
import { formatDistanceToNow, format } from 'date-fns';

const statusConfig = {
  in_progress: { 
    icon: <Loader2 className="h-4 w-4 animate-spin" />, 
    color: 'text-blue-400 bg-blue-500/10 border-blue-500/20',
    label: 'In Progress'
  },
  completed: { 
    icon: <CheckCircle2 className="h-4 w-4" />, 
    color: 'text-green-400 bg-green-500/10 border-green-500/20',
    label: 'Completed'
  },
  failed: { 
    icon: <XCircle className="h-4 w-4" />, 
    color: 'text-red-400 bg-red-500/10 border-red-500/20',
    label: 'Failed'
  },
  cancelled: { 
    icon: <AlertTriangle className="h-4 w-4" />, 
    color: 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20',
    label: 'Cancelled'
  },
};

function formatDuration(ms: number): string {
  if (ms < 1000) return `${ms}ms`;
  if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`;
  if (ms < 3600000) return `${Math.floor(ms / 60000)}m ${Math.round((ms % 60000) / 1000)}s`;
  return `${Math.floor(ms / 3600000)}h ${Math.floor((ms % 3600000) / 60000)}m`;
}

interface WorkflowHistoryItemProps {
  entry: WorkflowHistoryEntry;
}

function WorkflowHistoryItem({ entry }: WorkflowHistoryItemProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const status = statusConfig[entry.status];

  return (
    <Collapsible open={isExpanded} onOpenChange={setIsExpanded}>
      <div className={cn(
        "border rounded-lg transition-colors",
        entry.status === 'in_progress' && "border-blue-500/30 bg-blue-500/5"
      )}>
        <CollapsibleTrigger asChild>
          <button className="w-full p-3 text-left hover:bg-secondary/50 rounded-lg transition-colors">
            <div className="flex items-start gap-3">
              <div className={cn("p-1.5 rounded-md border", status.color)}>
                {status.icon}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs font-mono text-primary">{entry.taskKey}</span>
                  <Badge variant="outline" className={cn("text-[10px] px-1.5 py-0", status.color)}>
                    {status.label}
                  </Badge>
                  {entry.templateName && (
                    <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
                      {entry.templateName}
                    </Badge>
                  )}
                </div>
                <h4 className="text-sm font-medium truncate">
                  {entry.taskTitle || 'Untitled Task'}
                </h4>
                <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {formatDistanceToNow(entry.startedAt, { addSuffix: true })}
                  </span>
                  {entry.durationMs && (
                    <span className="flex items-center gap-1">
                      <Timer className="h-3 w-3" />
                      {formatDuration(entry.durationMs)}
                    </span>
                  )}
                  {entry.prNumber && (
                    <span className="flex items-center gap-1">
                      <GitPullRequest className="h-3 w-3" />
                      #{entry.prNumber}
                    </span>
                  )}
                </div>
              </div>
              {isExpanded ? (
                <ChevronDown className="h-4 w-4 text-muted-foreground" />
              ) : (
                <ChevronRight className="h-4 w-4 text-muted-foreground" />
              )}
            </div>
          </button>
        </CollapsibleTrigger>

        <CollapsibleContent>
          <div className="px-3 pb-3 space-y-3">
            <Separator />
            
            {/* Phase Progress */}
            <div>
              <span className="text-[10px] uppercase text-muted-foreground tracking-wider">
                Phases Completed ({entry.phasesCompleted.length})
              </span>
              <div className="flex flex-wrap gap-1 mt-1">
                {entry.phasesCompleted.map((phase) => (
                  <Badge key={phase} variant="secondary" className="text-[10px]">
                    <CheckCircle2 className="h-2.5 w-2.5 mr-1 text-green-400" />
                    {phase.replace(/_/g, ' ')}
                  </Badge>
                ))}
                {entry.phasesSkipped.map((phase) => (
                  <Badge key={phase} variant="outline" className="text-[10px] opacity-50">
                    {phase.replace(/_/g, ' ')} (skipped)
                  </Badge>
                ))}
              </div>
            </div>

            {/* Links */}
            {(entry.branchName || entry.prUrl) && (
              <div className="flex flex-wrap gap-2">
                {entry.branchName && (
                  <Badge variant="outline" className="text-[10px] gap-1">
                    <GitBranch className="h-3 w-3" />
                    {entry.branchName}
                  </Badge>
                )}
                {entry.prUrl && (
                  <a
                    href={entry.prUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex"
                  >
                    <Badge variant="outline" className="text-[10px] gap-1 hover:bg-secondary cursor-pointer">
                      <GitPullRequest className="h-3 w-3" />
                      PR #{entry.prNumber}
                      <ExternalLink className="h-2.5 w-2.5" />
                    </Badge>
                  </a>
                )}
              </div>
            )}

            {/* Error Message */}
            {entry.errorMessage && (
              <div className="p-2 rounded-md bg-red-500/10 border border-red-500/20">
                <div className="flex items-center gap-2 text-xs text-red-400">
                  <XCircle className="h-3.5 w-3.5" />
                  <span className="font-medium">Error</span>
                </div>
                <p className="text-xs text-red-300/80 mt-1">{entry.errorMessage}</p>
              </div>
            )}

            {/* Timing Details */}
            {entry.completedAt && (
              <div className="text-[10px] text-muted-foreground">
                Started: {format(entry.startedAt, 'MMM d, yyyy h:mm a')}
                <br />
                Completed: {format(entry.completedAt, 'MMM d, yyyy h:mm a')}
              </div>
            )}
          </div>
        </CollapsibleContent>
      </div>
    </Collapsible>
  );
}

interface WorkflowHistoryPanelProps {
  className?: string;
}

export function WorkflowHistoryPanel({ className }: WorkflowHistoryPanelProps) {
  const { history, stats, isLoading, refresh } = useWorkflowHistory();

  return (
    <div className={cn("flex flex-col h-full", className)}>
      {/* Stats Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold flex items-center gap-2">
            <History className="h-4 w-4 text-primary" />
            Workflow History
          </h3>
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-7 w-7"
            onClick={() => refresh()}
            disabled={isLoading}
          >
            <RefreshCw className={cn("h-4 w-4", isLoading && "animate-spin")} />
          </Button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-2">
          <Card className="bg-secondary/30">
            <CardContent className="p-2">
              <div className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-lg font-bold">{stats.totalWorkflows}</p>
                  <p className="text-[10px] text-muted-foreground">Total Runs</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-secondary/30">
            <CardContent className="p-2">
              <div className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-green-400" />
                <div>
                  <p className="text-lg font-bold">{stats.successRate}%</p>
                  <p className="text-[10px] text-muted-foreground">Success Rate</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-secondary/30">
            <CardContent className="p-2">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-green-400" />
                <div>
                  <p className="text-lg font-bold">{stats.completedWorkflows}</p>
                  <p className="text-[10px] text-muted-foreground">Completed</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-secondary/30">
            <CardContent className="p-2">
              <div className="flex items-center gap-2">
                <Timer className="h-4 w-4 text-muted-foreground" />
                <div>
                  <p className="text-lg font-bold">
                    {stats.averageDurationMs > 0 ? formatDuration(stats.averageDurationMs) : '-'}
                  </p>
                  <p className="text-[10px] text-muted-foreground">Avg Time</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* History List */}
      <ScrollArea className="flex-1">
        <div className="p-4 space-y-2">
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : history.length === 0 ? (
            <div className="text-center py-8">
              <Play className="h-10 w-10 mx-auto text-muted-foreground/50 mb-2" />
              <p className="text-sm text-muted-foreground">No workflow history yet</p>
              <p className="text-xs text-muted-foreground/70 mt-1">
                Start a workflow to see it here
              </p>
            </div>
          ) : (
            history.map((entry) => (
              <WorkflowHistoryItem key={entry.id} entry={entry} />
            ))
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
