import { Loader2, CheckCircle2, Play, GitBranch, Code, GitPullRequest, Link, MessageSquare } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipTrigger } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';
import type { WorkflowPhase } from '@/hooks/useEndToEndWorkflow';
import type { ActiveWorkflow } from '@/types/workflowTemplates';

const phaseIcons: Record<WorkflowPhase, React.ReactNode> = {
  idle: null,
  start_task: <Play className="h-2.5 w-2.5" />,
  create_branch: <GitBranch className="h-2.5 w-2.5" />,
  implement_code: <Code className="h-2.5 w-2.5" />,
  create_pr: <GitPullRequest className="h-2.5 w-2.5" />,
  link_jira: <Link className="h-2.5 w-2.5" />,
  post_slack: <MessageSquare className="h-2.5 w-2.5" />,
  completed: <CheckCircle2 className="h-2.5 w-2.5" />,
  failed: null,
};

const phaseLabels: Record<WorkflowPhase, string> = {
  idle: 'Ready',
  start_task: 'Starting',
  create_branch: 'Branch',
  implement_code: 'Coding',
  create_pr: 'PR',
  link_jira: 'Jira',
  post_slack: 'Slack',
  completed: 'Done',
  failed: 'Failed',
};

interface WorkflowProgressIndicatorProps {
  workflow: ActiveWorkflow;
  variant?: 'compact' | 'inline' | 'badge';
  className?: string;
}

export function WorkflowProgressIndicator({ 
  workflow, 
  variant = 'compact',
  className 
}: WorkflowProgressIndicatorProps) {
  if (variant === 'badge') {
    return (
      <Tooltip>
        <TooltipTrigger asChild>
          <Badge 
            variant="outline" 
            className={cn(
              "gap-1 px-1.5 py-0.5 text-[10px] bg-primary/10 border-primary/30 text-primary animate-pulse",
              className
            )}
          >
            <Loader2 className="h-2.5 w-2.5 animate-spin" />
            {phaseLabels[workflow.currentPhase]}
          </Badge>
        </TooltipTrigger>
        <TooltipContent side="top" className="text-xs">
          <div className="space-y-1">
            <p className="font-medium">Workflow in progress</p>
            <p className="text-muted-foreground">
              {workflow.progress}% complete
            </p>
          </div>
        </TooltipContent>
      </Tooltip>
    );
  }

  if (variant === 'inline') {
    return (
      <div className={cn("flex items-center gap-2", className)}>
        <div className="flex items-center gap-1 text-primary">
          <Loader2 className="h-3 w-3 animate-spin" />
          <span className="text-[10px] font-medium">
            {phaseLabels[workflow.currentPhase]}
          </span>
        </div>
        <Progress value={workflow.progress} className="h-1 flex-1 max-w-[60px]" />
        <span className="text-[10px] text-muted-foreground">{workflow.progress}%</span>
      </div>
    );
  }

  // Compact variant (default)
  return (
    <div className={cn("space-y-1.5", className)}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <div className="h-4 w-4 rounded bg-primary/20 flex items-center justify-center text-primary">
            {phaseIcons[workflow.currentPhase] || <Loader2 className="h-2.5 w-2.5 animate-spin" />}
          </div>
          <span className="text-[10px] font-medium text-primary">
            {phaseLabels[workflow.currentPhase]}
          </span>
        </div>
        <span className="text-[10px] text-muted-foreground">{workflow.progress}%</span>
      </div>
      <Progress value={workflow.progress} className="h-1" />
    </div>
  );
}
