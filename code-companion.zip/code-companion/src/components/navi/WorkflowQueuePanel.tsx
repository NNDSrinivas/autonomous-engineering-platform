import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { BatchTaskSelector } from './BatchTaskSelector';
import { 
  Play, 
  Pause, 
  Trash2, 
  MoreVertical,
  Clock,
  AlertCircle,
  CheckCircle2,
  XCircle,
  ArrowUp,
  ArrowDown,
  Plus,
  Settings,
  ListOrdered,
  RefreshCw,
  Loader2,
  GripVertical,
} from 'lucide-react';
import { useWorkflowQueue, type QueuedTask } from '@/hooks/useWorkflowQueue';
import { cn } from '@/lib/utils';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

interface WorkflowQueuePanelProps {
  className?: string;
  onStartTask?: (task: QueuedTask) => void;
}

const priorityConfig = {
  high: { label: 'High', color: 'text-status-error', bg: 'bg-status-error/10' },
  medium: { label: 'Medium', color: 'text-status-warning', bg: 'bg-status-warning/10' },
  low: { label: 'Low', color: 'text-muted-foreground', bg: 'bg-muted' },
};

const statusConfig = {
  queued: { icon: Clock, label: 'Queued', color: 'text-muted-foreground' },
  running: { icon: Loader2, label: 'Running', color: 'text-primary' },
  completed: { icon: CheckCircle2, label: 'Completed', color: 'text-status-success' },
  failed: { icon: XCircle, label: 'Failed', color: 'text-status-error' },
  paused: { icon: Pause, label: 'Paused', color: 'text-status-warning' },
};

function formatTimeAgo(date: Date): string {
  const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
  if (seconds < 60) return 'Just now';
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  return `${Math.floor(seconds / 86400)}d ago`;
}

interface SortableQueueItemProps {
  task: QueuedTask;
  onRemove: () => void;
  onUpdatePriority: (priority: 'high' | 'medium' | 'low') => void;
  onRetry: () => void;
}

function SortableQueueItem({ 
  task, 
  onRemove, 
  onUpdatePriority,
  onRetry,
}: SortableQueueItemProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: task.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  const StatusIcon = statusConfig[task.status].icon;
  const priority = priorityConfig[task.priority];

  return (
    <div 
      ref={setNodeRef}
      style={style}
      className={cn(
        "group p-3 rounded-lg border border-border/50 bg-card/30 hover:bg-card/50 transition-colors",
        task.status === 'running' && "border-primary/50 bg-primary/5",
        isDragging && "opacity-50 shadow-lg z-50"
      )}
    >
      <div className="flex items-start gap-3">
        {/* Drag Handle */}
        {task.status === 'queued' && (
          <div 
            {...attributes}
            {...listeners}
            className="cursor-grab active:cursor-grabbing opacity-0 group-hover:opacity-100 transition-opacity flex items-center"
          >
            <GripVertical className="w-4 h-4 text-muted-foreground" />
          </div>
        )}

        {/* Status Icon */}
        <StatusIcon className={cn(
          "w-5 h-5 mt-0.5 flex-shrink-0",
          statusConfig[task.status].color,
          task.status === 'running' && "animate-spin"
        )} />

        {/* Task Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className="font-medium text-sm">{task.taskKey}</span>
            <Badge 
              variant="outline" 
              className={cn("text-xs", priority.color, priority.bg)}
            >
              {priority.label}
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground truncate">{task.taskTitle}</p>
          
          <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground/70">
            <span>Added {formatTimeAgo(task.addedAt)}</span>
            {task.templateName && (
              <span className="truncate">Template: {task.templateName}</span>
            )}
            {task.retryCount > 0 && (
              <Badge variant="outline" className="text-xs">
                Retry {task.retryCount}/{task.maxRetries}
              </Badge>
            )}
          </div>

          {task.errorMessage && task.status === 'failed' && (
            <div className="mt-2 p-2 rounded bg-status-error/10 text-status-error text-xs">
              {task.errorMessage}
            </div>
          )}
        </div>

        {/* Actions */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <MoreVertical className="w-4 h-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            {task.status === 'queued' && (
              <>
                <DropdownMenuItem onClick={() => onUpdatePriority('high')}>
                  <ArrowUp className="w-4 h-4 mr-2 text-status-error" />
                  Set High Priority
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onUpdatePriority('medium')}>
                  <ArrowUp className="w-4 h-4 mr-2 text-status-warning" />
                  Set Medium Priority
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onUpdatePriority('low')}>
                  <ArrowDown className="w-4 h-4 mr-2" />
                  Set Low Priority
                </DropdownMenuItem>
                <DropdownMenuSeparator />
              </>
            )}
            {task.status === 'failed' && (
              <DropdownMenuItem onClick={onRetry}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Retry Task
              </DropdownMenuItem>
            )}
            <DropdownMenuItem onClick={onRemove} className="text-status-error">
              <Trash2 className="w-4 h-4 mr-2" />
              Remove from Queue
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}

function QueueItem({ 
  task, 
  onRemove, 
  onUpdatePriority,
  onRetry,
}: { 
  task: QueuedTask;
  onRemove: () => void;
  onUpdatePriority: (priority: 'high' | 'medium' | 'low') => void;
  onRetry: () => void;
}) {
  const StatusIcon = statusConfig[task.status].icon;
  const priority = priorityConfig[task.priority];

  return (
    <div className={cn(
      "group p-3 rounded-lg border border-border/50 bg-card/30 hover:bg-card/50 transition-colors",
      task.status === 'running' && "border-primary/50 bg-primary/5"
    )}>
      <div className="flex items-start gap-3">
        {/* Status Icon */}
        <StatusIcon className={cn(
          "w-5 h-5 mt-0.5 flex-shrink-0",
          statusConfig[task.status].color,
          task.status === 'running' && "animate-spin"
        )} />

        {/* Task Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className="font-medium text-sm">{task.taskKey}</span>
            <Badge 
              variant="outline" 
              className={cn("text-xs", priority.color, priority.bg)}
            >
              {priority.label}
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground truncate">{task.taskTitle}</p>
          
          <div className="flex items-center gap-3 mt-2 text-xs text-muted-foreground/70">
            <span>Added {formatTimeAgo(task.addedAt)}</span>
            {task.templateName && (
              <span className="truncate">Template: {task.templateName}</span>
            )}
            {task.retryCount > 0 && (
              <Badge variant="outline" className="text-xs">
                Retry {task.retryCount}/{task.maxRetries}
              </Badge>
            )}
          </div>

          {task.errorMessage && task.status === 'failed' && (
            <div className="mt-2 p-2 rounded bg-status-error/10 text-status-error text-xs">
              {task.errorMessage}
            </div>
          )}
        </div>

        {/* Actions */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <MoreVertical className="w-4 h-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            {task.status === 'failed' && (
              <DropdownMenuItem onClick={onRetry}>
                <RefreshCw className="w-4 h-4 mr-2" />
                Retry Task
              </DropdownMenuItem>
            )}
            <DropdownMenuItem onClick={onRemove} className="text-status-error">
              <Trash2 className="w-4 h-4 mr-2" />
              Remove from Queue
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}

export function WorkflowQueuePanel({ className, onStartTask }: WorkflowQueuePanelProps) {
  const {
    queue,
    isPaused,
    stats,
    settings,
    removeFromQueue,
    clearCompleted,
    clearQueue,
    updatePriority,
    reorderTask,
    pauseQueue,
    resumeQueue,
    updateSettings,
    retryTask,
  } = useWorkflowQueue();

  const [showSettings, setShowSettings] = useState(false);

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const queuedTasks = queue.filter(t => t.status === 'queued');
  const runningTasks = queue.filter(t => t.status === 'running');
  const completedTasks = queue.filter(t => t.status === 'completed' || t.status === 'failed');

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      const oldIndex = queuedTasks.findIndex((t) => t.id === active.id);
      const newIndex = queuedTasks.findIndex((t) => t.id === over.id);
      
      if (oldIndex !== -1 && newIndex !== -1) {
        reorderTask(active.id as string, newIndex);
      }
    }
  };

  return (
    <div className={cn("space-y-4", className)}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <ListOrdered className="w-5 h-5" />
            Workflow Queue
          </h2>
          <p className="text-sm text-muted-foreground">
            {stats.queued} queued • {stats.running} running • {stats.completed} completed
          </p>
        </div>
        
        {/* Batch Task Selector */}
        <BatchTaskSelector />
      </div>
      
      {/* Queue Controls */}
      <div className="flex items-center gap-2">
        <Dialog open={showSettings} onOpenChange={setShowSettings}>
          <DialogTrigger asChild>
            <Button variant="outline" size="sm">
              <Settings className="w-4 h-4 mr-2" />
              Settings
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Queue Settings</DialogTitle>
              <DialogDescription>
                Configure how the workflow queue behaves
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="pause-on-failure">Pause on failure</Label>
                <Switch
                  id="pause-on-failure"
                  checked={settings.pauseOnFailure}
                  onCheckedChange={(checked) => updateSettings({ pauseOnFailure: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <Label htmlFor="auto-retry">Auto-retry failed tasks</Label>
                <Switch
                  id="auto-retry"
                  checked={settings.autoRetry}
                  onCheckedChange={(checked) => updateSettings({ autoRetry: checked })}
                />
              </div>

              {settings.autoRetry && (
                <div className="space-y-2">
                  <Label htmlFor="retry-delay">Retry delay (seconds)</Label>
                  <Input
                    id="retry-delay"
                    type="number"
                    min={1}
                    max={300}
                    value={settings.retryDelayMs / 1000}
                    onChange={(e) => updateSettings({ 
                      retryDelayMs: parseInt(e.target.value) * 1000 
                    })}
                  />
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="max-concurrent">Max concurrent workflows</Label>
                <Select
                  value={String(settings.maxConcurrent)}
                  onValueChange={(value) => updateSettings({ maxConcurrent: parseInt(value) })}
                >
                  <SelectTrigger id="max-concurrent">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1 (Sequential)</SelectItem>
                    <SelectItem value="2">2</SelectItem>
                    <SelectItem value="3">3</SelectItem>
                    <SelectItem value="5">5</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setShowSettings(false)}>
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {isPaused ? (
          <Button size="sm" onClick={resumeQueue} className="gap-2">
            <Play className="w-4 h-4" />
            Resume
          </Button>
        ) : (
          <Button size="sm" variant="outline" onClick={pauseQueue} className="gap-2">
            <Pause className="w-4 h-4" />
            Pause
          </Button>
        )}
      </div>

      {/* Paused Banner */}
      {isPaused && (
        <Card className="bg-status-warning/10 border-status-warning/30">
          <CardContent className="py-3">
            <div className="flex items-center gap-2 text-status-warning">
              <Pause className="w-4 h-4" />
              <span className="text-sm font-medium">Queue is paused</span>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Queue Empty State */}
      {queue.length === 0 && (
        <Card className="bg-card/50">
          <CardContent className="py-12">
            <div className="flex flex-col items-center justify-center text-center">
              <ListOrdered className="w-12 h-12 text-muted-foreground/30 mb-4" />
              <p className="text-muted-foreground">No tasks in queue</p>
              <p className="text-sm text-muted-foreground/70">
                Add Jira tasks to start autonomous execution
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Running Tasks */}
      {runningTasks.length > 0 && (
        <Card className="bg-card/50 border-primary/30">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Loader2 className="w-4 h-4 animate-spin text-primary" />
              Running ({runningTasks.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {runningTasks.map(task => (
              <QueueItem
                key={task.id}
                task={task}
                onRemove={() => removeFromQueue(task.id)}
                onUpdatePriority={(p) => updatePriority(task.id, p)}
                onRetry={() => retryTask(task.id)}
              />
            ))}
          </CardContent>
        </Card>
      )}

      {/* Queued Tasks with Drag & Drop */}
      {queuedTasks.length > 0 && (
        <Card className="bg-card/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Clock className="w-4 h-4" />
              Queued ({queuedTasks.length})
              <span className="text-xs text-muted-foreground font-normal ml-2">
                Drag to reorder
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="max-h-[400px]">
              <DndContext
                sensors={sensors}
                collisionDetection={closestCenter}
                onDragEnd={handleDragEnd}
              >
                <SortableContext
                  items={queuedTasks.map(t => t.id)}
                  strategy={verticalListSortingStrategy}
                >
                  <div className="space-y-2">
                    {queuedTasks.map((task) => (
                      <SortableQueueItem
                        key={task.id}
                        task={task}
                        onRemove={() => removeFromQueue(task.id)}
                        onUpdatePriority={(p) => updatePriority(task.id, p)}
                        onRetry={() => retryTask(task.id)}
                      />
                    ))}
                  </div>
                </SortableContext>
              </DndContext>
            </ScrollArea>
          </CardContent>
        </Card>
      )}

      {/* Completed Tasks */}
      {completedTasks.length > 0 && (
        <Card className="bg-card/50">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4" />
                Completed ({completedTasks.length})
              </CardTitle>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={clearCompleted}
                className="text-xs"
              >
                Clear All
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <ScrollArea className="max-h-[200px]">
              <div className="space-y-2">
                {completedTasks.slice(0, 10).map(task => (
                  <QueueItem
                    key={task.id}
                    task={task}
                    onRemove={() => removeFromQueue(task.id)}
                    onUpdatePriority={(p) => updatePriority(task.id, p)}
                    onRetry={() => retryTask(task.id)}
                  />
                ))}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>
      )}

      {/* Clear All Button */}
      {queue.length > 0 && (
        <div className="flex justify-end">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={clearQueue}
            className="text-muted-foreground hover:text-status-error"
          >
            <Trash2 className="w-4 h-4 mr-2" />
            Clear Entire Queue
          </Button>
        </div>
      )}
    </div>
  );
}
