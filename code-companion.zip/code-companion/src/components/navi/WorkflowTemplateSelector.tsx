import { useState } from 'react';
import { 
  Zap, 
  GitPullRequest, 
  Code, 
  MessageSquare, 
  CheckCircle,
  ChevronRight,
  Settings2,
  Check,
  Save,
  Trash2,
  Loader2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';
import { useWorkflowTemplates } from '@/hooks/useWorkflowTemplates';
import type { WorkflowTemplate } from '@/types/workflowTemplates';
import type { WorkflowPhase } from '@/hooks/useEndToEndWorkflow';

const iconMap: Record<string, React.ReactNode> = {
  Zap: <Zap className="h-4 w-4" />,
  GitPullRequest: <GitPullRequest className="h-4 w-4" />,
  Code: <Code className="h-4 w-4" />,
  MessageSquare: <MessageSquare className="h-4 w-4" />,
  CheckCircle: <CheckCircle className="h-4 w-4" />,
  Settings2: <Settings2 className="h-4 w-4" />,
};

const phaseLabels: Record<WorkflowPhase, string> = {
  idle: 'Ready',
  start_task: 'Start Task',
  create_branch: 'Create Branch',
  implement_code: 'Implement Code',
  create_pr: 'Create PR',
  link_jira: 'Link Jira',
  post_slack: 'Post Slack',
  completed: 'Completed',
  failed: 'Failed',
};

interface WorkflowTemplateSelectorProps {
  selectedTemplate: WorkflowTemplate | null;
  onSelectTemplate: (template: WorkflowTemplate) => void;
  customPhases?: WorkflowPhase[];
  onCustomPhasesChange?: (phases: WorkflowPhase[]) => void;
  className?: string;
}

export function WorkflowTemplateSelector({
  selectedTemplate,
  onSelectTemplate,
  customPhases,
  onCustomPhasesChange,
  className,
}: WorkflowTemplateSelectorProps) {
  const [showCustomizer, setShowCustomizer] = useState(false);
  const [customTemplateName, setCustomTemplateName] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [localCustomPhases, setLocalCustomPhases] = useState<WorkflowPhase[]>(
    customPhases || ['start_task', 'create_branch', 'implement_code', 'create_pr', 'link_jira', 'post_slack']
  );

  const { templates, customTemplates, saveTemplate, deleteTemplate, isLoading } = useWorkflowTemplates();

  const allPhases: WorkflowPhase[] = [
    'start_task',
    'create_branch', 
    'implement_code',
    'create_pr',
    'link_jira',
    'post_slack',
  ];

  const handlePhaseToggle = (phase: WorkflowPhase) => {
    const newPhases = localCustomPhases.includes(phase)
      ? localCustomPhases.filter(p => p !== phase)
      : [...localCustomPhases, phase].sort((a, b) => allPhases.indexOf(a) - allPhases.indexOf(b));
    
    setLocalCustomPhases(newPhases);
    onCustomPhasesChange?.(newPhases);
  };

  const handleSelectTemplate = (template: WorkflowTemplate) => {
    onSelectTemplate(template);
    setLocalCustomPhases(template.phases);
    onCustomPhasesChange?.(template.phases);
  };

  const handleSaveCustomTemplate = async () => {
    if (!customTemplateName.trim() || localCustomPhases.length === 0) return;
    
    setIsSaving(true);
    const saved = await saveTemplate({
      name: customTemplateName,
      description: `Custom template with ${localCustomPhases.length} phases`,
      icon: 'Settings2',
      phases: localCustomPhases,
      isDefault: false,
    });
    setIsSaving(false);
    
    if (saved) {
      setCustomTemplateName('');
      onSelectTemplate(saved);
    }
  };

  if (isLoading) {
    return (
      <div className={cn("flex items-center justify-center py-8", className)}>
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className={cn("space-y-4", className)}>
      <div className="grid grid-cols-2 gap-2">
        {templates.map((template) => {
          const isCustom = customTemplates.some(t => t.id === template.id);
          
          return (
            <Card
              key={template.id}
              className={cn(
                "cursor-pointer transition-all hover:border-primary/50 relative group",
                selectedTemplate?.id === template.id && "border-primary bg-primary/5"
              )}
              onClick={() => handleSelectTemplate(template)}
            >
              {isCustom && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-1 right-1 h-5 w-5 opacity-0 group-hover:opacity-100 transition-opacity z-10"
                  onClick={(e) => {
                    e.stopPropagation();
                    deleteTemplate(template.id);
                  }}
                >
                  <Trash2 className="h-3 w-3 text-destructive" />
                </Button>
              )}
              <CardContent className="p-3">
                <div className="flex items-start gap-2">
                  <div className={cn(
                    "h-8 w-8 rounded-lg flex items-center justify-center",
                    selectedTemplate?.id === template.id 
                      ? "bg-primary text-primary-foreground" 
                      : "bg-secondary text-muted-foreground"
                  )}>
                    {iconMap[template.icon] || <Zap className="h-4 w-4" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1">
                      <h4 className="text-xs font-medium truncate">{template.name}</h4>
                      {selectedTemplate?.id === template.id && (
                        <Check className="h-3 w-3 text-primary flex-shrink-0" />
                      )}
                    </div>
                    <p className="text-[10px] text-muted-foreground line-clamp-2 mt-0.5">
                      {template.description}
                    </p>
                  </div>
                </div>
                <div className="flex flex-wrap gap-1 mt-2">
                  {template.phases.slice(0, 3).map((phase) => (
                    <Badge key={phase} variant="secondary" className="text-[9px] px-1 py-0">
                      {phaseLabels[phase]}
                    </Badge>
                  ))}
                  {template.phases.length > 3 && (
                    <Badge variant="outline" className="text-[9px] px-1 py-0">
                      +{template.phases.length - 3}
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Button
        variant="outline"
        size="sm"
        className="w-full text-xs gap-2"
        onClick={() => setShowCustomizer(!showCustomizer)}
      >
        <Settings2 className="h-3.5 w-3.5" />
        {showCustomizer ? 'Hide Customizer' : 'Customize Phases'}
        <ChevronRight className={cn("h-3.5 w-3.5 ml-auto transition-transform", showCustomizer && "rotate-90")} />
      </Button>

      {showCustomizer && (
        <Card className="animate-fade-in">
          <CardContent className="p-3 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-medium">Custom Phases</h4>
              <Badge variant="outline" className="text-[10px]">{localCustomPhases.length} selected</Badge>
            </div>
            <Separator />
            <ScrollArea className="h-[160px] pr-2">
              <div className="space-y-2">
                {allPhases.map((phase, index) => (
                  <div 
                    key={phase}
                    className={cn(
                      "flex items-center justify-between p-2 rounded-lg transition-colors",
                      localCustomPhases.includes(phase) 
                        ? "bg-primary/10 border border-primary/20"
                        : "bg-secondary/50 border border-transparent"
                    )}
                  >
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-muted-foreground font-mono w-4">{index + 1}.</span>
                      <Label htmlFor={`phase-${phase}`} className="text-xs cursor-pointer">
                        {phaseLabels[phase]}
                      </Label>
                    </div>
                    <Switch
                      id={`phase-${phase}`}
                      checked={localCustomPhases.includes(phase)}
                      onCheckedChange={() => handlePhaseToggle(phase)}
                      className="scale-75"
                    />
                  </div>
                ))}
              </div>
            </ScrollArea>
            <Separator />
            <div className="flex gap-2">
              <Input
                placeholder="Template name..."
                value={customTemplateName}
                onChange={(e) => setCustomTemplateName(e.target.value)}
                className="h-8 text-xs"
              />
              <Button
                size="sm"
                className="h-8 px-3 text-xs gap-1"
                onClick={handleSaveCustomTemplate}
                disabled={!customTemplateName.trim() || localCustomPhases.length === 0 || isSaving}
              >
                {isSaving ? <Loader2 className="h-3 w-3 animate-spin" /> : <Save className="h-3 w-3" />}
                Save
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
