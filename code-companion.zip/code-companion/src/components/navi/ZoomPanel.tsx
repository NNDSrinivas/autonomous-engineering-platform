import { useState, useEffect, useCallback } from 'react';
import { Video, Calendar, Clock, Users, FileText, Play, Download, Loader2, RefreshCw, Search, ChevronRight, Mic, ExternalLink, Sparkles, CheckCircle, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { cn } from '@/lib/utils';
import { useIntegrations } from '@/hooks/useIntegrations';
import { useZoomIntegration } from '@/hooks/useZoomIntegration';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { formatDistanceToNow, format } from 'date-fns';

interface ZoomMeeting {
  id: string;
  uuid: string;
  topic: string;
  start_time: string;
  duration: number;
  host_id: string;
  host_email: string;
  participant_count?: number;
  has_recording?: boolean;
  has_transcript?: boolean;
}

interface ZoomRecording {
  id: string;
  meeting_id: string;
  topic: string;
  start_time: string;
  duration: number;
  share_url?: string;
  recording_files: {
    id: string;
    file_type: string;
    file_size: number;
    download_url: string;
    play_url?: string;
    status: string;
  }[];
}

interface ZoomTranscript {
  meeting_id: string;
  topic: string;
  start_time: string;
  content: string;
  speakers: {
    name: string;
    segments: {
      text: string;
      start_time: number;
      end_time: number;
    }[];
  }[];
  summary?: string;
  action_items?: string[];
  key_decisions?: string[];
}

interface ZoomPanelProps {
  onTranscriptSelect?: (transcript: ZoomTranscript) => void;
  onMeetingSelect?: (meeting: ZoomMeeting) => void;
}

export function ZoomPanel({ onTranscriptSelect, onMeetingSelect }: ZoomPanelProps) {
  const [activeTab, setActiveTab] = useState<'meetings' | 'recordings' | 'transcripts'>('meetings');
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [meetings, setMeetings] = useState<ZoomMeeting[]>([]);
  const [recordings, setRecordings] = useState<ZoomRecording[]>([]);
  const [transcripts, setTranscripts] = useState<ZoomTranscript[]>([]);
  const [expandedTranscript, setExpandedTranscript] = useState<string | null>(null);
  const [summarizingId, setSummarizingId] = useState<string | null>(null);
  const [summaries, setSummaries] = useState<Record<string, any>>({});

  const { integrations, isAuthenticated } = useIntegrations();
  const { summarizeTranscript } = useZoomIntegration();
  const zoomConnected = integrations.find(i => i.type === 'zoom')?.status === 'connected';

  const fetchZoomData = useCallback(async (action: string) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return null;

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/integration-data`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ provider: 'zoom', action }),
        }
      );

      const result = await response.json();
      if (!response.ok) {
        console.error('Zoom API error:', result);
        return null;
      }
      return result.data;
    } catch (error) {
      console.error('Failed to fetch Zoom data:', error);
      return null;
    }
  }, []);

  const loadData = useCallback(async () => {
    if (!zoomConnected || !isAuthenticated) return;
    
    setIsLoading(true);
    try {
      const [meetingsData, recordingsData, transcriptsData] = await Promise.all([
        fetchZoomData('meetings'),
        fetchZoomData('recordings'),
        fetchZoomData('transcripts'),
      ]);

      if (meetingsData) setMeetings(meetingsData);
      if (recordingsData) setRecordings(recordingsData);
      if (transcriptsData) setTranscripts(transcriptsData);
    } finally {
      setIsLoading(false);
    }
  }, [zoomConnected, isAuthenticated, fetchZoomData]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await loadData();
    setIsRefreshing(false);
    toast.success('Zoom data refreshed');
  };

  const handleSummarize = async (transcript: ZoomTranscript, e: React.MouseEvent) => {
    e.stopPropagation();
    setSummarizingId(transcript.meeting_id);
    
    try {
      const result = await summarizeTranscript(
        transcript.content,
        transcript.topic,
        transcript.speakers.map(s => s.name)
      );
      
      if (result) {
        setSummaries(prev => ({
          ...prev,
          [transcript.meeting_id]: result
        }));
      }
    } finally {
      setSummarizingId(null);
    }
  };

  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hours > 0) return `${hours}h ${mins}m`;
    return `${mins}m`;
  };

  const filteredMeetings = meetings.filter(m =>
    m.topic.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredRecordings = recordings.filter(r =>
    r.topic.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredTranscripts = transcripts.filter(t =>
    t.topic.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.content?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (!isAuthenticated) {
    return (
      <div className="flex flex-col h-full bg-sidebar">
        <div className="px-4 py-3 border-b border-border">
          <h2 className="font-semibold text-sm flex items-center gap-2">
            <div className="h-5 w-5 rounded bg-blue-500/20 flex items-center justify-center">
              <Video className="h-3 w-3 text-blue-400" />
            </div>
            Zoom Meetings
          </h2>
        </div>
        <div className="flex-1 flex items-center justify-center px-4 text-center">
          <div>
            <Video className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">Sign in to connect Zoom</p>
          </div>
        </div>
      </div>
    );
  }

  const handleConnectZoom = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error('Please sign in first');
        return;
      }
      
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/oauth?provider=zoom`,
        {
          headers: {
            Authorization: `Bearer ${session.access_token}`,
          },
        }
      );
      
      const result = await response.json();
      if (result.authUrl) {
        window.open(result.authUrl, '_blank', 'width=600,height=700');
      } else {
        toast.error('Failed to initiate Zoom connection');
      }
    } catch (error) {
      console.error('Failed to connect Zoom:', error);
      toast.error('Failed to connect to Zoom');
    }
  };

  if (!zoomConnected) {
    return (
      <div className="flex flex-col h-full bg-sidebar">
        <div className="px-4 py-3 border-b border-border">
          <h2 className="font-semibold text-sm flex items-center gap-2">
            <div className="h-5 w-5 rounded bg-blue-500/20 flex items-center justify-center">
              <Video className="h-3 w-3 text-blue-400" />
            </div>
            Zoom Meetings
          </h2>
        </div>
        <div className="flex-1 flex flex-col items-center justify-center px-4 text-center">
          <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center mb-3">
            <Video className="h-6 w-6 text-muted-foreground" />
          </div>
          <h3 className="text-sm font-medium mb-1">Connect Zoom</h3>
          <p className="text-xs text-muted-foreground mb-4">
            Connect your Zoom account to view meetings, recordings, and transcripts.
          </p>
          <Button onClick={handleConnectZoom} variant="default" size="sm">
            <Video className="h-4 w-4 mr-2" />
            Connect Zoom
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-sidebar">
      {/* Header */}
      <div className="px-4 py-3 border-b border-border">
        <div className="flex items-center justify-between mb-2">
          <h2 className="font-semibold text-sm flex items-center gap-2">
            <div className="h-5 w-5 rounded bg-blue-500/20 flex items-center justify-center">
              <Video className="h-3 w-3 text-blue-400" />
            </div>
            Zoom
          </h2>
          <Button 
            variant="ghost" 
            size="icon" 
            className="h-7 w-7"
            onClick={handleRefresh}
            disabled={isRefreshing}
          >
            <RefreshCw className={cn("h-4 w-4", isRefreshing && "animate-spin")} />
          </Button>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as typeof activeTab)} className="w-full">
          <TabsList className="h-8 w-full">
            <TabsTrigger value="meetings" className="text-xs flex-1">
              <Calendar className="h-3 w-3 mr-1" />
              Meetings
            </TabsTrigger>
            <TabsTrigger value="recordings" className="text-xs flex-1">
              <Play className="h-3 w-3 mr-1" />
              Recordings
            </TabsTrigger>
            <TabsTrigger value="transcripts" className="text-xs flex-1">
              <FileText className="h-3 w-3 mr-1" />
              Transcripts
            </TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Search */}
        <div className="relative mt-2">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder={`Search ${activeTab}...`}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 h-8 text-sm"
          />
        </div>
      </div>

      {/* Content */}
      <ScrollArea className="flex-1">
        {isLoading ? (
          <div className="flex items-center justify-center h-32">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : activeTab === 'meetings' ? (
          filteredMeetings.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-32 px-4 text-center">
              <Calendar className="h-8 w-8 text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">
                {searchQuery ? 'No meetings match your search' : 'No recent meetings found'}
              </p>
            </div>
          ) : (
            <div className="p-2 space-y-2">
              {filteredMeetings.map((meeting) => (
                <Card 
                  key={meeting.id}
                  className="bg-secondary/30 border-none hover:bg-secondary/50 transition-colors cursor-pointer"
                  onClick={() => onMeetingSelect?.(meeting)}
                >
                  <CardContent className="p-3">
                    <div className="flex items-start gap-3">
                      <div className="h-8 w-8 rounded-lg bg-blue-500/20 flex items-center justify-center flex-shrink-0">
                        <Video className="h-4 w-4 text-blue-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-medium text-sm truncate">{meeting.topic}</div>
                        <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {format(new Date(meeting.start_time), 'MMM d, yyyy')}
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {formatDuration(meeting.duration)}
                          </div>
                          {meeting.participant_count && (
                            <div className="flex items-center gap-1">
                              <Users className="h-3 w-3" />
                              {meeting.participant_count}
                            </div>
                          )}
                        </div>
                        <div className="flex items-center gap-2 mt-2">
                          {meeting.has_recording && (
                            <Badge variant="outline" className="text-[10px] h-5">
                              <Play className="h-2.5 w-2.5 mr-1" />
                              Recording
                            </Badge>
                          )}
                          {meeting.has_transcript && (
                            <Badge variant="outline" className="text-[10px] h-5">
                              <FileText className="h-2.5 w-2.5 mr-1" />
                              Transcript
                            </Badge>
                          )}
                        </div>
                      </div>
                      <ChevronRight className="h-4 w-4 text-muted-foreground" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )
        ) : activeTab === 'recordings' ? (
          filteredRecordings.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-32 px-4 text-center">
              <Play className="h-8 w-8 text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">
                {searchQuery ? 'No recordings match your search' : 'No recordings found'}
              </p>
            </div>
          ) : (
            <div className="p-2 space-y-2">
              {filteredRecordings.map((recording) => (
                <Card 
                  key={recording.id}
                  className="bg-secondary/30 border-none hover:bg-secondary/50 transition-colors"
                >
                  <CardContent className="p-3">
                    <div className="flex items-start gap-3">
                      <div className="h-8 w-8 rounded-lg bg-green-500/20 flex items-center justify-center flex-shrink-0">
                        <Play className="h-4 w-4 text-green-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-medium text-sm truncate">{recording.topic}</div>
                        <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {format(new Date(recording.start_time), 'MMM d, yyyy')}
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {formatDuration(recording.duration)}
                          </div>
                        </div>
                        <div className="flex items-center gap-2 mt-2">
                          {recording.recording_files.map((file) => (
                            <Badge 
                              key={file.id} 
                              variant="outline" 
                              className="text-[10px] h-5"
                            >
                              {file.file_type}
                            </Badge>
                          ))}
                        </div>
                        <div className="flex items-center gap-2 mt-2">
                          {recording.share_url && (
                            <Button variant="outline" size="sm" className="h-6 text-xs gap-1" asChild>
                              <a href={recording.share_url} target="_blank" rel="noopener noreferrer">
                                <ExternalLink className="h-3 w-3" />
                                View
                              </a>
                            </Button>
                          )}
                          {recording.recording_files[0]?.download_url && (
                            <Button variant="outline" size="sm" className="h-6 text-xs gap-1" asChild>
                              <a href={recording.recording_files[0].download_url} download>
                                <Download className="h-3 w-3" />
                                Download
                              </a>
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )
        ) : (
          filteredTranscripts.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-32 px-4 text-center">
              <FileText className="h-8 w-8 text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">
                {searchQuery ? 'No transcripts match your search' : 'No transcripts found'}
              </p>
            </div>
          ) : (
            <div className="p-2 space-y-2">
              {filteredTranscripts.map((transcript) => (
                <Card 
                  key={transcript.meeting_id}
                  className={cn(
                    "bg-secondary/30 border-none transition-colors cursor-pointer",
                    expandedTranscript === transcript.meeting_id ? "bg-secondary/50" : "hover:bg-secondary/40"
                  )}
                  onClick={() => {
                    if (expandedTranscript === transcript.meeting_id) {
                      setExpandedTranscript(null);
                    } else {
                      setExpandedTranscript(transcript.meeting_id);
                      onTranscriptSelect?.(transcript);
                    }
                  }}
                >
                  <CardContent className="p-3">
                    <div className="flex items-start gap-3">
                      <div className="h-8 w-8 rounded-lg bg-purple-500/20 flex items-center justify-center flex-shrink-0">
                        <Mic className="h-4 w-4 text-purple-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-medium text-sm truncate">{transcript.topic}</div>
                        <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {format(new Date(transcript.start_time), 'MMM d, yyyy')}
                          </div>
                          <div className="flex items-center gap-1">
                            <Users className="h-3 w-3" />
                            {transcript.speakers.length} speakers
                          </div>
                        </div>
                        
                        {/* Summary */}
                        {transcript.summary && !summaries[transcript.meeting_id] && (
                          <div className="mt-2 text-xs text-muted-foreground line-clamp-2">
                            {transcript.summary}
                          </div>
                        )}

                        {/* AI Summarize Button */}
                        {!summaries[transcript.meeting_id] && transcript.content && (
                          <Button
                            variant="outline"
                            size="sm"
                            className="mt-2 h-6 text-xs gap-1"
                            onClick={(e) => handleSummarize(transcript, e)}
                            disabled={summarizingId === transcript.meeting_id}
                          >
                            {summarizingId === transcript.meeting_id ? (
                              <>
                                <Loader2 className="h-3 w-3 animate-spin" />
                                Summarizing...
                              </>
                            ) : (
                              <>
                                <Sparkles className="h-3 w-3" />
                                AI Summarize
                              </>
                            )}
                          </Button>
                        )}

                        {/* AI Summary Results */}
                        {summaries[transcript.meeting_id] && (
                          <div className="mt-2 p-2 rounded-lg bg-primary/5 border border-primary/20">
                            <div className="flex items-center gap-1 text-xs font-medium text-primary mb-1">
                              <Sparkles className="h-3 w-3" />
                              AI Summary
                            </div>
                            <p className="text-xs text-foreground line-clamp-3">
                              {summaries[transcript.meeting_id].summary}
                            </p>
                          </div>
                        )}

                        {/* Expanded content */}
                        {expandedTranscript === transcript.meeting_id && (
                          <div className="mt-3 pt-3 border-t border-border/50 space-y-3">
                            {/* AI-extracted Action Items */}
                            {summaries[transcript.meeting_id]?.actionItems?.length > 0 && (
                              <div>
                                <div className="text-xs font-medium text-foreground mb-1 flex items-center gap-1">
                                  <CheckCircle className="h-3 w-3 text-status-success" />
                                  AI-Extracted Action Items:
                                </div>
                                <ul className="space-y-1">
                                  {summaries[transcript.meeting_id].actionItems.map((item: any, i: number) => (
                                    <li key={i} className="text-xs text-muted-foreground flex items-start gap-2 pl-2">
                                      <span className="text-primary">•</span>
                                      <div>
                                        <span>{item.item}</span>
                                        {item.owner && (
                                          <Badge variant="outline" className="ml-2 text-[9px] h-4">
                                            {item.owner}
                                          </Badge>
                                        )}
                                        {item.priority && (
                                          <Badge 
                                            variant="outline" 
                                            className={cn(
                                              "ml-1 text-[9px] h-4",
                                              item.priority === 'high' && "border-destructive text-destructive",
                                              item.priority === 'medium' && "border-status-warning text-status-warning",
                                              item.priority === 'low' && "border-muted-foreground"
                                            )}
                                          >
                                            {item.priority}
                                          </Badge>
                                        )}
                                      </div>
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            )}

                            {/* AI-extracted Key Decisions */}
                            {summaries[transcript.meeting_id]?.keyDecisions?.length > 0 && (
                              <div>
                                <div className="text-xs font-medium text-foreground mb-1">Key Decisions:</div>
                                <ul className="space-y-1">
                                  {summaries[transcript.meeting_id].keyDecisions.map((decision: any, i: number) => (
                                    <li key={i} className="text-xs text-muted-foreground flex items-start gap-2 pl-2">
                                      <span className="text-status-success">✓</span>
                                      {typeof decision === 'string' ? decision : decision.decision}
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            )}

                            {/* Blockers */}
                            {summaries[transcript.meeting_id]?.blockers?.length > 0 && (
                              <div>
                                <div className="text-xs font-medium text-foreground mb-1 flex items-center gap-1">
                                  <AlertTriangle className="h-3 w-3 text-status-warning" />
                                  Blockers:
                                </div>
                                <ul className="space-y-1">
                                  {summaries[transcript.meeting_id].blockers.map((blocker: string, i: number) => (
                                    <li key={i} className="text-xs text-muted-foreground flex items-start gap-2 pl-2">
                                      <span className="text-status-warning">!</span>
                                      {blocker}
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            )}

                            {/* Original Action Items (fallback) */}
                            {!summaries[transcript.meeting_id] && transcript.action_items && transcript.action_items.length > 0 && (
                              <div>
                                <div className="text-xs font-medium text-foreground mb-1">Action Items:</div>
                                <ul className="space-y-1">
                                  {transcript.action_items.map((item, i) => (
                                    <li key={i} className="text-xs text-muted-foreground flex items-start gap-2">
                                      <span className="text-primary">•</span>
                                      {item}
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            )}

                            {/* Original Key Decisions (fallback) */}
                            {!summaries[transcript.meeting_id] && transcript.key_decisions && transcript.key_decisions.length > 0 && (
                              <div>
                                <div className="text-xs font-medium text-foreground mb-1">Key Decisions:</div>
                                <ul className="space-y-1">
                                  {transcript.key_decisions.map((decision, i) => (
                                    <li key={i} className="text-xs text-muted-foreground flex items-start gap-2">
                                      <span className="text-status-success">✓</span>
                                      {decision}
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            )}

                            {/* Speakers */}
                            <div>
                              <div className="text-xs font-medium text-foreground mb-1">Speakers:</div>
                              <div className="flex flex-wrap gap-1">
                                {transcript.speakers.map((speaker, i) => (
                                  <Badge key={i} variant="secondary" className="text-[10px]">
                                    {speaker.name}
                                  </Badge>
                                ))}
                              </div>
                            </div>

                            {/* Transcript Preview */}
                            {transcript.content && (
                              <div className="p-2 rounded bg-background/50 text-xs text-muted-foreground max-h-32 overflow-y-auto">
                                {transcript.content.substring(0, 500)}...
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                      <ChevronRight className={cn(
                        "h-4 w-4 text-muted-foreground transition-transform",
                        expandedTranscript === transcript.meeting_id && "rotate-90"
                      )} />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )
        )}
      </ScrollArea>
    </div>
  );
}
