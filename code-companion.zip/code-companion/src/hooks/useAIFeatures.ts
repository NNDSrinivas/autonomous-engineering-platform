import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface CodeFile {
  path: string;
  content: string;
  action: 'create' | 'modify' | 'delete';
  description: string;
}

interface CodeGenerationResult {
  success: boolean;
  taskKey: string;
  files: CodeFile[];
  summary: string;
  estimatedImpact: 'low' | 'medium' | 'high';
  testSuggestions: string[];
}

interface TaskAnalysis {
  suggestedFiles: string[];
  suggestedComponents: string[];
  keywords: string[];
  dependencies: string[];
  complexity: 'low' | 'medium' | 'high';
  estimatedFiles: number;
  suggestedBranchName: string;
}

interface LinkedItem {
  type: 'file' | 'pr' | 'commit' | 'branch' | 'slack_thread' | 'confluence_page';
  id: string;
  url?: string;
  title?: string;
  linkedAt?: string;
}

export function useAICodeGeneration() {
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedCode, setGeneratedCode] = useState<CodeGenerationResult | null>(null);

  const generateCode = useCallback(async (
    taskKey: string,
    taskTitle: string,
    taskDescription: string,
    options?: {
      acceptanceCriteria?: string;
      existingCode?: string;
      fileContext?: string[];
      action?: 'generate' | 'refactor' | 'fix' | 'test';
    }
  ): Promise<CodeGenerationResult | null> => {
    setIsGenerating(true);
    setGeneratedCode(null);

    try {
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-code-generator`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            taskKey,
            taskTitle,
            taskDescription,
            acceptanceCriteria: options?.acceptanceCriteria,
            existingCode: options?.existingCode,
            fileContext: options?.fileContext,
            action: options?.action || 'generate'
          }),
        }
      );

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Code generation failed');
      }

      const result = await response.json();
      setGeneratedCode(result);
      toast.success(`Generated ${result.files?.length || 0} code suggestions`);
      return result;
    } catch (error) {
      console.error('Code generation error:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to generate code');
      return null;
    } finally {
      setIsGenerating(false);
    }
  }, []);

  const clearGenerated = useCallback(() => {
    setGeneratedCode(null);
  }, []);

  return {
    isGenerating,
    generatedCode,
    generateCode,
    clearGenerated
  };
}

export function useTaskCorrelation() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<TaskAnalysis | null>(null);
  const [linkedItems, setLinkedItems] = useState<LinkedItem[]>([]);

  const analyzeTask = useCallback(async (
    taskKey: string,
    taskTitle: string,
    taskDescription: string
  ): Promise<TaskAnalysis | null> => {
    setIsAnalyzing(true);

    try {
      const { data: session } = await supabase.auth.getSession();
      
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/task-correlation`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${session.session?.access_token}`
          },
          body: JSON.stringify({
            action: 'analyze',
            taskKey,
            taskTitle,
            taskDescription
          }),
        }
      );

      if (!response.ok) {
        throw new Error('Task analysis failed');
      }

      const result = await response.json();
      setAnalysis(result.analysis);
      return result.analysis;
    } catch (error) {
      console.error('Task analysis error:', error);
      toast.error('Failed to analyze task');
      return null;
    } finally {
      setIsAnalyzing(false);
    }
  }, []);

  const linkItems = useCallback(async (
    taskKey: string,
    items: LinkedItem[],
    taskTitle?: string,
    taskDescription?: string
  ): Promise<boolean> => {
    try {
      const { data: session } = await supabase.auth.getSession();
      
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/task-correlation`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${session.session?.access_token}`
          },
          body: JSON.stringify({
            action: 'link',
            taskKey,
            taskTitle,
            taskDescription,
            linkedItems: items
          }),
        }
      );

      if (!response.ok) {
        throw new Error('Failed to link items');
      }

      toast.success(`Linked ${items.length} items to ${taskKey}`);
      await fetchLinks(taskKey);
      return true;
    } catch (error) {
      console.error('Link error:', error);
      toast.error('Failed to link items');
      return false;
    }
  }, []);

  const fetchLinks = useCallback(async (taskKey: string): Promise<LinkedItem[]> => {
    try {
      const { data: session } = await supabase.auth.getSession();
      
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/task-correlation`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${session.session?.access_token}`
          },
          body: JSON.stringify({
            action: 'get_links',
            taskKey
          }),
        }
      );

      if (!response.ok) {
        throw new Error('Failed to fetch links');
      }

      const result = await response.json();
      setLinkedItems(result.links || []);
      return result.links || [];
    } catch (error) {
      console.error('Fetch links error:', error);
      return [];
    }
  }, []);

  return {
    isAnalyzing,
    analysis,
    linkedItems,
    analyzeTask,
    linkItems,
    fetchLinks
  };
}

export function useAISummarization() {
  const [isSummarizing, setIsSummarizing] = useState(false);

  const summarize = useCallback(async (
    type: 'slack' | 'meeting' | 'pr_comments' | 'confluence',
    content: string,
    context?: {
      taskKey?: string;
      channelName?: string;
      participants?: string[];
    }
  ) => {
    setIsSummarizing(true);

    try {
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-summarize`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ type, content, context }),
        }
      );

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Summarization failed');
      }

      const result = await response.json();
      return result;
    } catch (error) {
      console.error('Summarization error:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to summarize');
      return null;
    } finally {
      setIsSummarizing(false);
    }
  }, []);

  return {
    isSummarizing,
    summarize
  };
}
