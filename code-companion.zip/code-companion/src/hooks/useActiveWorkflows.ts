import { useState, useCallback } from 'react';
import type { WorkflowPhase } from './useEndToEndWorkflow';
import type { ActiveWorkflow } from '@/types/workflowTemplates';

export function useActiveWorkflows() {
  const [activeWorkflows, setActiveWorkflows] = useState<Map<string, ActiveWorkflow>>(new Map());

  const startWorkflow = useCallback((
    taskId: string, 
    taskKey: string, 
    templateId: string
  ) => {
    setActiveWorkflows(prev => {
      const next = new Map(prev);
      next.set(taskId, {
        taskId,
        taskKey,
        templateId,
        currentPhase: 'start_task',
        progress: 0,
        startedAt: new Date(),
      });
      return next;
    });
  }, []);

  const updateWorkflowPhase = useCallback((
    taskId: string, 
    phase: WorkflowPhase, 
    progress: number
  ) => {
    setActiveWorkflows(prev => {
      const workflow = prev.get(taskId);
      if (!workflow) return prev;
      
      const next = new Map(prev);
      next.set(taskId, {
        ...workflow,
        currentPhase: phase,
        progress,
      });
      return next;
    });
  }, []);

  const completeWorkflow = useCallback((taskId: string) => {
    setActiveWorkflows(prev => {
      const next = new Map(prev);
      next.delete(taskId);
      return next;
    });
  }, []);

  const getWorkflowForTask = useCallback((taskId: string): ActiveWorkflow | undefined => {
    return activeWorkflows.get(taskId);
  }, [activeWorkflows]);

  const hasActiveWorkflow = useCallback((taskId: string): boolean => {
    return activeWorkflows.has(taskId);
  }, [activeWorkflows]);

  return {
    activeWorkflows,
    startWorkflow,
    updateWorkflowPhase,
    completeWorkflow,
    getWorkflowForTask,
    hasActiveWorkflow,
  };
}
