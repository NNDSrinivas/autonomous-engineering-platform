import { useCallback, useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface FeedbackAnalytics {
  total_likes: number;
  total_dislikes: number;
  feedback_by_day: Array<{
    day: string;
    likes: number;
    dislikes: number;
  }>;
  recent_dislikes: Array<{
    id: string;
    message_content: string;
    created_at: string;
    metadata: Record<string, unknown>;
  }>;
}

export function useAdminAnalytics() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [analytics, setAnalytics] = useState<FeedbackAnalytics | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Check if current user is admin
  const checkAdminStatus = useCallback(async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        setIsAdmin(false);
        return false;
      }

      const { data, error } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', user.id)
        .eq('role', 'admin')
        .maybeSingle();

      if (error) {
        console.error('Error checking admin status:', error);
        setIsAdmin(false);
        return false;
      }

      const adminStatus = !!data;
      setIsAdmin(adminStatus);
      return adminStatus;
    } catch (err) {
      console.error('Error checking admin status:', err);
      setIsAdmin(false);
      return false;
    }
  }, []);

  // Fetch analytics data
  const fetchAnalytics = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      const { data, error } = await supabase.rpc('get_feedback_analytics');

      if (error) {
        if (error.message.includes('Access denied')) {
          setError('You do not have permission to view analytics.');
        } else {
          setError('Failed to load analytics data.');
        }
        console.error('Analytics error:', error);
        return;
      }

      if (data && data.length > 0) {
        const row = data[0] as any;
        setAnalytics({
          total_likes: row.total_likes || 0,
          total_dislikes: row.total_dislikes || 0,
          feedback_by_day: (row.feedback_by_day as any[]) || [],
          recent_dislikes: (row.recent_dislikes as any[]) || [],
        });
      }
    } catch (err) {
      console.error('Error fetching analytics:', err);
      setError('An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    const init = async () => {
      const adminStatus = await checkAdminStatus();
      if (adminStatus) {
        await fetchAnalytics();
      } else {
        setIsLoading(false);
      }
    };
    init();
  }, [checkAdminStatus, fetchAnalytics]);

  return {
    isAdmin,
    isLoading,
    analytics,
    error,
    refetch: fetchAnalytics,
  };
}
