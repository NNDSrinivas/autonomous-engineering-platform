import { useState, useCallback, useEffect } from 'react';
import { AgentPhase, FileActivity, AgentStep } from '@/components/navi/AgentActivityPanel';
import { CommandToApprove, CommandApprovalChoice } from '@/components/navi/CommandApprovalCard';
import { Workflow, WorkflowStep } from '@/types/workflow';

export interface AgentActivityState {
  isActive: boolean;
  phase: AgentPhase;
  currentThought: string;
  files: FileActivity[];
  steps: AgentStep[];
  totalEdits: number;
  linesChanged: number;
  tokensProcessed: number;
  pendingCommands: CommandToApprove[];
  allowedCommands: Set<string>; // Commands that are "always allowed"
}

const initialState: AgentActivityState = {
  isActive: false,
  phase: 'idle',
  currentThought: '',
  files: [],
  steps: [],
  totalEdits: 0,
  linesChanged: 0,
  tokensProcessed: 0,
  pendingCommands: [],
  allowedCommands: new Set(),
};

// Map workflow step action types to agent phases
const actionToPhase: Record<string, AgentPhase> = {
  create_branch: 'executing',
  create_pr: 'writing',
  run_tests: 'executing',
  run_build: 'executing',
  code_review: 'reviewing',
  merge_pr: 'executing',
  deploy: 'executing',
  notify: 'complete',
  update_docs: 'writing',
  rollback: 'executing',
};

// Map workflow step action types to file actions
const actionToFileAction: Record<string, FileActivity['action']> = {
  create_branch: 'create',
  create_pr: 'write',
  run_tests: 'analyze',
  run_build: 'analyze',
  code_review: 'read',
  merge_pr: 'write',
  deploy: 'write',
  update_docs: 'write',
  rollback: 'write',
};

// Generate realistic file paths based on action type
const getFilesForAction = (actionType: string, stepName: string): string[] => {
  const filePatterns: Record<string, string[]> = {
    create_branch: ['.git/refs/heads/*', '.git/HEAD'],
    create_pr: ['.github/pull_request.md', 'CHANGELOG.md'],
    run_tests: ['src/**/*.test.ts', 'src/**/*.spec.tsx', 'jest.config.js', 'coverage/lcov-report/index.html'],
    run_build: ['dist/index.js', 'dist/index.css', 'vite.config.ts', 'tsconfig.json'],
    code_review: ['src/components/**/*.tsx', 'src/hooks/**/*.ts', 'src/lib/**/*.ts'],
    merge_pr: ['.git/refs/heads/main', 'package.json', 'package-lock.json'],
    deploy: ['vercel.json', '.env.production', 'dist/**/*'],
    update_docs: ['README.md', 'docs/API.md', 'CONTRIBUTING.md'],
    notify: ['slack-webhook.log'],
    rollback: ['.git/refs/heads/*', 'dist/**/*'],
  };
  
  return filePatterns[actionType] || [`src/${stepName.toLowerCase().replace(/\s+/g, '-')}.ts`];
};

// Generate thoughts based on workflow state
const getThoughtForStep = (step: WorkflowStep, workflow: Workflow): string => {
  const thoughts: Record<string, string[]> = {
    create_branch: [
      `Creating feature branch for ${workflow.context.taskKey || 'task'}...`,
      `Branching from ${workflow.context.baseBranch || 'main'}...`,
      'Setting up isolated development environment...',
    ],
    create_pr: [
      'Preparing pull request with all changes...',
      'Generating PR description from commit history...',
      'Linking PR to related tickets...',
    ],
    run_tests: [
      'Running test suite across all modules...',
      'Executing unit tests and integration tests...',
      'Checking code coverage thresholds...',
    ],
    run_build: [
      'Compiling TypeScript and bundling assets...',
      'Optimizing bundle size with tree shaking...',
      'Generating source maps for debugging...',
    ],
    code_review: [
      'Analyzing code changes for best practices...',
      'Checking for potential security issues...',
      'Reviewing architectural decisions...',
    ],
    merge_pr: [
      'Squashing commits and preparing merge...',
      'Updating main branch with approved changes...',
      'Cleaning up feature branch...',
    ],
    deploy: [
      `Deploying to ${(step.params as any)?.environment || 'staging'} environment...`,
      'Running deployment health checks...',
      'Updating CDN cache and DNS...',
    ],
    notify: [
      'Sending notifications to team channels...',
      'Updating stakeholders on progress...',
    ],
    update_docs: [
      'Generating API documentation from source...',
      'Updating README with new features...',
    ],
    rollback: [
      'Reverting to previous stable version...',
      'Restoring database state...',
    ],
  };
  
  const stepThoughts = thoughts[step.actionType] || [`Executing ${step.name}...`];
  return stepThoughts[Math.floor(Math.random() * stepThoughts.length)];
};

export function useAgentActivity() {
  const [state, setState] = useState<AgentActivityState>(initialState);

  // Start activity tracking
  const startActivity = useCallback((initialThought?: string) => {
    setState({
      ...initialState,
      isActive: true,
      phase: 'thinking',
      currentThought: initialThought || 'Analyzing request...',
      tokensProcessed: Math.floor(Math.random() * 500) + 100,
    });
  }, []);

  // Update from workflow state
  const syncWithWorkflow = useCallback((workflow: Workflow | null) => {
    if (!workflow) {
      setState(initialState);
      return;
    }

    const currentStep = workflow.steps[workflow.currentStepIndex];
    const completedSteps = workflow.steps.filter(s => s.status === 'completed' || s.status === 'skipped');
    const executingStep = workflow.steps.find(s => s.status === 'executing');
    
    // Determine phase
    let phase: AgentPhase = 'idle';
    if (workflow.status === 'completed') {
      phase = 'complete';
    } else if (workflow.status === 'running') {
      if (executingStep) {
        phase = actionToPhase[executingStep.actionType] || 'executing';
      } else if (currentStep?.status === 'awaiting_approval') {
        phase = 'reviewing';
      }
    } else if (workflow.status === 'paused') {
      phase = 'idle';
    }

    // Generate file activities
    const files: FileActivity[] = [];
    workflow.steps.forEach((step, index) => {
      const filePaths = getFilesForAction(step.actionType, step.name);
      const action = actionToFileAction[step.actionType] || 'analyze';
      
      filePaths.forEach((path, fileIndex) => {
        files.push({
          id: `${step.id}-file-${fileIndex}`,
          path: path.replace('**/*', `file${fileIndex + 1}`).replace('*', step.name.toLowerCase().replace(/\s+/g, '-')),
          action,
          status: step.status === 'completed' ? 'complete' : 
                  step.status === 'executing' ? 'active' : 'pending',
          changes: step.status === 'completed' ? Math.floor(Math.random() * 50) + 5 : undefined,
          timestamp: step.startedAt || new Date(),
        });
      });
    });

    // Convert workflow steps to agent steps
    const agentSteps: AgentStep[] = workflow.steps.map(step => ({
      id: step.id,
      label: step.name,
      description: step.description,
      status: step.status === 'completed' ? 'complete' :
              step.status === 'executing' ? 'active' :
              step.status === 'skipped' ? 'skipped' : 'pending',
      duration: step.completedAt && step.startedAt 
        ? step.completedAt.getTime() - step.startedAt.getTime()
        : undefined,
    }));

    // Calculate stats
    const totalEdits = completedSteps.length * Math.floor(Math.random() * 3 + 1);
    const linesChanged = completedSteps.reduce((sum, s) => 
      sum + Math.floor(Math.random() * 100 + 10), 0);
    const tokensProcessed = workflow.steps.reduce((sum, s, i) => 
      sum + (s.status !== 'pending' ? (i + 1) * 150 : 0), 500);

    // Get current thought
    const currentThought = executingStep 
      ? getThoughtForStep(executingStep, workflow)
      : currentStep?.status === 'awaiting_approval'
        ? `Waiting for approval: ${currentStep.name}`
        : workflow.status === 'completed'
          ? 'All tasks completed successfully!'
          : '';

    setState(prev => ({
      isActive: workflow.status === 'running' || workflow.status === 'paused',
      phase,
      currentThought,
      files: files.slice(0, 15), // Limit to 15 files for UI
      steps: agentSteps,
      totalEdits,
      linesChanged,
      tokensProcessed,
      pendingCommands: prev.pendingCommands,
      allowedCommands: prev.allowedCommands,
    }));
  }, []);

  // Update phase manually
  const setPhase = useCallback((phase: AgentPhase, thought?: string) => {
    setState(prev => ({
      ...prev,
      phase,
      currentThought: thought || prev.currentThought,
    }));
  }, []);

  // Add a file activity
  const addFileActivity = useCallback((file: Omit<FileActivity, 'id' | 'timestamp'>) => {
    setState(prev => ({
      ...prev,
      files: [
        ...prev.files,
        {
          ...file,
          id: `file-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          timestamp: new Date(),
        },
      ],
    }));
  }, []);

  // Update file status
  const updateFileStatus = useCallback((fileId: string, status: FileActivity['status'], changes?: number) => {
    setState(prev => ({
      ...prev,
      files: prev.files.map(f => 
        f.id === fileId ? { ...f, status, changes: changes ?? f.changes } : f
      ),
      totalEdits: status === 'complete' ? prev.totalEdits + 1 : prev.totalEdits,
    }));
  }, []);

  // Add a command that needs approval
  const addPendingCommand = useCallback((command: Omit<CommandToApprove, 'id' | 'timestamp' | 'status'>) => {
    const newCommand: CommandToApprove = {
      ...command,
      id: `cmd-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date(),
      status: 'pending',
    };

    setState(prev => {
      // Check if this command type is always allowed
      const commandSignature = `${command.type}:${command.command}`;
      if (prev.allowedCommands.has(commandSignature)) {
        // Auto-approve and mark as running
        return {
          ...prev,
          pendingCommands: [...prev.pendingCommands, { ...newCommand, status: 'approved' as const }],
          phase: 'executing',
          currentThought: `Running: ${command.command}`,
        };
      }

      return {
        ...prev,
        pendingCommands: [...prev.pendingCommands, newCommand],
        phase: 'awaiting_approval',
        currentThought: `Waiting for approval: ${command.command}`,
      };
    });

    return newCommand.id;
  }, []);

  // Handle command approval
  const approveCommand = useCallback((commandId: string, choice: CommandApprovalChoice) => {
    setState(prev => {
      const command = prev.pendingCommands.find(c => c.id === commandId);
      if (!command) return prev;

      const newAllowedCommands = new Set(prev.allowedCommands);
      if (choice === 'always_allow') {
        // Add to always allowed list
        const commandSignature = `${command.type}:${command.command}`;
        newAllowedCommands.add(commandSignature);
      }

      return {
        ...prev,
        pendingCommands: prev.pendingCommands.map(c =>
          c.id === commandId ? { ...c, status: 'running' as const } : c
        ),
        allowedCommands: newAllowedCommands,
        phase: 'executing',
        currentThought: `Running: ${command.command}`,
      };
    });
  }, []);

  // Skip a command
  const skipCommand = useCallback((commandId: string) => {
    setState(prev => ({
      ...prev,
      pendingCommands: prev.pendingCommands.map(c =>
        c.id === commandId ? { ...c, status: 'skipped' as const } : c
      ),
      phase: prev.pendingCommands.filter(c => c.id !== commandId && c.status === 'pending').length > 0
        ? 'awaiting_approval'
        : 'executing',
    }));
  }, []);

  // Mark command as completed
  const completeCommand = useCallback((commandId: string, output?: string, success: boolean = true) => {
    setState(prev => ({
      ...prev,
      pendingCommands: prev.pendingCommands.map(c =>
        c.id === commandId 
          ? { ...c, status: success ? 'completed' as const : 'failed' as const, output } 
          : c
      ),
    }));
  }, []);

  // Complete activity
  const completeActivity = useCallback(() => {
    setState(prev => ({
      ...prev,
      phase: 'complete',
      currentThought: 'All tasks completed successfully!',
      files: prev.files.map(f => ({ ...f, status: 'complete' as const })),
      steps: prev.steps.map(s => ({ ...s, status: 'complete' as const })),
      pendingCommands: prev.pendingCommands.map(c => 
        c.status === 'running' ? { ...c, status: 'completed' as const } : c
      ),
    }));
  }, []);

  // Reset activity
  const resetActivity = useCallback(() => {
    setState(prev => ({
      ...initialState,
      allowedCommands: prev.allowedCommands, // Preserve "always allow" settings
    }));
  }, []);

  return {
    ...state,
    startActivity,
    syncWithWorkflow,
    setPhase,
    addFileActivity,
    updateFileStatus,
    addPendingCommand,
    approveCommand,
    skipCommand,
    completeCommand,
    completeActivity,
    resetActivity,
  };
}
