import { useState, useCallback, useRef, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { AgentPhase, FileActivity, AgentStep } from '@/components/navi/AgentActivityPanel';
import { CommandToApprove, CommandApprovalChoice } from '@/components/navi/CommandApprovalCard';

// Event types from the backend
type AgentEventType = 
  | 'activity_started'
  | 'phase_changed'
  | 'thought_updated'
  | 'file_activity'
  | 'step_started'
  | 'step_completed'
  | 'command_pending'
  | 'command_executed'
  | 'stats_updated'
  | 'activity_completed'
  | 'error'
  | 'ai_response_chunk'
  | 'ai_response_complete';

interface AgentEvent {
  type: AgentEventType;
  timestamp: string;
  data: Record<string, unknown>;
}

export interface AgentActivityStreamState {
  isActive: boolean;
  isConnected: boolean;
  sessionId: string | null;
  phase: AgentPhase;
  currentThought: string;
  files: FileActivity[];
  steps: AgentStep[];
  totalEdits: number;
  linesChanged: number;
  tokensProcessed: number;
  pendingCommands: CommandToApprove[];
  allowedCommands: Set<string>;
  error: string | null;
  useWebSocket: boolean;
}

const initialState: AgentActivityStreamState = {
  isActive: false,
  isConnected: false,
  sessionId: null,
  phase: 'idle',
  currentThought: '',
  files: [],
  steps: [],
  totalEdits: 0,
  linesChanged: 0,
  tokensProcessed: 0,
  pendingCommands: [],
  allowedCommands: new Set(),
  error: null,
  useWebSocket: true,
};

// Parse AI response content for file operations (client-side version)
export function parseResponseContent(content: string): AgentEvent[] {
  const events: AgentEvent[] = [];
  const timestamp = new Date().toISOString();

  // Detect phase based on content
  if (content.includes('Analyzing') || content.includes('analyzing') || content.includes('Looking at')) {
    events.push({
      type: 'phase_changed',
      timestamp,
      data: { phase: 'analyzing', thought: 'Analyzing the request...' },
    });
  }

  if (content.includes('Reading') || content.includes('reading') || content.includes('Checking')) {
    events.push({
      type: 'phase_changed',
      timestamp,
      data: { phase: 'reading', thought: 'Reading relevant files...' },
    });
  }

  // Detect file operations with various patterns
  const filePatterns = [
    /(?:Reading|Writing|Creating|Editing|Updating|Modified|Created|Deleted|Viewing)\s+[`"]?([a-zA-Z0-9_\-\/\.]+\.[a-zA-Z]+)[`"]?/gi,
    /```(?:typescript|javascript|tsx|jsx|ts|js|css|html|json)?\s*\n?\/\/\s*([a-zA-Z0-9_\-\/\.]+\.[a-zA-Z]+)/gi,
    /(?:src|supabase|components|hooks|pages|lib|utils)\/[a-zA-Z0-9_\-\/]+\.[a-zA-Z]+/gi,
  ];

  const detectedFiles = new Set<string>();
  
  for (const pattern of filePatterns) {
    let match;
    while ((match = pattern.exec(content)) !== null) {
      const filePath = match[1] || match[0];
      if (filePath && !detectedFiles.has(filePath)) {
        detectedFiles.add(filePath);
        
        const lowerContent = content.toLowerCase();
        let action: 'read' | 'write' | 'create' | 'delete' = 'read';
        if (lowerContent.includes('creating') || lowerContent.includes('created') || lowerContent.includes('new file')) {
          action = 'create';
        } else if (lowerContent.includes('editing') || lowerContent.includes('writing') || lowerContent.includes('updating') || lowerContent.includes('modified')) {
          action = 'write';
        } else if (lowerContent.includes('deleting') || lowerContent.includes('removed')) {
          action = 'delete';
        }
        
        events.push({
          type: 'file_activity',
          timestamp,
          data: {
            file: {
              id: `file-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
              path: filePath,
              action,
              status: 'active',
            },
          },
        });
      }
    }
  }

  // Detect code blocks as writing phase
  const codeBlockCount = (content.match(/```/g) || []).length / 2;
  if (codeBlockCount > 0) {
    events.push({
      type: 'phase_changed',
      timestamp,
      data: { phase: 'writing', thought: `Writing code changes...` },
    });
    
    const codeContent: string[] = content.match(/```[\s\S]*?```/g) || [];
    let totalLines = 0;
    for (const block of codeContent) {
      totalLines += block.split('\n').length - 2;
    }
    
    if (totalLines > 0) {
      events.push({
        type: 'stats_updated',
        timestamp,
        data: { 
          linesChanged: totalLines,
          totalEdits: detectedFiles.size,
        },
      });
    }
  }

  // Detect completion indicators
  if (content.includes('Done') || content.includes('Completed') || content.includes('finished') || 
      content.includes('Successfully') || content.includes('All changes')) {
    events.push({
      type: 'activity_completed',
      timestamp,
      data: { message: 'Changes completed' },
    });
  }

  return events;
}

export function useAgentActivityStream() {
  const [state, setState] = useState<AgentActivityStreamState>(initialState);
  const eventSourceRef = useRef<EventSource | null>(null);
  const webSocketRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const reconnectAttempts = useRef(0);
  const maxReconnectAttempts = 5;

  // Process incoming events
  const processEvent = useCallback((event: AgentEvent) => {
    console.log('[AgentActivityStream] Processing event:', event.type, event.data);

    setState(prev => {
      switch (event.type) {
        case 'activity_started':
          return {
            ...prev,
            isActive: true,
            sessionId: event.data.sessionId as string,
            phase: (event.data.phase as AgentPhase) || 'thinking',
            currentThought: (event.data.message as string) || 'Starting...',
            error: null,
          };

        case 'phase_changed':
          return {
            ...prev,
            phase: event.data.phase as AgentPhase,
            currentThought: (event.data.thought as string) || prev.currentThought,
          };

        case 'thought_updated':
          return {
            ...prev,
            currentThought: event.data.thought as string,
          };

        case 'file_activity': {
          const fileData = event.data.file as Partial<FileActivity>;
          const existingIndex = prev.files.findIndex(f => f.id === fileData.id);
          
          const newFile: FileActivity = {
            id: fileData.id || `file-${Date.now()}`,
            path: fileData.path || 'unknown',
            action: fileData.action || 'read',
            status: fileData.status || 'pending',
            changes: fileData.changes,
            timestamp: new Date(event.timestamp),
          };

          const newFiles = existingIndex >= 0
            ? prev.files.map((f, i) => i === existingIndex ? newFile : f)
            : [...prev.files, newFile];

          return {
            ...prev,
            files: newFiles.slice(-20), // Keep last 20 files
          };
        }

        case 'step_started': {
          const stepData = event.data.step as Partial<AgentStep>;
          const newStep: AgentStep = {
            id: stepData.id || `step-${Date.now()}`,
            label: stepData.label || 'Unknown step',
            description: stepData.description,
            status: 'active',
          };
          
          return {
            ...prev,
            steps: [...prev.steps.map(s => 
              s.status === 'active' ? { ...s, status: 'complete' as const } : s
            ), newStep],
          };
        }

        case 'step_completed': {
          const stepId = event.data.stepId as string;
          const duration = event.data.duration as number | undefined;
          
          return {
            ...prev,
            steps: prev.steps.map(s => 
              s.id === stepId ? { ...s, status: 'complete' as const, duration } : s
            ),
          };
        }

        case 'command_pending': {
          const cmdData = event.data.command as Partial<CommandToApprove>;
          const newCommand: CommandToApprove = {
            id: cmdData.id || `cmd-${Date.now()}`,
            type: cmdData.type || 'terminal',
            command: cmdData.command || '',
            description: cmdData.description,
            risk: cmdData.risk || 'low',
            timestamp: new Date(event.timestamp),
            status: 'pending',
          };

          // Check if command is in allowed list
          const commandSignature = `${newCommand.type}:${newCommand.command}`;
          if (prev.allowedCommands.has(commandSignature)) {
            return {
              ...prev,
              pendingCommands: [...prev.pendingCommands, { ...newCommand, status: 'approved' }],
              phase: 'executing',
            };
          }

          return {
            ...prev,
            pendingCommands: [...prev.pendingCommands, newCommand],
            phase: 'awaiting_approval',
          };
        }

        case 'command_executed': {
          const cmdId = event.data.commandId as string;
          const success = event.data.success as boolean;
          const output = event.data.output as string | undefined;

          return {
            ...prev,
            pendingCommands: prev.pendingCommands.map(c =>
              c.id === cmdId 
                ? { ...c, status: success ? 'completed' as const : 'failed' as const, output }
                : c
            ),
          };
        }

        case 'stats_updated':
          return {
            ...prev,
            totalEdits: (event.data.totalEdits as number) ?? prev.totalEdits,
            linesChanged: (event.data.linesChanged as number) ?? prev.linesChanged,
            tokensProcessed: (event.data.tokensProcessed as number) ?? prev.tokensProcessed,
          };

        case 'activity_completed':
          return {
            ...prev,
            isActive: false,
            phase: 'complete',
            currentThought: (event.data.message as string) || 'All tasks completed!',
            files: prev.files.map(f => ({ ...f, status: 'complete' as const })),
            steps: prev.steps.map(s => ({ ...s, status: 'complete' as const })),
          };

        case 'error':
          return {
            ...prev,
            error: event.data.message as string,
            phase: 'idle',
          };

        default:
          return prev;
      }
    });
  }, []);

  // Connect via WebSocket (preferred) or SSE fallback
  const connect = useCallback((sessionId?: string) => {
    // Clean up existing connections
    if (eventSourceRef.current) {
      eventSourceRef.current.close();
      eventSourceRef.current = null;
    }
    if (webSocketRef.current) {
      webSocketRef.current.close();
      webSocketRef.current = null;
    }

    const newSessionId = sessionId || crypto.randomUUID();
    const baseUrl = import.meta.env.VITE_SUPABASE_URL;
    
    // Try WebSocket first
    if (state.useWebSocket) {
      const wsUrl = baseUrl.replace('https://', 'wss://').replace('http://', 'ws://') + 
        `/functions/v1/agent-activity-stream?sessionId=${newSessionId}`;
      
      console.log('[AgentActivityStream] Connecting via WebSocket:', wsUrl);
      
      try {
        const ws = new WebSocket(wsUrl);
        webSocketRef.current = ws;
        
        ws.onopen = () => {
          console.log('[AgentActivityStream] WebSocket connected');
          reconnectAttempts.current = 0;
          setState(prev => ({ ...prev, isConnected: true, error: null, sessionId: newSessionId }));
        };
        
        ws.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data) as AgentEvent;
            processEvent(data);
          } catch (error) {
            console.error('[AgentActivityStream] Failed to parse WebSocket message:', error);
          }
        };
        
        ws.onerror = (error) => {
          console.error('[AgentActivityStream] WebSocket error:', error);
        };
        
        ws.onclose = (event) => {
          console.log('[AgentActivityStream] WebSocket closed:', event.code, event.reason);
          webSocketRef.current = null;
          setState(prev => ({ ...prev, isConnected: false }));
          
          // Attempt reconnection
          if (reconnectAttempts.current < maxReconnectAttempts && state.isActive) {
            const delay = Math.min(1000 * Math.pow(2, reconnectAttempts.current), 30000);
            console.log(`[AgentActivityStream] Reconnecting in ${delay}ms...`);
            
            reconnectTimeoutRef.current = setTimeout(() => {
              reconnectAttempts.current++;
              connect(newSessionId);
            }, delay);
          }
        };
        
        return newSessionId;
      } catch (error) {
        console.warn('[AgentActivityStream] WebSocket failed, falling back to SSE:', error);
        setState(prev => ({ ...prev, useWebSocket: false }));
      }
    }
    
    // SSE fallback
    const url = `${baseUrl}/functions/v1/agent-activity-stream?sessionId=${newSessionId}`;
    console.log('[AgentActivityStream] Connecting via SSE:', url);

    const eventSource = new EventSource(url);
    eventSourceRef.current = eventSource;

    eventSource.onopen = () => {
      console.log('[AgentActivityStream] SSE connected');
      reconnectAttempts.current = 0;
      setState(prev => ({ ...prev, isConnected: true, error: null, sessionId: newSessionId }));
    };

    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data) as AgentEvent;
        processEvent(data);
      } catch (error) {
        console.error('[AgentActivityStream] Failed to parse SSE event:', error);
      }
    };

    eventSource.onerror = (error) => {
      console.error('[AgentActivityStream] SSE error:', error);
      eventSource.close();
      
      setState(prev => ({ ...prev, isConnected: false }));

      if (reconnectAttempts.current < maxReconnectAttempts) {
        const delay = Math.min(1000 * Math.pow(2, reconnectAttempts.current), 30000);
        console.log(`[AgentActivityStream] Reconnecting in ${delay}ms...`);
        
        reconnectTimeoutRef.current = setTimeout(() => {
          reconnectAttempts.current++;
          connect(newSessionId);
        }, delay);
      } else {
        setState(prev => ({ 
          ...prev, 
          error: 'Failed to connect to agent activity stream. Please refresh.' 
        }));
      }
    };

    return newSessionId;
  }, [processEvent, state.useWebSocket, state.isActive]);

  // Disconnect from the stream
  const disconnect = useCallback(() => {
    if (eventSourceRef.current) {
      eventSourceRef.current.close();
      eventSourceRef.current = null;
    }
    if (webSocketRef.current) {
      webSocketRef.current.close();
      webSocketRef.current = null;
    }
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }
    setState(prev => ({ ...prev, isConnected: false }));
  }, []);

  // Emit events to the backend (via WebSocket or HTTP)
  const emitEvents = useCallback(async (events: AgentEvent[]) => {
    if (!state.sessionId) {
      console.warn('[AgentActivityStream] Cannot emit events without session');
      return;
    }

    // Try WebSocket first if connected
    if (webSocketRef.current && webSocketRef.current.readyState === WebSocket.OPEN) {
      webSocketRef.current.send(JSON.stringify({
        type: 'emit_events',
        events,
      }));
      console.log('[AgentActivityStream] Events sent via WebSocket');
      return;
    }

    // Fallback to HTTP
    try {
      const response = await supabase.functions.invoke('agent-activity-stream', {
        body: { events },
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (response.error) {
        throw response.error;
      }

      console.log('[AgentActivityStream] Events emitted via HTTP:', response.data);
    } catch (error) {
      console.error('[AgentActivityStream] Failed to emit events:', error);
    }
  }, [state.sessionId]);

  // Parse AI response and emit events
  const parseAIResponse = useCallback((content: string) => {
    const events = parseResponseContent(content);
    
    // Process events locally for immediate feedback
    events.forEach(event => processEvent(event));
    
    // Also emit to backend for other connected clients
    if (webSocketRef.current && webSocketRef.current.readyState === WebSocket.OPEN) {
      webSocketRef.current.send(JSON.stringify({
        type: 'ai_response',
        content,
      }));
    }
    
    return events;
  }, [processEvent]);

  // Start activity with real-time streaming
  const startActivity = useCallback((initialThought?: string) => {
    const sessionId = connect();
    
    setState(prev => ({
      ...initialState,
      isActive: true,
      isConnected: prev.isConnected,
      sessionId,
      phase: 'thinking',
      currentThought: initialThought || 'Analyzing request...',
      allowedCommands: prev.allowedCommands,
    }));

    return sessionId;
  }, [connect]);

  // Simulate activity events (for testing/demo)
  const simulateActivity = useCallback(async (taskDescription: string) => {
    const sessionId = startActivity(`Analyzing: ${taskDescription}`);

    // Simulate a sequence of events
    const events: Array<{ delay: number; event: AgentEvent }> = [
      {
        delay: 500,
        event: {
          type: 'phase_changed',
          timestamp: new Date().toISOString(),
          data: { phase: 'reading', thought: 'Reading relevant files...' },
        },
      },
      {
        delay: 1000,
        event: {
          type: 'file_activity',
          timestamp: new Date().toISOString(),
          data: { 
            file: { 
              id: 'file-1', 
              path: 'src/components/Example.tsx', 
              action: 'read', 
              status: 'active' 
            } 
          },
        },
      },
      {
        delay: 1500,
        event: {
          type: 'file_activity',
          timestamp: new Date().toISOString(),
          data: { 
            file: { 
              id: 'file-1', 
              path: 'src/components/Example.tsx', 
              action: 'read', 
              status: 'complete' 
            } 
          },
        },
      },
      {
        delay: 2000,
        event: {
          type: 'phase_changed',
          timestamp: new Date().toISOString(),
          data: { phase: 'analyzing', thought: 'Understanding the codebase structure...' },
        },
      },
      {
        delay: 3000,
        event: {
          type: 'step_started',
          timestamp: new Date().toISOString(),
          data: { step: { id: 'step-1', label: 'Analyze requirements', description: 'Understanding what needs to be done' } },
        },
      },
      {
        delay: 4000,
        event: {
          type: 'step_completed',
          timestamp: new Date().toISOString(),
          data: { stepId: 'step-1', duration: 1000 },
        },
      },
      {
        delay: 4500,
        event: {
          type: 'phase_changed',
          timestamp: new Date().toISOString(),
          data: { phase: 'writing', thought: 'Implementing changes...' },
        },
      },
      {
        delay: 5000,
        event: {
          type: 'file_activity',
          timestamp: new Date().toISOString(),
          data: { 
            file: { 
              id: 'file-2', 
              path: 'src/components/NewFeature.tsx', 
              action: 'create', 
              status: 'active' 
            } 
          },
        },
      },
      {
        delay: 6500,
        event: {
          type: 'file_activity',
          timestamp: new Date().toISOString(),
          data: { 
            file: { 
              id: 'file-2', 
              path: 'src/components/NewFeature.tsx', 
              action: 'create', 
              status: 'complete',
              changes: 45 
            } 
          },
        },
      },
      {
        delay: 7000,
        event: {
          type: 'stats_updated',
          timestamp: new Date().toISOString(),
          data: { totalEdits: 1, linesChanged: 45, tokensProcessed: 1250 },
        },
      },
      {
        delay: 8000,
        event: {
          type: 'activity_completed',
          timestamp: new Date().toISOString(),
          data: { message: 'All changes completed successfully!' },
        },
      },
    ];

    // Process events with delays
    for (const { delay, event } of events) {
      await new Promise(resolve => setTimeout(resolve, delay));
      processEvent(event);
    }

    return sessionId;
  }, [startActivity, processEvent]);

  // Handle command approval
  const approveCommand = useCallback((commandId: string, choice: CommandApprovalChoice) => {
    setState(prev => {
      const command = prev.pendingCommands.find(c => c.id === commandId);
      if (!command) return prev;

      const newAllowedCommands = new Set(prev.allowedCommands);
      if (choice === 'always_allow') {
        const commandSignature = `${command.type}:${command.command}`;
        newAllowedCommands.add(commandSignature);
      }

      return {
        ...prev,
        pendingCommands: prev.pendingCommands.map(c =>
          c.id === commandId ? { ...c, status: 'running' as const } : c
        ),
        allowedCommands: newAllowedCommands,
        phase: 'executing',
        currentThought: `Running: ${command.command}`,
      };
    });

    // Emit approval event to backend
    emitEvents([{
      type: 'command_executed',
      timestamp: new Date().toISOString(),
      data: { commandId, approved: true, choice },
    }]);
  }, [emitEvents]);

  // Skip a command
  const skipCommand = useCallback((commandId: string) => {
    setState(prev => ({
      ...prev,
      pendingCommands: prev.pendingCommands.map(c =>
        c.id === commandId ? { ...c, status: 'skipped' as const } : c
      ),
      phase: prev.pendingCommands.filter(c => c.id !== commandId && c.status === 'pending').length > 0
        ? 'awaiting_approval'
        : 'executing',
    }));
  }, []);

  // Set phase manually
  const setPhase = useCallback((phase: AgentPhase, thought?: string) => {
    setState(prev => ({
      ...prev,
      phase,
      currentThought: thought || prev.currentThought,
    }));
  }, []);

  // Add a file activity
  const addFileActivity = useCallback((file: Omit<FileActivity, 'id' | 'timestamp'>) => {
    setState(prev => ({
      ...prev,
      files: [
        ...prev.files,
        {
          ...file,
          id: `file-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          timestamp: new Date(),
        },
      ],
    }));
  }, []);

  // Add a pending command
  const addPendingCommand = useCallback((command: Omit<CommandToApprove, 'id' | 'timestamp' | 'status'>) => {
    const newCommand: CommandToApprove = {
      ...command,
      id: `cmd-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date(),
      status: 'pending',
    };

    setState(prev => {
      // Check if this command type is always allowed
      const commandSignature = `${command.type}:${command.command}`;
      if (prev.allowedCommands.has(commandSignature)) {
        return {
          ...prev,
          pendingCommands: [...prev.pendingCommands, { ...newCommand, status: 'approved' as const }],
          phase: 'executing',
          currentThought: `Running: ${command.command}`,
        };
      }

      return {
        ...prev,
        pendingCommands: [...prev.pendingCommands, newCommand],
        phase: 'awaiting_approval',
        currentThought: `Waiting for approval: ${command.command}`,
      };
    });

    return newCommand.id;
  }, []);

  // Save activity to database for persistence
  const saveActivityToHistory = useCallback(async (
    conversationId?: string,
    taskKey?: string,
    summary?: string
  ) => {
    if (!state.sessionId) {
      console.warn('[AgentActivityStream] Cannot save activity without session');
      return null;
    }

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        console.warn('[AgentActivityStream] Cannot save activity without auth');
        return null;
      }

      const { data, error } = await supabase
        .from('agent_activity_history')
        .insert({
          user_id: session.user.id,
          session_id: state.sessionId,
          conversation_id: conversationId,
          task_key: taskKey,
          phase: state.phase,
          total_edits: state.totalEdits,
          lines_changed: state.linesChanged,
          tokens_processed: state.tokensProcessed,
          files: state.files.map(f => ({
            path: f.path,
            action: f.action,
            status: f.status,
            changes: f.changes,
          })),
          steps: state.steps.map(s => ({
            label: s.label,
            description: s.description,
            status: s.status,
            duration: s.duration,
          })),
          commands: state.pendingCommands.map(c => ({
            type: c.type,
            command: c.command,
            status: c.status,
            risk: c.risk,
          })),
          summary,
          completed_at: state.phase === 'complete' ? new Date().toISOString() : null,
          metadata: {
            thought: state.currentThought,
          },
        })
        .select()
        .single();

      if (error) {
        console.error('[AgentActivityStream] Failed to save activity:', error);
        return null;
      }

      console.log('[AgentActivityStream] Activity saved:', data.id);
      return data.id;
    } catch (error) {
      console.error('[AgentActivityStream] Failed to save activity:', error);
      return null;
    }
  }, [state]);

  // Complete activity
  const completeActivity = useCallback(() => {
    setState(prev => ({
      ...prev,
      phase: 'complete',
      currentThought: 'All tasks completed!',
      files: prev.files.map(f => ({ ...f, status: 'complete' as const })),
      steps: prev.steps.map(s => ({ ...s, status: 'complete' as const })),
    }));
  }, []);

  // Reset activity
  const resetActivity = useCallback(() => {
    disconnect();
    setState(prev => ({
      ...initialState,
      allowedCommands: prev.allowedCommands,
    }));
  }, [disconnect]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      disconnect();
    };
  }, [disconnect]);

  return {
    ...state,
    connect,
    disconnect,
    startActivity,
    simulateActivity,
    emitEvents,
    processEvent,
    parseAIResponse,
    approveCommand,
    skipCommand,
    setPhase,
    addFileActivity,
    addPendingCommand,
    completeActivity,
    resetActivity,
    saveActivityToHistory,
  };
}
