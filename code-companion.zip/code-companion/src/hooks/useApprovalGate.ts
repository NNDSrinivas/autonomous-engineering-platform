import { useState, useCallback, createContext, useContext, ReactNode, createElement } from 'react';

export type WriteActionType = 
  | 'github_create_branch'
  | 'github_create_pr'
  | 'github_merge_pr'
  | 'github_commit_files'
  | 'github_update_file'
  | 'cicd_rerun_workflow'
  | 'cicd_cancel_workflow'
  | 'cicd_trigger_deploy'
  | 'slack_post_message'
  | 'slack_post_thread_reply'
  | 'confluence_create_page'
  | 'confluence_update_page'
  | 'jira_update_status'
  | 'jira_add_comment'
  | 'jira_link_pr';

export type RiskLevel = 'low' | 'medium' | 'high' | 'critical';

export interface PendingAction {
  id: string;
  type: WriteActionType;
  title: string;
  description: string;
  risk: RiskLevel;
  details?: Record<string, unknown>;
  metadata?: {
    integration: string;
    target?: string;
    draftContent?: string;
  };
  createdAt: Date;
  expiresAt?: Date;
}

export interface ApprovalSettings {
  requireApprovalForAllWrites: boolean;
  github: {
    requireApproval: boolean;
    autoApproveForBranches?: string[];
    riskThreshold: RiskLevel;
  };
  cicd: {
    requireApproval: boolean;
    autoApproveRerun: boolean;
    requireApprovalForDeploy: boolean;
  };
  slack: {
    requireApproval: boolean;
    draftOnly: boolean;
  };
  confluence: {
    requireApproval: boolean;
    draftOnly: boolean;
  };
  jira: {
    requireApproval: boolean;
    autoApproveComments: boolean;
  };
}

const DEFAULT_SETTINGS: ApprovalSettings = {
  requireApprovalForAllWrites: true,
  github: {
    requireApproval: true,
    riskThreshold: 'low',
  },
  cicd: {
    requireApproval: true,
    autoApproveRerun: false,
    requireApprovalForDeploy: true,
  },
  slack: {
    requireApproval: true,
    draftOnly: true,
  },
  confluence: {
    requireApproval: true,
    draftOnly: true,
  },
  jira: {
    requireApproval: true,
    autoApproveComments: false,
  },
};

const ACTION_LABELS: Record<WriteActionType, string> = {
  github_create_branch: 'Create Git Branch',
  github_create_pr: 'Create Pull Request',
  github_merge_pr: 'Merge Pull Request',
  github_commit_files: 'Commit Files',
  github_update_file: 'Update File',
  cicd_rerun_workflow: 'Re-run CI/CD Workflow',
  cicd_cancel_workflow: 'Cancel CI/CD Workflow',
  cicd_trigger_deploy: 'Trigger Deployment',
  slack_post_message: 'Post Slack Message',
  slack_post_thread_reply: 'Reply in Slack Thread',
  confluence_create_page: 'Create Confluence Page',
  confluence_update_page: 'Update Confluence Page',
  jira_update_status: 'Update Jira Status',
  jira_add_comment: 'Add Jira Comment',
  jira_link_pr: 'Link PR to Jira Issue',
};

const ACTION_RISK_DEFAULTS: Record<WriteActionType, RiskLevel> = {
  github_create_branch: 'low',
  github_create_pr: 'medium',
  github_merge_pr: 'high',
  github_commit_files: 'medium',
  github_update_file: 'medium',
  cicd_rerun_workflow: 'low',
  cicd_cancel_workflow: 'medium',
  cicd_trigger_deploy: 'high',
  slack_post_message: 'low',
  slack_post_thread_reply: 'low',
  confluence_create_page: 'medium',
  confluence_update_page: 'medium',
  jira_update_status: 'low',
  jira_add_comment: 'low',
  jira_link_pr: 'low',
};

interface ApprovalGateContextValue {
  pendingActions: PendingAction[];
  settings: ApprovalSettings;
  updateSettings: (settings: Partial<ApprovalSettings>) => void;
  requestApproval: (action: Omit<PendingAction, 'id' | 'createdAt'>) => Promise<boolean>;
  approveAction: (actionId: string) => void;
  rejectAction: (actionId: string) => void;
  clearExpiredActions: () => void;
  getActionLabel: (type: WriteActionType) => string;
  getDefaultRisk: (type: WriteActionType) => RiskLevel;
  isDraftOnly: (type: WriteActionType) => boolean;
  requiresApproval: (type: WriteActionType) => boolean;
}

const ApprovalGateContext = createContext<ApprovalGateContextValue | null>(null);

export function useApprovalGate() {
  const context = useContext(ApprovalGateContext);
  if (!context) {
    throw new Error('useApprovalGate must be used within an ApprovalGateProvider');
  }
  return context;
}

interface ApprovalGateProviderProps {
  children: ReactNode;
  initialSettings?: Partial<ApprovalSettings>;
}

export function ApprovalGateProvider({ children, initialSettings }: ApprovalGateProviderProps) {
  const [pendingActions, setPendingActions] = useState<PendingAction[]>([]);
  const [settings, setSettings] = useState<ApprovalSettings>({
    ...DEFAULT_SETTINGS,
    ...initialSettings,
  });
  const [resolvers, setResolvers] = useState<Map<string, { resolve: (approved: boolean) => void }>>(new Map());

  const updateSettings = useCallback((newSettings: Partial<ApprovalSettings>) => {
    setSettings(prev => ({
      ...prev,
      ...newSettings,
    }));
  }, []);

  const isDraftOnly = useCallback((type: WriteActionType): boolean => {
    if (type.startsWith('slack_')) {
      return settings.slack.draftOnly;
    }
    if (type.startsWith('confluence_')) {
      return settings.confluence.draftOnly;
    }
    return false;
  }, [settings]);

  const requiresApproval = useCallback((type: WriteActionType): boolean => {
    if (settings.requireApprovalForAllWrites) return true;

    if (type.startsWith('github_')) {
      return settings.github.requireApproval;
    }
    if (type.startsWith('cicd_')) {
      if (type === 'cicd_rerun_workflow' && settings.cicd.autoApproveRerun) {
        return false;
      }
      return settings.cicd.requireApproval;
    }
    if (type.startsWith('slack_')) {
      return settings.slack.requireApproval;
    }
    if (type.startsWith('confluence_')) {
      return settings.confluence.requireApproval;
    }
    if (type.startsWith('jira_')) {
      if (type === 'jira_add_comment' && settings.jira.autoApproveComments) {
        return false;
      }
      return settings.jira.requireApproval;
    }
    return true;
  }, [settings]);

  const requestApproval = useCallback((action: Omit<PendingAction, 'id' | 'createdAt'>): Promise<boolean> => {
    if (isDraftOnly(action.type)) {
      console.log('[ApprovalGate] Action ' + action.type + ' is draft-only. Draft saved.');
      return Promise.resolve(false);
    }

    if (!requiresApproval(action.type)) {
      console.log('[ApprovalGate] Auto-approving action ' + action.type);
      return Promise.resolve(true);
    }

    const actionId = 'action_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    const pendingAction: PendingAction = {
      ...action,
      id: actionId,
      createdAt: new Date(),
      expiresAt: new Date(Date.now() + 30 * 60 * 1000),
    };

    return new Promise((resolve) => {
      setPendingActions(prev => [...prev, pendingAction]);
      setResolvers(prev => new Map(prev).set(actionId, { resolve }));
    });
  }, [isDraftOnly, requiresApproval]);

  const approveAction = useCallback((actionId: string) => {
    const resolver = resolvers.get(actionId);
    if (resolver) {
      resolver.resolve(true);
      setResolvers(prev => {
        const next = new Map(prev);
        next.delete(actionId);
        return next;
      });
    }
    setPendingActions(prev => prev.filter(a => a.id !== actionId));
  }, [resolvers]);

  const rejectAction = useCallback((actionId: string) => {
    const resolver = resolvers.get(actionId);
    if (resolver) {
      resolver.resolve(false);
      setResolvers(prev => {
        const next = new Map(prev);
        next.delete(actionId);
        return next;
      });
    }
    setPendingActions(prev => prev.filter(a => a.id !== actionId));
  }, [resolvers]);

  const clearExpiredActions = useCallback(() => {
    const now = new Date();
    setPendingActions(prev => {
      const expired = prev.filter(a => a.expiresAt && a.expiresAt < now);
      expired.forEach(a => {
        const resolver = resolvers.get(a.id);
        if (resolver) resolver.resolve(false);
      });
      return prev.filter(a => !a.expiresAt || a.expiresAt >= now);
    });
  }, [resolvers]);

  const getActionLabel = useCallback((type: WriteActionType) => {
    return ACTION_LABELS[type] || type;
  }, []);

  const getDefaultRisk = useCallback((type: WriteActionType) => {
    return ACTION_RISK_DEFAULTS[type] || 'medium';
  }, []);

  const value: ApprovalGateContextValue = {
    pendingActions,
    settings,
    updateSettings,
    requestApproval,
    approveAction,
    rejectAction,
    clearExpiredActions,
    getActionLabel,
    getDefaultRisk,
    isDraftOnly,
    requiresApproval,
  };

  return createElement(ApprovalGateContext.Provider, { value }, children);
}

export function useApprovalStatus() {
  const { pendingActions, settings } = useApprovalGate();
  
  return {
    hasPendingApprovals: pendingActions.length > 0,
    pendingCount: pendingActions.length,
    settings,
  };
}
