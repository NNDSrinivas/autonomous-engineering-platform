import { useState, useCallback } from 'react';
import { toast } from 'sonner';
import { useMemory } from './useMemory';
import type { JiraTask, ConfluenceDoc, SourceLink } from '@/types';

// Atlassian Cloud ID for the connected workspace
const ATLASSIAN_CLOUD_ID = '037e3789-12e1-42be-81b5-b7f903037b89';
const ATLASSIAN_CLOUD_URL = 'https://srinivasn7779.atlassian.net';

export interface JiraMCPIssue {
  id: string;
  key: string;
  self: string;
  fields: {
    summary: string;
    description: string | null;
    status: { name: string };
    priority: { name: string } | null;
    issuetype: { name: string };
    assignee?: { displayName: string; avatarUrl?: string } | null;
    created: string;
    updated?: string;
    labels?: string[];
    project?: { key: string; name: string };
  };
}

export interface ConfluenceMCPPage {
  id: string;
  title: string;
  spaceId: string;
  status: string;
  createdAt: string;
  body?: string;
  _links?: { webui: string };
}

export interface ConfluenceMCPSpace {
  id: string;
  key: string;
  name: string;
  type: string;
  status: string;
  _links?: { base: string; webui: string };
}

const mapJiraStatusToLocal = (status: string): JiraTask['status'] => {
  const statusLower = status.toLowerCase();
  if (statusLower.includes('done') || statusLower.includes('complete')) return 'done';
  if (statusLower.includes('progress') || statusLower.includes('development')) return 'in_progress';
  if (statusLower.includes('review') || statusLower.includes('testing')) return 'in_review';
  if (statusLower.includes('blocked')) return 'blocked';
  return 'todo';
};

const mapJiraPriorityToLocal = (priority: string | null): JiraTask['priority'] => {
  if (!priority) return 'medium';
  const priorityLower = priority.toLowerCase();
  if (priorityLower.includes('critical') || priorityLower.includes('highest')) return 'critical';
  if (priorityLower.includes('high')) return 'high';
  if (priorityLower.includes('medium') || priorityLower.includes('normal')) return 'medium';
  return 'low';
};

export function useAtlassianMCP() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { storeTask, storeMemory } = useMemory();

  // Transform MCP Jira issue to local JiraTask format
  const transformMCPIssue = useCallback((issue: JiraMCPIssue): JiraTask => ({
    id: issue.id,
    key: issue.key,
    title: issue.fields?.summary || 'Untitled',
    description: issue.fields?.description || '',
    status: mapJiraStatusToLocal(issue.fields?.status?.name || 'To Do'),
    priority: mapJiraPriorityToLocal(issue.fields?.priority?.name || null),
    assignee: issue.fields?.assignee?.displayName || null,
    project: issue.fields?.project?.key || null,
    labels: issue.fields?.labels || [],
    storyPoints: null,
    sprint: null,
    acceptanceCriteria: [],
    relatedDocs: [],
    relatedMessages: [],
    relatedMeetings: [],
    linkedPRs: [],
    createdAt: issue.fields?.created ? new Date(issue.fields.created) : undefined,
    updatedAt: issue.fields?.updated ? new Date(issue.fields.updated) : undefined,
  }), []);

  // Transform MCP Confluence page to local format
  const transformMCPPage = useCallback((page: ConfluenceMCPPage, baseUrl: string): ConfluenceDoc => ({
    id: page.id,
    title: page.title,
    space: page.spaceId,
    url: `${baseUrl}${page._links?.webui || `/pages/${page.id}`}`,
    lastUpdated: new Date(page.createdAt),
    author: '',
    type: 'wiki',
  }), []);

  // Sync Jira task to memory for RAG
  const syncTaskToMemory = useCallback(async (task: JiraTask) => {
    try {
      await storeTask({
        task_id: task.id,
        task_key: task.key,
        title: task.title,
        description: task.description,
        status: task.status,
        priority: task.priority,
        assignee: task.assignee || undefined,
        related_content: [
          ...task.relatedDocs.map(d => ({ type: 'doc', ...d })),
          ...task.relatedMessages.map(m => ({ type: 'message', ...m })),
        ],
      });
    } catch (err) {
      console.error('Failed to sync task to memory:', err);
    }
  }, [storeTask]);

  // Sync Confluence page to memory for RAG
  const syncPageToMemory = useCallback(async (page: ConfluenceMCPPage, baseUrl: string) => {
    try {
      await storeMemory({
        memory_type: 'documentation',
        source: 'confluence',
        title: page.title,
        content: page.body || page.title,
        source_url: `${baseUrl}${page._links?.webui || `/pages/${page.id}`}`,
        source_id: page.id,
        metadata: {
          spaceId: page.spaceId,
          status: page.status,
        },
      });
    } catch (err) {
      console.error('Failed to sync page to memory:', err);
    }
  }, [storeMemory]);

  // Get Atlassian connection info
  const getCloudInfo = useCallback(() => ({
    cloudId: ATLASSIAN_CLOUD_ID,
    cloudUrl: ATLASSIAN_CLOUD_URL,
    isConnected: true, // MCP connector is already connected
  }), []);

  // Process fetched Jira issues from MCP
  const processJiraIssues = useCallback(async (issues: JiraMCPIssue[]): Promise<JiraTask[]> => {
    setIsLoading(true);
    setError(null);

    try {
      const tasks = issues.map(transformMCPIssue);
      
      // Sync to memory for RAG context
      for (const task of tasks.slice(0, 10)) {
        await syncTaskToMemory(task);
      }

      toast.success(`Loaded ${tasks.length} tasks from Jira via MCP`);
      return tasks;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to process Jira issues';
      setError(message);
      console.error('Jira MCP processing error:', err);
      return [];
    } finally {
      setIsLoading(false);
    }
  }, [transformMCPIssue, syncTaskToMemory]);

  // Process fetched Confluence pages from MCP
  const processConfluencePages = useCallback(async (
    pages: ConfluenceMCPPage[], 
    baseUrl: string = ATLASSIAN_CLOUD_URL + '/wiki'
  ): Promise<ConfluenceDoc[]> => {
    setIsLoading(true);
    setError(null);

    try {
      const docs = pages.map(p => transformMCPPage(p, baseUrl));
      
      // Sync to memory for RAG context
      for (const page of pages.slice(0, 10)) {
        await syncPageToMemory(page, baseUrl);
      }

      toast.success(`Loaded ${docs.length} pages from Confluence via MCP`);
      return docs;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to process Confluence pages';
      setError(message);
      console.error('Confluence MCP processing error:', err);
      return [];
    } finally {
      setIsLoading(false);
    }
  }, [transformMCPPage, syncPageToMemory]);

  // Create source links for task context
  const createConfluenceSourceLinks = useCallback((pages: ConfluenceMCPPage[], baseUrl: string): SourceLink[] => {
    return pages.map(page => ({
      type: 'confluence' as const,
      title: page.title,
      url: `${baseUrl}${page._links?.webui || `/pages/${page.id}`}`,
      snippet: page.body?.substring(0, 200) || undefined,
    }));
  }, []);

  return {
    isLoading,
    error,
    cloudId: ATLASSIAN_CLOUD_ID,
    cloudUrl: ATLASSIAN_CLOUD_URL,
    getCloudInfo,
    processJiraIssues,
    processConfluencePages,
    transformMCPIssue,
    transformMCPPage,
    syncTaskToMemory,
    syncPageToMemory,
    createConfluenceSourceLinks,
  };
}
