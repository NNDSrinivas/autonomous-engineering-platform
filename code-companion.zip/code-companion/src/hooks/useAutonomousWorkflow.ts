import { useState, useCallback, useRef, useEffect } from 'react';
import { toast } from 'sonner';
import { useEndToEndWorkflow, WorkflowPhase, WorkflowStepResult } from './useEndToEndWorkflow';
import type { JiraTask } from '@/types';

export type CheckpointLevel = 'all' | 'high_risk' | 'critical_only' | 'none';

export interface CheckpointConfig {
  level: CheckpointLevel;
  phases: Partial<Record<WorkflowPhase, boolean>>;
  autoRetryOnFailure: boolean;
  maxRetries: number;
  notifyOnCompletion: boolean;
  pauseOnError: boolean;
  timeout: number; // in seconds per phase
}

export interface AutonomousExecutionState {
  isRunning: boolean;
  isPaused: boolean;
  currentTask: JiraTask | null;
  executedPhases: WorkflowPhase[];
  skippedPhases: WorkflowPhase[];
  startedAt: Date | null;
  estimatedCompletion: Date | null;
  retryCount: number;
  logs: ExecutionLog[];
}

export interface ExecutionLog {
  id: string;
  timestamp: Date;
  phase: WorkflowPhase;
  type: 'info' | 'success' | 'warning' | 'error';
  message: string;
  data?: Record<string, unknown>;
}

const DEFAULT_CHECKPOINT_CONFIG: CheckpointConfig = {
  level: 'high_risk',
  phases: {
    start_task: false,
    create_branch: false,
    implement_code: true,
    create_pr: true,
    link_jira: false,
    post_slack: false,
  },
  autoRetryOnFailure: true,
  maxRetries: 2,
  notifyOnCompletion: true,
  pauseOnError: true,
  timeout: 120,
};

const PHASE_RISK_LEVELS: Record<WorkflowPhase, 'low' | 'medium' | 'high' | 'critical'> = {
  idle: 'low',
  start_task: 'low',
  create_branch: 'low',
  implement_code: 'high',
  create_pr: 'high',
  link_jira: 'medium',
  post_slack: 'low',
  completed: 'low',
  failed: 'low',
};

export interface UseAutonomousWorkflowOptions {
  owner: string;
  repo: string;
  baseBranch?: string;
  slackChannel?: string;
  onPhaseComplete?: (phase: WorkflowPhase, result: WorkflowStepResult) => void;
  onWorkflowComplete?: (results: WorkflowStepResult[]) => void;
  onCheckpointReached?: (phase: WorkflowPhase) => void;
}

export function useAutonomousWorkflow(options: UseAutonomousWorkflowOptions) {
  const {
    owner,
    repo,
    baseBranch = 'main',
    slackChannel = '#engineering',
    onPhaseComplete,
    onWorkflowComplete,
    onCheckpointReached,
  } = options;

  const [config, setConfig] = useState<CheckpointConfig>(DEFAULT_CHECKPOINT_CONFIG);
  const [executionState, setExecutionState] = useState<AutonomousExecutionState>({
    isRunning: false,
    isPaused: false,
    currentTask: null,
    executedPhases: [],
    skippedPhases: [],
    startedAt: null,
    estimatedCompletion: null,
    retryCount: 0,
    logs: [],
  });

  const abortControllerRef = useRef<AbortController | null>(null);
  const checkpointPromiseRef = useRef<{
    resolve: () => void;
    reject: (reason?: string) => void;
  } | null>(null);

  const workflow = useEndToEndWorkflow({
    owner,
    repo,
    baseBranch,
    slackChannel,
  });

  // Add log entry
  const addLog = useCallback((
    phase: WorkflowPhase,
    type: ExecutionLog['type'],
    message: string,
    data?: Record<string, unknown>
  ) => {
    const log: ExecutionLog = {
      id: `log_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date(),
      phase,
      type,
      message,
      data,
    };
    setExecutionState(prev => ({
      ...prev,
      logs: [...prev.logs, log],
    }));
    return log;
  }, []);

  // Check if phase requires checkpoint
  const requiresCheckpoint = useCallback((phase: WorkflowPhase): boolean => {
    if (config.level === 'none') return false;
    if (config.level === 'all') return true;
    
    const phaseRisk = PHASE_RISK_LEVELS[phase];
    
    if (config.level === 'critical_only') {
      return phaseRisk === 'critical' || config.phases[phase] === true;
    }
    
    if (config.level === 'high_risk') {
      return phaseRisk === 'critical' || phaseRisk === 'high' || config.phases[phase] === true;
    }
    
    return config.phases[phase] === true;
  }, [config]);

  // Wait at checkpoint
  const waitAtCheckpoint = useCallback((phase: WorkflowPhase): Promise<void> => {
    return new Promise((resolve, reject) => {
      checkpointPromiseRef.current = { resolve, reject };
      onCheckpointReached?.(phase);
      addLog(phase, 'warning', `Checkpoint reached - awaiting approval for ${phase.replace(/_/g, ' ')}`);
      toast.info(`Autonomous workflow paused at: ${phase.replace(/_/g, ' ')}`);
    });
  }, [onCheckpointReached, addLog]);

  // Resume from checkpoint
  const resumeFromCheckpoint = useCallback(() => {
    if (checkpointPromiseRef.current) {
      checkpointPromiseRef.current.resolve();
      checkpointPromiseRef.current = null;
      addLog(workflow.state.currentPhase, 'info', 'Checkpoint approved - resuming execution');
      toast.success('Workflow resumed');
    }
  }, [addLog, workflow.state.currentPhase]);

  // Skip current checkpoint
  const skipCheckpoint = useCallback(() => {
    if (checkpointPromiseRef.current) {
      checkpointPromiseRef.current.reject('skipped');
      checkpointPromiseRef.current = null;
      setExecutionState(prev => ({
        ...prev,
        skippedPhases: [...prev.skippedPhases, workflow.state.currentPhase],
      }));
      addLog(workflow.state.currentPhase, 'warning', 'Checkpoint skipped');
    }
  }, [addLog, workflow.state.currentPhase]);

  // Execute single phase
  const executePhase = useCallback(async (phase: WorkflowPhase): Promise<boolean> => {
    if (abortControllerRef.current?.signal.aborted) {
      return false;
    }

    addLog(phase, 'info', `Executing phase: ${phase.replace(/_/g, ' ')}`);

    // Check for checkpoint
    if (requiresCheckpoint(phase)) {
      setExecutionState(prev => ({ ...prev, isPaused: true }));
      try {
        await waitAtCheckpoint(phase);
        setExecutionState(prev => ({ ...prev, isPaused: false }));
      } catch (err) {
        if (err === 'skipped') {
          addLog(phase, 'warning', `Phase skipped: ${phase.replace(/_/g, ' ')}`);
          return true; // Continue to next phase
        }
        return false;
      }
    }

    // Execute the phase using the workflow
    await workflow.approve();
    
    // Wait for phase to complete
    await new Promise<void>((resolve) => {
      const checkComplete = setInterval(() => {
        if (
          workflow.state.currentPhase !== phase ||
          workflow.state.currentPhase === 'completed' ||
          workflow.state.currentPhase === 'failed'
        ) {
          clearInterval(checkComplete);
          resolve();
        }
      }, 100);
    });

    const result = workflow.state.results.find(r => r.phase === phase);
    if (result) {
      addLog(phase, result.success ? 'success' : 'error', result.message, result.data);
      onPhaseComplete?.(phase, result);
      
      setExecutionState(prev => ({
        ...prev,
        executedPhases: [...prev.executedPhases, phase],
      }));
    }

    return result?.success ?? false;
  }, [requiresCheckpoint, waitAtCheckpoint, workflow, addLog, onPhaseComplete]);

  // Start autonomous execution
  const startAutonomousExecution = useCallback(async (task: JiraTask) => {
    abortControllerRef.current = new AbortController();
    
    const estimatedMinutes = 5; // Rough estimate
    const estimatedCompletion = new Date(Date.now() + estimatedMinutes * 60 * 1000);

    setExecutionState({
      isRunning: true,
      isPaused: false,
      currentTask: task,
      executedPhases: [],
      skippedPhases: [],
      startedAt: new Date(),
      estimatedCompletion,
      retryCount: 0,
      logs: [],
    });

    addLog('idle', 'info', `Starting autonomous workflow for ${task.key}: ${task.title}`);
    toast.success(`Autonomous workflow started for ${task.key}`);

    // Start the workflow
    await workflow.startTask(task);
  }, [addLog, workflow]);

  // Pause execution
  const pauseExecution = useCallback(() => {
    setExecutionState(prev => ({ ...prev, isPaused: true }));
    addLog(workflow.state.currentPhase, 'warning', 'Execution paused by user');
    toast.info('Workflow paused');
  }, [addLog, workflow.state.currentPhase]);

  // Resume execution
  const resumeExecution = useCallback(() => {
    setExecutionState(prev => ({ ...prev, isPaused: false }));
    addLog(workflow.state.currentPhase, 'info', 'Execution resumed');
    toast.success('Workflow resumed');
    
    // If awaiting approval, approve it
    if (workflow.state.awaitingApproval) {
      workflow.approve();
    }
  }, [addLog, workflow]);

  // Cancel execution
  const cancelExecution = useCallback(() => {
    abortControllerRef.current?.abort();
    setExecutionState(prev => ({
      ...prev,
      isRunning: false,
      isPaused: false,
    }));
    workflow.reset();
    addLog(workflow.state.currentPhase, 'warning', 'Execution cancelled by user');
    toast.warning('Workflow cancelled');
  }, [addLog, workflow]);

  // Update config
  const updateConfig = useCallback((updates: Partial<CheckpointConfig>) => {
    setConfig(prev => ({ ...prev, ...updates }));
  }, []);

  // Toggle phase checkpoint
  const togglePhaseCheckpoint = useCallback((phase: WorkflowPhase, enabled: boolean) => {
    setConfig(prev => ({
      ...prev,
      phases: {
        ...prev.phases,
        [phase]: enabled,
      },
    }));
  }, []);

  // Monitor workflow state changes
  useEffect(() => {
    if (!executionState.isRunning) return;

    // Auto-approve if not a checkpoint and not paused
    if (
      workflow.state.awaitingApproval &&
      !executionState.isPaused &&
      !requiresCheckpoint(workflow.state.currentPhase)
    ) {
      workflow.approve();
    }

    // Check for completion
    if (workflow.state.currentPhase === 'completed') {
      setExecutionState(prev => ({ ...prev, isRunning: false }));
      addLog('completed', 'success', 'Workflow completed successfully');
      onWorkflowComplete?.(workflow.state.results);
      
      if (config.notifyOnCompletion) {
        toast.success(`Autonomous workflow completed for ${executionState.currentTask?.key}`);
      }
    }

    // Check for failure
    if (workflow.state.currentPhase === 'failed') {
      if (config.autoRetryOnFailure && executionState.retryCount < config.maxRetries) {
        setExecutionState(prev => ({ ...prev, retryCount: prev.retryCount + 1 }));
        addLog('failed', 'warning', `Retrying workflow (attempt ${executionState.retryCount + 1}/${config.maxRetries})`);
        if (executionState.currentTask) {
          workflow.reset();
          setTimeout(() => {
            if (executionState.currentTask) {
              workflow.startTask(executionState.currentTask);
            }
          }, 2000);
        }
      } else {
        setExecutionState(prev => ({ ...prev, isRunning: false }));
        addLog('failed', 'error', `Workflow failed: ${workflow.state.error}`);
        toast.error(`Workflow failed: ${workflow.state.error}`);
      }
    }
  }, [
    workflow.state.awaitingApproval,
    workflow.state.currentPhase,
    workflow.state.error,
    workflow.state.results,
    executionState.isRunning,
    executionState.isPaused,
    executionState.currentTask,
    executionState.retryCount,
    requiresCheckpoint,
    config,
    addLog,
    onWorkflowComplete,
    workflow,
  ]);

  return {
    // State
    config,
    executionState,
    workflowState: workflow.state,
    
    // Actions
    startAutonomousExecution,
    pauseExecution,
    resumeExecution,
    cancelExecution,
    resumeFromCheckpoint,
    skipCheckpoint,
    
    // Config
    updateConfig,
    togglePhaseCheckpoint,
    
    // Utilities
    requiresCheckpoint,
    getPhaseInfo: workflow.getPhaseInfo,
  };
}
