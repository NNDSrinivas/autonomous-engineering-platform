import { useState, useEffect, useCallback, useRef } from 'react';
import { toast } from 'sonner';

export interface CICDBuildStatus {
  id: number;
  name: string;
  status: 'queued' | 'in_progress' | 'completed' | 'failure' | 'cancelled';
  conclusion?: 'success' | 'failure' | 'cancelled' | 'skipped' | 'timed_out' | null;
  html_url: string;
  head_branch: string;
  head_sha: string;
  run_number: number;
  created_at: string;
  updated_at: string;
}

interface UseCICDNotificationsOptions {
  owner?: string;
  repo?: string;
  pollInterval?: number;
  enabled?: boolean;
  soundEnabled?: boolean;
}

export function useCICDNotifications({
  owner,
  repo,
  pollInterval = 30000,
  enabled = true,
  soundEnabled = true,
}: UseCICDNotificationsOptions = {}) {
  const [builds, setBuilds] = useState<CICDBuildStatus[]>([]);
  const [newNotifications, setNewNotifications] = useState<CICDBuildStatus[]>([]);
  const previousBuildsRef = useRef<Map<number, CICDBuildStatus>>(new Map());
  const audioContextRef = useRef<AudioContext | null>(null);

  const playAlertSound = useCallback(() => {
    if (!soundEnabled) return;
    
    try {
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
      }
      const ctx = audioContextRef.current;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.frequency.setValueAtTime(440, ctx.currentTime);
      osc.type = 'sine';
      gain.gain.setValueAtTime(0, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(0.3, ctx.currentTime + 0.05);
      gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.3);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.3);
    } catch (e) {
      console.error('Failed to play alert sound:', e);
    }
  }, [soundEnabled]);

  const checkForUpdates = useCallback(async () => {
    if (!owner || !repo) return;

    try {
      const { supabase } = await import('@/integrations/supabase/client');
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/github-api`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            action: 'get_workflow_runs',
            owner,
            repo,
          }),
        }
      );

      if (!response.ok) return;

      const result = await response.json();
      const currentBuilds: CICDBuildStatus[] = result.data?.workflow_runs || [];
      
      // Check for status changes
      const notifications: CICDBuildStatus[] = [];
      
      currentBuilds.forEach(build => {
        const previousBuild = previousBuildsRef.current.get(build.id);
        
        if (previousBuild) {
          // Check if build just completed
          if (
            previousBuild.status !== 'completed' &&
            build.status === 'completed'
          ) {
            notifications.push(build);
            
            // Show toast notification
            if (build.conclusion === 'success') {
              toast.success(`Build #${build.run_number} succeeded`, {
                description: `${build.name} on ${build.head_branch}`,
                action: {
                  label: 'View',
                  onClick: () => window.open(build.html_url, '_blank'),
                },
              });
            } else if (build.conclusion === 'failure') {
              toast.error(`Build #${build.run_number} failed`, {
                description: `${build.name} on ${build.head_branch}`,
                action: {
                  label: 'View',
                  onClick: () => window.open(build.html_url, '_blank'),
                },
              });
              if (soundEnabled) {
                playAlertSound();
              }
            } else if (build.conclusion === 'cancelled') {
              toast.warning(`Build #${build.run_number} cancelled`, {
                description: `${build.name} on ${build.head_branch}`,
              });
            }
          }
          
          // Check if build just started
          if (
            previousBuild.status === 'queued' &&
            build.status === 'in_progress'
          ) {
            toast.info(`Build #${build.run_number} started`, {
              description: `${build.name} on ${build.head_branch}`,
            });
          }
        }
      });

      // Update previous builds reference
      previousBuildsRef.current = new Map(
        currentBuilds.map(build => [build.id, build])
      );
      
      setBuilds(currentBuilds);
      if (notifications.length > 0) {
        setNewNotifications(prev => [...notifications, ...prev].slice(0, 50));
      }
    } catch (error) {
      console.error('[CICDNotifications] Error checking for updates:', error);
    }
  }, [owner, repo, playAlertSound, soundEnabled]);

  // Initial fetch
  useEffect(() => {
    if (enabled && owner && repo) {
      checkForUpdates();
    }
  }, [enabled, owner, repo, checkForUpdates]);

  // Polling
  useEffect(() => {
    if (!enabled || !owner || !repo) return;

    const interval = setInterval(checkForUpdates, pollInterval);
    return () => clearInterval(interval);
  }, [enabled, owner, repo, pollInterval, checkForUpdates]);

  const clearNotifications = useCallback(() => {
    setNewNotifications([]);
  }, []);

  const markAsRead = useCallback((buildId: number) => {
    setNewNotifications(prev => prev.filter(n => n.id !== buildId));
  }, []);

  return {
    builds,
    newNotifications,
    notificationCount: newNotifications.length,
    checkForUpdates,
    clearNotifications,
    markAsRead,
  };
}
