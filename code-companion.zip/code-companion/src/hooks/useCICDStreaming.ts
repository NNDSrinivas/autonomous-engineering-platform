import { useState, useEffect, useCallback, useRef } from 'react';
import { useGitHubIntegration } from './useGitHubIntegration';

export interface BuildLogLine {
  id: string;
  timestamp: Date;
  content: string;
  level: 'info' | 'warning' | 'error' | 'success';
  step?: string;
}

export interface StreamingBuild {
  runId: number;
  name: string;
  status: 'queued' | 'in_progress' | 'completed';
  conclusion?: 'success' | 'failure' | 'cancelled' | 'skipped';
  progress: number;
  currentStep?: string;
  totalSteps: number;
  completedSteps: number;
  logs: BuildLogLine[];
  startedAt?: Date;
  estimatedCompletion?: Date;
}

interface UseCICDStreamingOptions {
  owner?: string;
  repo?: string;
  runId?: number;
  pollInterval?: number;
  enabled?: boolean;
}

export function useCICDStreaming(options: UseCICDStreamingOptions) {
  const { owner, repo, runId, pollInterval = 5000, enabled = true } = options;
  
  const [build, setBuild] = useState<StreamingBuild | null>(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const pollTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const logIndexRef = useRef(0);
  
  const github = useGitHubIntegration();

  // Parse log content into structured lines
  const parseLogContent = useCallback((rawLogs: string, startIndex: number): BuildLogLine[] => {
    const lines = rawLogs.split('\n').filter(line => line.trim());
    const parsed: BuildLogLine[] = [];
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const globalIndex = startIndex + i;
      
      // Determine log level based on content
      let level: BuildLogLine['level'] = 'info';
      if (line.toLowerCase().includes('error') || line.toLowerCase().includes('failed')) {
        level = 'error';
      } else if (line.toLowerCase().includes('warning') || line.toLowerCase().includes('warn')) {
        level = 'warning';
      } else if (line.toLowerCase().includes('success') || line.toLowerCase().includes('passed') || line.includes('✓')) {
        level = 'success';
      }
      
      // Extract step name if present
      let step: string | undefined;
      const stepMatch = line.match(/##\[group\](.+)/);
      if (stepMatch) {
        step = stepMatch[1];
      }
      
      parsed.push({
        id: `log-${runId}-${globalIndex}`,
        timestamp: new Date(),
        content: line.replace(/##\[\w+\]/g, '').trim(),
        level,
        step,
      });
    }
    
    return parsed;
  }, [runId]);

  // Simulate real-time log streaming (in production, this would use GitHub's log streaming API)
  const simulateLogStreaming = useCallback((currentBuild: StreamingBuild): BuildLogLine[] => {
    const simulatedLogs: string[] = [];
    const stepProgress = currentBuild.completedSteps / currentBuild.totalSteps;
    
    if (stepProgress < 0.2) {
      simulatedLogs.push(
        '> Preparing runner...',
        '> Setting up job...',
        'Run actions/checkout@v4',
        '  Syncing repository...',
      );
    } else if (stepProgress < 0.4) {
      simulatedLogs.push(
        '✓ Repository checkout complete',
        'Run actions/setup-node@v4',
        '  Installing Node.js v20...',
        '> npm ci',
        '  Installing dependencies...',
      );
    } else if (stepProgress < 0.6) {
      simulatedLogs.push(
        '✓ Dependencies installed',
        '> npm run lint',
        '  Running ESLint...',
        '  Checking code style...',
      );
    } else if (stepProgress < 0.8) {
      simulatedLogs.push(
        '✓ Linting passed',
        '> npm run test',
        '  Running test suite...',
        '  PASS src/components/Button.test.tsx',
        '  PASS src/hooks/useAuth.test.ts',
      );
    } else {
      simulatedLogs.push(
        '✓ All tests passed',
        '> npm run build',
        '  Building application...',
        '  Optimizing bundles...',
        '✓ Build complete',
      );
    }
    
    return parseLogContent(simulatedLogs.join('\n'), logIndexRef.current);
  }, [parseLogContent]);

  // Fetch build status and logs
  const fetchBuildStatus = useCallback(async () => {
    if (!owner || !repo || !runId || !enabled) return;
    
    try {
      // Fetch workflow run details
      const runs = await github.fetchWorkflowRuns(owner, repo);
      const run = runs.find(r => r.id === runId);
      
      if (!run) {
        setError('Build not found');
        return;
      }
      
      // Calculate progress based on status
      let progress = 0;
      let completedSteps = 0;
      const totalSteps = 6; // Typical CI steps
      
      if (run.status === 'completed') {
        progress = 100;
        completedSteps = totalSteps;
      } else if (run.status === 'in_progress') {
        // Estimate progress based on time elapsed
        const elapsed = Date.now() - new Date(run.created_at).getTime();
        const estimatedDuration = 5 * 60 * 1000; // 5 minutes
        progress = Math.min(90, (elapsed / estimatedDuration) * 100);
        completedSteps = Math.floor((progress / 100) * totalSteps);
      }
      
      const currentBuild: StreamingBuild = {
        runId: run.id,
        name: run.name,
        status: run.status as StreamingBuild['status'],
        conclusion: run.conclusion as StreamingBuild['conclusion'],
        progress,
        totalSteps,
        completedSteps,
        currentStep: completedSteps < totalSteps ? `Step ${completedSteps + 1}/${totalSteps}` : undefined,
        logs: [],
        startedAt: new Date(run.created_at),
        estimatedCompletion: run.status === 'in_progress' 
          ? new Date(Date.now() + (100 - progress) * 3000) 
          : undefined,
      };
      
      // Add simulated logs for streaming effect
      if (run.status === 'in_progress') {
        const newLogs = simulateLogStreaming(currentBuild);
        logIndexRef.current += newLogs.length;
        currentBuild.logs = newLogs;
      }
      
      setBuild(prev => {
        if (!prev) return currentBuild;
        
        // Merge new logs with existing
        return {
          ...currentBuild,
          logs: [...prev.logs, ...currentBuild.logs].slice(-200), // Keep last 200 lines
        };
      });
      
      // Stop streaming if build is complete
      if (run.status === 'completed') {
        setIsStreaming(false);
        if (pollTimeoutRef.current) {
          clearInterval(pollTimeoutRef.current);
          pollTimeoutRef.current = null;
        }
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to fetch build status';
      setError(message);
      console.error('[CICD Streaming] Error:', err);
    }
  }, [owner, repo, runId, enabled, github, simulateLogStreaming]);

  // Start streaming when runId changes
  useEffect(() => {
    if (!runId || !enabled) return;
    
    setIsStreaming(true);
    setError(null);
    logIndexRef.current = 0;
    
    // Initial fetch
    fetchBuildStatus();
    
    // Set up polling
    pollTimeoutRef.current = setInterval(fetchBuildStatus, pollInterval);
    
    return () => {
      if (pollTimeoutRef.current) {
        clearInterval(pollTimeoutRef.current);
        pollTimeoutRef.current = null;
      }
    };
  }, [runId, enabled, pollInterval, fetchBuildStatus]);

  // Manual refresh
  const refresh = useCallback(async () => {
    await fetchBuildStatus();
  }, [fetchBuildStatus]);

  // Clear logs
  const clearLogs = useCallback(() => {
    setBuild(prev => prev ? { ...prev, logs: [] } : null);
    logIndexRef.current = 0;
  }, []);

  return {
    build,
    isStreaming,
    error,
    refresh,
    clearLogs,
  };
}
