import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface CalendarEvent {
  id: string;
  title: string;
  description?: string;
  start: Date;
  end: Date;
  location?: string;
  attendees: string[];
  meetingUrl?: string;
  isAllDay: boolean;
  provider: 'google' | 'microsoft';
}

export interface CalendarConnection {
  provider: 'google_calendar' | 'microsoft_calendar';
  email: string;
  displayName: string;
  isConnected: boolean;
}

export function useCalendarIntegration() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [events, setEvents] = useState<CalendarEvent[]>([]);
  const [connections, setConnections] = useState<CalendarConnection[]>([]);

  // Check calendar connections
  const checkConnections = useCallback(async (): Promise<CalendarConnection[]> => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return [];

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/oauth?action=connections`,
        {
          headers: {
            Authorization: `Bearer ${session.access_token}`,
          },
        }
      );

      if (!response.ok) return [];

      const { connections: conns } = await response.json();
      const calendarConns = conns
        .filter((c: any) => c.provider === 'google_calendar' || c.provider === 'microsoft_calendar')
        .map((c: any) => ({
          provider: c.provider,
          email: c.provider_email || '',
          displayName: c.provider_display_name || '',
          isConnected: c.status === 'connected',
        }));
      
      setConnections(calendarConns);
      return calendarConns;
    } catch (err) {
      console.error('Failed to check calendar connections:', err);
      return [];
    }
  }, []);

  // Initiate OAuth flow for calendar
  const connectCalendar = useCallback(async (provider: 'google_calendar' | 'microsoft_calendar') => {
    setIsLoading(true);
    setError(null);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error('Please sign in to connect calendar');
        return;
      }

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/oauth?action=initiate`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            provider,
            redirectUri: window.location.origin,
          }),
        }
      );

      const data = await response.json();

      if (data.configRequired) {
        toast.error(data.message || `${provider} OAuth not configured`);
        return;
      }

      if (data.authUrl) {
        // Open OAuth popup
        const popup = window.open(
          data.authUrl,
          `${provider}-oauth`,
          'width=600,height=700,scrollbars=yes'
        );

        // Listen for OAuth completion
        const handleMessage = (event: MessageEvent) => {
          if (event.data?.type === 'oauth-success' && event.data?.provider === provider) {
            window.removeEventListener('message', handleMessage);
            toast.success(`${provider === 'google_calendar' ? 'Google' : 'Microsoft'} Calendar connected!`);
            checkConnections();
            fetchTodayEvents();
          }
        };
        window.addEventListener('message', handleMessage);
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to connect calendar';
      setError(message);
      toast.error(message);
    } finally {
      setIsLoading(false);
    }
  }, [checkConnections]);

  // Fetch today's events from connected calendars
  const fetchTodayEvents = useCallback(async (): Promise<CalendarEvent[]> => {
    setIsLoading(true);
    setError(null);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        return [];
      }

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/integration-data`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ 
            provider: 'calendar', 
            action: 'today-events' 
          }),
        }
      );

      if (!response.ok) {
        const result = await response.json();
        if (result.requiresAuth) {
          // No calendar connected, return empty
          return [];
        }
        throw new Error(result.error || 'Failed to fetch calendar events');
      }

      const { data } = await response.json();
      const mappedEvents: CalendarEvent[] = (data || []).map((event: any) => ({
        id: event.id,
        title: event.summary || event.subject || 'Untitled Event',
        description: event.description || event.bodyPreview || '',
        start: new Date(event.start?.dateTime || event.start?.date || event.start),
        end: new Date(event.end?.dateTime || event.end?.date || event.end),
        location: event.location?.displayName || event.location || '',
        attendees: (event.attendees || []).map((a: any) => a.email || a.emailAddress?.address || ''),
        meetingUrl: event.hangoutLink || event.onlineMeeting?.joinUrl || '',
        isAllDay: !!event.start?.date || event.isAllDay || false,
        provider: event.provider || 'google',
      }));

      setEvents(mappedEvents);
      return mappedEvents;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to fetch events';
      setError(message);
      console.error('Calendar fetch error:', err);
      return [];
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Disconnect calendar
  const disconnectCalendar = useCallback(async (provider: 'google_calendar' | 'microsoft_calendar') => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/oauth?action=disconnect`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ provider }),
        }
      );

      toast.success('Calendar disconnected');
      await checkConnections();
    } catch (err) {
      toast.error('Failed to disconnect calendar');
    }
  }, [checkConnections]);

  return {
    isLoading,
    error,
    events,
    connections,
    checkConnections,
    connectCalendar,
    fetchTodayEvents,
    disconnectCalendar,
  };
}
