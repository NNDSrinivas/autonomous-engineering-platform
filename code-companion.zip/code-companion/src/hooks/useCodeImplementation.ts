import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface GeneratedFile {
  path: string;
  content: string;
  action: 'create' | 'modify' | 'delete';
}

interface CodeGenerationResult {
  files: GeneratedFile[];
  explanation: string;
  testFiles?: GeneratedFile[];
}

interface ImplementationResult {
  success: boolean;
  filesGenerated: GeneratedFile[];
  commitSha?: string;
  error?: string;
}

interface UseCodeImplementationOptions {
  owner: string;
  repo: string;
}

export function useCodeImplementation({ owner, repo }: UseCodeImplementationOptions) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [isCommitting, setIsCommitting] = useState(false);
  const [generatedCode, setGeneratedCode] = useState<CodeGenerationResult | null>(null);

  // Generate code based on task requirements
  const generateCode = useCallback(async (
    taskKey: string,
    taskDescription: string,
    acceptanceCriteria?: string[],
    existingFiles?: Array<{ path: string; content: string }>
  ): Promise<CodeGenerationResult | null> => {
    setIsGenerating(true);
    
    try {
      const { data: session } = await supabase.auth.getSession();
      
      const response = await supabase.functions.invoke('ai-code-generator', {
        body: {
          taskKey,
          taskDescription,
          acceptanceCriteria: acceptanceCriteria?.join('\n'),
          existingCode: existingFiles,
          action: 'generate',
          includeTests: true,
        }
      });

      if (response.error) {
        throw new Error(response.error.message || 'Code generation failed');
      }

      const result: CodeGenerationResult = {
        files: response.data.files || [],
        explanation: response.data.explanation || '',
        testFiles: response.data.testFiles || [],
      };

      setGeneratedCode(result);
      toast.success(`Generated ${result.files.length} files`);
      return result;
    } catch (error) {
      console.error('Code generation error:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to generate code');
      return null;
    } finally {
      setIsGenerating(false);
    }
  }, []);

  // Commit generated code to GitHub branch
  const commitToGitHub = useCallback(async (
    branchName: string,
    files: GeneratedFile[],
    commitMessage: string
  ): Promise<ImplementationResult> => {
    setIsCommitting(true);
    
    try {
      const { data: session } = await supabase.auth.getSession();
      if (!session.session) {
        throw new Error('Not authenticated');
      }

      // Filter to only files with create/modify action
      const filesToCommit = files
        .filter(f => f.action !== 'delete')
        .map(f => ({ path: f.path, content: f.content }));

      if (filesToCommit.length === 0) {
        throw new Error('No files to commit');
      }

      // Call the github-write edge function
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/github-write`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${session.session.access_token}`
          },
          body: JSON.stringify({
            action: 'commit_files',
            owner,
            repo,
            branch: branchName,
            files: filesToCommit,
            commitMessage,
          }),
        }
      );

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to commit files');
      }

      const result = await response.json();
      
      toast.success(`Committed ${filesToCommit.length} files to ${branchName}`);
      
      return {
        success: true,
        filesGenerated: files,
        commitSha: result.commitSha,
      };
    } catch (error) {
      console.error('Commit error:', error);
      const message = error instanceof Error ? error.message : 'Failed to commit code';
      toast.error(message);
      return {
        success: false,
        filesGenerated: [],
        error: message,
      };
    } finally {
      setIsCommitting(false);
    }
  }, [owner, repo]);

  // Full implementation flow: generate + commit
  const implementTask = useCallback(async (
    taskKey: string,
    taskDescription: string,
    branchName: string,
    options?: {
      acceptanceCriteria?: string[];
      existingFiles?: Array<{ path: string; content: string }>;
      includeTests?: boolean;
    }
  ): Promise<ImplementationResult> => {
    // Step 1: Generate code
    const codeResult = await generateCode(
      taskKey,
      taskDescription,
      options?.acceptanceCriteria,
      options?.existingFiles
    );

    if (!codeResult || codeResult.files.length === 0) {
      return {
        success: false,
        filesGenerated: [],
        error: 'No code generated',
      };
    }

    // Combine main files and test files
    const allFiles = [
      ...codeResult.files,
      ...(codeResult.testFiles || []),
    ];

    // Step 2: Commit to GitHub
    const commitMessage = `[${taskKey}] ${codeResult.explanation.slice(0, 50)}...

Implemented by NAVI autonomous workflow.

Files changed:
${allFiles.map(f => `- ${f.action}: ${f.path}`).join('\n')}`;

    return await commitToGitHub(branchName, allFiles, commitMessage);
  }, [generateCode, commitToGitHub]);

  // Get file content from repo for context
  const getRepoContext = useCallback(async (
    branchName: string,
    filePaths: string[]
  ): Promise<Array<{ path: string; content: string }>> => {
    try {
      const { data: session } = await supabase.auth.getSession();
      if (!session.session) return [];

      const files: Array<{ path: string; content: string }> = [];
      
      for (const path of filePaths) {
        const response = await fetch(
          `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/github-api`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${session.session.access_token}`
            },
            body: JSON.stringify({
              action: 'get_file_content',
              params: { owner, repo, path, ref: branchName }
            }),
          }
        );

        if (response.ok) {
          const data = await response.json();
          if (data.content) {
            files.push({ path, content: atob(data.content) });
          }
        }
      }

      return files;
    } catch (error) {
      console.error('Failed to get repo context:', error);
      return [];
    }
  }, [owner, repo]);

  return {
    isGenerating,
    isCommitting,
    isLoading: isGenerating || isCommitting,
    generatedCode,
    generateCode,
    commitToGitHub,
    implementTask,
    getRepoContext,
  };
}
