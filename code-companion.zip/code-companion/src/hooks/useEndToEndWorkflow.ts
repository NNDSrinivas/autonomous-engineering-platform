import { useState, useCallback } from 'react';
import { toast } from 'sonner';
import { useGitHubIntegration } from './useGitHubIntegration';
import { useJiraMCP } from './useJiraMCP';
import { useSlackNotifications } from './useSlackNotifications';
import { useCodeImplementation } from './useCodeImplementation';
import { useRepoIndexing } from './useRepoIndexing';
import type { JiraTask } from '@/types';

export type WorkflowPhase = 
  | 'idle'
  | 'start_task'
  | 'create_branch'
  | 'implement_code'
  | 'create_pr'
  | 'link_jira'
  | 'post_slack'
  | 'completed'
  | 'failed';

export interface WorkflowStepResult {
  phase: WorkflowPhase;
  success: boolean;
  message: string;
  data?: Record<string, unknown>;
}

export interface EndToEndWorkflowState {
  currentPhase: WorkflowPhase;
  awaitingApproval: boolean;
  pendingAction: (() => Promise<void>) | null;
  results: WorkflowStepResult[];
  error: string | null;
  // Context data carried through workflow
  taskKey?: string;
  branchName?: string;
  prNumber?: number;
  prUrl?: string;
  // Code implementation data
  filesGenerated?: Array<{ path: string; content: string; action: string }>;
}

interface UseEndToEndWorkflowOptions {
  owner: string;
  repo: string;
  baseBranch?: string;
  slackChannel?: string;
  enabledPhases?: WorkflowPhase[];
  onPhaseChange?: (phase: WorkflowPhase, progress: number) => void;
}

const defaultPhases: WorkflowPhase[] = [
  'start_task',
  'create_branch',
  'implement_code',
  'create_pr',
  'link_jira',
  'post_slack',
];

export function useEndToEndWorkflow(options: UseEndToEndWorkflowOptions) {
  const { 
    owner, 
    repo, 
    baseBranch = 'main', 
    slackChannel = '#engineering',
    enabledPhases = defaultPhases,
    onPhaseChange,
  } = options;
  
  const [state, setState] = useState<EndToEndWorkflowState>({
    currentPhase: 'idle',
    awaitingApproval: false,
    pendingAction: null,
    results: [],
    error: null,
  });
  
  const github = useGitHubIntegration();
  const jira = useJiraMCP();
  const slack = useSlackNotifications();
  const codeImpl = useCodeImplementation({ owner, repo });
  const repoIndex = useRepoIndexing();

  // Helper to check if phase is enabled
  const isPhaseEnabled = useCallback((phase: WorkflowPhase): boolean => {
    return enabledPhases.includes(phase);
  }, [enabledPhases]);

  // Helper to get next enabled phase
  const getNextPhase = useCallback((currentPhase: WorkflowPhase): WorkflowPhase | null => {
    const phaseOrder: WorkflowPhase[] = [
      'start_task',
      'create_branch',
      'implement_code',
      'create_pr',
      'link_jira',
      'post_slack',
    ];
    
    const currentIndex = phaseOrder.indexOf(currentPhase);
    for (let i = currentIndex + 1; i < phaseOrder.length; i++) {
      if (enabledPhases.includes(phaseOrder[i])) {
        return phaseOrder[i];
      }
    }
    return null;
  }, [enabledPhases]);

  // Calculate progress based on enabled phases
  const calculateProgress = useCallback((phase: WorkflowPhase): number => {
    const phaseIndex = enabledPhases.indexOf(phase);
    if (phaseIndex === -1) return 0;
    return Math.round(((phaseIndex + 1) / enabledPhases.length) * 100);
  }, [enabledPhases]);

  // Helper to add result
  const addResult = useCallback((result: WorkflowStepResult) => {
    setState(prev => ({
      ...prev,
      results: [...prev.results, result],
    }));
  }, []);

  // Helper to request approval
  const requestApproval = useCallback((phase: WorkflowPhase, action: () => Promise<void>) => {
    const progress = calculateProgress(phase);
    setState(prev => ({
      ...prev,
      currentPhase: phase,
      awaitingApproval: true,
      pendingAction: action,
    }));
    onPhaseChange?.(phase, progress);
    toast.info(`Approval required for: ${phase.replace(/_/g, ' ')}`);
  }, [calculateProgress, onPhaseChange]);

  // User approves the pending action
  const approve = useCallback(async () => {
    const { pendingAction, currentPhase } = state;
    if (!pendingAction) return;
    
    setState(prev => ({
      ...prev,
      awaitingApproval: false,
      pendingAction: null,
    }));
    
    toast.success(`Approved: ${currentPhase.replace(/_/g, ' ')}`);
    
    try {
      await pendingAction();
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Action failed';
      setState(prev => ({
        ...prev,
        currentPhase: 'failed',
        error: message,
      }));
      addResult({
        phase: currentPhase,
        success: false,
        message,
      });
    }
  }, [state, addResult]);

  // User rejects the pending action
  const reject = useCallback((skipToNext = false) => {
    const { currentPhase } = state;
    
    setState(prev => ({
      ...prev,
      awaitingApproval: false,
      pendingAction: null,
      currentPhase: skipToNext ? prev.currentPhase : 'failed',
    }));
    
    addResult({
      phase: currentPhase,
      success: false,
      message: 'Rejected by user',
    });
    
    toast.info(`Skipped: ${currentPhase.replace(/_/g, ' ')}`);
  }, [state, addResult]);

  // Phase 1: Start Task
  const startTask = useCallback(async (task: JiraTask) => {
    const executeStart = async () => {
      setState(prev => ({
        ...prev,
        currentPhase: 'start_task',
        taskKey: task.key,
      }));
      
      // Update Jira status to In Progress
      await jira.updateIssueStatus(task.key, '21'); // In Progress transition
      await jira.addComment(task.key, '🚀 **NAVI Workflow Started**\n\nBeginning automated development workflow.');
      
      addResult({
        phase: 'start_task',
        success: true,
        message: `Started working on ${task.key}`,
        data: { taskKey: task.key },
      });
      
      toast.success(`Started task: ${task.key}`);
      
      // Proceed to next enabled phase
      const nextPhase = getNextPhase('start_task');
      if (nextPhase === 'create_branch') {
        await createBranch(task.key);
      } else if (nextPhase === 'implement_code') {
        await implementCode(task.key, `feature/${task.key.toLowerCase()}`);
      } else if (nextPhase) {
        // Skip to later phases
        await proceedToPhase(nextPhase, task.key);
      } else {
        completeWorkflow(task.key);
      }
    };
    
    // Check if this phase is enabled
    if (!isPhaseEnabled('start_task')) {
      // Skip to first enabled phase
      const firstPhase = enabledPhases[0];
      if (firstPhase === 'create_branch') {
        await createBranch(task.key);
      } else if (firstPhase === 'implement_code') {
        await implementCode(task.key, `feature/${task.key.toLowerCase()}`);
      }
      return;
    }
    
    requestApproval('start_task', executeStart);
  }, [jira, addResult, requestApproval, getNextPhase, isPhaseEnabled, enabledPhases]);

  // Helper to proceed to a specific phase
  const proceedToPhase = useCallback(async (
    phase: WorkflowPhase, 
    taskKey: string, 
    branchName?: string, 
    prUrl?: string, 
    prNumber?: number
  ) => {
    switch (phase) {
      case 'create_branch':
        await createBranch(taskKey);
        break;
      case 'implement_code':
        await implementCode(taskKey, branchName || `feature/${taskKey.toLowerCase()}`);
        break;
      case 'create_pr':
        await createPR(taskKey, branchName || `feature/${taskKey.toLowerCase()}`);
        break;
      case 'link_jira':
        await linkToJira(taskKey, prUrl || '', 'PR', prNumber || 0);
        break;
      case 'post_slack':
        await postToSlack(taskKey, prUrl || '', prNumber || 0);
        break;
    }
  }, []);

  // Phase 2: Create Branch
  const createBranch = useCallback(async (taskKey: string) => {
    const branchName = `feature/${taskKey.toLowerCase()}-${Date.now()}`;
    
    const executeCreateBranch = async () => {
      setState(prev => ({
        ...prev,
        currentPhase: 'create_branch',
        branchName,
      }));
      
      try {
        await github.createBranch(owner, repo, branchName, baseBranch);
        
        addResult({
          phase: 'create_branch',
          success: true,
          message: `Created branch: ${branchName}`,
          data: { branchName },
        });
        
        toast.success(`Branch created: ${branchName}`);
        
        // Proceed to next enabled phase
        const nextPhase = getNextPhase('create_branch');
        if (nextPhase === 'implement_code') {
          await implementCode(taskKey, branchName);
        } else if (nextPhase === 'create_pr') {
          await createPR(taskKey, branchName);
        } else if (nextPhase) {
          await proceedToPhase(nextPhase, taskKey, branchName);
        } else {
          completeWorkflow(taskKey);
        }
      } catch (err) {
        // Branch might already exist, which is fine
        const message = err instanceof Error ? err.message : 'Unknown error';
        if (message.includes('Reference already exists')) {
          addResult({
            phase: 'create_branch',
            success: true,
            message: `Using existing branch: ${branchName}`,
            data: { branchName, existed: true },
          });
          const nextPhase = getNextPhase('create_branch');
          if (nextPhase === 'implement_code') {
            await implementCode(taskKey, branchName);
          } else if (nextPhase === 'create_pr') {
            await createPR(taskKey, branchName);
          } else if (nextPhase) {
            await proceedToPhase(nextPhase, taskKey, branchName);
          } else {
            completeWorkflow(taskKey);
          }
        } else {
          throw err;
        }
      }
    };
    
    if (!isPhaseEnabled('create_branch')) {
      const nextPhase = getNextPhase('create_branch');
      if (nextPhase) {
        await proceedToPhase(nextPhase, taskKey, branchName);
      }
      return;
    }
    
    requestApproval('create_branch', executeCreateBranch);
  }, [owner, repo, baseBranch, github, addResult, requestApproval, getNextPhase, isPhaseEnabled]);

  // Phase 3: Implement Code - REAL GITHUB FILE WRITING
  const implementCode = useCallback(async (taskKey: string, branchName: string, task?: JiraTask) => {
    const executeImplement = async () => {
      setState(prev => ({ ...prev, currentPhase: 'implement_code' }));
      
      try {
        toast.info('Generating code with AI...');
        const taskDescription = task?.title || `Implementation for ${taskKey}`;
        
        // Generate and commit code to GitHub
        const result = await codeImpl.implementTask(taskKey, taskDescription, branchName);
        
        if (!result.success) {
          throw new Error(result.error || 'Failed to implement code');
        }
        
        setState(prev => ({ ...prev, filesGenerated: result.filesGenerated }));
        
        addResult({
          phase: 'implement_code',
          success: true,
          message: `Committed ${result.filesGenerated.length} files`,
          data: { filesModified: result.filesGenerated.map(f => f.path), commitSha: result.commitSha },
        });
        
        toast.success(`Committed ${result.filesGenerated.length} files to ${branchName}`);
        
        const nextPhase = getNextPhase('implement_code');
        if (nextPhase === 'create_pr') await createPR(taskKey, branchName);
        else if (nextPhase) await proceedToPhase(nextPhase, taskKey, branchName);
        else completeWorkflow(taskKey);
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Code implementation failed';
        addResult({ phase: 'implement_code', success: false, message });
        setState(prev => ({ ...prev, currentPhase: 'failed', error: message }));
      }
    };
    
    if (!isPhaseEnabled('implement_code')) {
      const nextPhase = getNextPhase('implement_code');
      if (nextPhase) await proceedToPhase(nextPhase, taskKey, branchName);
      return;
    }
    
    requestApproval('implement_code', executeImplement);
  }, [codeImpl, addResult, requestApproval, getNextPhase, isPhaseEnabled]);

  // Phase 4: Create PR
  const createPR = useCallback(async (taskKey: string, branchName: string) => {
    const executeCreatePR = async () => {
      setState(prev => ({
        ...prev,
        currentPhase: 'create_pr',
      }));
      
      const title = `[${taskKey}] Automated implementation`;
      const body = `## Summary\n\nAutomated PR created by NAVI workflow.\n\n**Task:** ${taskKey}\n\n## Changes\n\n- Implementation as per task requirements\n- Unit tests added\n\n---\n*Created by NAVI - Autonomous Engineering Intelligence*`;
      
      const pr = await github.createPullRequest(owner, repo, title, body, branchName, baseBranch);
      
      setState(prev => ({
        ...prev,
        prNumber: pr.number,
        prUrl: pr.html_url,
      }));
      
      addResult({
        phase: 'create_pr',
        success: true,
        message: `Pull request #${pr.number} created`,
        data: { prNumber: pr.number, prUrl: pr.html_url },
      });
      
      toast.success(`PR #${pr.number} created`);
      
      // Proceed to next enabled phase
      const nextPhase = getNextPhase('create_pr');
      if (nextPhase === 'link_jira') {
        await linkToJira(taskKey, pr.html_url, title, pr.number);
      } else if (nextPhase === 'post_slack') {
        await postToSlack(taskKey, pr.html_url, pr.number);
      } else if (nextPhase) {
        await proceedToPhase(nextPhase, taskKey, branchName, pr.html_url, pr.number);
      } else {
        completeWorkflow(taskKey);
      }
    };
    
    if (!isPhaseEnabled('create_pr')) {
      const nextPhase = getNextPhase('create_pr');
      if (nextPhase) {
        await proceedToPhase(nextPhase, taskKey, branchName);
      }
      return;
    }
    
    requestApproval('create_pr', executeCreatePR);
  }, [owner, repo, baseBranch, github, addResult, requestApproval, getNextPhase, isPhaseEnabled]);

  // Phase 5: Link Jira
  const linkToJira = useCallback(async (taskKey: string, prUrl: string, prTitle: string, prNumber: number) => {
    const executeLinkJira = async () => {
      setState(prev => ({
        ...prev,
        currentPhase: 'link_jira',
      }));
      
      await jira.linkToJira(taskKey, prUrl, prTitle);
      await jira.updateIssueStatus(taskKey, '31'); // In Review transition
      
      addResult({
        phase: 'link_jira',
        success: true,
        message: `PR linked to ${taskKey}`,
        data: { taskKey, prNumber },
      });
      
      toast.success(`Jira updated: ${taskKey}`);
      
      // Proceed to next enabled phase
      const nextPhase = getNextPhase('link_jira');
      if (nextPhase === 'post_slack') {
        await postToSlack(taskKey, prUrl, prNumber);
      } else if (nextPhase) {
        await proceedToPhase(nextPhase, taskKey, undefined, prUrl, prNumber);
      } else {
        completeWorkflow(taskKey);
      }
    };
    
    if (!isPhaseEnabled('link_jira')) {
      const nextPhase = getNextPhase('link_jira');
      if (nextPhase) {
        await proceedToPhase(nextPhase, taskKey, undefined, prUrl, prNumber);
      }
      return;
    }
    
    requestApproval('link_jira', executeLinkJira);
  }, [jira, addResult, requestApproval, getNextPhase, isPhaseEnabled]);

  // Phase 6: Post to Slack
  const postToSlack = useCallback(async (taskKey: string, prUrl: string, prNumber: number) => {
    const executePostSlack = async () => {
      setState(prev => ({
        ...prev,
        currentPhase: 'post_slack',
      }));
      
      // Send notification to Slack
      await slack.sendNotification({
        channel: slackChannel,
        message: `🚀 *PR Ready for Review*\n\n` +
          `*Task:* ${taskKey}\n` +
          `*PR:* <${prUrl}|#${prNumber}>\n\n` +
          `Created by NAVI automated workflow.`,
      });
      
      addResult({
        phase: 'post_slack',
        success: true,
        message: `Posted to ${slackChannel}`,
        data: { channel: slackChannel },
      });
      
      toast.success(`Notification sent to Slack`);
      
      // Complete workflow
      completeWorkflow(taskKey);
    };
    
    if (!isPhaseEnabled('post_slack')) {
      completeWorkflow(taskKey);
      return;
    }
    
    requestApproval('post_slack', executePostSlack);
  }, [slack, slackChannel, addResult, requestApproval, isPhaseEnabled]);

  // Complete the workflow
  const completeWorkflow = useCallback((taskKey: string) => {
    setState(prev => ({
      ...prev,
      currentPhase: 'completed',
    }));
    
    onPhaseChange?.('completed', 100);
    
    addResult({
      phase: 'completed',
      success: true,
      message: 'Workflow completed successfully!',
      data: { taskKey },
    });
    
    toast.success('🎉 End-to-end workflow completed!');
  }, [addResult, onPhaseChange]);

  // Reset the workflow
  const reset = useCallback(() => {
    setState({
      currentPhase: 'idle',
      awaitingApproval: false,
      pendingAction: null,
      results: [],
      error: null,
    });
  }, []);

  // Get phase display info
  const getPhaseInfo = useCallback((phase: WorkflowPhase) => {
    const phaseMap: Record<WorkflowPhase, { label: string; description: string }> = {
      idle: { label: 'Ready', description: 'Waiting to start' },
      start_task: { label: 'Start Task', description: 'Update Jira status to In Progress' },
      create_branch: { label: 'Create Branch', description: 'Create feature branch from main' },
      implement_code: { label: 'Implement Code', description: 'Apply code changes' },
      create_pr: { label: 'Create PR', description: 'Create pull request for review' },
      link_jira: { label: 'Link Jira', description: 'Add PR link to Jira ticket' },
      post_slack: { label: 'Post to Slack', description: 'Notify team in Slack channel' },
      completed: { label: 'Completed', description: 'Workflow finished successfully' },
      failed: { label: 'Failed', description: 'Workflow encountered an error' },
    };
    return phaseMap[phase];
  }, []);

  return {
    state,
    startTask,
    approve,
    reject,
    reset,
    getPhaseInfo,
    isLoading: github.isLoading || jira.isLoading,
  };
}
