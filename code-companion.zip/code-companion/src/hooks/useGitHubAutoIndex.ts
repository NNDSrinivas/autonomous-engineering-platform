import { useEffect, useCallback } from 'react';
import { useRepoIndexing } from './useRepoIndexing';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface GitHubRepo {
  owner: string;
  repo: string;
  branch?: string;
}

export function useGitHubAutoIndex() {
  const { autoIndexOnLogin, isIndexing, indexProgress, repoIndex } = useRepoIndexing();

  // Fetch connected GitHub repos
  const fetchConnectedRepos = useCallback(async (): Promise<GitHubRepo[]> => {
    const { data: session } = await supabase.auth.getSession();
    if (!session.session) return [];

    try {
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/github-api`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${session.session.access_token}`
          },
          body: JSON.stringify({
            action: 'list_repos',
            params: { per_page: 10, sort: 'updated' }
          }),
        }
      );

      if (!response.ok) return [];

      const repos = await response.json();
      return repos.slice(0, 5).map((r: any) => ({
        owner: r.owner?.login || r.full_name?.split('/')[0],
        repo: r.name,
        branch: r.default_branch || 'main',
      }));
    } catch (err) {
      console.error('Failed to fetch repos:', err);
      return [];
    }
  }, []);

  // Handle GitHub connect event
  useEffect(() => {
    const handleGitHubConnect = async (event: CustomEvent<{ owner: string; repo: string }>) => {
      const { owner, repo } = event.detail;
      if (owner && repo) {
        toast.info('Auto-indexing repository for lightning-fast context...');
        await autoIndexOnLogin(owner, repo);
      }
    };

    window.addEventListener('github-connected', handleGitHubConnect as EventListener);
    return () => window.removeEventListener('github-connected', handleGitHubConnect as EventListener);
  }, [autoIndexOnLogin]);

  // Auto-index on mount if user is authenticated and has GitHub connected
  useEffect(() => {
    const initAutoIndex = async () => {
      const { data: session } = await supabase.auth.getSession();
      if (!session.session) return;

      // Check for GitHub connection
      const { data: connections } = await supabase
        .from('integration_connections')
        .select('provider, provider_metadata')
        .eq('user_id', session.session.user.id)
        .eq('provider', 'github')
        .eq('status', 'connected')
        .limit(1);

      if (connections && connections.length > 0) {
        // Fetch repos and index the most recently updated ones
        const repos = await fetchConnectedRepos();
        
        if (repos.length > 0) {
          // Index first repo (most recently updated)
          const primaryRepo = repos[0];
          await autoIndexOnLogin(primaryRepo.owner, primaryRepo.repo, primaryRepo.branch);
        }
      }
    };

    // Slight delay to not block initial render
    const timeout = setTimeout(initAutoIndex, 2000);
    return () => clearTimeout(timeout);
  }, [autoIndexOnLogin, fetchConnectedRepos]);

  return {
    isIndexing,
    indexProgress,
    repoIndex,
    triggerIndex: autoIndexOnLogin,
  };
}
