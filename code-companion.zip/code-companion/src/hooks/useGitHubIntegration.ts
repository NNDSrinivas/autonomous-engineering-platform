import { useState, useCallback, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface GitHubRepo {
  id: number;
  name: string;
  full_name: string;
  description: string | null;
  html_url: string;
  private: boolean;
  default_branch: string;
  language: string | null;
  updated_at: string;
}

export interface GitHubBranch {
  name: string;
  commit: {
    sha: string;
    url: string;
  };
  protected: boolean;
}

export interface GitHubPullRequest {
  id: number;
  number: number;
  title: string;
  state: 'open' | 'closed';
  html_url: string;
  user: {
    login: string;
    avatar_url: string;
  };
  created_at: string;
  updated_at: string;
  merged_at: string | null;
  draft: boolean;
  head: {
    ref: string;
    sha: string;
  };
  base: {
    ref: string;
  };
}

export interface GitHubWorkflowRun {
  id: number;
  name: string;
  head_branch: string;
  status: 'queued' | 'in_progress' | 'completed' | 'waiting';
  conclusion: 'success' | 'failure' | 'cancelled' | 'skipped' | 'timed_out' | 'action_required' | null;
  html_url: string;
  created_at: string;
  updated_at: string;
  run_number: number;
  workflow_id: number;
  head_commit: {
    message: string;
    author: {
      name: string;
    };
  };
}

export interface GitHubConnection {
  connected: boolean;
  user?: {
    login: string;
    name: string;
    avatar_url: string;
    email: string;
  };
}

export function useGitHubIntegration() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [connection, setConnection] = useState<GitHubConnection>({ connected: false });
  const [repos, setRepos] = useState<GitHubRepo[]>([]);
  const [selectedRepo, setSelectedRepo] = useState<string | null>(null);
  const [branches, setBranches] = useState<GitHubBranch[]>([]);
  const [pullRequests, setPullRequests] = useState<GitHubPullRequest[]>([]);
  const [workflowRuns, setWorkflowRuns] = useState<GitHubWorkflowRun[]>([]);

  // Check connection status on mount
  useEffect(() => {
    checkConnection();
  }, []);

  const callGitHubAPI = useCallback(async (action: string, params: Record<string, unknown> = {}) => {
    setIsLoading(true);
    setError(null);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        throw new Error('Not authenticated');
      }

      const { data, error: fnError } = await supabase.functions.invoke('github-api', {
        body: { action, ...params },
      });

      if (fnError) throw fnError;
      if (data?.error) throw new Error(data.error);

      return data;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'GitHub API error';
      setError(message);
      throw err;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const checkConnection = useCallback(async () => {
    try {
      const data = await callGitHubAPI('check_connection');
      setConnection({
        connected: data.connected,
        user: data.user,
      });
      return data.connected;
    } catch {
      setConnection({ connected: false });
      return false;
    }
  }, [callGitHubAPI]);

  const fetchRepos = useCallback(async () => {
    try {
      const data = await callGitHubAPI('list_repos');
      setRepos(data.repos || []);
      return data.repos;
    } catch (err) {
      console.error('Failed to fetch repos:', err);
      return [];
    }
  }, [callGitHubAPI]);

  const fetchBranches = useCallback(async (owner: string, repo: string) => {
    try {
      const data = await callGitHubAPI('list_branches', { owner, repo });
      setBranches(data.branches || []);
      return data.branches;
    } catch (err) {
      console.error('Failed to fetch branches:', err);
      return [];
    }
  }, [callGitHubAPI]);

  const fetchPullRequests = useCallback(async (owner: string, repo: string) => {
    try {
      const data = await callGitHubAPI('list_pull_requests', { owner, repo });
      setPullRequests(data.pull_requests || []);
      return data.pull_requests;
    } catch (err) {
      console.error('Failed to fetch PRs:', err);
      return [];
    }
  }, [callGitHubAPI]);

  const fetchWorkflowRuns = useCallback(async (owner: string, repo: string) => {
    try {
      const data = await callGitHubAPI('list_workflow_runs', { owner, repo });
      setWorkflowRuns(data.workflow_runs || []);
      return data.workflow_runs;
    } catch (err) {
      console.error('Failed to fetch workflow runs:', err);
      return [];
    }
  }, [callGitHubAPI]);

  const createPullRequest = useCallback(async (
    owner: string,
    repo: string,
    title: string,
    body: string,
    head: string,
    base: string
  ) => {
    try {
      const data = await callGitHubAPI('create_pull_request', {
        owner,
        repo,
        title,
        body,
        head,
        base,
      });
      toast.success('Pull request created successfully');
      return data.pull_request;
    } catch (err) {
      toast.error('Failed to create pull request');
      throw err;
    }
  }, [callGitHubAPI]);

  const createBranch = useCallback(async (
    owner: string,
    repo: string,
    branchName: string,
    fromBranch: string
  ) => {
    try {
      const data = await callGitHubAPI('create_branch', {
        owner,
        repo,
        branch_name: branchName,
        from_branch: fromBranch,
      });
      toast.success(`Branch "${branchName}" created`);
      return data.branch;
    } catch (err) {
      toast.error('Failed to create branch');
      throw err;
    }
  }, [callGitHubAPI]);

  const rerunWorkflow = useCallback(async (owner: string, repo: string, runId: number) => {
    try {
      await callGitHubAPI('rerun_workflow', { owner, repo, run_id: runId });
      toast.success('Workflow re-run triggered');
    } catch (err) {
      toast.error('Failed to re-run workflow');
      throw err;
    }
  }, [callGitHubAPI]);

  const getFileContent = useCallback(async (owner: string, repo: string, path: string, ref?: string) => {
    try {
      const data = await callGitHubAPI('get_file_content', { owner, repo, path, ref });
      return data.content;
    } catch (err) {
      console.error('Failed to get file content:', err);
      throw err;
    }
  }, [callGitHubAPI]);

  const updateFile = useCallback(async (
    owner: string,
    repo: string,
    path: string,
    content: string,
    message: string,
    branch: string,
    sha?: string
  ) => {
    try {
      const data = await callGitHubAPI('update_file', {
        owner,
        repo,
        path,
        content,
        message,
        branch,
        sha,
      });
      toast.success('File updated successfully');
      return data.commit;
    } catch (err) {
      toast.error('Failed to update file');
      throw err;
    }
  }, [callGitHubAPI]);

  const mergePullRequest = useCallback(async (
    owner: string,
    repo: string,
    pullNumber: number,
    options?: {
      commitTitle?: string;
      commitMessage?: string;
      mergeMethod?: 'merge' | 'squash' | 'rebase';
    }
  ) => {
    try {
      const data = await callGitHubAPI('merge_pull_request', {
        owner,
        repo,
        pull_number: pullNumber,
        commit_title: options?.commitTitle,
        commit_message: options?.commitMessage,
        merge_method: options?.mergeMethod || 'merge',
      });
      toast.success('Pull request merged successfully');
      return data;
    } catch (err) {
      toast.error('Failed to merge pull request');
      throw err;
    }
  }, [callGitHubAPI]);

  const getWorkflowLogs = useCallback(async (owner: string, repo: string, runId: number) => {
    try {
      const data = await callGitHubAPI('get_workflow_logs', { owner, repo, run_id: runId });
      return data.jobs || [];
    } catch (err) {
      console.error('Failed to get workflow logs:', err);
      return [];
    }
  }, [callGitHubAPI]);

  const cancelWorkflow = useCallback(async (owner: string, repo: string, runId: number) => {
    try {
      await callGitHubAPI('cancel_workflow', { owner, repo, run_id: runId });
      toast.success('Workflow cancelled');
      return true;
    } catch (err) {
      toast.error('Failed to cancel workflow');
      throw err;
    }
  }, [callGitHubAPI]);

  return {
    isLoading,
    error,
    connection,
    repos,
    selectedRepo,
    setSelectedRepo,
    branches,
    pullRequests,
    workflowRuns,
    checkConnection,
    fetchRepos,
    fetchBranches,
    fetchPullRequests,
    fetchWorkflowRuns,
    createPullRequest,
    createBranch,
    rerunWorkflow,
    getFileContent,
    updateFile,
    mergePullRequest,
    getWorkflowLogs,
    cancelWorkflow,
  };
}
