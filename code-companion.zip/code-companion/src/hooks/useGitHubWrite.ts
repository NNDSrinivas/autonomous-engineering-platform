import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface GitHubWriteOptions {
  owner: string;
  repo: string;
}

interface CreateBranchResult {
  success: boolean;
  ref: string;
  sha: string;
}

interface CommitResult {
  success: boolean;
  commitSha: string;
  filesCommitted: number;
}

interface CreatePRResult {
  success: boolean;
  number: number;
  html_url: string;
  title: string;
}

export function useGitHubWrite() {
  const [isLoading, setIsLoading] = useState(false);

  const callGitHubWrite = useCallback(async (body: any) => {
    const { data: session } = await supabase.auth.getSession();
    if (!session.session) {
      toast.error('Please sign in to use GitHub features');
      return null;
    }

    const response = await fetch(
      `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/github-write`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.session.access_token}`
        },
        body: JSON.stringify(body),
      }
    );

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || 'GitHub operation failed');
    }

    return response.json();
  }, []);

  const createBranch = useCallback(async (
    options: GitHubWriteOptions & { branchName: string; baseBranch?: string }
  ): Promise<CreateBranchResult | null> => {
    setIsLoading(true);
    try {
      const result = await callGitHubWrite({
        action: 'create_branch',
        ...options
      });
      toast.success(`Created branch: ${options.branchName}`);
      return result;
    } catch (error) {
      console.error('Create branch error:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to create branch');
      return null;
    } finally {
      setIsLoading(false);
    }
  }, [callGitHubWrite]);

  const commitFiles = useCallback(async (
    options: GitHubWriteOptions & {
      branch: string;
      files: Array<{ path: string; content: string }>;
      commitMessage: string;
    }
  ): Promise<CommitResult | null> => {
    setIsLoading(true);
    try {
      const result = await callGitHubWrite({
        action: 'commit_files',
        ...options
      });
      toast.success(`Committed ${options.files.length} files to ${options.branch}`);
      return result;
    } catch (error) {
      console.error('Commit files error:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to commit files');
      return null;
    } finally {
      setIsLoading(false);
    }
  }, [callGitHubWrite]);

  const createPullRequest = useCallback(async (
    options: GitHubWriteOptions & {
      title: string;
      body?: string;
      head: string;
      base?: string;
    }
  ): Promise<CreatePRResult | null> => {
    setIsLoading(true);
    try {
      const result = await callGitHubWrite({
        action: 'create_pr',
        ...options
      });
      toast.success(`Created PR #${result.result.number}: ${options.title}`);
      return { 
        success: true, 
        number: result.result.number, 
        html_url: result.result.html_url,
        title: options.title 
      };
    } catch (error) {
      console.error('Create PR error:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to create PR');
      return null;
    } finally {
      setIsLoading(false);
    }
  }, [callGitHubWrite]);

  const mergePullRequest = useCallback(async (
    options: GitHubWriteOptions & { prNumber: number }
  ): Promise<boolean> => {
    setIsLoading(true);
    try {
      await callGitHubWrite({
        action: 'merge_pr',
        ...options
      });
      toast.success(`Merged PR #${options.prNumber}`);
      return true;
    } catch (error) {
      console.error('Merge PR error:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to merge PR');
      return false;
    } finally {
      setIsLoading(false);
    }
  }, [callGitHubWrite]);

  // Complete workflow: create branch, commit files, create PR
  const createFeaturePR = useCallback(async (options: {
    owner: string;
    repo: string;
    branchName: string;
    baseBranch?: string;
    files: Array<{ path: string; content: string }>;
    commitMessage: string;
    prTitle: string;
    prBody?: string;
  }): Promise<CreatePRResult | null> => {
    setIsLoading(true);
    try {
      // Step 1: Create branch
      toast.info('Creating branch...');
      const branchResult = await callGitHubWrite({
        action: 'create_branch',
        owner: options.owner,
        repo: options.repo,
        branchName: options.branchName,
        baseBranch: options.baseBranch || 'main'
      });

      if (!branchResult?.success) {
        throw new Error('Failed to create branch');
      }

      // Step 2: Commit files
      toast.info('Committing files...');
      const commitResult = await callGitHubWrite({
        action: 'commit_files',
        owner: options.owner,
        repo: options.repo,
        branch: options.branchName,
        files: options.files,
        commitMessage: options.commitMessage
      });

      if (!commitResult?.success) {
        throw new Error('Failed to commit files');
      }

      // Step 3: Create PR
      toast.info('Creating pull request...');
      const prResult = await callGitHubWrite({
        action: 'create_pr',
        owner: options.owner,
        repo: options.repo,
        title: options.prTitle,
        body: options.prBody || '',
        head: options.branchName,
        base: options.baseBranch || 'main'
      });

      if (!prResult?.success) {
        throw new Error('Failed to create PR');
      }

      toast.success(`Created PR #${prResult.result.number} with ${options.files.length} files`);
      
      return {
        success: true,
        number: prResult.result.number,
        html_url: prResult.result.html_url,
        title: options.prTitle
      };
    } catch (error) {
      console.error('Create feature PR error:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to create feature PR');
      return null;
    } finally {
      setIsLoading(false);
    }
  }, [callGitHubWrite]);

  return {
    isLoading,
    createBranch,
    commitFiles,
    createPullRequest,
    mergePullRequest,
    createFeaturePR
  };
}
