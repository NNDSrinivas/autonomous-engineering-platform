import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface GitHubRepo {
  id: number;
  name: string;
  full_name: string;
  description: string | null;
  html_url: string;
  updated_at: string;
  stargazers_count: number;
  open_issues_count: number;
}

export interface GitHubPR {
  id: number;
  number: number;
  title: string;
  state: string;
  html_url: string;
  created_at: string;
  user: { login: string; avatar_url: string };
  repo: string;
}

export interface JiraIssue {
  id: string;
  key: string;
  fields: {
    summary: string;
    status: { name: string };
    priority: { name: string };
    assignee: { displayName: string } | null;
    updated: string;
  };
}

export interface SlackChannel {
  id: string;
  name: string;
  is_private: boolean;
  num_members: number;
}

export interface SlackMessage {
  ts: string;
  text: string;
  user: string;
  channel_name: string;
  channel_id: string;
}

export interface ConfluencePage {
  id: string;
  title: string;
  spaceId: string;
  status: string;
  version: { number: number };
}

type IntegrationData = 
  | GitHubRepo[] 
  | GitHubPR[] 
  | JiraIssue[] 
  | SlackChannel[] 
  | SlackMessage[]
  | ConfluencePage[];

export function useIntegrationData() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchData = useCallback(async <T extends IntegrationData>(
    provider: string, 
    action: string
  ): Promise<T | null> => {
    setIsLoading(true);
    setError(null);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error('Please sign in to fetch integration data');
        return null;
      }

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/integration-data`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ provider, action }),
        }
      );

      const result = await response.json();

      if (!response.ok) {
        if (result.requiresAuth) {
          toast.error(`Please connect ${provider} first`);
        } else {
          toast.error(result.error || 'Failed to fetch data');
        }
        setError(result.error);
        return null;
      }

      return result.data as T;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      setError(message);
      toast.error(`Failed to fetch ${provider} data`);
      return null;
    } finally {
      setIsLoading(false);
    }
  }, []);

  // GitHub
  const fetchGitHubRepos = useCallback(() => 
    fetchData<GitHubRepo[]>('github', 'repos'), [fetchData]);
  
  const fetchGitHubPRs = useCallback(() => 
    fetchData<GitHubPR[]>('github', 'prs'), [fetchData]);
  
  const fetchGitHubIssues = useCallback(() => 
    fetchData<GitHubRepo[]>('github', 'issues'), [fetchData]);

  // Jira
  const fetchJiraIssues = useCallback(() => 
    fetchData<JiraIssue[]>('jira', 'issues'), [fetchData]);
  
  const fetchJiraProjects = useCallback(() => 
    fetchData<JiraIssue[]>('jira', 'projects'), [fetchData]);
  
  const fetchJiraSprints = useCallback(() => 
    fetchData<JiraIssue[]>('jira', 'sprints'), [fetchData]);

  // Slack
  const fetchSlackChannels = useCallback(() => 
    fetchData<SlackChannel[]>('slack', 'channels'), [fetchData]);
  
  const fetchSlackMessages = useCallback(() => 
    fetchData<SlackMessage[]>('slack', 'messages'), [fetchData]);

  // Confluence
  const fetchConfluenceSpaces = useCallback(() => 
    fetchData<ConfluencePage[]>('confluence', 'spaces'), [fetchData]);
  
  const fetchConfluencePages = useCallback(() => 
    fetchData<ConfluencePage[]>('confluence', 'pages'), [fetchData]);

  return {
    isLoading,
    error,
    fetchData,
    // GitHub
    fetchGitHubRepos,
    fetchGitHubPRs,
    fetchGitHubIssues,
    // Jira
    fetchJiraIssues,
    fetchJiraProjects,
    fetchJiraSprints,
    // Slack
    fetchSlackChannels,
    fetchSlackMessages,
    // Confluence
    fetchConfluenceSpaces,
    fetchConfluencePages,
  };
}
