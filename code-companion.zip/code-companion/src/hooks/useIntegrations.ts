import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface IntegrationConnection {
  provider: string;
  status: 'connected' | 'disconnected' | 'error' | 'expired';
  provider_display_name?: string;
  last_sync_at?: string;
  created_at?: string;
}

export interface IntegrationState {
  id: string;
  name: string;
  type: 'jira' | 'slack' | 'github' | 'confluence' | 'teams' | 'zoom' | 'cicd';
  status: 'connected' | 'disconnected' | 'error';
  lastSync?: Date;
  displayName?: string;
  isConfigured?: boolean; // Whether OAuth credentials are configured by admin
}

const defaultIntegrations: IntegrationState[] = [
  { id: '1', name: 'Jira', type: 'jira', status: 'disconnected' },
  { id: '2', name: 'Slack', type: 'slack', status: 'disconnected' },
  { id: '3', name: 'GitHub', type: 'github', status: 'disconnected' },
  { id: '4', name: 'Confluence', type: 'confluence', status: 'disconnected' },
  { id: '5', name: 'Microsoft Teams', type: 'teams', status: 'disconnected' },
  { id: '6', name: 'Zoom', type: 'zoom', status: 'disconnected' },
  { id: '7', name: 'CI/CD (GitHub Actions)', type: 'cicd', status: 'disconnected' },
];

// OAuth-supported providers
const oauthProviders = ['jira', 'slack', 'github', 'confluence', 'zoom', 'teams'];

export function useIntegrations() {
  const [integrations, setIntegrations] = useState<IntegrationState[]>(defaultIntegrations);
  const [isLoading, setIsLoading] = useState(false);
  const [user, setUser] = useState<{ id: string } | null>(null);
  const [configuredProviders, setConfiguredProviders] = useState<string[]>([]);

  // Check auth state
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  // Fetch configured providers from org config
  const fetchConfiguredProviders = useCallback(async () => {
    if (!user) return;

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/oauth?action=configured-providers`,
        {
          headers: {
            Authorization: `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
        }
      );

      if (response.ok) {
        const { configuredProviders: providers } = await response.json();
        setConfiguredProviders(providers || []);
        
        // Update integrations with configured status
        setIntegrations(prev => prev.map(integration => ({
          ...integration,
          isConfigured: providers?.includes(integration.type) || false,
        })));
      }
    } catch (error) {
      console.error('Failed to fetch configured providers:', error);
    }
  }, [user]);

  // Fetch connections when user is authenticated
  const fetchConnections = useCallback(async () => {
    if (!user) return;

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/oauth?action=connections`,
        {
          headers: {
            Authorization: `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
        }
      );

      if (response.ok) {
        const { connections } = await response.json();
        
        setIntegrations(prev => prev.map(integration => {
          const connection = connections?.find(
            (c: IntegrationConnection) => c.provider === integration.type
          );
          if (connection) {
            return {
              ...integration,
              status: connection.status as 'connected' | 'disconnected' | 'error',
              lastSync: connection.last_sync_at ? new Date(connection.last_sync_at) : undefined,
              displayName: connection.provider_display_name,
            };
          }
          return integration;
        }));
      }
    } catch (error) {
      console.error('Failed to fetch connections:', error);
    }
  }, [user]);

  useEffect(() => {
    fetchConnections();
    fetchConfiguredProviders();
  }, [fetchConnections, fetchConfiguredProviders]);

  // Listen for OAuth success messages from popup
  useEffect(() => {
    const handleMessage = async (event: MessageEvent) => {
      if (event.data?.type === 'oauth-success') {
        const provider = event.data.provider;
        toast.success(`Successfully connected to ${provider}`);
        fetchConnections();
        
        // Auto-index repository when GitHub is connected
        if (provider === 'github' && event.data.repoInfo) {
          const { owner, repo } = event.data.repoInfo;
          // Dispatch custom event for repo indexing
          window.dispatchEvent(new CustomEvent('github-connected', {
            detail: { owner, repo }
          }));
        }
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [fetchConnections]);

  const initiateOAuth = useCallback(async (provider: string) => {
    if (!user) {
      toast.error('Please sign in to connect integrations');
      return;
    }

    if (!oauthProviders.includes(provider)) {
      toast.info(`${provider} integration coming soon!`);
      return;
    }

    setIsLoading(true);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error('Please sign in to connect integrations');
        return;
      }

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/oauth?action=initiate`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            provider,
            redirectUri: window.location.origin,
          }),
        }
      );

      const data = await response.json();

      if (data.configRequired) {
        toast.info(data.message);
        return;
      }

      if (data.authUrl) {
        // Open OAuth popup
        const width = 600;
        const height = 700;
        const left = window.screenX + (window.outerWidth - width) / 2;
        const top = window.screenY + (window.outerHeight - height) / 2;
        
        window.open(
          data.authUrl,
          `oauth-${provider}`,
          `width=${width},height=${height},left=${left},top=${top}`
        );
      } else {
        toast.error('Failed to initiate OAuth');
      }
    } catch (error) {
      console.error('OAuth initiation error:', error);
      toast.error('Failed to connect integration');
    } finally {
      setIsLoading(false);
    }
  }, [user]);

  const disconnect = useCallback(async (provider: string) => {
    if (!user) return;

    setIsLoading(true);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/oauth?action=disconnect`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ provider }),
        }
      );

      if (response.ok) {
        toast.success(`Disconnected from ${provider}`);
        setIntegrations(prev => prev.map(i => 
          i.type === provider ? { ...i, status: 'disconnected' as const, lastSync: undefined } : i
        ));
      } else {
        toast.error('Failed to disconnect');
      }
    } catch (error) {
      console.error('Disconnect error:', error);
      toast.error('Failed to disconnect integration');
    } finally {
      setIsLoading(false);
    }
  }, [user]);

  const refresh = useCallback(() => {
    fetchConnections();
    fetchConfiguredProviders();
  }, [fetchConnections, fetchConfiguredProviders]);

  return {
    integrations,
    isLoading,
    isAuthenticated: !!user,
    configuredProviders,
    initiateOAuth,
    disconnect,
    refresh,
  };
}
