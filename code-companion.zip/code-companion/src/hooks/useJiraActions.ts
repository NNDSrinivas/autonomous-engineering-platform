import { useCallback, useState } from 'react';
import { toast } from 'sonner';
import type { JiraTask } from '@/types';

// Atlassian Cloud ID for the connected workspace
const ATLASSIAN_CLOUD_ID = '037e3789-12e1-42be-81b5-b7f903037b89';

interface JiraTransition {
  id: string;
  name: string;
  to: {
    id: string;
    name: string;
  };
}

interface UseJiraActionsReturn {
  isLoading: boolean;
  error: string | null;
  transitionIssue: (issueKey: string, targetStatus: string) => Promise<boolean>;
  addComment: (issueKey: string, comment: string) => Promise<boolean>;
  getAvailableTransitions: (issueKey: string) => Promise<JiraTransition[]>;
  updateIssueForWorkflowStep: (task: JiraTask, stepName: string, stepStatus: 'started' | 'completed' | 'failed') => Promise<boolean>;
}

// Map workflow step names to Jira status transitions
const STEP_TO_STATUS_MAP: Record<string, Record<string, string>> = {
  started: {
    'create_branch': 'In Progress',
    'create_pr': 'In Progress',
    'run_tests': 'In Progress',
    'run_build': 'In Progress',
    'code_review': 'In Review',
    'merge_pr': 'In Review',
    'deploy': 'In Progress',
  },
  completed: {
    'create_branch': 'In Progress',
    'create_pr': 'In Progress',
    'run_tests': 'In Progress',
    'run_build': 'In Progress',
    'code_review': 'In Progress',
    'merge_pr': 'Done',
    'deploy': 'Done',
  },
  failed: {
    'run_tests': 'Blocked',
    'run_build': 'Blocked',
    'deploy': 'Blocked',
  },
};

export function useJiraActions(): UseJiraActionsReturn {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Get available transitions for an issue
  const getAvailableTransitions = useCallback(async (issueKey: string): Promise<JiraTransition[]> => {
    try {
      // This would use the Atlassian MCP tool - for now we'll simulate
      // In a real implementation, this would call:
      // mcp_01kdsg3c20f3h8rqtxk419cg3z--getTransitionsForJiraIssue
      console.log(`[Jira] Getting transitions for ${issueKey}`);
      
      // Simulated transitions - these would come from the MCP
      return [
        { id: '11', name: 'Start Progress', to: { id: '3', name: 'In Progress' } },
        { id: '21', name: 'Review', to: { id: '4', name: 'In Review' } },
        { id: '31', name: 'Done', to: { id: '5', name: 'Done' } },
        { id: '41', name: 'Blocked', to: { id: '6', name: 'Blocked' } },
      ];
    } catch (err) {
      console.error('[Jira] Failed to get transitions:', err);
      return [];
    }
  }, []);

  // Transition an issue to a new status
  const transitionIssue = useCallback(async (issueKey: string, targetStatus: string): Promise<boolean> => {
    setIsLoading(true);
    setError(null);

    try {
      console.log(`[Jira] Transitioning ${issueKey} to ${targetStatus}`);
      
      // Get available transitions
      const transitions = await getAvailableTransitions(issueKey);
      
      // Find matching transition
      const transition = transitions.find(t => 
        t.to.name.toLowerCase() === targetStatus.toLowerCase() ||
        t.name.toLowerCase().includes(targetStatus.toLowerCase())
      );

      if (!transition) {
        console.warn(`[Jira] No transition found for status: ${targetStatus}`);
        return false;
      }

      // This would use the Atlassian MCP tool to transition
      // mcp_01kdsg3c20f3h8rqtxk419cg3z--transitionJiraIssue
      console.log(`[Jira] Executing transition ${transition.id} (${transition.name}) for ${issueKey}`);
      
      // Simulate the API call
      await new Promise(resolve => setTimeout(resolve, 500));
      
      toast.success(`${issueKey} moved to ${targetStatus}`);
      return true;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to transition issue';
      setError(message);
      console.error('[Jira] Transition error:', err);
      toast.error(`Failed to update ${issueKey}: ${message}`);
      return false;
    } finally {
      setIsLoading(false);
    }
  }, [getAvailableTransitions]);

  // Add a comment to an issue
  const addComment = useCallback(async (issueKey: string, comment: string): Promise<boolean> => {
    setIsLoading(true);
    setError(null);

    try {
      console.log(`[Jira] Adding comment to ${issueKey}`);
      
      // This would use the Atlassian MCP tool
      // mcp_01kdsg3c20f3h8rqtxk419cg3z--addCommentToJiraIssue
      await new Promise(resolve => setTimeout(resolve, 300));
      
      console.log(`[Jira] Comment added to ${issueKey}: ${comment.substring(0, 50)}...`);
      return true;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to add comment';
      setError(message);
      console.error('[Jira] Comment error:', err);
      return false;
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Update Jira issue based on workflow step execution
  const updateIssueForWorkflowStep = useCallback(async (
    task: JiraTask,
    stepName: string,
    stepStatus: 'started' | 'completed' | 'failed'
  ): Promise<boolean> => {
    try {
      const stepKey = stepName.toLowerCase().replace(/\s+/g, '_');
      const targetStatus = STEP_TO_STATUS_MAP[stepStatus]?.[stepKey];
      
      // Add comment about the workflow step
      const commentMap: Record<string, string> = {
        started: `🚀 Workflow step "${stepName}" started`,
        completed: `✅ Workflow step "${stepName}" completed successfully`,
        failed: `❌ Workflow step "${stepName}" failed`,
      };
      
      await addComment(task.key, commentMap[stepStatus] || `Workflow step: ${stepName} - ${stepStatus}`);
      
      // Only transition if we have a target status for this step
      if (targetStatus) {
        await transitionIssue(task.key, targetStatus);
      }
      
      return true;
    } catch (err) {
      console.error('[Jira] Failed to update issue for workflow step:', err);
      return false;
    }
  }, [addComment, transitionIssue]);

  return {
    isLoading,
    error,
    transitionIssue,
    addComment,
    getAvailableTransitions,
    updateIssueForWorkflowStep,
  };
}
