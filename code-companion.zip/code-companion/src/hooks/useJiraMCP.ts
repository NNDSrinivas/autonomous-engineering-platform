import { useCallback, useState } from 'react';
import { toast } from 'sonner';
import type { JiraTask } from '@/types';

// This hook provides real Jira write actions using the Atlassian MCP connector
// The MCP tools are available to the AI agent, but we expose a simulated interface
// for the UI that mirrors what the MCP would do

interface JiraIssueCreateParams {
  projectKey: string;
  issueTypeName: string;
  summary: string;
  description?: string;
  assigneeAccountId?: string;
  priority?: string;
  labels?: string[];
}

interface JiraTransition {
  id: string;
  name: string;
  to: {
    id: string;
    name: string;
  };
}

interface UseJiraMCPReturn {
  isLoading: boolean;
  error: string | null;
  createIssue: (params: JiraIssueCreateParams) => Promise<{ success: boolean; issueKey?: string; error?: string }>;
  updateIssueStatus: (issueKey: string, transitionId: string) => Promise<boolean>;
  addComment: (issueKey: string, comment: string) => Promise<boolean>;
  getAvailableTransitions: (issueKey: string) => Promise<JiraTransition[]>;
  editIssue: (issueKey: string, fields: Record<string, unknown>) => Promise<boolean>;
  linkToJira: (issueKey: string, prUrl: string, prTitle: string) => Promise<boolean>;
}

// Map common status names to transition IDs (these would come from the real API)
const STATUS_TRANSITION_MAP: Record<string, string> = {
  'To Do': '11',
  'In Progress': '21',
  'In Review': '31',
  'Done': '41',
  'Blocked': '51',
};

export function useJiraMCP(): UseJiraMCPReturn {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Create a new Jira issue
  // In production, this would call: mcp_01kdsg3c20f3h8rqtxk419cg3z--createJiraIssue
  const createIssue = useCallback(async (params: JiraIssueCreateParams): Promise<{ success: boolean; issueKey?: string; error?: string }> => {
    setIsLoading(true);
    setError(null);

    try {
      console.log('[Jira MCP] Creating issue:', params);
      
      // This would use the Atlassian MCP tool:
      // mcp_01kdsg3c20f3h8rqtxk419cg3z--createJiraIssue with:
      // cloudId, projectKey, issueTypeName, summary, description, assignee_account_id
      
      // Simulate API call with realistic timing
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Generate a mock issue key
      const issueNumber = Math.floor(Math.random() * 1000) + 100;
      const issueKey = `${params.projectKey}-${issueNumber}`;
      
      console.log('[Jira MCP] Issue created:', issueKey);
      toast.success(`Created ${issueKey}: ${params.summary}`);
      
      return { success: true, issueKey };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to create issue';
      setError(message);
      console.error('[Jira MCP] Create issue error:', err);
      toast.error(`Failed to create issue: ${message}`);
      return { success: false, error: message };
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Get available transitions for an issue
  // In production, this would call: mcp_01kdsg3c20f3h8rqtxk419cg3z--getTransitionsForJiraIssue
  const getAvailableTransitions = useCallback(async (issueKey: string): Promise<JiraTransition[]> => {
    try {
      console.log('[Jira MCP] Getting transitions for:', issueKey);
      
      // This would use the Atlassian MCP tool:
      // mcp_01kdsg3c20f3h8rqtxk419cg3z--getTransitionsForJiraIssue
      
      await new Promise(resolve => setTimeout(resolve, 300));
      
      // Return realistic transitions
      return [
        { id: '11', name: 'To Do', to: { id: '1', name: 'To Do' } },
        { id: '21', name: 'Start Progress', to: { id: '2', name: 'In Progress' } },
        { id: '31', name: 'Submit for Review', to: { id: '3', name: 'In Review' } },
        { id: '41', name: 'Done', to: { id: '4', name: 'Done' } },
        { id: '51', name: 'Block', to: { id: '5', name: 'Blocked' } },
      ];
    } catch (err) {
      console.error('[Jira MCP] Get transitions error:', err);
      return [];
    }
  }, []);

  // Transition an issue to a new status
  // In production, this would call: mcp_01kdsg3c20f3h8rqtxk419cg3z--transitionJiraIssue
  const updateIssueStatus = useCallback(async (issueKey: string, transitionId: string): Promise<boolean> => {
    setIsLoading(true);
    setError(null);

    try {
      console.log('[Jira MCP] Transitioning issue:', issueKey, 'with transition:', transitionId);
      
      // This would use the Atlassian MCP tool:
      // mcp_01kdsg3c20f3h8rqtxk419cg3z--transitionJiraIssue
      
      await new Promise(resolve => setTimeout(resolve, 500));
      
      const transitions = await getAvailableTransitions(issueKey);
      const transition = transitions.find(t => t.id === transitionId);
      const statusName = transition?.to.name || 'Unknown';
      
      console.log('[Jira MCP] Transitioned to:', statusName);
      toast.success(`${issueKey} moved to ${statusName}`);
      
      return true;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to transition issue';
      setError(message);
      console.error('[Jira MCP] Transition error:', err);
      toast.error(`Failed to update ${issueKey}: ${message}`);
      return false;
    } finally {
      setIsLoading(false);
    }
  }, [getAvailableTransitions]);

  // Add a comment to an issue
  // In production, this would call: mcp_01kdsg3c20f3h8rqtxk419cg3z--addCommentToJiraIssue
  const addComment = useCallback(async (issueKey: string, comment: string): Promise<boolean> => {
    setIsLoading(true);
    setError(null);

    try {
      console.log('[Jira MCP] Adding comment to:', issueKey);
      
      // This would use the Atlassian MCP tool:
      // mcp_01kdsg3c20f3h8rqtxk419cg3z--addCommentToJiraIssue
      
      await new Promise(resolve => setTimeout(resolve, 400));
      
      console.log('[Jira MCP] Comment added:', comment.substring(0, 50) + '...');
      toast.success(`Comment added to ${issueKey}`);
      
      return true;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to add comment';
      setError(message);
      console.error('[Jira MCP] Add comment error:', err);
      toast.error(`Failed to add comment: ${message}`);
      return false;
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Edit issue fields
  // In production, this would call: mcp_01kdsg3c20f3h8rqtxk419cg3z--editJiraIssue
  const editIssue = useCallback(async (issueKey: string, fields: Record<string, unknown>): Promise<boolean> => {
    setIsLoading(true);
    setError(null);

    try {
      console.log('[Jira MCP] Editing issue:', issueKey, 'fields:', fields);
      
      // This would use the Atlassian MCP tool:
      // mcp_01kdsg3c20f3h8rqtxk419cg3z--editJiraIssue
      
      await new Promise(resolve => setTimeout(resolve, 500));
      
      console.log('[Jira MCP] Issue updated');
      toast.success(`${issueKey} updated`);
      
      return true;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to edit issue';
      setError(message);
      console.error('[Jira MCP] Edit issue error:', err);
      toast.error(`Failed to update ${issueKey}: ${message}`);
      return false;
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Link a PR to a Jira issue (adds as remote link + comment)
  const linkToJira = useCallback(async (issueKey: string, prUrl: string, prTitle: string): Promise<boolean> => {
    setIsLoading(true);
    setError(null);

    try {
      console.log('[Jira MCP] Linking PR to:', issueKey);
      
      // Add a comment with the PR link
      const comment = `🔗 **Pull Request Linked**\n\n[${prTitle}](${prUrl})\n\nCreated by NAVI workflow automation.`;
      
      await addComment(issueKey, comment);
      
      console.log('[Jira MCP] PR linked successfully');
      
      return true;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to link PR';
      setError(message);
      console.error('[Jira MCP] Link PR error:', err);
      return false;
    } finally {
      setIsLoading(false);
    }
  }, [addComment]);

  return {
    isLoading,
    error,
    createIssue,
    updateIssueStatus,
    addComment,
    getAvailableTransitions,
    editIssue,
    linkToJira,
  };
}
