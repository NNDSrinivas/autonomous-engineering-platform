import { useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface FeedbackParams {
  messageId: string;
  conversationId: string;
  feedbackType: 'like' | 'dislike';
  messageContent: string;
  messageRole: 'user' | 'assistant';
  metadata?: Record<string, unknown>;
}

export function useMessageFeedback() {
  const submitFeedback = useCallback(async ({
    messageId,
    conversationId,
    feedbackType,
    messageContent,
    messageRole,
    metadata = {},
  }: FeedbackParams) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        console.log('User not authenticated, skipping feedback persistence');
        return { success: false, reason: 'not_authenticated' };
      }

      // Upsert feedback (update if exists, insert if not)
      const { data: existingFeedback } = await supabase
        .from('message_feedback')
        .select('id')
        .eq('user_id', user.id)
        .eq('message_id', messageId)
        .eq('conversation_id', conversationId)
        .maybeSingle();

      let error;
      if (existingFeedback) {
        // Update existing feedback
        const result = await supabase
          .from('message_feedback')
          .update({
            feedback_type: feedbackType,
            message_content: messageContent,
            metadata: metadata as any,
          })
          .eq('id', existingFeedback.id);
        error = result.error;
      } else {
        // Insert new feedback
        const result = await supabase
          .from('message_feedback')
          .insert({
            user_id: user.id,
            message_id: messageId,
            conversation_id: conversationId,
            feedback_type: feedbackType,
            message_content: messageContent,
            message_role: messageRole,
            metadata: metadata as any,
          });
        error = result.error;
      }

      console.log(`Feedback saved: ${feedbackType} for message ${messageId}`);
      return { success: true };
    } catch (err) {
      console.error('Error submitting feedback:', err);
      return { success: false, reason: 'unknown_error', error: err };
    }
  }, []);

  const removeFeedback = useCallback(async (messageId: string, conversationId: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        return { success: false, reason: 'not_authenticated' };
      }

      const { error } = await supabase
        .from('message_feedback')
        .delete()
        .eq('user_id', user.id)
        .eq('message_id', messageId)
        .eq('conversation_id', conversationId);

      if (error) {
        console.error('Failed to remove feedback:', error);
        return { success: false, reason: 'database_error', error };
      }

      return { success: true };
    } catch (err) {
      console.error('Error removing feedback:', err);
      return { success: false, reason: 'unknown_error', error: err };
    }
  }, []);

  return { submitFeedback, removeFeedback };
}
