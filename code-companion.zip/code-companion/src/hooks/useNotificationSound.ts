import { useEffect, useRef, useCallback, useState } from 'react';

const NOTIFICATION_SOUND_KEY = 'notification-sound-enabled';
const NOTIFICATION_SOUND_TYPE_KEY = 'notification-sound-type';
const NOTIFICATION_SOUND_VOLUME_KEY = 'notification-sound-volume';

export type SoundType = 'chime' | 'bell' | 'pop' | 'ding';

export const SOUND_OPTIONS: { value: SoundType; label: string; description: string }[] = [
  { value: 'chime', label: 'Chime', description: 'Gentle two-tone chime' },
  { value: 'bell', label: 'Bell', description: 'Classic notification bell' },
  { value: 'pop', label: 'Pop', description: 'Quick bubbly pop' },
  { value: 'ding', label: 'Ding', description: 'Simple single ding' },
];

// Create notification sounds using Web Audio API
const createSoundPlayer = (audioContext: AudioContext, type: SoundType, volume: number = 0.5) => {
  const normalizedVolume = Math.max(0, Math.min(1, volume));
  
  const playChime = () => {
    const osc1 = audioContext.createOscillator();
    const gain1 = audioContext.createGain();
    osc1.connect(gain1);
    gain1.connect(audioContext.destination);
    osc1.frequency.setValueAtTime(784, audioContext.currentTime);
    osc1.type = 'sine';
    gain1.gain.setValueAtTime(0, audioContext.currentTime);
    gain1.gain.linearRampToValueAtTime(0.3 * normalizedVolume, audioContext.currentTime + 0.05);
    gain1.gain.linearRampToValueAtTime(0, audioContext.currentTime + 0.3);
    osc1.start(audioContext.currentTime);
    osc1.stop(audioContext.currentTime + 0.3);

    setTimeout(() => {
      const osc2 = audioContext.createOscillator();
      const gain2 = audioContext.createGain();
      osc2.connect(gain2);
      gain2.connect(audioContext.destination);
      osc2.frequency.setValueAtTime(988, audioContext.currentTime);
      osc2.type = 'sine';
      gain2.gain.setValueAtTime(0, audioContext.currentTime);
      gain2.gain.linearRampToValueAtTime(0.25 * normalizedVolume, audioContext.currentTime + 0.05);
      gain2.gain.linearRampToValueAtTime(0, audioContext.currentTime + 0.25);
      osc2.start(audioContext.currentTime);
      osc2.stop(audioContext.currentTime + 0.25);
    }, 100);
  };

  const playBell = () => {
    const fundamental = 880;
    const harmonics = [1, 2, 3, 4.2];
    const gains = [0.5, 0.3, 0.15, 0.1];
    
    harmonics.forEach((harmonic, i) => {
      const osc = audioContext.createOscillator();
      const gain = audioContext.createGain();
      osc.connect(gain);
      gain.connect(audioContext.destination);
      osc.frequency.setValueAtTime(fundamental * harmonic, audioContext.currentTime);
      osc.type = 'sine';
      gain.gain.setValueAtTime(0, audioContext.currentTime);
      gain.gain.linearRampToValueAtTime(gains[i] * 0.4 * normalizedVolume, audioContext.currentTime + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.8);
      osc.start(audioContext.currentTime);
      osc.stop(audioContext.currentTime + 0.8);
    });
  };

  const playPop = () => {
    const osc = audioContext.createOscillator();
    const gain = audioContext.createGain();
    osc.connect(gain);
    gain.connect(audioContext.destination);
    osc.frequency.setValueAtTime(600, audioContext.currentTime);
    osc.frequency.exponentialRampToValueAtTime(200, audioContext.currentTime + 0.1);
    osc.type = 'sine';
    gain.gain.setValueAtTime(0.4 * normalizedVolume, audioContext.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.15);
    osc.start(audioContext.currentTime);
    osc.stop(audioContext.currentTime + 0.15);
  };

  const playDing = () => {
    const osc = audioContext.createOscillator();
    const gain = audioContext.createGain();
    osc.connect(gain);
    gain.connect(audioContext.destination);
    osc.frequency.setValueAtTime(1200, audioContext.currentTime);
    osc.type = 'sine';
    gain.gain.setValueAtTime(0, audioContext.currentTime);
    gain.gain.linearRampToValueAtTime(0.35 * normalizedVolume, audioContext.currentTime + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.4);
    osc.start(audioContext.currentTime);
    osc.stop(audioContext.currentTime + 0.4);
  };

  return {
    play: () => {
      switch (type) {
        case 'chime': playChime(); break;
        case 'bell': playBell(); break;
        case 'pop': playPop(); break;
        case 'ding': playDing(); break;
      }
    }
  };
};

export function useNotificationSoundPreference() {
  const [soundEnabled, setSoundEnabled] = useState(() => {
    if (typeof window === 'undefined') return true;
    const stored = localStorage.getItem(NOTIFICATION_SOUND_KEY);
    return stored === null ? true : stored === 'true';
  });

  const [soundType, setSoundType] = useState<SoundType>(() => {
    if (typeof window === 'undefined') return 'chime';
    const stored = localStorage.getItem(NOTIFICATION_SOUND_TYPE_KEY);
    return (stored as SoundType) || 'chime';
  });

  const [volume, setVolume] = useState(() => {
    if (typeof window === 'undefined') return 0.5;
    const stored = localStorage.getItem(NOTIFICATION_SOUND_VOLUME_KEY);
    return stored ? parseFloat(stored) : 0.5;
  });

  const toggleSound = useCallback((enabled: boolean) => {
    setSoundEnabled(enabled);
    localStorage.setItem(NOTIFICATION_SOUND_KEY, String(enabled));
  }, []);

  const changeSoundType = useCallback((type: SoundType) => {
    setSoundType(type);
    localStorage.setItem(NOTIFICATION_SOUND_TYPE_KEY, type);
  }, []);

  const changeVolume = useCallback((newVolume: number) => {
    const clampedVolume = Math.max(0, Math.min(1, newVolume));
    setVolume(clampedVolume);
    localStorage.setItem(NOTIFICATION_SOUND_VOLUME_KEY, String(clampedVolume));
  }, []);

  return { soundEnabled, toggleSound, soundType, changeSoundType, volume, changeVolume };
}

export function useNotificationSound(notificationCount: number, enabled: boolean = true, soundType: SoundType = 'chime', volume: number = 0.5) {
  const prevCountRef = useRef(notificationCount);
  const audioContextRef = useRef<AudioContext | null>(null);

  const initAudio = useCallback(() => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
  }, []);

  const playPreview = useCallback((type: SoundType, previewVolume?: number) => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    const player = createSoundPlayer(audioContextRef.current, type, previewVolume ?? volume);
    player.play();
  }, [volume]);

  useEffect(() => {
    const handleInteraction = () => {
      initAudio();
      document.removeEventListener('click', handleInteraction);
    };
    document.addEventListener('click', handleInteraction);
    
    return () => {
      document.removeEventListener('click', handleInteraction);
    };
  }, [initAudio]);

  useEffect(() => {
    if (enabled && notificationCount > prevCountRef.current && audioContextRef.current) {
      const player = createSoundPlayer(audioContextRef.current, soundType, volume);
      player.play();
    }
    prevCountRef.current = notificationCount;
  }, [notificationCount, enabled, soundType, volume]);

  return { initAudio, playPreview };
}
