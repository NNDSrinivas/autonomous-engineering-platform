import { useState, useCallback } from 'react';

export interface ProjectFile {
  name: string;
  path: string;
  content?: string;
  language?: string;
  size?: number;
}

// Mock file contents - in production, this would fetch from an API
const MOCK_FILE_CONTENTS: Record<string, string> = {
  'src/components/navi/NaviChat.tsx': `// NAVI Chat Component
import { useState, useRef, useEffect } from 'react';
// ... main chat interface component
export function NaviChat({ selectedTask, userName }: NaviChatProps) {
  // Chat logic implementation
}`,
  'src/components/navi/NaviHeader.tsx': `// NAVI Header Component
import { Button } from '@/components/ui/button';
export function NaviHeader() {
  return <header className="navi-header">...</header>;
}`,
  'src/components/navi/FileExplorer.tsx': `// File Explorer Component
export function FileExplorer({ onFileSelect }: FileExplorerProps) {
  // Tree view of project files
}`,
  'src/components/navi/SettingsPanel.tsx': `// Settings Panel
export function SettingsPanel() {
  return <div>Settings...</div>;
}`,
  'src/components/navi/IntegrationsSidebar.tsx': `// Integrations Sidebar
export function IntegrationsSidebar() {
  // Slack, Teams, Jira, etc.
}`,
  'src/components/ui/button.tsx': `// Button Component with variants
import { cva } from 'class-variance-authority';
export const buttonVariants = cva('...');`,
  'src/components/ui/input.tsx': `// Input Component
export function Input(props) {
  return <input {...props} />;
}`,
  'src/components/ui/dialog.tsx': `// Dialog Component
export function Dialog({ children }) {
  return <div className="dialog">{children}</div>;
}`,
  'src/hooks/useNaviChat.ts': `// NAVI Chat Hook
export function useNaviChat() {
  // Manages chat state, streaming, model selection
}`,
  'src/hooks/useTheme.ts': `// Theme Hook
export function useTheme() {
  // Dark/light mode toggle
}`,
  'src/hooks/useSidebarPins.ts': `// Sidebar Pin Management
export function useSidebarPins() {
  // Manages which sidebar items are pinned
}`,
  'src/pages/Index.tsx': `// Main Index Page
export default function Index() {
  return <div>NAVI Application</div>;
}`,
  'src/pages/Auth.tsx': `// Auth Page
export default function Auth() {
  return <div>Login/Signup</div>;
}`,
  'src/App.tsx': `// App Root
import { Routes } from 'react-router-dom';
export default function App() {
  return <Routes>...</Routes>;
}`,
  'src/main.tsx': `// Entry Point
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
ReactDOM.createRoot(...).render(<App />);`,
  'src/index.css': `/* Global Styles */
@tailwind base;
@tailwind components;
@tailwind utilities;
:root {
  --background: 0 0% 100%;
  --foreground: 222.2 47.4% 11.2%;
}`,
  'public/favicon.ico': '[Binary: favicon.ico]',
  'public/robots.txt': `User-agent: *
Allow: /`,
  'package.json': `{
  "name": "navi",
  "version": "1.0.0",
  "scripts": {
    "dev": "vite",
    "build": "tsc && vite build"
  }
}`,
  'tsconfig.json': `{
  "compilerOptions": {
    "target": "ES2020",
    "strict": true
  }
}`,
  'vite.config.ts': `import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({
  plugins: [react()]
});`,
  'tailwind.config.ts': `import type { Config } from 'tailwindcss';
export default {
  content: ['./src/**/*.{ts,tsx}'],
  theme: { extend: {} }
} satisfies Config;`,
  'README.md': `# NAVI - Autonomous Engineering Intelligence
The most powerful engineering agent ever created.`
};

export function useProjectFiles() {
  const [isLoading, setIsLoading] = useState(false);
  const [loadedFiles, setLoadedFiles] = useState<Map<string, string>>(new Map());

  const fetchFileContent = useCallback(async (filePath: string): Promise<string | null> => {
    // Check cache first
    if (loadedFiles.has(filePath)) {
      return loadedFiles.get(filePath) || null;
    }

    setIsLoading(true);
    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 100));
      
      // In production, this would be a real API call:
      // const response = await fetch(`/api/files/${encodeURIComponent(filePath)}`);
      // const data = await response.json();
      // return data.content;
      
      const content = MOCK_FILE_CONTENTS[filePath] || null;
      if (content) {
        setLoadedFiles(prev => new Map(prev).set(filePath, content));
      }
      return content;
    } catch (error) {
      console.error('Failed to fetch file content:', error);
      return null;
    } finally {
      setIsLoading(false);
    }
  }, [loadedFiles]);

  const fetchMultipleFiles = useCallback(async (filePaths: string[]): Promise<ProjectFile[]> => {
    setIsLoading(true);
    const results: ProjectFile[] = [];
    
    try {
      for (const path of filePaths) {
        const content = await fetchFileContent(path);
        const name = path.split('/').pop() || path;
        const ext = name.split('.').pop() || '';
        
        const languageMap: Record<string, string> = {
          'ts': 'typescript',
          'tsx': 'typescript',
          'js': 'javascript',
          'jsx': 'javascript',
          'css': 'css',
          'json': 'json',
          'md': 'markdown',
          'txt': 'text',
        };
        
        results.push({
          name,
          path,
          content: content || `[Unable to load: ${path}]`,
          language: languageMap[ext] || 'text',
        });
      }
    } finally {
      setIsLoading(false);
    }
    
    return results;
  }, [fetchFileContent]);

  const formatFilesForContext = useCallback((files: ProjectFile[]): string => {
    return files
      .map(file => `--- File: ${file.path} ---\n\`\`\`${file.language || 'text'}\n${file.content}\n\`\`\``)
      .join('\n\n');
  }, []);

  const clearCache = useCallback(() => {
    setLoadedFiles(new Map());
  }, []);

  return {
    isLoading,
    fetchFileContent,
    fetchMultipleFiles,
    formatFilesForContext,
    clearCache,
  };
}
