import { useState, useCallback, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface IndexedFile {
  path: string;
  type: 'file' | 'directory';
  size?: number;
  language?: string;
  lastIndexed: string;
}

interface RepoIndex {
  owner: string;
  repo: string;
  branch: string;
  files: IndexedFile[];
  totalFiles: number;
  lastFullScan: string;
  isIndexing: boolean;
}

interface FileSearchResult {
  path: string;
  score: number;
  snippet?: string;
  language?: string;
}

const LANGUAGE_MAP: Record<string, string> = {
  ts: 'typescript',
  tsx: 'typescript',
  js: 'javascript',
  jsx: 'javascript',
  py: 'python',
  go: 'go',
  rs: 'rust',
  java: 'java',
  kt: 'kotlin',
  rb: 'ruby',
  php: 'php',
  css: 'css',
  scss: 'scss',
  html: 'html',
  json: 'json',
  yaml: 'yaml',
  yml: 'yaml',
  md: 'markdown',
  sql: 'sql',
};

export function useRepoIndexing() {
  const [repoIndex, setRepoIndex] = useState<RepoIndex | null>(null);
  const [isIndexing, setIsIndexing] = useState(false);
  const [indexProgress, setIndexProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);

  // Get language from file extension
  const getLanguage = useCallback((path: string): string => {
    const ext = path.split('.').pop()?.toLowerCase() || '';
    return LANGUAGE_MAP[ext] || 'text';
  }, []);

  // Scan repository structure
  const scanRepository = useCallback(async (
    owner: string,
    repo: string,
    branch: string = 'main'
  ): Promise<IndexedFile[]> => {
    const { data: session } = await supabase.auth.getSession();
    if (!session.session) {
      throw new Error('Not authenticated');
    }

    const response = await fetch(
      `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/github-api`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.session.access_token}`
        },
        body: JSON.stringify({
          action: 'list_repo_tree',
          params: { owner, repo, ref: branch, recursive: true }
        }),
      }
    );

    if (!response.ok) {
      // Fallback to listing files via contents API
      return await scanRepositoryFallback(owner, repo, branch, session.session.access_token);
    }

    const data = await response.json();
    const tree = data.tree || [];
    
    return tree
      .filter((item: any) => item.type === 'blob')
      .map((item: any) => ({
        path: item.path,
        type: 'file' as const,
        size: item.size,
        language: getLanguage(item.path),
        lastIndexed: new Date().toISOString(),
      }));
  }, [getLanguage]);

  // Fallback scanning method using contents API
  const scanRepositoryFallback = useCallback(async (
    owner: string,
    repo: string,
    branch: string,
    accessToken: string,
    path: string = ''
  ): Promise<IndexedFile[]> => {
    const response = await fetch(
      `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/github-api`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify({
          action: 'list_contents',
          params: { owner, repo, path, ref: branch }
        }),
      }
    );

    if (!response.ok) {
      return [];
    }

    const contents = await response.json();
    const files: IndexedFile[] = [];

    for (const item of contents) {
      if (item.type === 'file') {
        files.push({
          path: item.path,
          type: 'file',
          size: item.size,
          language: getLanguage(item.path),
          lastIndexed: new Date().toISOString(),
        });
      } else if (item.type === 'dir' && !item.path.includes('node_modules')) {
        // Recursively scan subdirectories (skip node_modules)
        const subFiles = await scanRepositoryFallback(owner, repo, branch, accessToken, item.path);
        files.push(...subFiles);
      }
    }

    return files;
  }, [getLanguage]);

  // Index a repository (full scan)
  const indexRepository = useCallback(async (
    owner: string,
    repo: string,
    branch: string = 'main'
  ): Promise<void> => {
    setIsIndexing(true);
    setIndexProgress(0);
    setError(null);

    try {
      toast.info(`Scanning repository ${owner}/${repo}...`);
      
      // Step 1: Get file tree
      setIndexProgress(10);
      const files = await scanRepository(owner, repo, branch);
      setIndexProgress(40);
      
      // Step 2: Store index in Supabase
      const { data: session } = await supabase.auth.getSession();
      if (!session.session) throw new Error('Not authenticated');

      // Store file index as workspace memory
      const indexData = {
        owner,
        repo,
        branch,
        files: files.slice(0, 1000), // Limit to 1000 files
        totalFiles: files.length,
        lastFullScan: new Date().toISOString(),
      };

      setIndexProgress(60);

      // Save to workspace_memories table
      await supabase.from('workspace_memories').upsert({
        user_id: session.session.user.id,
        memory_type: 'documentation' as const,
        source: 'github' as const,
        source_id: `repo-index-${owner}-${repo}`,
        title: `Repository Index: ${owner}/${repo}`,
        content: JSON.stringify(indexData),
        metadata: {
          type: 'repo_index',
          owner,
          repo,
          branch,
          totalFiles: files.length,
          fileTypes: [...new Set(files.map(f => f.language))],
        },
      }, {
        onConflict: 'source_id',
      });

      setIndexProgress(80);

      // Step 3: Index key files for embeddings
      const keyFiles = files.filter(f => 
        f.language === 'typescript' || 
        f.language === 'javascript' ||
        f.path.includes('README') ||
        f.path.includes('package.json')
      ).slice(0, 50);

      await indexKeyFiles(owner, repo, branch, keyFiles, session.session.access_token);

      setIndexProgress(100);
      
      setRepoIndex({
        ...indexData,
        isIndexing: false,
      });

      toast.success(`Indexed ${files.length} files from ${owner}/${repo}`);
    } catch (err) {
      console.error('Indexing error:', err);
      const message = err instanceof Error ? err.message : 'Indexing failed';
      setError(message);
      toast.error(message);
    } finally {
      setIsIndexing(false);
    }
  }, [scanRepository]);

  // Index key files with content for semantic search
  const indexKeyFiles = useCallback(async (
    owner: string,
    repo: string,
    branch: string,
    files: IndexedFile[],
    accessToken: string
  ): Promise<void> => {
    const { data: session } = await supabase.auth.getSession();
    if (!session.session) return;

    for (const file of files) {
      try {
        // Get file content
        const response = await fetch(
          `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/github-api`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${accessToken}`
            },
            body: JSON.stringify({
              action: 'get_file_content',
              params: { owner, repo, path: file.path, ref: branch }
            }),
          }
        );

        if (!response.ok) continue;

        const data = await response.json();
        if (!data.content) continue;

        const content = atob(data.content);
        
        // Store file content for RAG
        await supabase.from('workspace_memories').upsert({
          user_id: session.session.user.id,
          memory_type: 'code_snippet' as const,
          source: 'github' as const,
          source_id: `file-${owner}-${repo}-${file.path.replace(/\//g, '-')}`,
          source_url: `https://github.com/${owner}/${repo}/blob/${branch}/${file.path}`,
          title: file.path,
          content: content.slice(0, 10000), // Limit content size
          metadata: {
            type: 'repo_file',
            owner,
            repo,
            branch,
            path: file.path,
            language: file.language,
            size: file.size,
          },
        }, {
          onConflict: 'source_id',
        });
      } catch (err) {
        // Continue with other files if one fails
        console.warn(`Failed to index ${file.path}:`, err);
      }
    }
  }, []);

  // Search indexed files
  const searchFiles = useCallback(async (
    query: string,
    options?: {
      language?: string;
      owner?: string;
      repo?: string;
      limit?: number;
    }
  ): Promise<FileSearchResult[]> => {
    const { data: session } = await supabase.auth.getSession();
    if (!session.session) return [];

    try {
      // Search in workspace_memories with simpler query
      const { data, error } = await supabase
        .from('workspace_memories')
        .select('title, content, metadata')
        .eq('user_id', session.session.user.id)
        .eq('source', 'github')
        .ilike('content', `%${query}%`)
        .limit(options?.limit || 20);

      if (error) throw error;

      return (data || []).map((item) => ({
        path: item.title || '',
        score: 1.0,
        snippet: item.content?.slice(0, 200),
        language: (item.metadata as Record<string, unknown>)?.language as string | undefined,
      }));
    } catch (err) {
      console.error('Search error:', err);
      return [];
    }
  }, []);

  // Load cached index
  const loadCachedIndex = useCallback(async (
    owner: string,
    repo: string
  ): Promise<RepoIndex | null> => {
    const { data: session } = await supabase.auth.getSession();
    if (!session.session) return null;

    try {
      const { data, error } = await supabase
        .from('workspace_memories')
        .select('content, updated_at')
        .eq('user_id', session.session.user.id)
        .eq('source_id', `repo-index-${owner}-${repo}`)
        .single();

      if (error || !data) return null;

      const indexData = JSON.parse(data.content);
      return {
        ...indexData,
        isIndexing: false,
      };
    } catch {
      return null;
    }
  }, []);

  // Auto-index on login if connected to GitHub
  const autoIndexOnLogin = useCallback(async (
    owner: string,
    repo: string,
    branch: string = 'main'
  ): Promise<void> => {
    // Check if we have a recent index
    const cached = await loadCachedIndex(owner, repo);
    
    if (cached) {
      const lastScan = new Date(cached.lastFullScan);
      const hoursSinceLastScan = (Date.now() - lastScan.getTime()) / (1000 * 60 * 60);
      
      if (hoursSinceLastScan < 24) {
        // Use cached index if less than 24 hours old
        setRepoIndex(cached);
        return;
      }
    }

    // Perform fresh index
    await indexRepository(owner, repo, branch);
  }, [loadCachedIndex, indexRepository]);

  // Get files relevant to a task
  const getRelevantFiles = useCallback(async (
    taskDescription: string,
    limit: number = 10
  ): Promise<FileSearchResult[]> => {
    // Extract keywords from task description
    const keywords = taskDescription
      .toLowerCase()
      .split(/\s+/)
      .filter(w => w.length > 3)
      .slice(0, 5);

    const results: FileSearchResult[] = [];
    
    for (const keyword of keywords) {
      const matches = await searchFiles(keyword, { limit: 5 });
      results.push(...matches);
    }

    // Deduplicate and sort by frequency
    const pathCounts = new Map<string, { result: FileSearchResult; count: number }>();
    
    for (const result of results) {
      const existing = pathCounts.get(result.path);
      if (existing) {
        existing.count++;
        existing.result.score = Math.max(existing.result.score, result.score);
      } else {
        pathCounts.set(result.path, { result, count: 1 });
      }
    }

    return Array.from(pathCounts.values())
      .sort((a, b) => b.count - a.count)
      .slice(0, limit)
      .map(item => item.result);
  }, [searchFiles]);

  return {
    repoIndex,
    isIndexing,
    indexProgress,
    error,
    indexRepository,
    searchFiles,
    loadCachedIndex,
    autoIndexOnLogin,
    getRelevantFiles,
  };
}
