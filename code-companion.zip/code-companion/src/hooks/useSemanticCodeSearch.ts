import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface CodeSearchResult {
  path: string;
  content: string;
  score: number;
  language: string;
  snippet: string;
  lineStart?: number;
  lineEnd?: number;
}

interface SearchOptions {
  limit?: number;
  language?: string;
  minScore?: number;
}

export function useSemanticCodeSearch() {
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<CodeSearchResult[]>([]);
  const [lastQuery, setLastQuery] = useState('');

  // Extract relevant snippet around a match
  const extractSnippet = useCallback((content: string, query: string, contextLines: number = 3): { snippet: string; lineStart: number; lineEnd: number } => {
    const lines = content.split('\n');
    const queryLower = query.toLowerCase();
    
    // Find the best matching line
    let bestLineIndex = 0;
    let bestScore = 0;
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].toLowerCase();
      const words = queryLower.split(/\s+/);
      const matchCount = words.filter(w => line.includes(w)).length;
      if (matchCount > bestScore) {
        bestScore = matchCount;
        bestLineIndex = i;
      }
    }
    
    const startLine = Math.max(0, bestLineIndex - contextLines);
    const endLine = Math.min(lines.length - 1, bestLineIndex + contextLines);
    
    return {
      snippet: lines.slice(startLine, endLine + 1).join('\n'),
      lineStart: startLine + 1,
      lineEnd: endLine + 1,
    };
  }, []);

  // Calculate semantic relevance score
  const calculateScore = useCallback((content: string, query: string): number => {
    const contentLower = content.toLowerCase();
    const queryWords = query.toLowerCase().split(/\s+/).filter(w => w.length > 2);
    
    if (queryWords.length === 0) return 0;
    
    let score = 0;
    let matchedWords = 0;
    
    for (const word of queryWords) {
      if (contentLower.includes(word)) {
        matchedWords++;
        // Boost for exact word match
        const regex = new RegExp(`\\b${word}\\b`, 'gi');
        const matches = contentLower.match(regex);
        score += (matches?.length || 0) * 10;
      }
    }
    
    // Calculate percentage of query words matched
    const matchPercentage = matchedWords / queryWords.length;
    score += matchPercentage * 50;
    
    // Boost for function/class definitions matching query
    if (/function|class|interface|type|const|export/i.test(content)) {
      score += 10;
    }
    
    return Math.min(100, score);
  }, []);

  // Get language from file path
  const getLanguage = useCallback((path: string): string => {
    const ext = path.split('.').pop()?.toLowerCase() || '';
    const langMap: Record<string, string> = {
      ts: 'typescript', tsx: 'typescript',
      js: 'javascript', jsx: 'javascript',
      py: 'python', go: 'go', rs: 'rust',
      java: 'java', kt: 'kotlin', rb: 'ruby',
      php: 'php', css: 'css', scss: 'scss',
      html: 'html', json: 'json', yaml: 'yaml',
      yml: 'yaml', md: 'markdown', sql: 'sql',
    };
    return langMap[ext] || 'text';
  }, []);

  // Semantic search through indexed code files
  const searchCode = useCallback(async (
    query: string,
    options: SearchOptions = {}
  ): Promise<CodeSearchResult[]> => {
    const { limit = 10, language, minScore = 20 } = options;
    
    if (!query.trim()) {
      setSearchResults([]);
      return [];
    }
    
    setIsSearching(true);
    setLastQuery(query);
    
    try {
      const { data: session } = await supabase.auth.getSession();
      if (!session.session) {
        console.warn('Not authenticated for code search');
        return [];
      }

      // Search in workspace_memories for indexed code files
      let queryBuilder = supabase
        .from('workspace_memories')
        .select('title, content, metadata, source_url')
        .eq('user_id', session.session.user.id)
        .eq('source', 'github')
        .eq('memory_type', 'code_snippet');

      // Add text search
      const searchTerms = query.split(/\s+/).filter(t => t.length > 2);
      if (searchTerms.length > 0) {
        // Search in content using ilike for each term
        for (const term of searchTerms.slice(0, 3)) {
          queryBuilder = queryBuilder.ilike('content', `%${term}%`);
        }
      }

      const { data, error } = await queryBuilder.limit(limit * 2);

      if (error) {
        console.error('Search error:', error);
        throw error;
      }

      const results: CodeSearchResult[] = [];

      for (const item of data || []) {
        const content = item.content || '';
        const path = item.title || '';
        const fileLang = getLanguage(path);
        
        // Filter by language if specified
        if (language && fileLang !== language) continue;
        
        const score = calculateScore(content, query);
        
        if (score >= minScore) {
          const { snippet, lineStart, lineEnd } = extractSnippet(content, query);
          
          results.push({
            path,
            content,
            score,
            language: fileLang,
            snippet,
            lineStart,
            lineEnd,
          });
        }
      }

      // Sort by score descending
      results.sort((a, b) => b.score - a.score);
      
      const finalResults = results.slice(0, limit);
      setSearchResults(finalResults);
      return finalResults;
    } catch (err) {
      console.error('Code search error:', err);
      return [];
    } finally {
      setIsSearching(false);
    }
  }, [calculateScore, extractSnippet, getLanguage]);

  // Get code context for a chat query
  const getContextForQuery = useCallback(async (
    query: string,
    maxFiles: number = 5
  ): Promise<string> => {
    const results = await searchCode(query, { limit: maxFiles, minScore: 15 });
    
    if (results.length === 0) {
      return '';
    }

    const contextParts: string[] = [
      '📁 **Relevant Code Context:**\n'
    ];

    for (const result of results) {
      contextParts.push(`\n### ${result.path} (${result.language})`);
      if (result.lineStart && result.lineEnd) {
        contextParts.push(`Lines ${result.lineStart}-${result.lineEnd}:`);
      }
      contextParts.push('```' + result.language);
      contextParts.push(result.snippet);
      contextParts.push('```\n');
    }

    return contextParts.join('\n');
  }, [searchCode]);

  // Quick search for autocomplete
  const quickSearch = useCallback(async (
    query: string,
    limit: number = 5
  ): Promise<{ path: string; language: string }[]> => {
    if (!query.trim() || query.length < 2) return [];
    
    try {
      const { data: session } = await supabase.auth.getSession();
      if (!session.session) return [];

      const { data } = await supabase
        .from('workspace_memories')
        .select('title, metadata')
        .eq('user_id', session.session.user.id)
        .eq('source', 'github')
        .eq('memory_type', 'code_snippet')
        .ilike('title', `%${query}%`)
        .limit(limit);

      return (data || []).map(item => ({
        path: item.title || '',
        language: getLanguage(item.title || ''),
      }));
    } catch {
      return [];
    }
  }, [getLanguage]);

  // Clear search results
  const clearResults = useCallback(() => {
    setSearchResults([]);
    setLastQuery('');
  }, []);

  return {
    isSearching,
    searchResults,
    lastQuery,
    searchCode,
    getContextForQuery,
    quickSearch,
    clearResults,
  };
}
