import { useState, useEffect, useCallback } from 'react';

// All available sidebar items that can be pinned
export const ALL_SIDEBAR_ITEMS = [
  { id: 'briefing', name: 'Daily Briefing', icon: 'Sun', defaultPinned: true },
  { id: 'files', name: 'File Explorer', icon: 'FolderTree', defaultPinned: true },
  { id: 'tasks', name: 'My Tasks', icon: 'LayoutGrid', defaultPinned: true },
  { id: 'search', name: 'Search', icon: 'Search', defaultPinned: true },
  { id: 'activity', name: 'Activity', icon: 'Activity', defaultPinned: true },
  { id: 'cicd', name: 'CI/CD Dashboard', icon: 'Play', defaultPinned: true },
  { id: 'workflows', name: 'Workflow Engine', icon: 'Zap', defaultPinned: true },
  { id: 'queue', name: 'Workflow Queue', icon: 'ListOrdered', defaultPinned: true },
  { id: 'analytics', name: 'Workflow Analytics', icon: 'BarChart3', defaultPinned: true },
  { id: 'workflow-history', name: 'Workflow History', icon: 'ClipboardList', defaultPinned: true },
  { id: 'calendar', name: 'Calendar', icon: 'Calendar', defaultPinned: false },
  { id: 'github', name: 'GitHub', icon: 'Github', defaultPinned: false },
  { id: 'slack', name: 'Slack', icon: 'MessageSquare', defaultPinned: false },
  { id: 'teams', name: 'Teams', icon: 'Users', defaultPinned: false },
  { id: 'zoom', name: 'Zoom', icon: 'Video', defaultPinned: false },
  { id: 'confluence', name: 'Confluence', icon: 'FileText', defaultPinned: false },
  { id: 'memory', name: 'Memory', icon: 'Brain', defaultPinned: false },
] as const;

export type SidebarItemId = typeof ALL_SIDEBAR_ITEMS[number]['id'];

const STORAGE_KEY = 'navi-pinned-sidebar-items';
const ORDER_STORAGE_KEY = 'navi-sidebar-order';

export function useSidebarPins() {
  const [pinnedItems, setPinnedItems] = useState<SidebarItemId[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // Fall through to default
    }
    // Default: all items marked as defaultPinned
    return ALL_SIDEBAR_ITEMS.filter(item => item.defaultPinned).map(item => item.id);
  });

  const [itemOrder, setItemOrder] = useState<SidebarItemId[]>(() => {
    try {
      const saved = localStorage.getItem(ORDER_STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // Fall through to default
    }
    return ALL_SIDEBAR_ITEMS.map(item => item.id);
  });

  // Persist to localStorage when pinnedItems changes
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(pinnedItems));
    } catch {
      // Ignore storage errors
    }
  }, [pinnedItems]);

  // Persist order to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(ORDER_STORAGE_KEY, JSON.stringify(itemOrder));
    } catch {
      // Ignore storage errors
    }
  }, [itemOrder]);

  const togglePin = useCallback((itemId: SidebarItemId) => {
    setPinnedItems(prev => {
      if (prev.includes(itemId)) {
        return prev.filter(id => id !== itemId);
      } else {
        return [...prev, itemId];
      }
    });
  }, []);

  const isPinned = useCallback((itemId: SidebarItemId) => {
    return pinnedItems.includes(itemId);
  }, [pinnedItems]);

  const getPinnedItems = useCallback(() => {
    // Return items in order, filtered by pinned status
    return itemOrder
      .filter(id => pinnedItems.includes(id))
      .map(id => ALL_SIDEBAR_ITEMS.find(item => item.id === id)!)
      .filter(Boolean);
  }, [pinnedItems, itemOrder]);

  const getUnpinnedItems = useCallback(() => {
    return itemOrder
      .filter(id => !pinnedItems.includes(id))
      .map(id => ALL_SIDEBAR_ITEMS.find(item => item.id === id)!)
      .filter(Boolean);
  }, [pinnedItems, itemOrder]);

  const reorderItems = useCallback((newOrder: SidebarItemId[]) => {
    setItemOrder(newOrder);
  }, []);

  const movePinnedItem = useCallback((fromIndex: number, toIndex: number) => {
    const pinnedIds = itemOrder.filter(id => pinnedItems.includes(id));
    const [movedItem] = pinnedIds.splice(fromIndex, 1);
    pinnedIds.splice(toIndex, 0, movedItem);
    
    // Rebuild full order with unpinned items in original positions
    const unpinnedIds = itemOrder.filter(id => !pinnedItems.includes(id));
    const newOrder = [...pinnedIds, ...unpinnedIds];
    setItemOrder(newOrder);
  }, [itemOrder, pinnedItems]);

  const resetToDefaults = useCallback(() => {
    const defaults = ALL_SIDEBAR_ITEMS.filter(item => item.defaultPinned).map(item => item.id);
    setPinnedItems(defaults);
    setItemOrder(ALL_SIDEBAR_ITEMS.map(item => item.id));
  }, []);

  return {
    pinnedItems,
    itemOrder,
    togglePin,
    isPinned,
    getPinnedItems,
    getUnpinnedItems,
    reorderItems,
    movePinnedItem,
    resetToDefaults,
  };
}
