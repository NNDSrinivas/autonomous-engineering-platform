import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useMemory } from './useMemory';
import { toast } from 'sonner';
import type { SlackMessage, SourceLink } from '@/types';

export interface SlackChannelData {
  id: string;
  name: string;
  is_private: boolean;
  num_members: number;
  topic?: { value: string };
  purpose?: { value: string };
}

export interface SlackMessageData {
  ts: string;
  text: string;
  user: string;
  channel: string;
  channel_name?: string;
  thread_ts?: string;
  reply_count?: number;
  reactions?: Array<{ name: string; count: number }>;
}

export interface SlackUserData {
  id: string;
  name: string;
  real_name: string;
  profile: {
    display_name: string;
    email?: string;
    image_48?: string;
  };
}

export function useSlackIntegration() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [channels, setChannels] = useState<SlackChannelData[]>([]);
  const [messages, setMessages] = useState<SlackMessageData[]>([]);
  const [users, setUsers] = useState<Map<string, SlackUserData>>(new Map());
  
  const { storeMemory } = useMemory();

  const fetchSlackData = useCallback(async (action: string): Promise<any> => {
    setIsLoading(true);
    setError(null);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error('Please sign in to fetch Slack data');
        return null;
      }

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/integration-data`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ provider: 'slack', action }),
        }
      );

      const result = await response.json();

      if (!response.ok) {
        if (result.requiresAuth) {
          toast.error('Please connect Slack first');
        } else {
          toast.error(result.error || 'Failed to fetch Slack data');
        }
        setError(result.error);
        return null;
      }

      return result.data;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      setError(message);
      toast.error('Failed to fetch Slack data');
      return null;
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Fetch all channels
  const fetchChannels = useCallback(async (): Promise<SlackChannelData[]> => {
    const data = await fetchSlackData('channels');
    if (data) {
      setChannels(data);
      return data;
    }
    return [];
  }, [fetchSlackData]);

  // Fetch recent messages from all channels
  const fetchMessages = useCallback(async (): Promise<SlackMessageData[]> => {
    const data = await fetchSlackData('messages');
    if (data) {
      setMessages(data);
      return data;
    }
    return [];
  }, [fetchSlackData]);

  // Fetch team users for name resolution
  const fetchUsers = useCallback(async (): Promise<Map<string, SlackUserData>> => {
    const data = await fetchSlackData('users');
    if (data) {
      const userMap = new Map<string, SlackUserData>();
      data.forEach((user: SlackUserData) => userMap.set(user.id, user));
      setUsers(userMap);
      return userMap;
    }
    return new Map();
  }, [fetchSlackData]);

  // Sync messages to memory for RAG context
  const syncMessagesToMemory = useCallback(async (messagesToSync: SlackMessageData[]) => {
    let synced = 0;
    
    for (const msg of messagesToSync.slice(0, 50)) { // Limit to 50 messages
      try {
        const userName = users.get(msg.user)?.real_name || msg.user;
        
        await storeMemory({
          memory_type: 'slack_message',
          source: 'slack',
          title: `Message in #${msg.channel_name || msg.channel}`,
          content: `[${userName}]: ${msg.text}`,
          source_id: msg.ts,
          metadata: {
            channel: msg.channel,
            channel_name: msg.channel_name,
            user: msg.user,
            user_name: userName,
            timestamp: msg.ts,
            has_thread: !!msg.thread_ts,
            reply_count: msg.reply_count || 0,
          },
        });
        synced++;
      } catch (err) {
        console.error('Failed to sync Slack message to memory:', err);
      }
    }

    if (synced > 0) {
      toast.success(`Synced ${synced} Slack messages to memory`);
    }
    
    return synced;
  }, [storeMemory, users]);

  // Transform Slack messages to local format
  const transformToLocalMessages = useCallback((slackMessages: SlackMessageData[]): SlackMessage[] => {
    return slackMessages.map(msg => ({
      id: msg.ts,
      channel: msg.channel_name || msg.channel,
      author: users.get(msg.user)?.real_name || msg.user,
      content: msg.text,
      timestamp: new Date(parseFloat(msg.ts) * 1000),
      threadUrl: msg.thread_ts ? `#${msg.channel_name}/${msg.thread_ts}` : undefined,
      reactions: msg.reactions?.map(r => `${r.name}:${r.count}`) || [],
    }));
  }, [users]);

  // Create source links for task context
  const createSlackSourceLinks = useCallback((slackMessages: SlackMessageData[], workspaceUrl: string = ''): SourceLink[] => {
    return slackMessages.map(msg => ({
      type: 'slack' as const,
      title: `#${msg.channel_name || msg.channel}`,
      url: workspaceUrl ? `${workspaceUrl}/archives/${msg.channel}/p${msg.ts.replace('.', '')}` : '#',
      snippet: msg.text.substring(0, 150),
    }));
  }, []);

  // Full sync: channels, users, messages, and memory
  const syncAll = useCallback(async () => {
    setIsLoading(true);
    
    try {
      // Fetch users first for name resolution
      await fetchUsers();
      
      // Fetch channels and messages in parallel
      const [channelData, messageData] = await Promise.all([
        fetchChannels(),
        fetchMessages(),
      ]);

      // Sync messages to memory
      if (messageData.length > 0) {
        await syncMessagesToMemory(messageData);
      }

      toast.success(`Slack sync complete: ${channelData.length} channels, ${messageData.length} messages`);
      
      return { channels: channelData, messages: messageData };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Sync failed';
      setError(message);
      toast.error('Slack sync failed');
      return { channels: [], messages: [] };
    } finally {
      setIsLoading(false);
    }
  }, [fetchUsers, fetchChannels, fetchMessages, syncMessagesToMemory]);

  return {
    isLoading,
    error,
    channels,
    messages,
    users,
    fetchChannels,
    fetchMessages,
    fetchUsers,
    syncAll,
    syncMessagesToMemory,
    transformToLocalMessages,
    createSlackSourceLinks,
  };
}
