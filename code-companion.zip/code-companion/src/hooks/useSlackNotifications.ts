import { useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import type { WorkflowStep, Workflow } from '@/types/workflow';

export interface SlackNotificationPayload {
  channel?: string;
  message: string;
  blocks?: SlackBlock[];
  thread_ts?: string;
}

export interface SlackBlock {
  type: 'section' | 'header' | 'divider' | 'context' | 'actions';
  text?: { type: 'mrkdwn' | 'plain_text'; text: string };
  fields?: Array<{ type: 'mrkdwn' | 'plain_text'; text: string }>;
  accessory?: Record<string, unknown>;
  elements?: Array<Record<string, unknown>>;
}

export function useSlackNotifications() {
  const sendNotification = useCallback(async (payload: SlackNotificationPayload): Promise<boolean> => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        console.warn('No session for Slack notification');
        return false;
      }

      const response = await supabase.functions.invoke('slack-notify', {
        body: payload,
      });

      if (response.error) {
        console.error('Slack notification error:', response.error);
        return false;
      }

      return response.data?.success ?? false;
    } catch (err) {
      console.error('Failed to send Slack notification:', err);
      return false;
    }
  }, []);

  // Notify when a workflow step completes
  const notifyStepCompleted = useCallback(async (
    step: WorkflowStep,
    workflow: Workflow,
    channel?: string
  ) => {
    const emoji = step.status === 'completed' ? '✅' : step.status === 'failed' ? '❌' : '⏭️';
    const statusText = step.status === 'completed' ? 'completed' : step.status === 'failed' ? 'failed' : 'skipped';
    
    const blocks: SlackBlock[] = [
      {
        type: 'header',
        text: { type: 'plain_text', text: `${emoji} Workflow Step ${statusText.charAt(0).toUpperCase() + statusText.slice(1)}` }
      },
      {
        type: 'section',
        fields: [
          { type: 'mrkdwn', text: `*Workflow:*\n${workflow.name}` },
          { type: 'mrkdwn', text: `*Step:*\n${step.name}` },
          { type: 'mrkdwn', text: `*Status:*\n${statusText}` },
          { type: 'mrkdwn', text: `*Task:*\n${workflow.context.taskKey || 'N/A'}` },
        ]
      }
    ];

    if (step.result?.message) {
      blocks.push({
        type: 'context',
        elements: [{ type: 'mrkdwn', text: step.result.message }]
      });
    }

    return sendNotification({
      channel,
      message: `${emoji} Step "${step.name}" ${statusText} in workflow "${workflow.name}"`,
      blocks,
    });
  }, [sendNotification]);

  // Notify when approval is required
  const notifyApprovalRequired = useCallback(async (
    step: WorkflowStep,
    workflow: Workflow,
    channel?: string
  ) => {
    const blocks: SlackBlock[] = [
      {
        type: 'header',
        text: { type: 'plain_text', text: '🔔 Approval Required' }
      },
      {
        type: 'section',
        text: { 
          type: 'mrkdwn', 
          text: `The workflow *${workflow.name}* is waiting for approval on step *${step.name}*` 
        }
      },
      {
        type: 'section',
        fields: [
          { type: 'mrkdwn', text: `*Step:*\n${step.name}` },
          { type: 'mrkdwn', text: `*Description:*\n${step.description || 'No description'}` },
          { type: 'mrkdwn', text: `*Task:*\n${workflow.context.taskKey || 'N/A'}` },
          { type: 'mrkdwn', text: `*Repository:*\n${workflow.context.repository || 'N/A'}` },
        ]
      },
      { type: 'divider' },
      {
        type: 'context',
        elements: [{ type: 'mrkdwn', text: '👆 Please review and approve in NAVI to continue the workflow' }]
      }
    ];

    const success = await sendNotification({
      channel,
      message: `🔔 Approval required for step "${step.name}" in workflow "${workflow.name}"`,
      blocks,
    });

    if (success) {
      toast.info('Approval notification sent to Slack');
    }

    return success;
  }, [sendNotification]);

  // Notify when workflow completes
  const notifyWorkflowCompleted = useCallback(async (
    workflow: Workflow,
    channel?: string
  ) => {
    const completedSteps = workflow.steps.filter(s => s.status === 'completed').length;
    const failedSteps = workflow.steps.filter(s => s.status === 'failed').length;
    const skippedSteps = workflow.steps.filter(s => s.status === 'skipped').length;

    const emoji = failedSteps > 0 ? '⚠️' : '🎉';
    const status = failedSteps > 0 ? 'completed with errors' : 'completed successfully';

    const blocks: SlackBlock[] = [
      {
        type: 'header',
        text: { type: 'plain_text', text: `${emoji} Workflow ${status.charAt(0).toUpperCase() + status.slice(1)}` }
      },
      {
        type: 'section',
        fields: [
          { type: 'mrkdwn', text: `*Workflow:*\n${workflow.name}` },
          { type: 'mrkdwn', text: `*Task:*\n${workflow.context.taskKey || 'N/A'}` },
          { type: 'mrkdwn', text: `*Completed:*\n${completedSteps}/${workflow.steps.length}` },
          { type: 'mrkdwn', text: `*Failed:*\n${failedSteps}` },
        ]
      }
    ];

    if (workflow.context.repository) {
      blocks.push({
        type: 'context',
        elements: [{ type: 'mrkdwn', text: `📂 Repository: ${workflow.context.repository}` }]
      });
    }

    return sendNotification({
      channel,
      message: `${emoji} Workflow "${workflow.name}" ${status}. Completed: ${completedSteps}, Failed: ${failedSteps}, Skipped: ${skippedSteps}`,
      blocks,
    });
  }, [sendNotification]);

  // Notify workflow failure
  const notifyWorkflowFailed = useCallback(async (
    workflow: Workflow,
    error: string,
    channel?: string
  ) => {
    const blocks: SlackBlock[] = [
      {
        type: 'header',
        text: { type: 'plain_text', text: '❌ Workflow Failed' }
      },
      {
        type: 'section',
        text: { type: 'mrkdwn', text: `Workflow *${workflow.name}* has failed.` }
      },
      {
        type: 'section',
        fields: [
          { type: 'mrkdwn', text: `*Error:*\n${error}` },
          { type: 'mrkdwn', text: `*Task:*\n${workflow.context.taskKey || 'N/A'}` },
        ]
      }
    ];

    return sendNotification({
      channel,
      message: `❌ Workflow "${workflow.name}" failed: ${error}`,
      blocks,
    });
  }, [sendNotification]);

  return {
    sendNotification,
    notifyStepCompleted,
    notifyApprovalRequired,
    notifyWorkflowCompleted,
    notifyWorkflowFailed,
  };
}
