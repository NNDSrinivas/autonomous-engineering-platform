import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface SlackRealtimeMessage {
  id: string;
  ts: string;
  text: string;
  user: string;
  userName?: string;
  channel: string;
  channelName?: string;
  timestamp: Date;
  threadTs?: string;
  replyCount?: number;
  isNew?: boolean;
}

export interface ThreadSummary {
  threadTs: string;
  channel: string;
  channelName?: string;
  messageCount: number;
  participants: string[];
  lastMessage: string;
  lastActivity: Date;
  summary?: string;
}

interface UseSlackRealtimeOptions {
  pollInterval?: number; // in milliseconds
  enabled?: boolean;
  channels?: string[]; // specific channels to monitor
}

export function useSlackRealtime(options: UseSlackRealtimeOptions = {}) {
  const { pollInterval = 30000, enabled = true, channels } = options;
  
  const [isPolling, setIsPolling] = useState(false);
  const [messages, setMessages] = useState<SlackRealtimeMessage[]>([]);
  const [threads, setThreads] = useState<ThreadSummary[]>([]);
  const [lastPollTime, setLastPollTime] = useState<Date | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [unreadCount, setUnreadCount] = useState(0);
  
  const pollTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const lastMessageTsRef = useRef<string>('0');
  const userCacheRef = useRef<Map<string, string>>(new Map());

  // Fetch user name from cache or API
  const getUserName = useCallback(async (userId: string): Promise<string> => {
    if (userCacheRef.current.has(userId)) {
      return userCacheRef.current.get(userId)!;
    }
    // In production, this would fetch from Slack API
    // For now, return the userId as placeholder
    return userId;
  }, []);

  // Fetch latest messages from Slack
  const fetchLatestMessages = useCallback(async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return [];

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/integration-data`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ 
            provider: 'slack', 
            action: 'messages',
            params: {
              channels,
              oldest: lastMessageTsRef.current,
            }
          }),
        }
      );

      if (!response.ok) {
        throw new Error('Failed to fetch messages');
      }

      const result = await response.json();
      return result.data || [];
    } catch (err) {
      console.error('[Slack Realtime] Fetch error:', err);
      return [];
    }
  }, [channels]);

  // Process and deduplicate messages
  const processMessages = useCallback(async (rawMessages: any[]): Promise<SlackRealtimeMessage[]> => {
    const processed: SlackRealtimeMessage[] = [];
    
    for (const msg of rawMessages) {
      const userName = await getUserName(msg.user);
      
      processed.push({
        id: `${msg.channel}-${msg.ts}`,
        ts: msg.ts,
        text: msg.text,
        user: msg.user,
        userName,
        channel: msg.channel,
        channelName: msg.channel_name,
        timestamp: new Date(parseFloat(msg.ts) * 1000),
        threadTs: msg.thread_ts,
        replyCount: msg.reply_count || 0,
        isNew: parseFloat(msg.ts) > parseFloat(lastMessageTsRef.current),
      });
    }
    
    return processed.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }, [getUserName]);

  // Generate thread summaries
  const generateThreadSummaries = useCallback((messages: SlackRealtimeMessage[]): ThreadSummary[] => {
    const threadMap = new Map<string, SlackRealtimeMessage[]>();
    
    // Group messages by thread
    for (const msg of messages) {
      if (msg.threadTs) {
        const key = `${msg.channel}-${msg.threadTs}`;
        if (!threadMap.has(key)) {
          threadMap.set(key, []);
        }
        threadMap.get(key)!.push(msg);
      }
    }
    
    // Create summaries
    const summaries: ThreadSummary[] = [];
    
    threadMap.forEach((threadMessages, key) => {
      const [channel, threadTs] = key.split('-');
      const participants = [...new Set(threadMessages.map(m => m.userName || m.user))];
      const sortedMessages = threadMessages.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
      const lastMsg = sortedMessages[0];
      
      summaries.push({
        threadTs,
        channel,
        channelName: lastMsg.channelName,
        messageCount: threadMessages.length,
        participants,
        lastMessage: lastMsg.text.substring(0, 100),
        lastActivity: lastMsg.timestamp,
        summary: `${participants.length} people discussing: ${lastMsg.text.substring(0, 50)}...`,
      });
    });
    
    return summaries.sort((a, b) => b.lastActivity.getTime() - a.lastActivity.getTime());
  }, []);

  // Main polling function
  const poll = useCallback(async () => {
    if (!enabled) return;
    
    setIsPolling(true);
    setError(null);
    
    try {
      const rawMessages = await fetchLatestMessages();
      
      if (rawMessages.length > 0) {
        const processed = await processMessages(rawMessages);
        
        // Count new messages
        const newMessages = processed.filter(m => m.isNew);
        if (newMessages.length > 0) {
          setUnreadCount(prev => prev + newMessages.length);
          
          // Show notification for new messages
          if (lastMessageTsRef.current !== '0') {
            toast.info(`${newMessages.length} new Slack message${newMessages.length > 1 ? 's' : ''}`);
          }
        }
        
        // Update last message timestamp
        const latestTs = Math.max(...processed.map(m => parseFloat(m.ts)));
        lastMessageTsRef.current = latestTs.toString();
        
        // Merge with existing messages (deduplication)
        setMessages(prev => {
          const existingIds = new Set(prev.map(m => m.id));
          const newMsgs = processed.filter(m => !existingIds.has(m.id));
          const merged = [...newMsgs, ...prev].slice(0, 100); // Keep last 100 messages
          return merged;
        });
        
        // Generate thread summaries
        const summaries = generateThreadSummaries(processed);
        setThreads(summaries);
      }
      
      setLastPollTime(new Date());
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Polling failed';
      setError(message);
      console.error('[Slack Realtime] Poll error:', err);
    } finally {
      setIsPolling(false);
    }
  }, [enabled, fetchLatestMessages, processMessages, generateThreadSummaries]);

  // Start/stop polling
  useEffect(() => {
    if (!enabled) {
      if (pollTimeoutRef.current) {
        clearInterval(pollTimeoutRef.current);
        pollTimeoutRef.current = null;
      }
      return;
    }
    
    // Initial poll
    poll();
    
    // Set up interval
    pollTimeoutRef.current = setInterval(poll, pollInterval);
    
    return () => {
      if (pollTimeoutRef.current) {
        clearInterval(pollTimeoutRef.current);
        pollTimeoutRef.current = null;
      }
    };
  }, [enabled, pollInterval, poll]);

  // Mark messages as read
  const markAsRead = useCallback(() => {
    setUnreadCount(0);
    setMessages(prev => prev.map(m => ({ ...m, isNew: false })));
  }, []);

  // Force refresh
  const refresh = useCallback(async () => {
    await poll();
  }, [poll]);

  return {
    isPolling,
    messages,
    threads,
    lastPollTime,
    error,
    unreadCount,
    markAsRead,
    refresh,
  };
}
