import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast as sonnerToast } from 'sonner';

interface ToastPreferences {
  in_app_toasts: boolean;
  toast_important_only: boolean;
}

const defaultPrefs: ToastPreferences = {
  in_app_toasts: true,
  toast_important_only: false,
};

let cachedPrefs: ToastPreferences = defaultPrefs;
let prefsLoaded = false;

// Load preferences once at startup
const loadPreferences = async () => {
  if (prefsLoaded) return;
  
  try {
    const { data: { session } } = await supabase.auth.getSession();
    if (session) {
      const { data } = await supabase
        .from('profiles')
        .select('notification_preferences')
        .eq('user_id', session.user.id)
        .single();
      
      if (data?.notification_preferences) {
        const prefs = data.notification_preferences as Record<string, boolean>;
        cachedPrefs = {
          in_app_toasts: prefs.in_app_toasts ?? true,
          toast_important_only: prefs.toast_important_only ?? false,
        };
      }
    }
  } catch (error) {
    console.error('Error loading toast preferences:', error);
  }
  prefsLoaded = true;
};

// Initialize preferences
loadPreferences();

// Listen for auth changes to reload preferences
supabase.auth.onAuthStateChange(() => {
  prefsLoaded = false;
  loadPreferences();
});

export type ToastType = 'success' | 'error' | 'info' | 'warning';

// Smart toast that respects user preferences
export const smartToast = {
  success: (message: string) => {
    if (!cachedPrefs.in_app_toasts) return;
    if (cachedPrefs.toast_important_only) return; // Skip success toasts in important-only mode
    sonnerToast.success(message);
  },
  error: (message: string) => {
    if (!cachedPrefs.in_app_toasts) return;
    // Always show errors regardless of important-only setting
    sonnerToast.error(message);
  },
  info: (message: string) => {
    if (!cachedPrefs.in_app_toasts) return;
    if (cachedPrefs.toast_important_only) return; // Skip info toasts in important-only mode
    sonnerToast.info(message);
  },
  warning: (message: string) => {
    if (!cachedPrefs.in_app_toasts) return;
    // Always show warnings regardless of important-only setting
    sonnerToast.warning(message);
  },
  // Force show regardless of preferences (for critical actions)
  force: {
    success: (message: string) => sonnerToast.success(message),
    error: (message: string) => sonnerToast.error(message),
    info: (message: string) => sonnerToast.info(message),
    warning: (message: string) => sonnerToast.warning(message),
  },
};

export function useToastPreferences() {
  const [preferences, setPreferences] = useState<ToastPreferences>(cachedPrefs);

  useEffect(() => {
    const load = async () => {
      await loadPreferences();
      setPreferences(cachedPrefs);
    };
    load();
  }, []);

  const updatePreferences = useCallback((newPrefs: Partial<ToastPreferences>) => {
    cachedPrefs = { ...cachedPrefs, ...newPrefs };
    setPreferences(cachedPrefs);
  }, []);

  // Refresh preferences from database
  const refresh = useCallback(async () => {
    prefsLoaded = false;
    await loadPreferences();
    setPreferences(cachedPrefs);
  }, []);

  return {
    preferences,
    updatePreferences,
    refresh,
    toast: smartToast,
  };
}

export default smartToast;
