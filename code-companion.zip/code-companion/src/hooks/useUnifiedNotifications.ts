import { useState, useCallback, useEffect, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { useNotificationSound, useNotificationSoundPreference, SoundType } from './useNotificationSound';

export type NotificationSource = 
  | 'cicd' 
  | 'slack' 
  | 'teams' 
  | 'jira' 
  | 'confluence' 
  | 'github' 
  | 'zoom'
  | 'calendar'
  | 'system';

export type NotificationPriority = 'low' | 'normal' | 'high' | 'urgent';

export interface UnifiedNotification {
  id: string;
  source: NotificationSource;
  type: 'info' | 'warning' | 'error' | 'success';
  title: string;
  description: string;
  timestamp: Date;
  read: boolean;
  priority: NotificationPriority;
  metadata?: {
    url?: string;
    entityId?: string;
    entityType?: string;
    [key: string]: any;
  };
  actions?: Array<{
    label: string;
    action: string;
    primary?: boolean;
  }>;
}

interface NotificationFilters {
  sources: NotificationSource[];
  types: UnifiedNotification['type'][];
  priorities: NotificationPriority[];
  showRead: boolean;
}

const DEFAULT_FILTERS: NotificationFilters = {
  sources: [],
  types: [],
  priorities: [],
  showRead: true,
};

export function useUnifiedNotifications() {
  const [notifications, setNotifications] = useState<UnifiedNotification[]>([]);
  const [filters, setFilters] = useState<NotificationFilters>(DEFAULT_FILTERS);
  const [isLoading, setIsLoading] = useState(false);
  const [lastFetchTime, setLastFetchTime] = useState<Date | null>(null);
  const pollingInterval = useRef<NodeJS.Timeout | null>(null);
  const [notificationCount, setNotificationCount] = useState(0);
  
  const { soundEnabled, soundType, volume } = useNotificationSoundPreference();
  const { playPreview } = useNotificationSound(notificationCount, soundEnabled, soundType, volume);

  // Helper to play notification sound
  const playNotificationSound = useCallback((type: 'notification' | 'error' = 'notification') => {
    const soundToPlay: SoundType = type === 'error' ? 'bell' : soundType;
    playPreview(soundToPlay, volume);
  }, [playPreview, soundType, volume]);

  // Add a notification
  const addNotification = useCallback((
    notification: Omit<UnifiedNotification, 'id' | 'timestamp' | 'read'>
  ) => {
    const newNotification: UnifiedNotification = {
      ...notification,
      id: `${notification.source}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date(),
      read: false,
    };

    setNotifications(prev => [newNotification, ...prev]);
    setNotificationCount(prev => prev + 1);

    // Play sound for high priority notifications
    if (notification.priority === 'high' || notification.priority === 'urgent') {
      playNotificationSound(notification.type === 'error' ? 'error' : 'notification');
    }

    // Show toast for urgent notifications
    if (notification.priority === 'urgent') {
      toast[notification.type](notification.title, {
        description: notification.description,
      });
    }

    return newNotification;
  }, [playNotificationSound]);

  // Fetch notifications from all sources
  const fetchNotifications = useCallback(async () => {
    setIsLoading(true);
    
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      // Fetch from integration-data endpoint for each source
      const sources: NotificationSource[] = ['slack', 'teams', 'jira', 'github'];
      const fetchPromises = sources.map(async (source) => {
        try {
          const response = await fetch(
            `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/integration-data`,
            {
              method: 'POST',
              headers: {
                Authorization: `Bearer ${session.access_token}`,
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({ 
                provider: source, 
                action: 'notifications',
                since: lastFetchTime?.toISOString(),
              }),
            }
          );

          if (!response.ok) return [];
          
          const result = await response.json();
          return (result.data || []).map((item: any) => ({
            ...item,
            source,
            timestamp: new Date(item.timestamp || Date.now()),
            read: false,
          }));
        } catch {
          return [];
        }
      });

      const results = await Promise.all(fetchPromises);
      const allNotifications = results.flat();

      // Merge with existing, avoiding duplicates
      setNotifications(prev => {
        const existingIds = new Set(prev.map(n => n.id));
        const newOnes = allNotifications.filter((n: UnifiedNotification) => !existingIds.has(n.id));
        
        // Play sound if there are new high priority notifications
        const highPriorityNew = newOnes.filter((n: UnifiedNotification) => 
          n.priority === 'high' || n.priority === 'urgent'
        );
        if (highPriorityNew.length > 0) {
          playNotificationSound('notification');
          setNotificationCount(prev => prev + highPriorityNew.length);
        }

        return [...newOnes, ...prev].slice(0, 200); // Keep last 200 notifications
      });

      setLastFetchTime(new Date());
    } catch (err) {
      console.error('Failed to fetch notifications:', err);
    } finally {
      setIsLoading(false);
    }
  }, [lastFetchTime, playNotificationSound]);

  // Add CI/CD notification
  const addCICDNotification = useCallback((
    status: 'success' | 'failure' | 'pending',
    workflowName: string,
    runId: string,
    url?: string
  ) => {
    addNotification({
      source: 'cicd',
      type: status === 'success' ? 'success' : status === 'failure' ? 'error' : 'info',
      title: `Build ${status === 'success' ? 'Succeeded' : status === 'failure' ? 'Failed' : 'Started'}`,
      description: `${workflowName} - Run #${runId}`,
      priority: status === 'failure' ? 'high' : 'normal',
      metadata: { url, entityId: runId, entityType: 'workflow_run' },
      actions: url ? [{ label: 'View Run', action: url, primary: true }] : undefined,
    });
  }, [addNotification]);

  // Add Slack notification
  const addSlackNotification = useCallback((
    type: 'mention' | 'dm' | 'channel',
    channel: string,
    sender: string,
    message: string,
    url?: string
  ) => {
    addNotification({
      source: 'slack',
      type: 'info',
      title: type === 'mention' ? `Mentioned by ${sender}` : type === 'dm' ? `DM from ${sender}` : `New message in #${channel}`,
      description: message.substring(0, 100),
      priority: type === 'mention' || type === 'dm' ? 'high' : 'normal',
      metadata: { url, channel, sender, entityType: type },
      actions: url ? [{ label: 'Open in Slack', action: url }] : undefined,
    });
  }, [addNotification]);

  // Add Jira notification
  const addJiraNotification = useCallback((
    type: 'assigned' | 'commented' | 'updated' | 'mentioned',
    issueKey: string,
    issueTitle: string,
    detail: string,
    url?: string
  ) => {
    const titles: Record<string, string> = {
      assigned: `Assigned: ${issueKey}`,
      commented: `Comment on ${issueKey}`,
      updated: `Updated: ${issueKey}`,
      mentioned: `Mentioned in ${issueKey}`,
    };

    addNotification({
      source: 'jira',
      type: 'info',
      title: titles[type] || `Jira: ${issueKey}`,
      description: `${issueTitle} - ${detail}`,
      priority: type === 'assigned' || type === 'mentioned' ? 'high' : 'normal',
      metadata: { url, entityId: issueKey, entityType: 'issue' },
      actions: url ? [{ label: 'Open Issue', action: url, primary: true }] : undefined,
    });
  }, [addNotification]);

  // Add GitHub notification
  const addGitHubNotification = useCallback((
    type: 'pr' | 'issue' | 'review' | 'ci',
    title: string,
    description: string,
    url?: string
  ) => {
    addNotification({
      source: 'github',
      type: type === 'ci' ? 'warning' : 'info',
      title,
      description,
      priority: type === 'review' ? 'high' : 'normal',
      metadata: { url, entityType: type },
      actions: url ? [{ label: 'View on GitHub', action: url }] : undefined,
    });
  }, [addNotification]);

  // Mark notification as read
  const markAsRead = useCallback((id: string) => {
    setNotifications(prev => prev.map(n => 
      n.id === id ? { ...n, read: true } : n
    ));
  }, []);

  // Mark all as read
  const markAllAsRead = useCallback(() => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  }, []);

  // Mark all from source as read
  const markSourceAsRead = useCallback((source: NotificationSource) => {
    setNotifications(prev => prev.map(n => 
      n.source === source ? { ...n, read: true } : n
    ));
  }, []);

  // Clear all notifications
  const clearAll = useCallback(() => {
    setNotifications([]);
  }, []);

  // Clear notifications from source
  const clearSource = useCallback((source: NotificationSource) => {
    setNotifications(prev => prev.filter(n => n.source !== source));
  }, []);

  // Get filtered notifications
  const getFilteredNotifications = useCallback(() => {
    return notifications.filter(n => {
      if (filters.sources.length > 0 && !filters.sources.includes(n.source)) return false;
      if (filters.types.length > 0 && !filters.types.includes(n.type)) return false;
      if (filters.priorities.length > 0 && !filters.priorities.includes(n.priority)) return false;
      if (!filters.showRead && n.read) return false;
      return true;
    });
  }, [notifications, filters]);

  // Get unread count
  const unreadCount = notifications.filter(n => !n.read).length;

  // Get unread count by source
  const getUnreadCountBySource = useCallback((source: NotificationSource) => {
    return notifications.filter(n => n.source === source && !n.read).length;
  }, [notifications]);

  // Get count by priority
  const getCountByPriority = useCallback((priority: NotificationPriority) => {
    return notifications.filter(n => n.priority === priority && !n.read).length;
  }, [notifications]);

  // Start polling for notifications
  const startPolling = useCallback((intervalMs: number = 60000) => {
    if (pollingInterval.current) {
      clearInterval(pollingInterval.current);
    }
    pollingInterval.current = setInterval(fetchNotifications, intervalMs);
    fetchNotifications(); // Initial fetch
  }, [fetchNotifications]);

  // Stop polling
  const stopPolling = useCallback(() => {
    if (pollingInterval.current) {
      clearInterval(pollingInterval.current);
      pollingInterval.current = null;
    }
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (pollingInterval.current) {
        clearInterval(pollingInterval.current);
      }
    };
  }, []);

  return {
    notifications: getFilteredNotifications(),
    allNotifications: notifications,
    unreadCount,
    isLoading,
    filters,
    setFilters,
    addNotification,
    addCICDNotification,
    addSlackNotification,
    addJiraNotification,
    addGitHubNotification,
    markAsRead,
    markAllAsRead,
    markSourceAsRead,
    clearAll,
    clearSource,
    fetchNotifications,
    startPolling,
    stopPolling,
    getUnreadCountBySource,
    getCountByPriority,
  };
}
