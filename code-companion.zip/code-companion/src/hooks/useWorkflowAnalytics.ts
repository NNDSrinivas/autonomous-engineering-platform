import { useState, useEffect, useCallback, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface PhaseStats {
  phase: string;
  successCount: number;
  failureCount: number;
  averageTimeMs: number;
}

interface FailurePoint {
  phase: string;
  errorMessage: string;
  count: number;
  lastOccurred: Date;
}

interface DailyStats {
  date: string;
  completed: number;
  failed: number;
  cancelled: number;
  totalDurationMs: number;
}

interface WorkflowAnalytics {
  totalWorkflows: number;
  completedWorkflows: number;
  failedWorkflows: number;
  cancelledWorkflows: number;
  inProgressWorkflows: number;
  successRate: number;
  averageDurationMs: number;
  phaseStats: PhaseStats[];
  failurePoints: FailurePoint[];
  dailyStats: DailyStats[];
  templateUsage: { templateName: string; count: number }[];
  averagePhaseCount: number;
}

export function useWorkflowAnalytics() {
  const [analytics, setAnalytics] = useState<WorkflowAnalytics | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchAnalytics = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        setIsLoading(false);
        return;
      }

      // Fetch all workflow history for this user
      const { data: workflows, error: fetchError } = await supabase
        .from('workflow_history')
        .select('*')
        .order('started_at', { ascending: false });

      if (fetchError) throw fetchError;

      if (!workflows || workflows.length === 0) {
        setAnalytics({
          totalWorkflows: 0,
          completedWorkflows: 0,
          failedWorkflows: 0,
          cancelledWorkflows: 0,
          inProgressWorkflows: 0,
          successRate: 0,
          averageDurationMs: 0,
          phaseStats: [],
          failurePoints: [],
          dailyStats: [],
          templateUsage: [],
          averagePhaseCount: 0,
        });
        setIsLoading(false);
        return;
      }

      // Calculate basic stats
      const completed = workflows.filter(w => w.status === 'completed');
      const failed = workflows.filter(w => w.status === 'failed');
      const cancelled = workflows.filter(w => w.status === 'cancelled');
      const inProgress = workflows.filter(w => w.status === 'in_progress');

      const durations = workflows
        .filter(w => w.duration_ms !== null)
        .map(w => w.duration_ms!);
      const averageDurationMs = durations.length > 0
        ? Math.round(durations.reduce((a, b) => a + b, 0) / durations.length)
        : 0;

      const finishedWorkflows = completed.length + failed.length;
      const successRate = finishedWorkflows > 0
        ? Math.round((completed.length / finishedWorkflows) * 100)
        : 0;

      // Calculate phase statistics
      const phaseMap = new Map<string, { success: number; failure: number; times: number[] }>();
      workflows.forEach(w => {
        const phasesCompleted = w.phases_completed || [];
        const phasesSkipped = w.phases_skipped || [];
        
        phasesCompleted.forEach((phase: string) => {
          const current = phaseMap.get(phase) || { success: 0, failure: 0, times: [] };
          current.success++;
          phaseMap.set(phase, current);
        });

        // Track failures at phase level
        if (w.status === 'failed' && w.error_message) {
          const lastPhase = phasesCompleted[phasesCompleted.length - 1];
          if (lastPhase) {
            const current = phaseMap.get(lastPhase) || { success: 0, failure: 0, times: [] };
            current.failure++;
            phaseMap.set(lastPhase, current);
          }
        }
      });

      const phaseStats: PhaseStats[] = Array.from(phaseMap.entries()).map(([phase, stats]) => ({
        phase,
        successCount: stats.success,
        failureCount: stats.failure,
        averageTimeMs: stats.times.length > 0
          ? Math.round(stats.times.reduce((a, b) => a + b, 0) / stats.times.length)
          : 0,
      }));

      // Calculate failure points
      const failureMap = new Map<string, { count: number; lastOccurred: Date; errorMessage: string }>();
      failed.forEach(w => {
        const phasesCompleted = w.phases_completed || [];
        const failedPhase = phasesCompleted.length > 0 
          ? phasesCompleted[phasesCompleted.length - 1]
          : 'initialization';
        const key = `${failedPhase}:${w.error_message?.slice(0, 50) || 'Unknown error'}`;
        const current = failureMap.get(key);
        
        if (current) {
          current.count++;
          if (new Date(w.started_at) > current.lastOccurred) {
            current.lastOccurred = new Date(w.started_at);
          }
        } else {
          failureMap.set(key, {
            count: 1,
            lastOccurred: new Date(w.started_at),
            errorMessage: w.error_message || 'Unknown error',
          });
        }
      });

      const failurePoints: FailurePoint[] = Array.from(failureMap.entries())
        .map(([key, data]) => ({
          phase: key.split(':')[0],
          errorMessage: data.errorMessage,
          count: data.count,
          lastOccurred: data.lastOccurred,
        }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 10);

      // Calculate daily stats for last 30 days
      const dailyMap = new Map<string, DailyStats>();
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

      workflows
        .filter(w => new Date(w.started_at) >= thirtyDaysAgo)
        .forEach(w => {
          const date = new Date(w.started_at).toISOString().split('T')[0];
          const current = dailyMap.get(date) || {
            date,
            completed: 0,
            failed: 0,
            cancelled: 0,
            totalDurationMs: 0,
          };

          if (w.status === 'completed') current.completed++;
          else if (w.status === 'failed') current.failed++;
          else if (w.status === 'cancelled') current.cancelled++;

          if (w.duration_ms) current.totalDurationMs += w.duration_ms;
          dailyMap.set(date, current);
        });

      const dailyStats = Array.from(dailyMap.values()).sort((a, b) => 
        a.date.localeCompare(b.date)
      );

      // Calculate template usage
      const templateMap = new Map<string, number>();
      workflows.forEach(w => {
        const name = w.template_name || 'Custom Workflow';
        templateMap.set(name, (templateMap.get(name) || 0) + 1);
      });

      const templateUsage = Array.from(templateMap.entries())
        .map(([templateName, count]) => ({ templateName, count }))
        .sort((a, b) => b.count - a.count);

      // Calculate average phases completed
      const totalPhases = workflows.reduce((sum, w) => 
        sum + (w.phases_completed?.length || 0), 0
      );
      const averagePhaseCount = workflows.length > 0
        ? Math.round((totalPhases / workflows.length) * 10) / 10
        : 0;

      setAnalytics({
        totalWorkflows: workflows.length,
        completedWorkflows: completed.length,
        failedWorkflows: failed.length,
        cancelledWorkflows: cancelled.length,
        inProgressWorkflows: inProgress.length,
        successRate,
        averageDurationMs,
        phaseStats,
        failurePoints,
        dailyStats,
        templateUsage,
        averagePhaseCount,
      });
    } catch (err) {
      console.error('Failed to fetch workflow analytics:', err);
      setError('Failed to load analytics data');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAnalytics();
  }, [fetchAnalytics]);

  const formattedDuration = useMemo(() => {
    if (!analytics?.averageDurationMs) return '0s';
    const ms = analytics.averageDurationMs;
    if (ms < 60000) return `${Math.round(ms / 1000)}s`;
    if (ms < 3600000) return `${Math.round(ms / 60000)}m`;
    return `${(ms / 3600000).toFixed(1)}h`;
  }, [analytics]);

  return {
    analytics,
    isLoading,
    error,
    refresh: fetchAnalytics,
    formattedDuration,
  };
}
