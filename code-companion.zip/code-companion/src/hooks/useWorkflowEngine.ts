import { useState, useCallback, useRef } from 'react';
import { 
  Workflow, 
  WorkflowStep, 
  WorkflowStepStatus,
  WorkflowTemplate,
  WORKFLOW_TEMPLATES 
} from '@/types/workflow';
import { toast } from 'sonner';
import { useGitHubIntegration } from './useGitHubIntegration';
import { useJiraActions } from './useJiraActions';
import { useSlackNotifications } from './useSlackNotifications';
import type { JiraTask } from '@/types';

interface UseWorkflowEngineProps {
  onStepApprovalRequired?: (step: WorkflowStep, workflow: Workflow) => void;
  onStepCompleted?: (step: WorkflowStep, workflow: Workflow) => void;
  onWorkflowCompleted?: (workflow: Workflow) => void;
  onWorkflowFailed?: (workflow: Workflow, error: string) => void;
  // GitHub repo context
  repoOwner?: string;
  repoName?: string;
  // Jira task context
  linkedTask?: JiraTask;
  // Slack notification settings
  slackNotificationsEnabled?: boolean;
  slackChannel?: string;
}

export function useWorkflowEngine(props: UseWorkflowEngineProps = {}) {
  const { 
    onStepApprovalRequired, 
    onStepCompleted, 
    onWorkflowCompleted, 
    onWorkflowFailed,
    repoOwner,
    repoName,
    linkedTask,
    slackNotificationsEnabled = true,
    slackChannel,
  } = props;

  const [workflow, setWorkflow] = useState<Workflow | null>(null);
  const [isExecuting, setIsExecuting] = useState(false);
  const [pendingApprovalStep, setPendingApprovalStep] = useState<WorkflowStep | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  // Real GitHub integration
  const github = useGitHubIntegration();
  
  // Real Jira actions
  const jira = useJiraActions();

  // Slack notifications
  const slack = useSlackNotifications();

  // Create a new workflow from a template
  const createWorkflow = useCallback((
    template: WorkflowTemplate,
    context: Workflow['context'],
    customName?: string
  ): Workflow => {
    const newWorkflow: Workflow = {
      id: `wf_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      name: customName || template.name,
      description: template.description,
      status: 'idle',
      steps: template.steps.map((step, index) => ({
        ...step,
        id: `step_${index}_${Math.random().toString(36).substr(2, 9)}`,
        status: 'pending' as WorkflowStepStatus,
      })),
      currentStepIndex: 0,
      context,
      createdAt: new Date(),
    };
    
    setWorkflow(newWorkflow);
    return newWorkflow;
  }, []);

  // Execute a single step with real GitHub API calls
  const executeStep = useCallback(async (
    step: WorkflowStep, 
    context: Workflow['context']
  ): Promise<WorkflowStep['result']> => {
    const owner = repoOwner || context.repository?.split('/')[0];
    const repo = repoName || context.repository?.split('/')[1];
    const branchName = context.branch || `feature/${context.taskKey || 'new-feature'}`;
    const baseBranch = context.baseBranch || 'main';

    // Update Jira when step starts
    if (linkedTask) {
      await jira.updateIssueForWorkflowStep(linkedTask, step.name, 'started');
    }

    try {
      switch (step.actionType) {
        case 'create_branch': {
          if (!owner || !repo) {
            return { success: false, message: 'Repository not configured', error: 'Missing owner/repo' };
          }
          
          try {
            const branch = await github.createBranch(owner, repo, branchName, baseBranch);
            return {
              success: true,
              message: `Branch created: ${branchName}`,
              data: { branch: branchName, sha: branch?.object?.sha },
            };
          } catch (err) {
            const message = err instanceof Error ? err.message : 'Failed to create branch';
            // Check if branch already exists
            if (message.includes('Reference already exists')) {
              return {
                success: true,
                message: `Branch already exists: ${branchName}`,
                data: { branch: branchName, existed: true },
              };
            }
            throw err;
          }
        }

        case 'create_pr': {
          if (!owner || !repo) {
            return { success: false, message: 'Repository not configured', error: 'Missing owner/repo' };
          }
          
          const title = context.prTitle || `[${context.taskKey || 'TASK'}] ${step.name}`;
          const body = context.prBody || `Automated PR created by NAVI workflow.\n\nTask: ${context.taskKey || 'N/A'}`;
          
          const pr = await github.createPullRequest(owner, repo, title, body, branchName, baseBranch);
          return {
            success: true,
            message: `Pull request #${pr.number} created`,
            data: { prNumber: pr.number, url: pr.html_url },
          };
        }

        case 'run_tests':
        case 'run_build': {
          // For tests/builds, we check the latest workflow run status
          if (!owner || !repo) {
            // Simulate if no repo configured
            await new Promise(resolve => setTimeout(resolve, 2000));
            return {
              success: true,
              message: step.actionType === 'run_tests' ? 'All tests passed' : 'Build completed',
              data: { simulated: true },
            };
          }

          // Wait for CI to complete by polling workflow runs
          let attempts = 0;
          const maxAttempts = 30; // 5 minutes max wait
          
          while (attempts < maxAttempts) {
            await new Promise(resolve => setTimeout(resolve, 10000)); // 10 second intervals
            const runs = await github.fetchWorkflowRuns(owner, repo);
            
            const latestRun = runs?.[0];
            if (latestRun) {
              if (latestRun.status === 'completed') {
                if (latestRun.conclusion === 'success') {
                  return {
                    success: true,
                    message: `${step.name} passed`,
                    data: { runId: latestRun.id, url: latestRun.html_url },
                  };
                } else {
                  return {
                    success: false,
                    message: `${step.name} failed`,
                    error: `Workflow conclusion: ${latestRun.conclusion}`,
                    data: { runId: latestRun.id, url: latestRun.html_url },
                  };
                }
              }
            }
            attempts++;
          }
          
          return {
            success: false,
            message: 'Timed out waiting for CI',
            error: 'CI did not complete in time',
          };
        }

        case 'code_review': {
          // Code review is manual - just mark as needing approval
          return {
            success: true,
            message: 'Code review step - awaiting manual review',
            data: { requiresManualReview: true },
          };
        }

        case 'merge_pr': {
          if (!owner || !repo) {
            return { success: false, message: 'Repository not configured', error: 'Missing owner/repo' };
          }
          
          // Get the PR number from previous step data or context
          const prNumber = context.prNumber;
          if (!prNumber) {
            return { success: false, message: 'No PR number found', error: 'Missing PR number in context' };
          }
          
          const mergeResult = await github.mergePullRequest(owner, repo, prNumber, {
            mergeMethod: 'squash',
            commitTitle: `Merge PR #${prNumber}: ${context.taskKey || 'Task'}`,
          });
          
          return {
            success: true,
            message: `PR #${prNumber} merged`,
            data: { sha: mergeResult.sha, merged: true },
          };
        }

        case 'deploy': {
          const environment = (step.params as { environment?: string })?.environment || 'staging';
          
          // In a real implementation, this would trigger a deployment workflow
          // For now, we simulate it
          await new Promise(resolve => setTimeout(resolve, 3000));
          
          return {
            success: true,
            message: `Deployed to ${environment}`,
            data: { environment, deploymentId: `deploy_${Date.now()}` },
          };
        }

        case 'notify': {
          // Notification step - always succeeds
          const channel = (step.params as { channel?: string })?.channel || 'team';
          return {
            success: true,
            message: `Notification sent to ${channel}`,
            data: { notified: true },
          };
        }

        case 'update_docs': {
          // Documentation update - simulate
          await new Promise(resolve => setTimeout(resolve, 1000));
          return {
            success: true,
            message: 'Documentation updated',
            data: { updated: true },
          };
        }

        case 'rollback': {
          // Rollback step
          await new Promise(resolve => setTimeout(resolve, 2000));
          return {
            success: true,
            message: 'Rollback completed',
            data: { rolledBack: true },
          };
        }

        default:
          // For unknown actions, simulate execution
          await new Promise(resolve => setTimeout(resolve, 1000));
          return {
            success: true,
            message: `${step.name} completed`,
          };
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      
      // Update Jira on failure
      if (linkedTask) {
        await jira.updateIssueForWorkflowStep(linkedTask, step.name, 'failed');
      }
      
      return {
        success: false,
        message: `Failed: ${step.name}`,
        error: errorMessage,
      };
    }
  }, [github, jira, repoOwner, repoName, linkedTask]);

  // Update a specific step in the workflow
  const updateStep = useCallback((stepId: string, updates: Partial<WorkflowStep>) => {
    setWorkflow(prev => {
      if (!prev) return null;
      return {
        ...prev,
        steps: prev.steps.map(s => 
          s.id === stepId ? { ...s, ...updates } : s
        ),
      };
    });
  }, []);

  // Start the workflow execution
  const startWorkflow = useCallback(async () => {
    if (!workflow) {
      toast.error('No workflow to execute');
      return;
    }

    abortControllerRef.current = new AbortController();
    setIsExecuting(true);
    
    setWorkflow(prev => prev ? {
      ...prev,
      status: 'running',
      startedAt: new Date(),
    } : null);

    toast.success(`Starting workflow: ${workflow.name}`);
    await runNextStep();
  }, [workflow]);

  // Run the next pending step
  const runNextStep = useCallback(async () => {
    setWorkflow(prev => {
      if (!prev || prev.status !== 'running') return prev;
      
      const nextStepIndex = prev.steps.findIndex(s => s.status === 'pending');
      if (nextStepIndex === -1) {
        // All steps completed
        if (linkedTask) {
          jira.addComment(linkedTask.key, '✅ Workflow completed successfully');
        }
        // Send Slack notification for workflow completion
        if (slackNotificationsEnabled) {
          slack.notifyWorkflowCompleted(prev, slackChannel);
        }
        onWorkflowCompleted?.(prev);
        return {
          ...prev,
          status: 'completed',
          completedAt: new Date(),
        };
      }

      const nextStep = prev.steps[nextStepIndex];
      
      // Check if step requires approval
      if (nextStep.requiresApproval) {
        setPendingApprovalStep(nextStep);
        // Send Slack notification for approval required
        if (slackNotificationsEnabled) {
          slack.notifyApprovalRequired(nextStep, prev, slackChannel);
        }
        onStepApprovalRequired?.(nextStep, prev);
        return {
          ...prev,
          currentStepIndex: nextStepIndex,
          steps: prev.steps.map((s, i) => 
            i === nextStepIndex ? { ...s, status: 'awaiting_approval' } : s
          ),
        };
      }

      // Auto-execute step
      return {
        ...prev,
        currentStepIndex: nextStepIndex,
        steps: prev.steps.map((s, i) => 
          i === nextStepIndex ? { ...s, status: 'executing', startedAt: new Date() } : s
        ),
      };
    });
  }, [onStepApprovalRequired, onWorkflowCompleted, linkedTask, jira, slack, slackNotificationsEnabled, slackChannel]);

  // Approve a pending step
  const approveStep = useCallback(async (stepId: string) => {
    if (!workflow) return;

    const step = workflow.steps.find(s => s.id === stepId);
    if (!step) return;

    setPendingApprovalStep(null);
    
    // Mark as approved and start executing
    updateStep(stepId, { 
      status: 'executing', 
      startedAt: new Date() 
    });

    try {
      const result = await executeStep(step, workflow.context);
      
      const updatedStep = {
        ...step,
        status: result.success ? 'completed' as const : 'failed' as const,
        result,
        completedAt: new Date(),
      };
      
      updateStep(stepId, {
        status: result.success ? 'completed' : 'failed',
        result,
        completedAt: new Date(),
      });

      // Update Jira on completion
      if (result.success && linkedTask) {
        await jira.updateIssueForWorkflowStep(linkedTask, step.name, 'completed');
      }

      // Send Slack notification for step completion
      if (slackNotificationsEnabled) {
        slack.notifyStepCompleted(updatedStep, workflow, slackChannel);
      }

      if (result.success) {
        onStepCompleted?.(step, workflow);
        toast.success(`✓ ${step.name} completed`);
        
        // Update workflow context with step results (e.g., PR number)
        if (result.data?.prNumber) {
          setWorkflow(prev => prev ? {
            ...prev,
            context: { ...prev.context, prNumber: result.data?.prNumber as number },
          } : null);
        }
        
        // Continue to next step
        setTimeout(() => runNextStep(), 500);
      } else {
        setWorkflow(prev => prev ? {
          ...prev,
          status: 'failed',
          error: result.error,
        } : null);
        // Send Slack notification for workflow failure
        if (slackNotificationsEnabled) {
          slack.notifyWorkflowFailed(workflow, result.error || 'Unknown error', slackChannel);
        }
        onWorkflowFailed?.(workflow, result.error || 'Unknown error');
        toast.error(`✗ ${step.name} failed: ${result.error}`);
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      updateStep(stepId, {
        status: 'failed',
        result: { success: false, message: errorMessage, error: errorMessage },
        completedAt: new Date(),
      });
      setWorkflow(prev => prev ? {
        ...prev,
        status: 'failed',
        error: errorMessage,
      } : null);
      // Send Slack notification for workflow failure
      if (slackNotificationsEnabled) {
        slack.notifyWorkflowFailed(workflow, errorMessage, slackChannel);
      }
      onWorkflowFailed?.(workflow, errorMessage);
      toast.error(`Workflow failed: ${errorMessage}`);
    }
  }, [workflow, executeStep, updateStep, runNextStep, onStepCompleted, onWorkflowFailed, linkedTask, jira, slack, slackNotificationsEnabled, slackChannel]);

  // Reject/skip a step
  const rejectStep = useCallback((stepId: string) => {
    if (!workflow) return;

    const step = workflow.steps.find(s => s.id === stepId);
    if (!step) return;

    setPendingApprovalStep(null);
    updateStep(stepId, { 
      status: 'skipped',
      result: { success: false, message: 'Skipped by user' },
      completedAt: new Date(),
    });

    if (linkedTask) {
      jira.addComment(linkedTask.key, `⏭️ Workflow step "${step.name}" skipped by user`);
    }

    toast.info(`Skipped: ${step.name}`);
    
    // Continue to next step
    setTimeout(() => runNextStep(), 300);
  }, [workflow, updateStep, runNextStep, linkedTask, jira]);

  // Pause the workflow
  const pauseWorkflow = useCallback(() => {
    setWorkflow(prev => prev ? {
      ...prev,
      status: 'paused',
    } : null);
    setIsExecuting(false);
    toast.info('Workflow paused');
  }, []);

  // Resume the workflow
  const resumeWorkflow = useCallback(async () => {
    if (!workflow || workflow.status !== 'paused') return;
    
    setWorkflow(prev => prev ? {
      ...prev,
      status: 'running',
    } : null);
    setIsExecuting(true);
    await runNextStep();
  }, [workflow, runNextStep]);

  // Cancel the workflow
  const cancelWorkflow = useCallback(() => {
    abortControllerRef.current?.abort();
    setWorkflow(prev => prev ? {
      ...prev,
      status: 'cancelled',
    } : null);
    setIsExecuting(false);
    setPendingApprovalStep(null);
    
    if (linkedTask) {
      jira.addComment(linkedTask.key, '🚫 Workflow cancelled by user');
    }
    
    toast.info('Workflow cancelled');
  }, [linkedTask, jira]);

  // Reset the workflow
  const resetWorkflow = useCallback(() => {
    setWorkflow(null);
    setIsExecuting(false);
    setPendingApprovalStep(null);
  }, []);

  // Get workflow progress percentage
  const getProgress = useCallback((): number => {
    if (!workflow) return 0;
    const completedSteps = workflow.steps.filter(s => 
      s.status === 'completed' || s.status === 'skipped'
    ).length;
    return Math.round((completedSteps / workflow.steps.length) * 100);
  }, [workflow]);

  return {
    workflow,
    isExecuting,
    pendingApprovalStep,
    templates: WORKFLOW_TEMPLATES,
    createWorkflow,
    startWorkflow,
    pauseWorkflow,
    resumeWorkflow,
    cancelWorkflow,
    resetWorkflow,
    approveStep,
    rejectStep,
    getProgress,
    // Expose integrations for external use
    github,
    jira,
    slack,
  };
}
