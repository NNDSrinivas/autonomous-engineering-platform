import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import type { WorkflowPhase, WorkflowStepResult } from './useEndToEndWorkflow';

export interface WorkflowHistoryEntry {
  id: string;
  taskId: string;
  taskKey: string;
  taskTitle: string | null;
  templateId: string | null;
  templateName: string | null;
  phasesCompleted: WorkflowPhase[];
  phasesSkipped: WorkflowPhase[];
  status: 'in_progress' | 'completed' | 'failed' | 'cancelled';
  startedAt: Date;
  completedAt: Date | null;
  durationMs: number | null;
  results: WorkflowStepResult[];
  errorMessage: string | null;
  prUrl: string | null;
  prNumber: number | null;
  branchName: string | null;
}

interface DbWorkflowHistory {
  id: string;
  user_id: string;
  task_id: string;
  task_key: string;
  task_title: string | null;
  template_id: string | null;
  template_name: string | null;
  phases_completed: string[];
  phases_skipped: string[];
  status: string;
  started_at: string;
  completed_at: string | null;
  duration_ms: number | null;
  results: unknown;
  error_message: string | null;
  pr_url: string | null;
  pr_number: number | null;
  branch_name: string | null;
  created_at: string;
}

export function useWorkflowHistory() {
  const [history, setHistory] = useState<WorkflowHistoryEntry[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [stats, setStats] = useState({
    totalWorkflows: 0,
    completedWorkflows: 0,
    failedWorkflows: 0,
    averageDurationMs: 0,
    successRate: 0,
  });

  const mapDbToEntry = (row: DbWorkflowHistory): WorkflowHistoryEntry => ({
    id: row.id,
    taskId: row.task_id,
    taskKey: row.task_key,
    taskTitle: row.task_title,
    templateId: row.template_id,
    templateName: row.template_name,
    phasesCompleted: row.phases_completed as WorkflowPhase[],
    phasesSkipped: row.phases_skipped as WorkflowPhase[],
    status: row.status as WorkflowHistoryEntry['status'],
    startedAt: new Date(row.started_at),
    completedAt: row.completed_at ? new Date(row.completed_at) : null,
    durationMs: row.duration_ms,
    results: (row.results || []) as WorkflowStepResult[],
    errorMessage: row.error_message,
    prUrl: row.pr_url,
    prNumber: row.pr_number,
    branchName: row.branch_name,
  });

  // Fetch workflow history
  const fetchHistory = useCallback(async (limit = 50) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        setIsLoading(false);
        return;
      }

      const { data, error } = await supabase
        .from('workflow_history')
        .select('*')
        .order('started_at', { ascending: false })
        .limit(limit);

      if (error) throw error;

      const entries = (data || []).map(mapDbToEntry);
      setHistory(entries);

      // Calculate stats
      const completed = entries.filter(e => e.status === 'completed').length;
      const failed = entries.filter(e => e.status === 'failed').length;
      const durations = entries
        .filter(e => e.durationMs !== null)
        .map(e => e.durationMs!);
      
      setStats({
        totalWorkflows: entries.length,
        completedWorkflows: completed,
        failedWorkflows: failed,
        averageDurationMs: durations.length > 0 
          ? Math.round(durations.reduce((a, b) => a + b, 0) / durations.length)
          : 0,
        successRate: entries.length > 0 
          ? Math.round((completed / entries.length) * 100)
          : 0,
      });
    } catch (err) {
      console.error('Failed to fetch workflow history:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchHistory();
  }, [fetchHistory]);

  // Start a new workflow entry
  const startWorkflowEntry = useCallback(async (
    taskId: string,
    taskKey: string,
    taskTitle: string | null,
    templateId: string | null,
    templateName: string | null
  ): Promise<string | null> => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return null;

      const { data, error } = await supabase
        .from('workflow_history')
        .insert({
          user_id: user.id,
          task_id: taskId,
          task_key: taskKey,
          task_title: taskTitle,
          template_id: templateId,
          template_name: templateName,
          status: 'in_progress',
        })
        .select()
        .single();

      if (error) throw error;

      const entry = mapDbToEntry(data);
      setHistory(prev => [entry, ...prev]);
      
      return data.id;
    } catch (err) {
      console.error('Failed to start workflow entry:', err);
      return null;
    }
  }, []);

  // Update workflow progress
  const updateWorkflowProgress = useCallback(async (
    id: string,
    updates: {
      phasesCompleted?: WorkflowPhase[];
      branchName?: string;
      prUrl?: string;
      prNumber?: number;
    }
  ) => {
    try {
      const { error } = await supabase
        .from('workflow_history')
        .update({
          phases_completed: updates.phasesCompleted,
          branch_name: updates.branchName,
          pr_url: updates.prUrl,
          pr_number: updates.prNumber,
        })
        .eq('id', id);

      if (error) throw error;

      setHistory(prev =>
        prev.map(e => e.id === id ? {
          ...e,
          phasesCompleted: updates.phasesCompleted || e.phasesCompleted,
          branchName: updates.branchName || e.branchName,
          prUrl: updates.prUrl || e.prUrl,
          prNumber: updates.prNumber || e.prNumber,
        } : e)
      );
    } catch (err) {
      console.error('Failed to update workflow progress:', err);
    }
  }, []);

  // Complete a workflow
  const completeWorkflow = useCallback(async (
    id: string,
    status: 'completed' | 'failed' | 'cancelled',
    results: WorkflowStepResult[],
    errorMessage?: string
  ) => {
    try {
      const entry = history.find(e => e.id === id);
      const durationMs = entry 
        ? Date.now() - entry.startedAt.getTime()
        : null;

      const { error } = await supabase
        .from('workflow_history')
        .update({
          status,
          completed_at: new Date().toISOString(),
          duration_ms: durationMs,
          results: JSON.parse(JSON.stringify(results)),
          error_message: errorMessage,
        })
        .eq('id', id);

      if (error) throw error;

      setHistory(prev =>
        prev.map(e => e.id === id ? {
          ...e,
          status,
          completedAt: new Date(),
          durationMs,
          results,
          errorMessage: errorMessage || null,
        } : e)
      );

      // Update stats
      if (status === 'completed') {
        setStats(prev => ({
          ...prev,
          completedWorkflows: prev.completedWorkflows + 1,
          successRate: Math.round(((prev.completedWorkflows + 1) / prev.totalWorkflows) * 100),
        }));
      } else if (status === 'failed') {
        setStats(prev => ({
          ...prev,
          failedWorkflows: prev.failedWorkflows + 1,
          successRate: Math.round((prev.completedWorkflows / prev.totalWorkflows) * 100),
        }));
      }
    } catch (err) {
      console.error('Failed to complete workflow:', err);
    }
  }, [history]);

  // Get history for a specific task
  const getTaskHistory = useCallback((taskId: string) => {
    return history.filter(e => e.taskId === taskId);
  }, [history]);

  return {
    history,
    stats,
    isLoading,
    startWorkflowEntry,
    updateWorkflowProgress,
    completeWorkflow,
    getTaskHistory,
    refresh: fetchHistory,
  };
}
