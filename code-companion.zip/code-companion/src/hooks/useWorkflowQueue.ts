import { useState, useCallback, useEffect } from 'react';
import { toast } from 'sonner';

export interface QueuedTask {
  id: string;
  taskId: string;
  taskKey: string;
  taskTitle: string;
  priority: 'high' | 'medium' | 'low';
  templateId: string | null;
  templateName: string | null;
  status: 'queued' | 'running' | 'completed' | 'failed' | 'paused';
  addedAt: Date;
  startedAt: Date | null;
  completedAt: Date | null;
  errorMessage: string | null;
  estimatedDurationMs: number | null;
  retryCount: number;
  maxRetries: number;
}

interface QueueSettings {
  maxConcurrent: number;
  pauseOnFailure: boolean;
  autoRetry: boolean;
  retryDelayMs: number;
}

const DEFAULT_SETTINGS: QueueSettings = {
  maxConcurrent: 1,
  pauseOnFailure: true,
  autoRetry: false,
  retryDelayMs: 5000,
};

const STORAGE_KEY = 'navi-workflow-queue';
const SETTINGS_KEY = 'navi-workflow-queue-settings';

export function useWorkflowQueue() {
  const [queue, setQueue] = useState<QueuedTask[]>([]);
  const [settings, setSettings] = useState<QueueSettings>(DEFAULT_SETTINGS);
  const [isPaused, setIsPaused] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentTask, setCurrentTask] = useState<QueuedTask | null>(null);

  // Load queue from localStorage
  useEffect(() => {
    try {
      const savedQueue = localStorage.getItem(STORAGE_KEY);
      if (savedQueue) {
        const parsed = JSON.parse(savedQueue);
        setQueue(parsed.map((t: any) => ({
          ...t,
          addedAt: new Date(t.addedAt),
          startedAt: t.startedAt ? new Date(t.startedAt) : null,
          completedAt: t.completedAt ? new Date(t.completedAt) : null,
        })));
      }

      const savedSettings = localStorage.getItem(SETTINGS_KEY);
      if (savedSettings) {
        setSettings(JSON.parse(savedSettings));
      }
    } catch (err) {
      console.error('Failed to load workflow queue:', err);
    }
  }, []);

  // Save queue to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(queue));
    } catch (err) {
      console.error('Failed to save workflow queue:', err);
    }
  }, [queue]);

  // Save settings to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    } catch (err) {
      console.error('Failed to save queue settings:', err);
    }
  }, [settings]);

  // Add task to queue
  const addToQueue = useCallback((
    taskId: string,
    taskKey: string,
    taskTitle: string,
    priority: 'high' | 'medium' | 'low' = 'medium',
    templateId: string | null = null,
    templateName: string | null = null,
    estimatedDurationMs: number | null = null
  ) => {
    const newTask: QueuedTask = {
      id: `queue-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      taskId,
      taskKey,
      taskTitle,
      priority,
      templateId,
      templateName,
      status: 'queued',
      addedAt: new Date(),
      startedAt: null,
      completedAt: null,
      errorMessage: null,
      estimatedDurationMs,
      retryCount: 0,
      maxRetries: settings.autoRetry ? 3 : 0,
    };

    setQueue(prev => {
      // Insert based on priority
      const priorityOrder = { high: 0, medium: 1, low: 2 };
      const insertIndex = prev.findIndex(t => 
        t.status === 'queued' && priorityOrder[t.priority] > priorityOrder[priority]
      );

      if (insertIndex === -1) {
        return [...prev, newTask];
      }
      
      const newQueue = [...prev];
      newQueue.splice(insertIndex, 0, newTask);
      return newQueue;
    });

    toast.success(`Added "${taskKey}" to workflow queue`);
    return newTask.id;
  }, [settings.autoRetry]);

  // Add multiple tasks to queue
  const addBatchToQueue = useCallback((
    tasks: Array<{
      taskId: string;
      taskKey: string;
      taskTitle: string;
      priority?: 'high' | 'medium' | 'low';
      templateId?: string | null;
      templateName?: string | null;
    }>
  ) => {
    const newTasks: QueuedTask[] = tasks.map(task => ({
      id: `queue-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      taskId: task.taskId,
      taskKey: task.taskKey,
      taskTitle: task.taskTitle,
      priority: task.priority || 'medium',
      templateId: task.templateId || null,
      templateName: task.templateName || null,
      status: 'queued' as const,
      addedAt: new Date(),
      startedAt: null,
      completedAt: null,
      errorMessage: null,
      estimatedDurationMs: null,
      retryCount: 0,
      maxRetries: settings.autoRetry ? 3 : 0,
    }));

    setQueue(prev => {
      const priorityOrder = { high: 0, medium: 1, low: 2 };
      const sortedTasks = [...newTasks].sort((a, b) => 
        priorityOrder[a.priority] - priorityOrder[b.priority]
      );
      return [...prev, ...sortedTasks];
    });

    toast.success(`Added ${tasks.length} tasks to workflow queue`);
  }, [settings.autoRetry]);

  // Remove task from queue
  const removeFromQueue = useCallback((id: string) => {
    setQueue(prev => prev.filter(t => t.id !== id));
    toast.info('Task removed from queue');
  }, []);

  // Clear completed/failed tasks
  const clearCompleted = useCallback(() => {
    setQueue(prev => prev.filter(t => 
      t.status !== 'completed' && t.status !== 'failed'
    ));
    toast.info('Cleared completed tasks');
  }, []);

  // Reorder task in queue
  const reorderTask = useCallback((id: string, newIndex: number) => {
    setQueue(prev => {
      const taskIndex = prev.findIndex(t => t.id === id);
      if (taskIndex === -1) return prev;

      const newQueue = [...prev];
      const [task] = newQueue.splice(taskIndex, 1);
      newQueue.splice(newIndex, 0, task);
      return newQueue;
    });
  }, []);

  // Update task priority
  const updatePriority = useCallback((id: string, priority: 'high' | 'medium' | 'low') => {
    setQueue(prev => prev.map(t => 
      t.id === id ? { ...t, priority } : t
    ));
  }, []);

  // Get next task to process
  const getNextTask = useCallback((): QueuedTask | null => {
    return queue.find(t => t.status === 'queued') || null;
  }, [queue]);

  // Start processing a task
  const startTask = useCallback((id: string) => {
    setQueue(prev => prev.map(t => 
      t.id === id 
        ? { ...t, status: 'running' as const, startedAt: new Date() }
        : t
    ));
    setCurrentTask(queue.find(t => t.id === id) || null);
    setIsProcessing(true);
  }, [queue]);

  // Complete a task
  const completeTask = useCallback((id: string, success: boolean, errorMessage?: string) => {
    setQueue(prev => prev.map(t => {
      if (t.id !== id) return t;

      if (success) {
        return {
          ...t,
          status: 'completed' as const,
          completedAt: new Date(),
        };
      }

      // Handle failure
      if (settings.autoRetry && t.retryCount < t.maxRetries) {
        return {
          ...t,
          status: 'queued' as const,
          retryCount: t.retryCount + 1,
          errorMessage,
        };
      }

      return {
        ...t,
        status: 'failed' as const,
        completedAt: new Date(),
        errorMessage,
      };
    }));

    setCurrentTask(null);
    setIsProcessing(false);

    if (!success && settings.pauseOnFailure) {
      setIsPaused(true);
      toast.error('Queue paused due to task failure');
    }
  }, [settings.autoRetry, settings.pauseOnFailure]);

  // Pause queue
  const pauseQueue = useCallback(() => {
    setIsPaused(true);
    toast.info('Workflow queue paused');
  }, []);

  // Resume queue
  const resumeQueue = useCallback(() => {
    setIsPaused(false);
    toast.success('Workflow queue resumed');
  }, []);

  // Clear entire queue
  const clearQueue = useCallback(() => {
    setQueue([]);
    setCurrentTask(null);
    setIsProcessing(false);
    toast.info('Workflow queue cleared');
  }, []);

  // Update settings
  const updateSettings = useCallback((newSettings: Partial<QueueSettings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  }, []);

  // Retry failed task
  const retryTask = useCallback((id: string) => {
    setQueue(prev => prev.map(t => 
      t.id === id 
        ? { ...t, status: 'queued' as const, retryCount: 0, errorMessage: null }
        : t
    ));
    toast.info('Task queued for retry');
  }, []);

  // Get queue statistics
  const stats = {
    total: queue.length,
    queued: queue.filter(t => t.status === 'queued').length,
    running: queue.filter(t => t.status === 'running').length,
    completed: queue.filter(t => t.status === 'completed').length,
    failed: queue.filter(t => t.status === 'failed').length,
    estimatedTimeMs: queue
      .filter(t => t.status === 'queued' && t.estimatedDurationMs)
      .reduce((sum, t) => sum + (t.estimatedDurationMs || 0), 0),
  };

  return {
    queue,
    currentTask,
    isPaused,
    isProcessing,
    settings,
    stats,
    addToQueue,
    addBatchToQueue,
    removeFromQueue,
    clearCompleted,
    clearQueue,
    reorderTask,
    updatePriority,
    getNextTask,
    startTask,
    completeTask,
    pauseQueue,
    resumeQueue,
    updateSettings,
    retryTask,
  };
}
