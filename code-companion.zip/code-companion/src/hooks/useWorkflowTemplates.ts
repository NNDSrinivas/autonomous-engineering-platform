import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import type { WorkflowPhase } from './useEndToEndWorkflow';
import { defaultWorkflowTemplates, WorkflowTemplate } from '@/types/workflowTemplates';

interface DbWorkflowTemplate {
  id: string;
  user_id: string;
  name: string;
  description: string | null;
  icon: string;
  phases: string[];
  is_default: boolean;
  created_at: string;
  updated_at: string;
}

export function useWorkflowTemplates() {
  const [templates, setTemplates] = useState<WorkflowTemplate[]>(defaultWorkflowTemplates);
  const [customTemplates, setCustomTemplates] = useState<WorkflowTemplate[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Fetch user's custom templates
  const fetchTemplates = useCallback(async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        setIsLoading(false);
        return;
      }

      const { data, error } = await supabase
        .from('workflow_templates')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const userTemplates: WorkflowTemplate[] = (data || []).map((t: DbWorkflowTemplate) => ({
        id: t.id,
        name: t.name,
        description: t.description || '',
        icon: t.icon,
        phases: t.phases as WorkflowPhase[],
        isDefault: t.is_default,
      }));

      setCustomTemplates(userTemplates);
      setTemplates([...defaultWorkflowTemplates, ...userTemplates]);
    } catch (err) {
      console.error('Failed to fetch workflow templates:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchTemplates();
  }, [fetchTemplates]);

  // Save a new template
  const saveTemplate = useCallback(async (template: Omit<WorkflowTemplate, 'id'>) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast.error('Please sign in to save templates');
        return null;
      }

      const { data, error } = await supabase
        .from('workflow_templates')
        .insert({
          user_id: user.id,
          name: template.name,
          description: template.description,
          icon: template.icon,
          phases: template.phases,
          is_default: template.isDefault || false,
        })
        .select()
        .single();

      if (error) throw error;

      const newTemplate: WorkflowTemplate = {
        id: data.id,
        name: data.name,
        description: data.description || '',
        icon: data.icon,
        phases: data.phases as WorkflowPhase[],
        isDefault: data.is_default,
      };

      setCustomTemplates(prev => [newTemplate, ...prev]);
      setTemplates(prev => [...defaultWorkflowTemplates, newTemplate, ...prev.filter(t => !defaultWorkflowTemplates.find(d => d.id === t.id) && t.id !== newTemplate.id)]);
      
      toast.success(`Template "${template.name}" saved`);
      return newTemplate;
    } catch (err) {
      console.error('Failed to save template:', err);
      toast.error('Failed to save template');
      return null;
    }
  }, []);

  // Update a template
  const updateTemplate = useCallback(async (id: string, updates: Partial<WorkflowTemplate>) => {
    try {
      const { error } = await supabase
        .from('workflow_templates')
        .update({
          name: updates.name,
          description: updates.description,
          icon: updates.icon,
          phases: updates.phases,
          is_default: updates.isDefault,
        })
        .eq('id', id);

      if (error) throw error;

      setCustomTemplates(prev => 
        prev.map(t => t.id === id ? { ...t, ...updates } : t)
      );
      setTemplates(prev => 
        prev.map(t => t.id === id ? { ...t, ...updates } : t)
      );
      
      toast.success('Template updated');
    } catch (err) {
      console.error('Failed to update template:', err);
      toast.error('Failed to update template');
    }
  }, []);

  // Delete a template
  const deleteTemplate = useCallback(async (id: string) => {
    try {
      const { error } = await supabase
        .from('workflow_templates')
        .delete()
        .eq('id', id);

      if (error) throw error;

      setCustomTemplates(prev => prev.filter(t => t.id !== id));
      setTemplates(prev => prev.filter(t => t.id !== id));
      
      toast.success('Template deleted');
    } catch (err) {
      console.error('Failed to delete template:', err);
      toast.error('Failed to delete template');
    }
  }, []);

  return {
    templates,
    customTemplates,
    isLoading,
    saveTemplate,
    updateTemplate,
    deleteTemplate,
    refresh: fetchTemplates,
  };
}
