import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface ZoomMeeting {
  id: string;
  uuid: string;
  topic: string;
  start_time: string;
  duration: number;
  host_id: string;
  host_email: string;
  participant_count?: number;
  has_recording?: boolean;
  has_transcript?: boolean;
}

export interface ZoomRecording {
  id: string;
  meeting_id: string;
  topic: string;
  start_time: string;
  duration: number;
  share_url?: string;
  recording_files: {
    id: string;
    file_type: string;
    file_size: number;
    download_url: string;
    play_url?: string;
    status: string;
  }[];
}

export interface ZoomTranscript {
  meeting_id: string;
  topic: string;
  start_time: string;
  content: string;
  speakers: {
    name: string;
    segments: {
      text: string;
      start_time: number;
      end_time: number;
    }[];
  }[];
  summary?: string;
  action_items?: string[];
  key_decisions?: string[];
}

export function useZoomIntegration() {
  const [isLoading, setIsLoading] = useState(false);
  const [meetings, setMeetings] = useState<ZoomMeeting[]>([]);
  const [recordings, setRecordings] = useState<ZoomRecording[]>([]);
  const [transcripts, setTranscripts] = useState<ZoomTranscript[]>([]);
  const [error, setError] = useState<string | null>(null);

  const fetchZoomData = useCallback(async (action: string) => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error('Please sign in to access Zoom');
        return null;
      }

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/integration-data`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ provider: 'zoom', action }),
        }
      );

      const result = await response.json();
      if (!response.ok) {
        if (result.requiresAuth) {
          toast.error('Please connect Zoom first');
        }
        throw new Error(result.error || 'Failed to fetch Zoom data');
      }

      return result.data;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      setError(message);
      return null;
    }
  }, []);

  const fetchMeetings = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const data = await fetchZoomData('meetings');
      if (data) {
        setMeetings(data);
      }
      return data || [];
    } finally {
      setIsLoading(false);
    }
  }, [fetchZoomData]);

  const fetchRecordings = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const data = await fetchZoomData('recordings');
      if (data) {
        setRecordings(data);
      }
      return data || [];
    } finally {
      setIsLoading(false);
    }
  }, [fetchZoomData]);

  const fetchTranscripts = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      const data = await fetchZoomData('transcripts');
      if (data) {
        setTranscripts(data);
      }
      return data || [];
    } finally {
      setIsLoading(false);
    }
  }, [fetchZoomData]);

  const fetchTranscriptForMeeting = useCallback(async (meetingId: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return null;

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/integration-data`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ 
            provider: 'zoom', 
            action: 'transcript',
            params: { meetingId }
          }),
        }
      );

      const result = await response.json();
      if (!response.ok) {
        throw new Error(result.error || 'Failed to fetch transcript');
      }

      return result.data as ZoomTranscript;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      setError(message);
      toast.error('Failed to fetch transcript');
      return null;
    } finally {
      setIsLoading(false);
    }
  }, []);

  const syncAll = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      await Promise.all([
        fetchMeetings(),
        fetchRecordings(),
        fetchTranscripts(),
      ]);
      toast.success('Zoom data synced');
    } catch (err) {
      toast.error('Failed to sync Zoom data');
    } finally {
      setIsLoading(false);
    }
  }, [fetchMeetings, fetchRecordings, fetchTranscripts]);

  const summarizeTranscript = useCallback(async (
    transcript: string,
    meetingTopic?: string,
    participants?: string[]
  ) => {
    setIsLoading(true);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error('Please sign in to summarize transcripts');
        return null;
      }

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-summarize-transcript`,
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ transcript, meetingTopic, participants }),
        }
      );

      const result = await response.json();
      if (!response.ok) {
        throw new Error(result.error || 'Failed to summarize transcript');
      }

      toast.success('Transcript summarized successfully');
      return result;
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Unknown error';
      setError(message);
      toast.error('Failed to summarize transcript');
      return null;
    } finally {
      setIsLoading(false);
    }
  }, []);

  return {
    isLoading,
    error,
    meetings,
    recordings,
    transcripts,
    fetchMeetings,
    fetchRecordings,
    fetchTranscripts,
    fetchTranscriptForMeeting,
    syncAll,
    summarizeTranscript,
  };
}
