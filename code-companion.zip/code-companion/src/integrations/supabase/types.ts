export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      agent_activity_history: {
        Row: {
          commands: Json | null
          completed_at: string | null
          conversation_id: string | null
          created_at: string
          duration_ms: number | null
          files: Json | null
          id: string
          lines_changed: number | null
          metadata: Json | null
          phase: string
          session_id: string
          steps: Json | null
          summary: string | null
          task_key: string | null
          tokens_processed: number | null
          total_edits: number | null
          user_id: string
        }
        Insert: {
          commands?: Json | null
          completed_at?: string | null
          conversation_id?: string | null
          created_at?: string
          duration_ms?: number | null
          files?: Json | null
          id?: string
          lines_changed?: number | null
          metadata?: Json | null
          phase?: string
          session_id: string
          steps?: Json | null
          summary?: string | null
          task_key?: string | null
          tokens_processed?: number | null
          total_edits?: number | null
          user_id: string
        }
        Update: {
          commands?: Json | null
          completed_at?: string | null
          conversation_id?: string | null
          created_at?: string
          duration_ms?: number | null
          files?: Json | null
          id?: string
          lines_changed?: number | null
          metadata?: Json | null
          phase?: string
          session_id?: string
          steps?: Json | null
          summary?: string | null
          task_key?: string | null
          tokens_processed?: number | null
          total_edits?: number | null
          user_id?: string
        }
        Relationships: []
      }
      conversation_memories: {
        Row: {
          conversation_id: string
          created_at: string
          embedding: string | null
          id: string
          key_topics: string[] | null
          last_message_at: string | null
          message_count: number | null
          metadata: Json | null
          summary: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          conversation_id: string
          created_at?: string
          embedding?: string | null
          id?: string
          key_topics?: string[] | null
          last_message_at?: string | null
          message_count?: number | null
          metadata?: Json | null
          summary?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          conversation_id?: string
          created_at?: string
          embedding?: string | null
          id?: string
          key_topics?: string[] | null
          last_message_at?: string | null
          message_count?: number | null
          metadata?: Json | null
          summary?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      integration_connections: {
        Row: {
          access_token: string
          created_at: string
          id: string
          last_sync_at: string | null
          provider: string
          provider_display_name: string | null
          provider_email: string | null
          provider_metadata: Json | null
          provider_user_id: string | null
          refresh_token: string | null
          scopes: string[] | null
          status: string
          token_expires_at: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          access_token: string
          created_at?: string
          id?: string
          last_sync_at?: string | null
          provider: string
          provider_display_name?: string | null
          provider_email?: string | null
          provider_metadata?: Json | null
          provider_user_id?: string | null
          refresh_token?: string | null
          scopes?: string[] | null
          status?: string
          token_expires_at?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          access_token?: string
          created_at?: string
          id?: string
          last_sync_at?: string | null
          provider?: string
          provider_display_name?: string | null
          provider_email?: string | null
          provider_metadata?: Json | null
          provider_user_id?: string | null
          refresh_token?: string | null
          scopes?: string[] | null
          status?: string
          token_expires_at?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      message_feedback: {
        Row: {
          conversation_id: string
          created_at: string
          feedback_type: string
          id: string
          message_content: string | null
          message_id: string
          message_role: string
          metadata: Json | null
          updated_at: string
          user_id: string
        }
        Insert: {
          conversation_id: string
          created_at?: string
          feedback_type: string
          id?: string
          message_content?: string | null
          message_id: string
          message_role: string
          metadata?: Json | null
          updated_at?: string
          user_id: string
        }
        Update: {
          conversation_id?: string
          created_at?: string
          feedback_type?: string
          id?: string
          message_content?: string | null
          message_id?: string
          message_role?: string
          metadata?: Json | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      newsletter_subscribers: {
        Row: {
          email: string
          id: string
          is_active: boolean
          source: string | null
          subscribed_at: string
        }
        Insert: {
          email: string
          id?: string
          is_active?: boolean
          source?: string | null
          subscribed_at?: string
        }
        Update: {
          email?: string
          id?: string
          is_active?: boolean
          source?: string | null
          subscribed_at?: string
        }
        Relationships: []
      }
      oauth_states: {
        Row: {
          created_at: string
          expires_at: string
          id: string
          provider: string
          redirect_uri: string | null
          state: string
          user_id: string
        }
        Insert: {
          created_at?: string
          expires_at?: string
          id?: string
          provider: string
          redirect_uri?: string | null
          state: string
          user_id: string
        }
        Update: {
          created_at?: string
          expires_at?: string
          id?: string
          provider?: string
          redirect_uri?: string | null
          state?: string
          user_id?: string
        }
        Relationships: []
      }
      organization_members: {
        Row: {
          created_at: string
          id: string
          organization_id: string
          role: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          organization_id: string
          role?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          organization_id?: string
          role?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "organization_members_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      organization_oauth_configs: {
        Row: {
          additional_config: Json | null
          client_id: string
          client_secret: string
          created_at: string
          id: string
          organization_id: string
          provider: string
          updated_at: string
        }
        Insert: {
          additional_config?: Json | null
          client_id: string
          client_secret: string
          created_at?: string
          id?: string
          organization_id: string
          provider: string
          updated_at?: string
        }
        Update: {
          additional_config?: Json | null
          client_id?: string
          client_secret?: string
          created_at?: string
          id?: string
          organization_id?: string
          provider?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "organization_oauth_configs_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      organizations: {
        Row: {
          created_at: string
          id: string
          name: string
          slug: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          slug: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          slug?: string
          updated_at?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          current_organization_id: string | null
          display_name: string | null
          id: string
          notification_preferences: Json | null
          theme: string | null
          timezone: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          current_organization_id?: string | null
          display_name?: string | null
          id?: string
          notification_preferences?: Json | null
          theme?: string | null
          timezone?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          current_organization_id?: string | null
          display_name?: string | null
          id?: string
          notification_preferences?: Json | null
          theme?: string | null
          timezone?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "profiles_current_organization_id_fkey"
            columns: ["current_organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
      sync_history: {
        Row: {
          completed_at: string | null
          error_message: string | null
          id: string
          items_synced: number | null
          metadata: Json | null
          provider: string
          started_at: string
          status: string
          sync_type: string
          user_id: string
        }
        Insert: {
          completed_at?: string | null
          error_message?: string | null
          id?: string
          items_synced?: number | null
          metadata?: Json | null
          provider: string
          started_at?: string
          status?: string
          sync_type: string
          user_id: string
        }
        Update: {
          completed_at?: string | null
          error_message?: string | null
          id?: string
          items_synced?: number | null
          metadata?: Json | null
          provider?: string
          started_at?: string
          status?: string
          sync_type?: string
          user_id?: string
        }
        Relationships: []
      }
      task_memories: {
        Row: {
          assignee: string | null
          created_at: string
          description: string | null
          embedding: string | null
          id: string
          priority: string | null
          related_content: Json | null
          status: string | null
          task_id: string
          task_key: string | null
          title: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          assignee?: string | null
          created_at?: string
          description?: string | null
          embedding?: string | null
          id?: string
          priority?: string | null
          related_content?: Json | null
          status?: string | null
          task_id: string
          task_key?: string | null
          title?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          assignee?: string | null
          created_at?: string
          description?: string | null
          embedding?: string | null
          id?: string
          priority?: string | null
          related_content?: Json | null
          status?: string | null
          task_id?: string
          task_key?: string | null
          title?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_preferences: {
        Row: {
          created_at: string
          id: string
          preference_key: string
          preference_value: Json
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          preference_key: string
          preference_value?: Json
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          preference_key?: string
          preference_value?: Json
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      workflow_history: {
        Row: {
          branch_name: string | null
          completed_at: string | null
          created_at: string
          duration_ms: number | null
          error_message: string | null
          id: string
          phases_completed: string[]
          phases_skipped: string[] | null
          pr_number: number | null
          pr_url: string | null
          results: Json | null
          started_at: string
          status: string
          task_id: string
          task_key: string
          task_title: string | null
          template_id: string | null
          template_name: string | null
          user_id: string
        }
        Insert: {
          branch_name?: string | null
          completed_at?: string | null
          created_at?: string
          duration_ms?: number | null
          error_message?: string | null
          id?: string
          phases_completed?: string[]
          phases_skipped?: string[] | null
          pr_number?: number | null
          pr_url?: string | null
          results?: Json | null
          started_at?: string
          status?: string
          task_id: string
          task_key: string
          task_title?: string | null
          template_id?: string | null
          template_name?: string | null
          user_id: string
        }
        Update: {
          branch_name?: string | null
          completed_at?: string | null
          created_at?: string
          duration_ms?: number | null
          error_message?: string | null
          id?: string
          phases_completed?: string[]
          phases_skipped?: string[] | null
          pr_number?: number | null
          pr_url?: string | null
          results?: Json | null
          started_at?: string
          status?: string
          task_id?: string
          task_key?: string
          task_title?: string | null
          template_id?: string | null
          template_name?: string | null
          user_id?: string
        }
        Relationships: []
      }
      workflow_templates: {
        Row: {
          created_at: string
          description: string | null
          icon: string | null
          id: string
          is_default: boolean | null
          name: string
          phases: string[]
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          icon?: string | null
          id?: string
          is_default?: boolean | null
          name: string
          phases: string[]
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          description?: string | null
          icon?: string | null
          id?: string
          is_default?: boolean | null
          name?: string
          phases?: string[]
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      workspace_memories: {
        Row: {
          content: string
          created_at: string
          embedding: string | null
          expires_at: string | null
          id: string
          memory_type: Database["public"]["Enums"]["memory_type"]
          metadata: Json | null
          organization_id: string | null
          relevance_score: number | null
          source: Database["public"]["Enums"]["memory_source"]
          source_id: string | null
          source_url: string | null
          title: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          content: string
          created_at?: string
          embedding?: string | null
          expires_at?: string | null
          id?: string
          memory_type: Database["public"]["Enums"]["memory_type"]
          metadata?: Json | null
          organization_id?: string | null
          relevance_score?: number | null
          source?: Database["public"]["Enums"]["memory_source"]
          source_id?: string | null
          source_url?: string | null
          title?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          content?: string
          created_at?: string
          embedding?: string | null
          expires_at?: string | null
          id?: string
          memory_type?: Database["public"]["Enums"]["memory_type"]
          metadata?: Json | null
          organization_id?: string | null
          relevance_score?: number | null
          source?: Database["public"]["Enums"]["memory_source"]
          source_id?: string | null
          source_url?: string | null
          title?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "workspace_memories_organization_id_fkey"
            columns: ["organization_id"]
            isOneToOne: false
            referencedRelation: "organizations"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      get_feedback_analytics: {
        Args: never
        Returns: {
          feedback_by_day: Json
          recent_dislikes: Json
          total_dislikes: number
          total_likes: number
        }[]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_org_admin: {
        Args: { _org_id: string; _user_id: string }
        Returns: boolean
      }
      is_org_member: {
        Args: { _org_id: string; _user_id: string }
        Returns: boolean
      }
      search_memories: {
        Args: {
          filter_type?: Database["public"]["Enums"]["memory_type"]
          filter_user_id?: string
          match_count?: number
          query_embedding: string
        }
        Returns: {
          content: string
          id: string
          memory_type: Database["public"]["Enums"]["memory_type"]
          metadata: Json
          similarity: number
          source: Database["public"]["Enums"]["memory_source"]
          title: string
        }[]
      }
    }
    Enums: {
      app_role: "admin" | "moderator" | "user"
      memory_source:
        | "jira"
        | "confluence"
        | "slack"
        | "teams"
        | "zoom"
        | "github"
        | "manual"
        | "conversation"
      memory_type:
        | "user_preference"
        | "task_context"
        | "code_snippet"
        | "meeting_note"
        | "conversation"
        | "documentation"
        | "slack_message"
        | "jira_ticket"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "moderator", "user"],
      memory_source: [
        "jira",
        "confluence",
        "slack",
        "teams",
        "zoom",
        "github",
        "manual",
        "conversation",
      ],
      memory_type: [
        "user_preference",
        "task_context",
        "code_snippet",
        "meeting_note",
        "conversation",
        "documentation",
        "slack_message",
        "jira_ticket",
      ],
    },
  },
} as const
