// Intelligent LLM Router - Selects optimal model based on task type

export type TaskType = 
  | 'code_generation'
  | 'code_refactoring'
  | 'code_review'
  | 'bug_fix'
  | 'test_generation'
  | 'documentation'
  | 'summarization'
  | 'conversation'
  | 'rag_reasoning'
  | 'ui_generation'
  | 'planning'
  | 'explanation';

interface ModelRecommendation {
  modelId: string;
  modelName: string;
  reason: string;
  confidence: number;
}

interface TaskPattern {
  patterns: RegExp[];
  keywords: string[];
}

const TASK_PATTERNS: Record<TaskType, TaskPattern> = {
  code_generation: {
    patterns: [/write\s+(a\s+)?code/i, /create\s+(a\s+)?function/i, /implement/i, /build\s+(a\s+)?/i],
    keywords: ['write', 'create', 'generate', 'implement', 'build', 'scaffold', 'new function', 'new component'],
  },
  code_refactoring: {
    patterns: [/refactor/i, /improve\s+(the\s+)?code/i, /optimize/i, /clean\s+up/i],
    keywords: ['refactor', 'optimize', 'improve', 'clean up', 'restructure', 'reorganize', 'simplify'],
  },
  code_review: {
    patterns: [/review\s+(this\s+)?code/i, /check\s+(this\s+)?code/i, /what('s|\s+is)\s+wrong/i],
    keywords: ['review', 'check', 'analyze', 'audit', 'inspect', 'evaluate'],
  },
  bug_fix: {
    patterns: [/fix\s+(this\s+)?bug/i, /debug/i, /error/i, /not\s+working/i, /broken/i],
    keywords: ['fix', 'bug', 'error', 'debug', 'broken', 'issue', 'problem', 'crash', 'fail'],
  },
  test_generation: {
    patterns: [/write\s+(unit\s+)?tests?/i, /create\s+tests?/i, /test\s+coverage/i],
    keywords: ['test', 'unit test', 'integration test', 'coverage', 'testing', 'spec', 'jest', 'vitest'],
  },
  documentation: {
    patterns: [/document/i, /write\s+(a\s+)?readme/i, /add\s+comments/i, /jsdoc/i],
    keywords: ['document', 'readme', 'documentation', 'comments', 'jsdoc', 'explain code'],
  },
  summarization: {
    patterns: [/summarize/i, /summary/i, /tldr/i, /key\s+points/i],
    keywords: ['summarize', 'summary', 'tldr', 'key points', 'overview', 'brief', 'highlights'],
  },
  conversation: {
    patterns: [/how\s+are\s+you/i, /hello/i, /hi\s+navi/i, /good\s+morning/i],
    keywords: ['hello', 'hi', 'how are you', 'good morning', 'good afternoon', 'thanks', 'thank you'],
  },
  rag_reasoning: {
    patterns: [/what\s+was\s+discussed/i, /find\s+(information|docs)/i, /search\s+(for|in)/i],
    keywords: ['find', 'search', 'what was', 'where is', 'who said', 'meeting notes', 'discussed', 'decided'],
  },
  ui_generation: {
    patterns: [/create\s+(a\s+)?ui/i, /design\s+(a\s+)?component/i, /build\s+(a\s+)?page/i, /style/i],
    keywords: ['ui', 'component', 'page', 'design', 'layout', 'style', 'css', 'tailwind', 'button', 'form'],
  },
  planning: {
    patterns: [/plan\s+(the\s+)?/i, /how\s+should\s+(i|we)/i, /steps\s+to/i, /approach/i],
    keywords: ['plan', 'approach', 'steps', 'strategy', 'how should', 'best way', 'architecture'],
  },
  explanation: {
    patterns: [/explain/i, /what\s+is/i, /how\s+does/i, /why\s+/i, /tell\s+me\s+about/i],
    keywords: ['explain', 'what is', 'how does', 'why', 'tell me', 'describe', 'understand'],
  },
};

// Model recommendations based on task type
const MODEL_RECOMMENDATIONS: Record<TaskType, ModelRecommendation> = {
  code_generation: {
    modelId: 'anthropic/claude-sonnet-4',
    modelName: 'Claude Sonnet 4',
    reason: 'Best for generating clean, well-structured code',
    confidence: 0.9,
  },
  code_refactoring: {
    modelId: 'anthropic/claude-sonnet-4',
    modelName: 'Claude Sonnet 4',
    reason: 'Excellent at understanding and restructuring large codebases',
    confidence: 0.95,
  },
  code_review: {
    modelId: 'google/gemini-2.5-pro',
    modelName: 'Gemini 2.5 Pro',
    reason: 'Strong analytical capabilities for code review',
    confidence: 0.85,
  },
  bug_fix: {
    modelId: 'anthropic/claude-sonnet-4',
    modelName: 'Claude Sonnet 4',
    reason: 'Superior debugging and error analysis',
    confidence: 0.9,
  },
  test_generation: {
    modelId: 'google/gemini-2.5-flash',
    modelName: 'Gemini 2.5 Flash',
    reason: 'Fast and efficient for test generation',
    confidence: 0.85,
  },
  documentation: {
    modelId: 'openai/gpt-5-mini',
    modelName: 'GPT-5 Mini',
    reason: 'Great for clear, concise documentation',
    confidence: 0.85,
  },
  summarization: {
    modelId: 'google/gemini-2.5-flash',
    modelName: 'Gemini 2.5 Flash',
    reason: 'Fast summarization with good accuracy',
    confidence: 0.9,
  },
  conversation: {
    modelId: 'openai/gpt-5',
    modelName: 'GPT-5',
    reason: 'Natural, engaging conversational responses',
    confidence: 0.95,
  },
  rag_reasoning: {
    modelId: 'google/gemini-2.5-pro',
    modelName: 'Gemini 2.5 Pro',
    reason: 'Excellent at multi-source reasoning and RAG',
    confidence: 0.9,
  },
  ui_generation: {
    modelId: 'openai/gpt-5',
    modelName: 'GPT-5',
    reason: 'Strong UI/UX generation capabilities',
    confidence: 0.85,
  },
  planning: {
    modelId: 'google/gemini-2.5-pro',
    modelName: 'Gemini 2.5 Pro',
    reason: 'Great for strategic planning and architecture',
    confidence: 0.9,
  },
  explanation: {
    modelId: 'openai/gpt-5',
    modelName: 'GPT-5',
    reason: 'Clear, detailed explanations',
    confidence: 0.9,
  },
};

export function detectTaskType(message: string): TaskType {
  const lowerMessage = message.toLowerCase();
  
  // Score each task type based on pattern and keyword matches
  const scores: Record<TaskType, number> = {} as Record<TaskType, number>;
  
  for (const [taskType, pattern] of Object.entries(TASK_PATTERNS)) {
    let score = 0;
    
    // Check regex patterns (higher weight)
    for (const regex of pattern.patterns) {
      if (regex.test(message)) {
        score += 3;
      }
    }
    
    // Check keywords (lower weight)
    for (const keyword of pattern.keywords) {
      if (lowerMessage.includes(keyword.toLowerCase())) {
        score += 1;
      }
    }
    
    scores[taskType as TaskType] = score;
  }
  
  // Find the task type with the highest score
  let maxScore = 0;
  let detectedType: TaskType = 'conversation';
  
  for (const [taskType, score] of Object.entries(scores)) {
    if (score > maxScore) {
      maxScore = score;
      detectedType = taskType as TaskType;
    }
  }
  
  // Default to conversation if no strong match
  if (maxScore < 2) {
    return 'conversation';
  }
  
  return detectedType;
}

export function getRecommendedModel(message: string): ModelRecommendation & { taskType: TaskType } {
  const taskType = detectTaskType(message);
  const recommendation = MODEL_RECOMMENDATIONS[taskType];
  
  return {
    ...recommendation,
    taskType,
  };
}

export function getModelForTaskType(taskType: TaskType): ModelRecommendation {
  return MODEL_RECOMMENDATIONS[taskType];
}

// Get all task types with their recommended models
export function getAllModelRecommendations(): Array<{ taskType: TaskType; recommendation: ModelRecommendation }> {
  return Object.entries(MODEL_RECOMMENDATIONS).map(([taskType, recommendation]) => ({
    taskType: taskType as TaskType,
    recommendation,
  }));
}
