import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Navbar } from '@/components/marketing/Navbar';
import { Footer } from '@/components/marketing/Footer';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { 
  Search, 
  Calendar, 
  Clock, 
  User, 
  ArrowRight,
  BookOpen,
  Tag,
  TrendingUp
} from 'lucide-react';

const categories = [
  { id: 'all', name: 'All Posts', count: 12 },
  { id: 'engineering', name: 'Engineering', count: 5 },
  { id: 'ai', name: 'AI & ML', count: 3 },
  { id: 'product', name: 'Product Updates', count: 2 },
  { id: 'tutorials', name: 'Tutorials', count: 2 },
];

const articles = [
  {
    id: 1,
    title: 'Introducing NAVI 3.0: The Future of Autonomous Engineering',
    excerpt: 'Today we\'re excited to announce NAVI 3.0, our most ambitious release yet. With full autonomous workflow execution, NAVI can now handle complete engineering tasks from Jira ticket to merged PR.',
    category: 'product',
    author: 'Alex Morgan',
    authorRole: 'CEO',
    date: 'Dec 15, 2025',
    readTime: '8 min read',
    image: '🚀',
    featured: true,
    tags: ['Release', 'Autonomous', 'AI'],
  },
  {
    id: 2,
    title: 'How We Built NAVI\'s Memory System',
    excerpt: 'Deep dive into the architecture behind NAVI\'s context-aware memory system that enables persistent knowledge across sessions and projects.',
    category: 'engineering',
    author: 'Dr. Sarah Chen',
    authorRole: 'Head of AI',
    date: 'Dec 10, 2025',
    readTime: '12 min read',
    image: '🧠',
    featured: true,
    tags: ['Architecture', 'Memory', 'Technical'],
  },
  {
    id: 3,
    title: 'The Complete Guide to Workflow Automation with NAVI',
    excerpt: 'Learn how to set up and optimize your development workflows with NAVI. From basic automation to advanced custom workflows.',
    category: 'tutorials',
    author: 'Marcus Johnson',
    authorRole: 'Developer Advocate',
    date: 'Dec 5, 2025',
    readTime: '15 min read',
    image: '📚',
    featured: false,
    tags: ['Tutorial', 'Workflows', 'Automation'],
  },
  {
    id: 4,
    title: 'Understanding LLM Routing for Code Generation',
    excerpt: 'Explore how NAVI intelligently routes between different AI models to optimize for speed, cost, and quality based on the task at hand.',
    category: 'ai',
    author: 'Dr. Emily Rodriguez',
    authorRole: 'ML Engineer',
    date: 'Nov 28, 2025',
    readTime: '10 min read',
    image: '🤖',
    featured: false,
    tags: ['LLM', 'AI', 'Architecture'],
  },
  {
    id: 5,
    title: 'Enterprise Security Best Practices with NAVI',
    excerpt: 'A comprehensive guide to deploying NAVI in enterprise environments with SOC2 compliance, SSO, and advanced security features.',
    category: 'engineering',
    author: 'James Wilson',
    authorRole: 'Security Lead',
    date: 'Nov 20, 2025',
    readTime: '11 min read',
    image: '🔒',
    featured: false,
    tags: ['Security', 'Enterprise', 'Compliance'],
  },
  {
    id: 6,
    title: 'Building Custom Integrations with NAVI API',
    excerpt: 'Step-by-step tutorial on creating custom integrations using NAVI\'s powerful API. Connect your favorite tools and extend NAVI\'s capabilities.',
    category: 'tutorials',
    author: 'Lisa Park',
    authorRole: 'Integration Engineer',
    date: 'Nov 15, 2025',
    readTime: '14 min read',
    image: '🔧',
    featured: false,
    tags: ['API', 'Integration', 'Tutorial'],
  },
  {
    id: 7,
    title: 'The State of AI-Assisted Development in 2025',
    excerpt: 'Our annual report on how AI is transforming software development. Key trends, challenges, and predictions for the future.',
    category: 'ai',
    author: 'Alex Morgan',
    authorRole: 'CEO',
    date: 'Nov 10, 2025',
    readTime: '20 min read',
    image: '📊',
    featured: false,
    tags: ['Report', 'Trends', 'Industry'],
  },
  {
    id: 8,
    title: 'Scaling Engineering Teams with NAVI',
    excerpt: 'How growing startups are using NAVI to maintain velocity while scaling their engineering organizations from 10 to 100+ developers.',
    category: 'engineering',
    author: 'David Kim',
    authorRole: 'Customer Success',
    date: 'Nov 5, 2025',
    readTime: '9 min read',
    image: '📈',
    featured: false,
    tags: ['Scaling', 'Teams', 'Growth'],
  },
];

export default function Blog() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState('all');

  const filteredArticles = useMemo(() => {
    return articles.filter((article) => {
      const matchesSearch = article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        article.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
        article.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
      
      const matchesCategory = activeCategory === 'all' || article.category === activeCategory;
      
      return matchesSearch && matchesCategory;
    });
  }, [searchQuery, activeCategory]);

  const featuredArticles = articles.filter(a => a.featured);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-24 pb-20">
        <div className="max-w-7xl mx-auto px-6">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <Badge variant="outline" className="mb-4">
              <BookOpen className="h-3.5 w-3.5 mr-2" />
              NAVI Blog
            </Badge>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Insights & Updates
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Stay up to date with the latest in AI engineering, product updates, and development best practices.
            </p>
          </motion.div>

          {/* Featured Articles */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="mb-16"
          >
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              Featured
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              {featuredArticles.map((article, index) => (
                <motion.div
                  key={article.id}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ y: -5 }}
                >
                  <Card className="h-full overflow-hidden group cursor-pointer hover:shadow-xl transition-all border-primary/20">
                    <CardContent className="p-0">
                      <div className="bg-gradient-to-br from-primary/20 to-accent/20 p-8 flex items-center justify-center">
                        <span className="text-7xl">{article.image}</span>
                      </div>
                      <div className="p-6">
                        <div className="flex items-center gap-2 mb-3">
                          <Badge>{article.category}</Badge>
                          <span className="text-sm text-muted-foreground">{article.date}</span>
                        </div>
                        <h3 className="text-xl font-bold mb-2 group-hover:text-primary transition-colors">
                          {article.title}
                        </h3>
                        <p className="text-muted-foreground mb-4 line-clamp-2">{article.excerpt}</p>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-sm font-bold">
                              {article.author[0]}
                            </div>
                            <div>
                              <div className="text-sm font-medium">{article.author}</div>
                              <div className="text-xs text-muted-foreground">{article.readTime}</div>
                            </div>
                          </div>
                          <ArrowRight className="h-5 w-5 text-primary group-hover:translate-x-1 transition-transform" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Search and Filter */}
          <div className="flex flex-col md:flex-row gap-6 mb-8">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search articles..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="flex flex-wrap gap-2">
              {categories.map((category) => (
                <Button
                  key={category.id}
                  variant={activeCategory === category.id ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setActiveCategory(category.id)}
                  className="flex items-center gap-1"
                >
                  {category.name}
                  <span className="text-xs opacity-60">({category.count})</span>
                </Button>
              ))}
            </div>
          </div>

          {/* Articles Grid */}
          <AnimatePresence mode="wait">
            <motion.div
              key={activeCategory + searchQuery}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
            >
              {filteredArticles.map((article, index) => (
                <motion.div
                  key={article.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  whileHover={{ y: -5 }}
                >
                  <Card className="h-full overflow-hidden group cursor-pointer hover:shadow-lg transition-all">
                    <CardContent className="p-0">
                      <div className="bg-gradient-to-br from-muted to-muted/50 p-6 flex items-center justify-center">
                        <span className="text-5xl">{article.image}</span>
                      </div>
                      <div className="p-5">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="secondary" className="text-xs">
                            {article.category}
                          </Badge>
                          <span className="text-xs text-muted-foreground flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {article.readTime}
                          </span>
                        </div>
                        <h3 className="font-semibold mb-2 group-hover:text-primary transition-colors line-clamp-2">
                          {article.title}
                        </h3>
                        <p className="text-sm text-muted-foreground mb-4 line-clamp-2">
                          {article.excerpt}
                        </p>
                        <div className="flex flex-wrap gap-1 mb-4">
                          {article.tags.map((tag) => (
                            <span
                              key={tag}
                              className="text-xs px-2 py-0.5 rounded-full bg-muted text-muted-foreground"
                            >
                              #{tag}
                            </span>
                          ))}
                        </div>
                        <div className="flex items-center gap-2 pt-4 border-t border-border">
                          <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold">
                            {article.author[0]}
                          </div>
                          <div className="flex-1">
                            <div className="text-xs font-medium">{article.author}</div>
                          </div>
                          <span className="text-xs text-muted-foreground flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {article.date}
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          </AnimatePresence>

          {filteredArticles.length === 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-16"
            >
              <BookOpen className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-xl font-semibold mb-2">No articles found</h3>
              <p className="text-muted-foreground">
                Try adjusting your search or filter to find what you're looking for.
              </p>
            </motion.div>
          )}

          {/* Newsletter CTA */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-16 text-center p-8 rounded-2xl bg-gradient-to-r from-primary/10 to-accent/10 border border-primary/20"
          >
            <h3 className="text-2xl font-bold mb-2">Subscribe to our newsletter</h3>
            <p className="text-muted-foreground mb-6">
              Get the latest articles, tutorials, and product updates delivered to your inbox.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center max-w-md mx-auto">
              <Input placeholder="Enter your email" className="flex-1" />
              <Button>Subscribe</Button>
            </div>
          </motion.div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
