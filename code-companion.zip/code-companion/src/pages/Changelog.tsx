import { motion } from 'framer-motion';
import { Navbar } from '@/components/marketing/Navbar';
import { Footer } from '@/components/marketing/Footer';
import { Badge } from '@/components/ui/badge';
import { 
  Rocket, 
  Zap, 
  Shield, 
  Brain, 
  GitBranch, 
  Sparkles,
  Bug,
  ArrowUp,
  Star
} from 'lucide-react';

const releases = [
  {
    version: '3.0.0',
    date: 'December 2025',
    type: 'major',
    title: 'NAVI 3.0 - Autonomous Engineering',
    description: 'Complete reimagining of NAVI with full autonomous workflow execution.',
    features: [
      { icon: Brain, text: 'Full autonomous task execution from Jira to PR' },
      { icon: GitBranch, text: 'Intelligent branch management and code generation' },
      { icon: Shield, text: 'Enterprise-grade security with SOC2 compliance' },
      { icon: Sparkles, text: 'Context-aware AI with 100k+ token memory' },
    ],
  },
  {
    version: '2.8.0',
    date: 'November 2025',
    type: 'minor',
    title: 'Enhanced Integrations',
    description: 'Deep integration with your entire development ecosystem.',
    features: [
      { icon: Zap, text: 'Slack real-time notifications and commands' },
      { icon: GitBranch, text: 'GitHub Actions CI/CD pipeline integration' },
      { icon: Brain, text: 'Confluence documentation sync' },
    ],
  },
  {
    version: '2.7.0',
    date: 'October 2025',
    type: 'minor',
    title: 'Smart Memory System',
    description: 'NAVI now remembers context across sessions and projects.',
    features: [
      { icon: Brain, text: 'Persistent conversation memory' },
      { icon: Sparkles, text: 'Cross-project knowledge transfer' },
      { icon: Star, text: 'User preference learning' },
    ],
  },
  {
    version: '2.6.0',
    date: 'September 2025',
    type: 'minor',
    title: 'Workflow Templates',
    description: 'Pre-built workflow templates for common development tasks.',
    features: [
      { icon: Rocket, text: '20+ built-in workflow templates' },
      { icon: Zap, text: 'Custom template creation' },
      { icon: GitBranch, text: 'Team template sharing' },
    ],
  },
  {
    version: '2.5.2',
    date: 'August 2025',
    type: 'patch',
    title: 'Bug Fixes & Performance',
    description: 'Critical bug fixes and performance improvements.',
    features: [
      { icon: Bug, text: 'Fixed memory leak in long sessions' },
      { icon: ArrowUp, text: '40% faster code generation' },
      { icon: Shield, text: 'Security vulnerability patches' },
    ],
  },
  {
    version: '2.5.0',
    date: 'July 2025',
    type: 'minor',
    title: 'Multi-Model AI',
    description: 'Support for multiple AI models with intelligent routing.',
    features: [
      { icon: Brain, text: 'GPT-4, Claude, and Gemini support' },
      { icon: Zap, text: 'Automatic model selection based on task' },
      { icon: Sparkles, text: 'Custom model fine-tuning' },
    ],
  },
  {
    version: '2.0.0',
    date: 'June 2025',
    type: 'major',
    title: 'NAVI 2.0 - Team Collaboration',
    description: 'Major release focused on team collaboration features.',
    features: [
      { icon: Rocket, text: 'Real-time team collaboration' },
      { icon: Shield, text: 'Role-based access control' },
      { icon: GitBranch, text: 'Shared workspace management' },
      { icon: Brain, text: 'Team knowledge base' },
    ],
  },
  {
    version: '1.5.0',
    date: 'April 2025',
    type: 'minor',
    title: 'Code Review Assistant',
    description: 'AI-powered code review with actionable suggestions.',
    features: [
      { icon: Sparkles, text: 'Automated PR reviews' },
      { icon: Bug, text: 'Bug detection and suggestions' },
      { icon: Shield, text: 'Security vulnerability scanning' },
    ],
  },
  {
    version: '1.0.0',
    date: 'January 2025',
    type: 'major',
    title: 'NAVI 1.0 - Initial Release',
    description: 'The beginning of autonomous engineering intelligence.',
    features: [
      { icon: Brain, text: 'AI-powered code generation' },
      { icon: GitBranch, text: 'GitHub integration' },
      { icon: Zap, text: 'Jira task management' },
      { icon: Rocket, text: 'Basic workflow automation' },
    ],
  },
];

const getTypeBadge = (type: string) => {
  switch (type) {
    case 'major':
      return <Badge className="bg-primary text-primary-foreground">Major Release</Badge>;
    case 'minor':
      return <Badge variant="secondary">Feature Update</Badge>;
    case 'patch':
      return <Badge variant="outline">Bug Fix</Badge>;
    default:
      return null;
  }
};

export default function Changelog() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="pt-24 pb-20">
        <div className="max-w-4xl mx-auto px-6">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-16"
          >
            <Badge variant="outline" className="mb-4">
              <Rocket className="h-3.5 w-3.5 mr-2" />
              Product Updates
            </Badge>
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Changelog</h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Track the evolution of NAVI. See what's new, what's improved, and what's coming next.
            </p>
          </motion.div>

          {/* Timeline */}
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-8 top-0 bottom-0 w-px bg-gradient-to-b from-primary via-primary/50 to-transparent" />

            {releases.map((release, index) => (
              <motion.div
                key={release.version}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="relative pl-20 pb-12 last:pb-0"
              >
                {/* Timeline dot */}
                <div className={`absolute left-6 w-5 h-5 rounded-full border-4 border-background ${
                  release.type === 'major' ? 'bg-primary' : release.type === 'minor' ? 'bg-accent' : 'bg-muted-foreground'
                }`} />

                {/* Content card */}
                <motion.div
                  whileHover={{ scale: 1.02 }}
                  className="bg-card border border-border rounded-xl p-6 shadow-lg hover:shadow-xl transition-all"
                >
                  <div className="flex flex-wrap items-center gap-3 mb-3">
                    <span className="text-2xl font-bold text-primary">v{release.version}</span>
                    {getTypeBadge(release.type)}
                    <span className="text-sm text-muted-foreground">{release.date}</span>
                  </div>

                  <h3 className="text-xl font-semibold mb-2">{release.title}</h3>
                  <p className="text-muted-foreground mb-4">{release.description}</p>

                  <div className="grid gap-2">
                    {release.features.map((feature, i) => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0 }}
                        whileInView={{ opacity: 1 }}
                        viewport={{ once: true }}
                        transition={{ delay: i * 0.05 }}
                        className="flex items-center gap-3 text-sm"
                      >
                        <feature.icon className="h-4 w-4 text-primary flex-shrink-0" />
                        <span>{feature.text}</span>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              </motion.div>
            ))}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
