import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useInView } from 'framer-motion';
import { 
  Check, X, Minus, Sparkles, ArrowRight, Zap, 
  Brain, Shield, Workflow, Plug, MessageSquare 
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { Navbar } from '@/components/marketing/Navbar';
import { Footer } from '@/components/marketing/Footer';
import { CTASection } from '@/components/marketing/CTASection';

const competitors = [
  {
    name: 'NAVI',
    tagline: 'Autonomous Engineering AI',
    isMain: true,
    logo: '✨',
    color: 'from-primary to-accent',
  },
  {
    name: 'GitHub Copilot',
    tagline: 'AI Pair Programmer',
    isMain: false,
    logo: 'GH',
    color: 'from-gray-600 to-gray-700',
  },
  {
    name: 'Cursor',
    tagline: 'AI Code Editor',
    isMain: false,
    logo: 'CU',
    color: 'from-blue-600 to-blue-700',
  },
  {
    name: 'Cline',
    tagline: 'Open Coding Agent',
    isMain: false,
    logo: 'CL',
    color: 'from-purple-600 to-purple-700',
  },
];

const features = [
  {
    category: 'Core Capabilities',
    items: [
      {
        name: 'Code Completion',
        description: 'Auto-complete code as you type',
        navi: true,
        copilot: true,
        cursor: true,
        cline: true,
      },
      {
        name: 'Code Generation',
        description: 'Generate code from natural language',
        navi: true,
        copilot: true,
        cursor: true,
        cline: true,
      },
      {
        name: 'End-to-End Task Execution',
        description: 'Complete entire engineering workflows autonomously',
        navi: true,
        copilot: false,
        cursor: 'partial',
        cline: 'partial',
      },
      {
        name: 'Multi-File Refactoring',
        description: 'Refactor across multiple files intelligently',
        navi: true,
        copilot: false,
        cursor: true,
        cline: true,
      },
    ],
  },
  {
    category: 'Context & Intelligence',
    items: [
      {
        name: 'Full Codebase Context',
        description: 'Understands your entire repository',
        navi: true,
        copilot: 'partial',
        cursor: true,
        cline: true,
      },
      {
        name: 'Jira/Project Management Integration',
        description: 'Reads and updates tickets automatically',
        navi: true,
        copilot: false,
        cursor: false,
        cline: false,
      },
      {
        name: 'Slack/Teams Integration',
        description: 'Accesses team conversations for context',
        navi: true,
        copilot: false,
        cursor: false,
        cline: false,
      },
      {
        name: 'Confluence/Docs Integration',
        description: 'References documentation automatically',
        navi: true,
        copilot: false,
        cursor: false,
        cline: false,
      },
      {
        name: 'Memory & Learning',
        description: 'Remembers preferences and past interactions',
        navi: true,
        copilot: false,
        cursor: 'partial',
        cline: true,
      },
    ],
  },
  {
    category: 'Workflow Automation',
    items: [
      {
        name: 'Git Branch Creation',
        description: 'Creates branches automatically',
        navi: true,
        copilot: false,
        cursor: false,
        cline: true,
      },
      {
        name: 'Pull Request Creation',
        description: 'Opens PRs with descriptions',
        navi: true,
        copilot: false,
        cursor: false,
        cline: true,
      },
      {
        name: 'CI/CD Monitoring',
        description: 'Monitors and responds to build status',
        navi: true,
        copilot: false,
        cursor: false,
        cline: false,
      },
      {
        name: 'Code Review Assistance',
        description: 'Addresses PR feedback automatically',
        navi: true,
        copilot: false,
        cursor: 'partial',
        cline: 'partial',
      },
    ],
  },
  {
    category: 'Security & Control',
    items: [
      {
        name: 'Approval-First Actions',
        description: 'Requires explicit approval before changes',
        navi: true,
        copilot: false,
        cursor: false,
        cline: true,
      },
      {
        name: 'Enterprise SSO',
        description: 'SAML/SSO authentication',
        navi: true,
        copilot: true,
        cursor: true,
        cline: false,
      },
      {
        name: 'On-Premise Deployment',
        description: 'Self-hosted option available',
        navi: true,
        copilot: true,
        cursor: false,
        cline: true,
      },
      {
        name: 'Audit Logging',
        description: 'Complete action history',
        navi: true,
        copilot: 'partial',
        cursor: false,
        cline: false,
      },
    ],
  },
];

function FeatureStatus({ value }: { value: boolean | string }) {
  if (value === true) {
    return (
      <div className="flex items-center justify-center">
        <div className="w-6 h-6 rounded-full bg-green-500/20 flex items-center justify-center">
          <Check className="h-4 w-4 text-green-500" />
        </div>
      </div>
    );
  }
  if (value === false) {
    return (
      <div className="flex items-center justify-center">
        <div className="w-6 h-6 rounded-full bg-muted flex items-center justify-center">
          <X className="h-4 w-4 text-muted-foreground" />
        </div>
      </div>
    );
  }
  return (
    <div className="flex items-center justify-center">
      <div className="w-6 h-6 rounded-full bg-yellow-500/20 flex items-center justify-center">
        <Minus className="h-4 w-4 text-yellow-500" />
      </div>
    </div>
  );
}

export default function Compare() {
  const navigate = useNavigate();
  const headerRef = useRef<HTMLDivElement>(null);
  const isHeaderInView = useInView(headerRef, { once: true });

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero Section */}
      <section className="pt-32 pb-20 relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl" />
        </div>

        <div 
          ref={headerRef}
          className="max-w-7xl mx-auto px-6 relative text-center"
          style={{
            opacity: isHeaderInView ? 1 : 0,
            transform: isHeaderInView ? 'translateY(0)' : 'translateY(30px)',
            transition: 'all 0.8s cubic-bezier(0.16, 1, 0.3, 1)',
          }}
        >
          <Badge variant="outline" className="mb-6 px-4 py-2 border-primary/30 bg-primary/5">
            <Sparkles className="h-3.5 w-3.5 mr-2 text-primary" />
            Compare AI Coding Tools
          </Badge>

          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            NAVI vs{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
              The Competition
            </span>
          </h1>

          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-10">
            See how NAVI's autonomous engineering capabilities compare to other AI coding assistants
          </p>
        </div>
      </section>

      {/* Quick Comparison Cards */}
      <section className="py-12 bg-muted/30">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-6">
            {competitors.map((competitor, index) => (
              <div
                key={competitor.name}
                className={cn(
                  'relative p-6 rounded-2xl border transition-all duration-500',
                  competitor.isMain
                    ? 'border-primary bg-primary/5 shadow-xl shadow-primary/10'
                    : 'border-border bg-card/50'
                )}
              >
                {competitor.isMain && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <Badge className="bg-gradient-to-r from-primary to-accent">
                      Recommended
                    </Badge>
                  </div>
                )}

                <div className={cn(
                  'w-14 h-14 rounded-xl flex items-center justify-center text-xl font-bold text-white mb-4 mx-auto',
                  'bg-gradient-to-br',
                  competitor.color
                )}>
                  {competitor.logo}
                </div>

                <h3 className="text-xl font-bold text-center mb-1">{competitor.name}</h3>
                <p className="text-sm text-muted-foreground text-center">{competitor.tagline}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Detailed Comparison Table */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-6">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-4 px-4 w-1/3">Feature</th>
                  {competitors.map((c) => (
                    <th 
                      key={c.name} 
                      className={cn(
                        'text-center py-4 px-4',
                        c.isMain && 'bg-primary/5'
                      )}
                    >
                      <span className={cn(
                        'font-semibold',
                        c.isMain && 'text-primary'
                      )}>
                        {c.name}
                      </span>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {features.map((category) => (
                  <>
                    <tr key={category.category} className="bg-muted/50">
                      <td colSpan={5} className="py-3 px-4 font-semibold text-sm">
                        {category.category}
                      </td>
                    </tr>
                    {category.items.map((item) => (
                      <tr key={item.name} className="border-b border-border/50 hover:bg-muted/30 transition-colors">
                        <td className="py-4 px-4">
                          <div className="font-medium">{item.name}</div>
                          <div className="text-sm text-muted-foreground">{item.description}</div>
                        </td>
                        <td className={cn('py-4 px-4', 'bg-primary/5')}>
                          <FeatureStatus value={item.navi} />
                        </td>
                        <td className="py-4 px-4">
                          <FeatureStatus value={item.copilot} />
                        </td>
                        <td className="py-4 px-4">
                          <FeatureStatus value={item.cursor} />
                        </td>
                        <td className="py-4 px-4">
                          <FeatureStatus value={item.cline} />
                        </td>
                      </tr>
                    ))}
                  </>
                ))}
              </tbody>
            </table>
          </div>

          {/* Legend */}
          <div className="flex items-center justify-center gap-8 mt-8 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 rounded-full bg-green-500/20 flex items-center justify-center">
                <Check className="h-3 w-3 text-green-500" />
              </div>
              <span className="text-muted-foreground">Full Support</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 rounded-full bg-yellow-500/20 flex items-center justify-center">
                <Minus className="h-3 w-3 text-yellow-500" />
              </div>
              <span className="text-muted-foreground">Partial Support</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 rounded-full bg-muted flex items-center justify-center">
                <X className="h-3 w-3 text-muted-foreground" />
              </div>
              <span className="text-muted-foreground">Not Available</span>
            </div>
          </div>
        </div>
      </section>

      {/* Key Differentiators */}
      <section className="py-20 bg-muted/30">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              What Makes NAVI{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
                Different
              </span>
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              NAVI isn't just another code completion tool — it's a complete autonomous engineering system
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: Brain,
                title: 'Universal Context',
                description: 'NAVI connects to Jira, Slack, Confluence, and GitHub to understand your complete engineering context.',
              },
              {
                icon: Workflow,
                title: 'End-to-End Workflows',
                description: 'Execute entire tasks from ticket to PR, including code, tests, and documentation.',
              },
              {
                icon: Shield,
                title: 'Approval-First',
                description: 'Every action requires your explicit approval. Full control, complete transparency.',
              },
              {
                icon: Plug,
                title: 'Deep Integrations',
                description: 'Not just IDE plugins — full OAuth integrations with your entire tool stack.',
              },
            ].map((diff, i) => (
              <div
                key={diff.title}
                className="p-6 rounded-2xl border border-border bg-card/50 hover:border-primary/50 transition-all duration-300"
              >
                <diff.icon className="h-10 w-10 text-primary mb-4" />
                <h3 className="text-lg font-semibold mb-2">{diff.title}</h3>
                <p className="text-muted-foreground text-sm">{diff.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CTASection />
      <Footer />
    </div>
  );
}
