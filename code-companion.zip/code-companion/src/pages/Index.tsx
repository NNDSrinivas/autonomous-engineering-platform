import { useState, useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { IntegrationsSidebar } from '@/components/navi/IntegrationsSidebar';
import { NaviChat } from '@/components/navi/NaviChat';
import { NaviHeader } from '@/components/navi/NaviHeader';
import { CommandPalette } from '@/components/navi/CommandPalette';
import { EditorPanel } from '@/components/navi/EditorPanel';
import { NotificationPanel, useNotifications } from '@/components/navi/NotificationPanel';
import { KeyboardShortcutsModal } from '@/components/navi/KeyboardShortcutsModal';
import { QuickActionsButton } from '@/components/navi/QuickActionsButton';
import { TerminalPanel } from '@/components/navi/TerminalPanel';
import { EndToEndWorkflowPanel } from '@/components/navi/EndToEndWorkflowPanel';
import { AutonomousWorkflowPanel } from '@/components/navi/AutonomousWorkflowPanel';
import { WorkflowAnalyticsDashboard } from '@/components/navi/WorkflowAnalyticsDashboard';
import { WorkflowQueuePanel } from '@/components/navi/WorkflowQueuePanel';
import { OnboardingGuide } from '@/components/navi/OnboardingGuide';
import { supabase } from '@/integrations/supabase/client';
import { ResizablePanelGroup, ResizablePanel, ResizableHandle } from '@/components/ui/resizable';
import { useNotificationSound, useNotificationSoundPreference } from '@/hooks/useNotificationSound';
import { useGitHubAutoIndex } from '@/hooks/useGitHubAutoIndex';
import { useCodeImplementation } from '@/hooks/useCodeImplementation';
import { toast } from 'sonner';
import type { JiraTask } from '@/types';

type EditorView = 'settings' | 'activity' | 'tasks' | 'search' | 'integrations' | 'context' | 'history' | 'files' | 'briefing' | 'workflow' | 'autonomous-workflow' | 'workflows' | 'workflow-history' | 'workflow-analytics' | 'workflow-queue' | 'approvals' | 'cicd' | 'cicd-dashboard' | 'zoom' | 'teams' | 'calendar' | 'notifications' | 'slack' | 'confluence' | 'github' | 'memory' | 'ai-code' | 'task-correlation' | 'github-actions' | 'ai-summarize' | 'approval-settings' | 'analytics' | 'queue' | 'code-preview' | null;

export default function Index() {
  const navigate = useNavigate();
  const [editorView, setEditorView] = useState<EditorView>(null);
  const [activeIntegration, setActiveIntegration] = useState<string | null>(null);
  const [jiraTasks, setJiraTasks] = useState<JiraTask[]>([]);
  const [selectedTask, setSelectedTask] = useState<JiraTask | null>(null);
  const [commandPaletteOpen, setCommandPaletteOpen] = useState(false);
  const [shortcutsModalOpen, setShortcutsModalOpen] = useState(false);
  const [notificationOpen, setNotificationOpen] = useState(false);
  const [selectedModel, setSelectedModel] = useState('lovable/gemini-flash');
  const [selectedProvider, setSelectedProvider] = useState('lovable');
  const [userName, setUserName] = useState('Guest');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isTerminalExpanded, setIsTerminalExpanded] = useState(false);
  const [selectedFileName, setSelectedFileName] = useState<string | null>(null);
  const [workflowTask, setWorkflowTask] = useState<JiraTask | null>(null);
  const [autonomousMode, setAutonomousMode] = useState(false);
  const [generatedFiles, setGeneratedFiles] = useState<Array<{ path: string; content: string; action: 'create' | 'modify' | 'delete' }>>([]);
  const [workflowBranchName, setWorkflowBranchName] = useState<string>('');
  
  const { notifications, unreadCount, markAsRead, markAllRead, clearAll } = useNotifications();
  
  // Play sound when new notifications arrive (respects user preference)
  const { soundEnabled, soundType, volume } = useNotificationSoundPreference();
  useNotificationSound(unreadCount, soundEnabled, soundType, volume);
  
  // Auto-index repositories on GitHub connect
  const { isIndexing, indexProgress, repoIndex, triggerIndex } = useGitHubAutoIndex();
  
  // Code implementation for workflow
  const codeImpl = useCodeImplementation({ 
    owner: repoIndex?.owner || '', 
    repo: repoIndex?.repo || '' 
  });
  
  // Handle commit from code preview
  const handleCommitFiles = useCallback(async (branchName: string, commitMessage: string) => {
    if (generatedFiles.length === 0) return;
    await codeImpl.commitToGitHub(branchName, generatedFiles, commitMessage);
    setGeneratedFiles([]);
    setEditorView(null);
    toast.success('Files committed successfully!');
  }, [generatedFiles, codeImpl]);
  
  // Handler to refresh repo index
  const handleRefreshIndex = useCallback(async () => {
    if (repoIndex?.owner && repoIndex?.repo) {
      await triggerIndex(repoIndex.owner, repoIndex.repo, repoIndex.branch);
    }
  }, [repoIndex, triggerIndex]);
  
  // Show indexing progress in toast
  useEffect(() => {
    if (isIndexing && indexProgress > 0 && indexProgress < 100) {
      toast.info(`Indexing repository: ${indexProgress}%`, { id: 'repo-index-progress' });
    }
  }, [isIndexing, indexProgress]);

  const handleStartWorkflow = useCallback((task: JiraTask, useAutonomous = false) => {
    setWorkflowTask(task);
    setAutonomousMode(useAutonomous);
    setEditorView(useAutonomous ? 'autonomous-workflow' : 'workflow');
  }, []);

  const handleCloseWorkflow = useCallback(() => {
    setWorkflowTask(null);
    setAutonomousMode(false);
    setEditorView(null);
  }, []);

  useEffect(() => {
    // Check auth state
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        setIsAuthenticated(true);
        setUserName(session.user.user_metadata?.display_name || session.user.email?.split('@')[0] || 'User');
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (session?.user) {
        setIsAuthenticated(true);
        setUserName(session.user.user_metadata?.display_name || session.user.email?.split('@')[0] || 'User');
      } else {
        setIsAuthenticated(false);
        setUserName('Guest');
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleViewChange = useCallback((view: string) => {
    // Map sidebar views to editor panel views - now supports all views
    const validViews = ['tasks', 'code', 'search', 'activity', 'files', 'briefing', 'cicd', 'cicd-dashboard', 'zoom', 'teams', 'calendar', 'workflows', 'workflow-history', 'workflow-analytics', 'workflow-queue', 'slack', 'confluence', 'github', 'memory', 'ai-code', 'task-correlation', 'github-actions', 'ai-summarize', 'analytics', 'queue'];
    if (validViews.includes(view)) {
      setEditorView(editorView === view ? null : view as EditorView);
    }
    setActiveIntegration(null);
  }, [editorView]);

  const handleIntegrationSelect = useCallback((id: string) => {
    setActiveIntegration(id);
    setEditorView('integrations');
  }, []);

  const handleTaskSelect = useCallback((task: JiraTask) => {
    setSelectedTask(task);
    setEditorView('context');
  }, []);

  const handleModelChange = useCallback((providerId: string, modelId: string) => {
    setSelectedProvider(providerId);
    setSelectedModel(modelId);
  }, []);

  const handleSettingsClick = useCallback(() => {
    if (!isAuthenticated) {
      navigate('/auth');
    } else {
      setEditorView(editorView === 'settings' ? null : 'settings');
      setActiveIntegration(null);
    }
  }, [isAuthenticated, navigate, editorView]);

  const handleProfileClick = useCallback(() => {
    if (!isAuthenticated) {
      navigate('/auth');
    } else {
      setEditorView(editorView === 'settings' ? null : 'settings');
      setActiveIntegration(null);
    }
  }, [isAuthenticated, navigate, editorView]);

  const handleHistoryClick = useCallback(() => {
    setEditorView(editorView === 'history' ? null : 'history');
  }, [editorView]);

  const handleNotificationClick = useCallback(() => {
    // Toggle between notification panel (popup) and unified notification center (editor panel)
    if (editorView === 'notifications') {
      setEditorView(null);
    } else {
      setEditorView('notifications');
    }
  }, [editorView]);

  const handleApprovalsClick = useCallback(() => {
    setEditorView(editorView === 'approvals' ? null : 'approvals');
  }, [editorView]);

  const handleCloseEditor = useCallback(() => {
    setEditorView(null);
    setActiveIntegration(null);
  }, []);

  const handleToggleSidebar = useCallback(() => {
    setIsSidebarCollapsed(prev => !prev);
  }, []);

  // Comprehensive keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const isMod = e.metaKey || e.ctrlKey;
      const isShift = e.shiftKey;
      
      // Escape - Close all panels and notifications
      if (e.key === 'Escape') {
        e.preventDefault();
        if (notificationOpen) {
          setNotificationOpen(false);
        } else if (editorView) {
          setEditorView(null);
          setActiveIntegration(null);
        }
        return;
      }

      // ⌘K - Open search panel
      if (e.key === 'k' && isMod && !isShift) {
        e.preventDefault();
        setEditorView(editorView === 'search' ? null : 'search');
        return;
      }

      // ⌘/ - Open command palette
      if (e.key === '/' && isMod) {
        e.preventDefault();
        setCommandPaletteOpen(prev => !prev);
        return;
      }

      // ⌘T - Open tasks panel
      if (e.key === 't' && isMod && !isShift) {
        e.preventDefault();
        setEditorView(editorView === 'tasks' ? null : 'tasks');
        return;
      }

      // ⌘, - Open settings
      if (e.key === ',' && isMod) {
        e.preventDefault();
        if (isAuthenticated) {
          setEditorView(editorView === 'settings' ? null : 'settings');
        } else {
          navigate('/auth');
        }
        return;
      }

      // ⌘H - Open history panel
      if (e.key === 'h' && isMod && !isShift) {
        e.preventDefault();
        setEditorView(editorView === 'history' ? null : 'history');
        return;
      }

      // ⌘⇧A - Open activity panel
      if (e.key === 'a' && isMod && isShift) {
        e.preventDefault();
        setEditorView(editorView === 'activity' ? null : 'activity');
        return;
      }

      // ⌘N - Toggle notifications
      if (e.key === 'n' && isMod && !isShift) {
        e.preventDefault();
        setNotificationOpen(prev => !prev);
        return;
      }

      // ⌘⇧I - Open integrations/connectors
      if (e.key === 'i' && isMod && isShift) {
        e.preventDefault();
        setEditorView(editorView === 'integrations' ? null : 'integrations');
        return;
      }

      // ⌘B - Focus chat input (close editor panel)
      if (e.key === 'b' && isMod) {
        e.preventDefault();
        setEditorView(null);
        setActiveIntegration(null);
        // Focus chat input
        const chatInput = document.querySelector('input[placeholder*="NAVI"]') as HTMLInputElement;
        chatInput?.focus();
        return;
      }

      // ⌘[ - Toggle sidebar
      if (e.key === '[' && isMod) {
        e.preventDefault();
        setIsSidebarCollapsed(prev => !prev);
        return;
      }

      // ⌘⇧W - Start workflow on selected task
      if (e.key === 'w' && isMod && isShift) {
        e.preventDefault();
        if (selectedTask) {
          handleStartWorkflow(selectedTask);
        } else {
          // Open tasks panel if no task selected
          setEditorView('tasks');
        }
        return;
      }

      // ⌘⇧H - Open workflow history
      if (e.key === 'h' && isMod && isShift) {
        e.preventDefault();
        setEditorView(editorView === 'workflow-history' ? null : 'workflow-history');
        return;
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [editorView, notificationOpen, isAuthenticated, navigate, selectedTask, handleStartWorkflow]);

  return (
    <div className="h-screen flex flex-col bg-background overflow-hidden">
      <NaviHeader 
        userName={isAuthenticated ? userName : 'Sign In'} 
        isSidebarCollapsed={isSidebarCollapsed}
        onToggleSidebar={handleToggleSidebar}
      />
      
      {/* Notification Panel */}
      <NotificationPanel
        isOpen={notificationOpen}
        onClose={() => setNotificationOpen(false)}
        notifications={notifications}
        onMarkAsRead={markAsRead}
        onMarkAllRead={markAllRead}
        onClearAll={clearAll}
      />
      
      <CommandPalette open={commandPaletteOpen} onOpenChange={setCommandPaletteOpen} />
      <KeyboardShortcutsModal open={shortcutsModalOpen} onOpenChange={setShortcutsModalOpen} />
      
      <div className="flex-1 flex overflow-hidden relative">
        <IntegrationsSidebar 
          activeView={editorView || 'chat'}
          onViewChange={handleViewChange}
          onIntegrationSelect={handleIntegrationSelect}
          activeIntegration={activeIntegration}
          onSettingsClick={handleSettingsClick}
          onProfileClick={handleProfileClick}
          onHistoryClick={handleHistoryClick}
          onNotificationClick={handleNotificationClick}
          onApprovalsClick={handleApprovalsClick}
          notificationCount={unreadCount}
          isCollapsed={isSidebarCollapsed}
          isIndexing={isIndexing}
          indexProgress={indexProgress}
          repoIndex={repoIndex}
          onRefreshIndex={handleRefreshIndex}
        />
        
        {/* Main Content with Resizable Panels */}
        <ResizablePanelGroup direction="horizontal" className="flex-1">
          {/* Chat Panel */}
          <ResizablePanel id="chat-panel" order={1} defaultSize={editorView ? 60 : 100} minSize={30}>
            <div className="flex flex-col h-full">
              <div className="flex-1 overflow-hidden">
                <NaviChat 
                  selectedTask={selectedTask} 
                  userName={userName} 
                  jiraTasks={jiraTasks}
                  onTaskClick={handleTaskSelect}
                />
              </div>
              <TerminalPanel 
                isExpanded={isTerminalExpanded}
                onToggleExpand={() => setIsTerminalExpanded(!isTerminalExpanded)}
              />
            </div>
          </ResizablePanel>

          {/* Editor Panel - Conditionally shown */}
          {editorView && (
            <>
              <ResizableHandle withHandle className="bg-border hover:bg-primary/20 transition-colors" />
              <ResizablePanel id="editor-panel" order={2} defaultSize={40} minSize={20} maxSize={70}>
                {editorView === 'autonomous-workflow' && workflowTask ? (
                  <AutonomousWorkflowPanel 
                    task={workflowTask}
                    onClose={handleCloseWorkflow}
                    owner={repoIndex?.owner}
                    repo={repoIndex?.repo}
                    onPreviewCode={(files, branch) => {
                      setGeneratedFiles(files);
                      setWorkflowBranchName(branch);
                      setEditorView('code-preview');
                    }}
                  />
                ) : editorView === 'workflow' && workflowTask ? (
                  <EndToEndWorkflowPanel 
                    task={workflowTask}
                    onClose={handleCloseWorkflow}
                  />
                ) : editorView === 'workflow-analytics' ? (
                  <div className="flex flex-col h-full bg-panel-content">
                    <div className="h-12 flex items-center justify-between px-4 border-b border-border bg-panel-header">
                      <span className="font-medium text-sm">Workflow Analytics</span>
                    </div>
                    <div className="flex-1 overflow-auto p-4">
                      <WorkflowAnalyticsDashboard />
                    </div>
                  </div>
                ) : editorView === 'workflow-queue' ? (
                  <div className="flex flex-col h-full bg-panel-content">
                    <div className="h-12 flex items-center justify-between px-4 border-b border-border bg-panel-header">
                      <span className="font-medium text-sm">Workflow Queue</span>
                    </div>
                    <div className="flex-1 overflow-auto p-4">
                      <WorkflowQueuePanel />
                    </div>
                  </div>
                ) : (
                  <EditorPanel 
                    activeView={editorView}
                    onClose={handleCloseEditor}
                    selectedTask={selectedTask}
                    onTaskSelect={handleTaskSelect}
                    selectedFileName={selectedFileName}
                    onFileSelect={setSelectedFileName}
                    onStartWorkflow={handleStartWorkflow}
                    generatedFiles={generatedFiles}
                    onCommitFiles={handleCommitFiles}
                    isCommitting={codeImpl.isCommitting}
                  />
                )}
              </ResizablePanel>
            </>
          )}
        </ResizablePanelGroup>

        {/* Quick Actions FAB */}
        <QuickActionsButton
          currentView={editorView}
          onOpenSearch={() => setEditorView('search')}
          onOpenTasks={() => setEditorView('tasks')}
          onOpenSettings={() => setEditorView('settings')}
          onOpenHistory={() => setEditorView('history')}
          onOpenNotifications={() => setNotificationOpen(true)}
          onOpenShortcuts={() => setShortcutsModalOpen(true)}
          onFocusChat={() => {
            setEditorView(null);
            const chatInput = document.querySelector('input[placeholder*="NAVI"]') as HTMLInputElement;
            chatInput?.focus();
          }}
        />

        {/* Onboarding Guide */}
        <OnboardingGuide />
      </div>
    </div>
  );
}
