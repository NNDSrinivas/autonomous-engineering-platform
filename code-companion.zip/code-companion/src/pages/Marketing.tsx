import { Suspense, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Play, CheckCircle2, ArrowRight, Zap } from 'lucide-react';
import { Hero3DEnhanced } from '@/components/marketing/Hero3DEnhanced';
import { Navbar } from '@/components/marketing/Navbar';
import { FeatureShowcase } from '@/components/marketing/FeatureShowcase';
import { DemoSection } from '@/components/marketing/DemoSection';
import { IntegrationsGrid } from '@/components/marketing/IntegrationsGrid';
import { PricingSection } from '@/components/marketing/PricingSection';
import { StatsSection } from '@/components/marketing/StatsSection';
import { TestimonialsCarousel } from '@/components/marketing/TestimonialsCarousel';
import { CTASection } from '@/components/marketing/CTASection';
import { Footer } from '@/components/marketing/Footer';
import { AnimatedText } from '@/components/marketing/AnimatedText';
import { FAQSection } from '@/components/marketing/FAQSection';
import { CaseStudiesSection } from '@/components/marketing/CaseStudiesSection';
import { VideoTestimonialsSection } from '@/components/marketing/VideoTestimonialsSection';
import { ProductTourSection } from '@/components/marketing/ProductTourSection';
import { ParallaxBackground } from '@/components/marketing/ParallaxEffects';
import { CompareSection } from '@/components/marketing/CompareSection';
import { ChangelogSection } from '@/components/marketing/ChangelogSection';
import { BlogListSection } from '@/components/marketing/BlogListSection';
import { LiveDemoModal } from '@/components/marketing/LiveDemoModal';
import { NewsletterSection } from '@/components/marketing/NewsletterSection';

export default function Marketing() {
  const navigate = useNavigate();
  const [isDemoOpen, setIsDemoOpen] = useState(false);

  return (
    <div className="min-h-screen bg-background overflow-x-hidden">
      <Navbar />

      {/* Hero Section with 3D Background */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
        <ParallaxBackground />
        <Suspense fallback={<div className="absolute inset-0 bg-gradient-to-b from-primary/5 to-transparent" />}>
          <Hero3DEnhanced />
        </Suspense>
        
        <div className="relative z-10 max-w-7xl mx-auto px-6 py-32 text-center">
          <Badge 
            variant="outline" 
            className="mb-6 px-4 py-2 border-primary/30 bg-primary/5 backdrop-blur-sm animate-fade-in"
          >
            <Sparkles className="h-3.5 w-3.5 mr-2 text-primary" />
            Autonomous Engineering Intelligence
          </Badge>
          
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold tracking-tight mb-8 animate-fade-in" style={{ animationDelay: '0.1s' }}>
            The most powerful
            <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-accent to-primary bg-[length:200%_auto] animate-gradient">
              <AnimatedText 
                words={['engineering AI', 'coding assistant', 'workflow engine', 'task automator']} 
              />
            </span>
            <br />
            ever built
          </h1>
          
          <p className="text-xl md:text-2xl text-muted-foreground mb-10 max-w-3xl mx-auto animate-fade-in" style={{ animationDelay: '0.2s' }}>
            NAVI is not a chat assistant. It's a full-stack autonomous engineering system that understands your entire environment and executes complete workflows.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-fade-in" style={{ animationDelay: '0.3s' }}>
            <Button 
              size="lg" 
              className="h-14 px-8 text-lg bg-gradient-to-r from-primary to-accent hover:opacity-90 shadow-xl shadow-primary/30"
              onClick={() => navigate('/auth')}
            >
              <Zap className="h-5 w-5 mr-2" />
              Start Free Trial
              <ArrowRight className="h-5 w-5 ml-2" />
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="h-14 px-8 text-lg backdrop-blur-sm"
              onClick={() => setIsDemoOpen(true)}
            >
              <Play className="h-5 w-5 mr-2" />
              Live Demo
            </Button>
          </div>
          
          <div className="flex flex-wrap items-center justify-center gap-6 mt-10 text-sm text-muted-foreground animate-fade-in" style={{ animationDelay: '0.4s' }}>
            <span className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-primary" />
              No credit card required
            </span>
            <span className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-primary" />
              14-day free trial
            </span>
            <span className="flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-primary" />
              Cancel anytime
            </span>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 rounded-full border-2 border-muted-foreground/30 flex items-start justify-center p-2">
            <div className="w-1 h-2 rounded-full bg-primary animate-pulse" />
          </div>
        </div>
      </section>

      {/* Stats */}
      <StatsSection />

      {/* Features */}
      <div id="features">
        <FeatureShowcase />
      </div>

      {/* Interactive Product Tour */}
      <ProductTourSection />

      {/* Demo */}
      <DemoSection />

      {/* Video Testimonials */}
      <VideoTestimonialsSection />

      {/* Integrations */}
      <div id="integrations">
        <IntegrationsGrid />
      </div>

      {/* Testimonials */}
      <TestimonialsCarousel />

      {/* Case Studies */}
      <CaseStudiesSection />

      {/* Compare */}
      <CompareSection />

      {/* FAQ */}
      <FAQSection />

      {/* Blog */}
      <BlogListSection />

      {/* Changelog */}
      <ChangelogSection />

      {/* Pricing */}
      <div id="pricing">
        <PricingSection />
      </div>

      {/* Newsletter */}
      <NewsletterSection />

      {/* CTA */}
      <CTASection />

      {/* Footer */}
      <Footer />

      {/* Live Demo Modal */}
      <LiveDemoModal isOpen={isDemoOpen} onClose={() => setIsDemoOpen(false)} />

      {/* Custom styles for gradient animation */}
      <style>{`
        @keyframes gradient {
          0%, 100% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
        }
        .animate-gradient {
          animation: gradient 4s ease infinite;
        }
        @keyframes float {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-10px); }
        }
      `}</style>
    </div>
  );
}
