import { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, Mail, ArrowLeft, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import confetti from 'canvas-confetti';

export default function NewsletterThankYou() {
  const hasTriggeredConfetti = useRef(false);

  useEffect(() => {
    if (hasTriggeredConfetti.current) return;
    hasTriggeredConfetti.current = true;

    // Trigger confetti on page load
    const duration = 3000;
    const end = Date.now() + duration;

    const frame = () => {
      confetti({
        particleCount: 3,
        angle: 60,
        spread: 55,
        origin: { x: 0, y: 0.7 },
        colors: ['hsl(var(--primary))', 'hsl(var(--accent))', '#FFD700', '#FF6B6B', '#4ECDC4']
      });
      confetti({
        particleCount: 3,
        angle: 120,
        spread: 55,
        origin: { x: 1, y: 0.7 },
        colors: ['hsl(var(--primary))', 'hsl(var(--accent))', '#FFD700', '#FF6B6B', '#4ECDC4']
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    };

    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['hsl(var(--primary))', 'hsl(var(--accent))', '#FFD700', '#FF6B6B', '#4ECDC4']
    });

    frame();
  }, []);

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-6">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-accent/10" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-primary/5 rounded-full blur-3xl" />

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        className="relative text-center max-w-lg"
      >
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
          className="w-24 h-24 mx-auto mb-8 rounded-full bg-green-500/10 border border-green-500/30 flex items-center justify-center"
        >
          <CheckCircle className="h-12 w-12 text-green-500" />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            You're{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
              Subscribed!
            </span>
          </h1>

          <p className="text-lg text-muted-foreground mb-6">
            Thank you for joining our newsletter. We've sent a confirmation email to your inbox.
          </p>

          <div className="p-6 rounded-xl bg-card/50 backdrop-blur-sm border border-border mb-8">
            <div className="flex items-center justify-center gap-3 mb-4">
              <Mail className="h-5 w-5 text-primary" />
              <span className="font-medium">Check Your Inbox</span>
            </div>
            <p className="text-sm text-muted-foreground">
              Look for an email from us with your welcome message and what to expect from our newsletter.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild variant="outline" className="gap-2">
              <Link to="/marketing">
                <ArrowLeft className="h-4 w-4" />
                Back to Home
              </Link>
            </Button>
            <Button asChild className="gap-2 bg-gradient-to-r from-primary to-accent hover:opacity-90">
              <Link to="/">
                <Sparkles className="h-4 w-4" />
                Try NAVI Now
              </Link>
            </Button>
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
}
