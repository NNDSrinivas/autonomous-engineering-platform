import { useEffect, useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { MailX, CheckCircle, Loader2, ArrowLeft, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';

type UnsubscribeStatus = 'loading' | 'success' | 'error' | 'missing-token';

export default function NewsletterUnsubscribe() {
  const [searchParams] = useSearchParams();
  const [status, setStatus] = useState<UnsubscribeStatus>('loading');
  const token = searchParams.get('token');

  useEffect(() => {
    if (!token) {
      setStatus('missing-token');
      return;
    }

    const unsubscribe = async () => {
      try {
        const { error } = await supabase.functions.invoke('newsletter-unsubscribe', {
          body: { token }
        });

        if (error) throw error;
        setStatus('success');
      } catch (err) {
        console.error('Unsubscribe error:', err);
        setStatus('error');
      }
    };

    unsubscribe();
  }, [token]);

  return (
    <div className="min-h-screen bg-background flex items-center justify-center px-6">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-accent/10" />

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="relative text-center max-w-lg"
      >
        {status === 'loading' && (
          <>
            <div className="w-24 h-24 mx-auto mb-8 rounded-full bg-muted flex items-center justify-center">
              <Loader2 className="h-12 w-12 text-muted-foreground animate-spin" />
            </div>
            <h1 className="text-3xl font-bold mb-4">Processing...</h1>
            <p className="text-muted-foreground">Please wait while we unsubscribe you.</p>
          </>
        )}

        {status === 'success' && (
          <>
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', stiffness: 200 }}
              className="w-24 h-24 mx-auto mb-8 rounded-full bg-green-500/10 border border-green-500/30 flex items-center justify-center"
            >
              <CheckCircle className="h-12 w-12 text-green-500" />
            </motion.div>
            <h1 className="text-3xl font-bold mb-4">Unsubscribed Successfully</h1>
            <p className="text-muted-foreground mb-8">
              You've been removed from our newsletter. We're sorry to see you go!
            </p>
            <Button asChild variant="outline" className="gap-2">
              <Link to="/marketing">
                <ArrowLeft className="h-4 w-4" />
                Back to Home
              </Link>
            </Button>
          </>
        )}

        {status === 'error' && (
          <>
            <div className="w-24 h-24 mx-auto mb-8 rounded-full bg-destructive/10 border border-destructive/30 flex items-center justify-center">
              <AlertCircle className="h-12 w-12 text-destructive" />
            </div>
            <h1 className="text-3xl font-bold mb-4">Something Went Wrong</h1>
            <p className="text-muted-foreground mb-8">
              We couldn't process your request. The link may have expired or is invalid.
            </p>
            <Button asChild variant="outline" className="gap-2">
              <Link to="/marketing">
                <ArrowLeft className="h-4 w-4" />
                Back to Home
              </Link>
            </Button>
          </>
        )}

        {status === 'missing-token' && (
          <>
            <div className="w-24 h-24 mx-auto mb-8 rounded-full bg-muted flex items-center justify-center">
              <MailX className="h-12 w-12 text-muted-foreground" />
            </div>
            <h1 className="text-3xl font-bold mb-4">Invalid Link</h1>
            <p className="text-muted-foreground mb-8">
              This unsubscribe link is missing required information.
            </p>
            <Button asChild variant="outline" className="gap-2">
              <Link to="/marketing">
                <ArrowLeft className="h-4 w-4" />
                Back to Home
              </Link>
            </Button>
          </>
        )}
      </motion.div>
    </div>
  );
}
