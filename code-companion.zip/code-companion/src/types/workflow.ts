// Workflow and Task Execution Types

export type WorkflowStepStatus = 
  | 'pending' 
  | 'awaiting_approval' 
  | 'approved' 
  | 'executing' 
  | 'completed' 
  | 'failed' 
  | 'skipped';

export type WorkflowStatus = 
  | 'idle' 
  | 'running' 
  | 'paused' 
  | 'completed' 
  | 'failed' 
  | 'cancelled';

export type StepActionType = 
  | 'create_branch'
  | 'create_pr'
  | 'update_file'
  | 'commit_changes'
  | 'run_tests'
  | 'run_build'
  | 'merge_pr'
  | 'deploy'
  | 'notify_slack'
  | 'update_jira'
  | 'code_review'
  | 'notify'
  | 'update_docs'
  | 'rollback'
  | 'custom';

export interface WorkflowStep {
  id: string;
  name: string;
  description: string;
  actionType: StepActionType;
  status: WorkflowStepStatus;
  requiresApproval: boolean;
  riskLevel: 'low' | 'medium' | 'high';
  params: Record<string, unknown>;
  result?: {
    success: boolean;
    message: string;
    data?: Record<string, unknown>;
    error?: string;
  };
  startedAt?: Date;
  completedAt?: Date;
  dependsOn?: string[]; // IDs of steps that must complete first
}

export interface WorkflowContext {
  taskKey?: string;
  repository?: string;
  repoOwner?: string;
  repoName?: string;
  branch?: string;
  baseBranch?: string;
  targetBranch?: string;
  prTitle?: string;
  prBody?: string;
  prNumber?: number;
  [key: string]: string | number | boolean | undefined;
}

export interface Workflow {
  id: string;
  name: string;
  description: string;
  status: WorkflowStatus;
  steps: WorkflowStep[];
  currentStepIndex: number;
  context: WorkflowContext;
  createdAt: Date;
  startedAt?: Date;
  completedAt?: Date;
  error?: string;
}

export interface WorkflowTemplate {
  id: string;
  name: string;
  description: string;
  category: 'development' | 'release' | 'hotfix' | 'maintenance' | 'custom';
  steps: Omit<WorkflowStep, 'id' | 'status' | 'result' | 'startedAt' | 'completedAt'>[];
}

// Predefined workflow templates
export const WORKFLOW_TEMPLATES: WorkflowTemplate[] = [
  {
    id: 'feature-development',
    name: 'Feature Development',
    description: 'Complete workflow from branch creation to PR merge',
    category: 'development',
    steps: [
      {
        name: 'Create Feature Branch',
        description: 'Create a new branch from main/develop',
        actionType: 'create_branch',
        requiresApproval: true,
        riskLevel: 'low',
        params: {},
      },
      {
        name: 'Implement Changes',
        description: 'Apply code changes to implement the feature',
        actionType: 'update_file',
        requiresApproval: true,
        riskLevel: 'medium',
        params: {},
      },
      {
        name: 'Commit Changes',
        description: 'Commit all changes with a descriptive message',
        actionType: 'commit_changes',
        requiresApproval: true,
        riskLevel: 'low',
        params: {},
      },
      {
        name: 'Run Tests',
        description: 'Execute test suite to validate changes',
        actionType: 'run_tests',
        requiresApproval: false,
        riskLevel: 'low',
        params: {},
      },
      {
        name: 'Create Pull Request',
        description: 'Create PR for code review',
        actionType: 'create_pr',
        requiresApproval: true,
        riskLevel: 'medium',
        params: {},
      },
      {
        name: 'Update Jira',
        description: 'Update task status to In Review',
        actionType: 'update_jira',
        requiresApproval: false,
        riskLevel: 'low',
        params: { status: 'in_review' },
      },
    ],
  },
  {
    id: 'hotfix-deployment',
    name: 'Hotfix Deployment',
    description: 'Urgent fix with expedited review and deployment',
    category: 'hotfix',
    steps: [
      {
        name: 'Create Hotfix Branch',
        description: 'Create hotfix branch from production',
        actionType: 'create_branch',
        requiresApproval: true,
        riskLevel: 'medium',
        params: { prefix: 'hotfix/' },
      },
      {
        name: 'Apply Fix',
        description: 'Apply the hotfix changes',
        actionType: 'update_file',
        requiresApproval: true,
        riskLevel: 'high',
        params: {},
      },
      {
        name: 'Run Critical Tests',
        description: 'Run critical path tests',
        actionType: 'run_tests',
        requiresApproval: false,
        riskLevel: 'low',
        params: { suite: 'critical' },
      },
      {
        name: 'Create Emergency PR',
        description: 'Create PR with priority label',
        actionType: 'create_pr',
        requiresApproval: true,
        riskLevel: 'medium',
        params: { labels: ['hotfix', 'priority'] },
      },
      {
        name: 'Merge to Production',
        description: 'Merge hotfix to production branch',
        actionType: 'merge_pr',
        requiresApproval: true,
        riskLevel: 'high',
        params: {},
      },
      {
        name: 'Deploy',
        description: 'Trigger production deployment',
        actionType: 'deploy',
        requiresApproval: true,
        riskLevel: 'high',
        params: { environment: 'production' },
      },
      {
        name: 'Notify Team',
        description: 'Send deployment notification to team',
        actionType: 'notify_slack',
        requiresApproval: false,
        riskLevel: 'low',
        params: { channel: '#engineering' },
      },
    ],
  },
  {
    id: 'pr-review-cycle',
    name: 'PR Review Cycle',
    description: 'Handle PR feedback and iterate',
    category: 'development',
    steps: [
      {
        name: 'Apply Review Feedback',
        description: 'Implement changes requested in PR review',
        actionType: 'update_file',
        requiresApproval: true,
        riskLevel: 'medium',
        params: {},
      },
      {
        name: 'Push Updates',
        description: 'Commit and push the review changes',
        actionType: 'commit_changes',
        requiresApproval: true,
        riskLevel: 'low',
        params: {},
      },
      {
        name: 'Re-run Tests',
        description: 'Verify all tests still pass',
        actionType: 'run_tests',
        requiresApproval: false,
        riskLevel: 'low',
        params: {},
      },
    ],
  },
];
