import type { WorkflowPhase } from '@/hooks/useEndToEndWorkflow';

export interface WorkflowTemplate {
  id: string;
  name: string;
  description: string;
  icon: string;
  phases: WorkflowPhase[];
  isDefault?: boolean;
}

export const defaultWorkflowTemplates: WorkflowTemplate[] = [
  {
    id: 'full',
    name: 'Full Workflow',
    description: 'Complete end-to-end workflow with all phases',
    icon: 'Zap',
    phases: ['start_task', 'create_branch', 'implement_code', 'create_pr', 'link_jira', 'post_slack'],
    isDefault: true,
  },
  {
    id: 'quick-pr',
    name: 'Quick PR',
    description: 'Skip Jira/Slack, just create branch and PR',
    icon: 'GitPullRequest',
    phases: ['create_branch', 'implement_code', 'create_pr'],
  },
  {
    id: 'code-only',
    name: 'Code Only',
    description: 'Just implement code without git operations',
    icon: 'Code',
    phases: ['start_task', 'implement_code'],
  },
  {
    id: 'notify-only',
    name: 'Notify Team',
    description: 'Update Jira and notify Slack without code changes',
    icon: 'MessageSquare',
    phases: ['start_task', 'link_jira', 'post_slack'],
  },
  {
    id: 'review-ready',
    name: 'Review Ready',
    description: 'Branch, code, and PR - ready for review',
    icon: 'CheckCircle',
    phases: ['start_task', 'create_branch', 'implement_code', 'create_pr', 'link_jira'],
  },
];

export interface ActiveWorkflow {
  taskId: string;
  taskKey: string;
  templateId: string;
  currentPhase: WorkflowPhase;
  progress: number;
  startedAt: Date;
}
