import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, upgrade, connection',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
};

// Agent activity event types
type AgentEventType = 
  | 'activity_started'
  | 'phase_changed'
  | 'thought_updated'
  | 'file_activity'
  | 'step_started'
  | 'step_completed'
  | 'command_pending'
  | 'command_executed'
  | 'stats_updated'
  | 'activity_completed'
  | 'error'
  | 'ai_response_chunk'
  | 'ai_response_complete';

interface AgentEvent {
  type: AgentEventType;
  timestamp: string;
  data: Record<string, unknown>;
}

// Store for connected WebSocket clients by session
const connectedClients = new Map<string, WebSocket[]>();

// Broadcast event to all clients in a session
function broadcastToSession(sessionId: string, event: AgentEvent) {
  const clients = connectedClients.get(sessionId) || [];
  const message = JSON.stringify(event);
  
  clients.forEach(ws => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(message);
    }
  });
}

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const url = new URL(req.url);
  const sessionId = url.searchParams.get('sessionId') || crypto.randomUUID();
  const action = url.searchParams.get('action');

  console.log(`[Agent Activity] Session: ${sessionId}, Action: ${action}, Method: ${req.method}`);

  // Check for WebSocket upgrade
  const upgradeHeader = req.headers.get('upgrade') || '';
  if (upgradeHeader.toLowerCase() === 'websocket') {
    console.log(`[Agent Activity] WebSocket upgrade requested for session: ${sessionId}`);
    
    try {
      const { socket, response } = Deno.upgradeWebSocket(req);
      
      // Add client to session
      if (!connectedClients.has(sessionId)) {
        connectedClients.set(sessionId, []);
      }
      connectedClients.get(sessionId)!.push(socket);
      
      socket.onopen = () => {
        console.log(`[Agent Activity] WebSocket connected for session: ${sessionId}`);
        
        // Send initial connection event
        const connectEvent: AgentEvent = {
          type: 'activity_started',
          timestamp: new Date().toISOString(),
          data: { 
            sessionId,
            message: 'Connected to agent activity stream via WebSocket',
            phase: 'idle',
          },
        };
        socket.send(JSON.stringify(connectEvent));
      };
      
      socket.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          console.log(`[Agent Activity] Received WebSocket message:`, data);
          
          // Handle different message types
          if (data.type === 'broadcast') {
            // Broadcast to all clients in this session
            const agentEvent: AgentEvent = {
              type: data.eventType || 'thought_updated',
              timestamp: new Date().toISOString(),
              data: data.payload || {},
            };
            broadcastToSession(sessionId, agentEvent);
          } else if (data.type === 'emit_events') {
            // Process and broadcast multiple events
            const events = data.events as AgentEvent[];
            events?.forEach(evt => {
              broadcastToSession(sessionId, evt);
            });
          } else if (data.type === 'ai_response') {
            // Parse AI response content for file operations
            const parsed = parseAIResponse(data.content);
            parsed.forEach(evt => {
              broadcastToSession(sessionId, evt);
            });
          }
        } catch (error) {
          console.error(`[Agent Activity] Error processing WebSocket message:`, error);
        }
      };
      
      socket.onclose = () => {
        console.log(`[Agent Activity] WebSocket closed for session: ${sessionId}`);
        
        // Remove client from session
        const clients = connectedClients.get(sessionId) || [];
        const index = clients.indexOf(socket);
        if (index > -1) {
          clients.splice(index, 1);
        }
        if (clients.length === 0) {
          connectedClients.delete(sessionId);
        }
      };
      
      socket.onerror = (error) => {
        console.error(`[Agent Activity] WebSocket error for session ${sessionId}:`, error);
      };
      
      return response;
    } catch (error) {
      console.error('[Agent Activity] WebSocket upgrade failed:', error);
      return new Response(JSON.stringify({ error: 'WebSocket upgrade failed' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
  }

  // POST endpoint to emit events (HTTP fallback)
  if (req.method === 'POST') {
    try {
      const body = await req.json();
      const { events, aiResponse } = body as { events?: AgentEvent[]; aiResponse?: string };

      console.log(`[Agent Activity] POST - Emitting ${events?.length || 0} events for session ${sessionId}`);

      // Process events
      if (events) {
        events.forEach(evt => {
          broadcastToSession(sessionId, evt);
        });
      }

      // Parse AI response if provided
      if (aiResponse) {
        const parsed = parseAIResponse(aiResponse);
        parsed.forEach(evt => {
          broadcastToSession(sessionId, evt);
        });
        
        return new Response(JSON.stringify({ 
          success: true, 
          sessionId,
          eventsReceived: events?.length || 0,
          parsedEvents: parsed.length,
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      return new Response(JSON.stringify({ 
        success: true, 
        sessionId,
        eventsReceived: events?.length || 0 
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    } catch (error) {
      console.error('[Agent Activity] Error processing events:', error);
      return new Response(JSON.stringify({ error: 'Failed to process events' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }
  }

  // GET endpoint for SSE streaming (fallback for clients that don't support WebSocket)
  if (req.method === 'GET') {
    console.log(`[Agent Activity] Starting SSE stream for session ${sessionId}`);

    const encoder = new TextEncoder();
    const stream = new ReadableStream({
      start(controller) {
        // Send initial connection event
        const connectEvent: AgentEvent = {
          type: 'activity_started',
          timestamp: new Date().toISOString(),
          data: { 
            sessionId,
            message: 'Connected to agent activity stream',
            phase: 'idle',
          },
        };
        controller.enqueue(encoder.encode(`data: ${JSON.stringify(connectEvent)}\n\n`));

        // Heartbeat to keep connection alive
        const heartbeatInterval = setInterval(() => {
          try {
            controller.enqueue(encoder.encode(`: heartbeat\n\n`));
          } catch {
            clearInterval(heartbeatInterval);
          }
        }, 15000);

        // Cleanup on close
        req.signal.addEventListener('abort', () => {
          console.log(`[Agent Activity] SSE client disconnected: ${sessionId}`);
          clearInterval(heartbeatInterval);
          controller.close();
        });
      },
    });

    return new Response(stream, {
      headers: {
        ...corsHeaders,
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection': 'keep-alive',
      },
    });
  }

  return new Response(JSON.stringify({ error: 'Method not allowed' }), {
    status: 405,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
});

// Parse AI response content for file operations and code changes
function parseAIResponse(content: string): AgentEvent[] {
  const events: AgentEvent[] = [];
  const timestamp = new Date().toISOString();

  // Detect phase based on content
  if (content.includes('Analyzing') || content.includes('analyzing') || content.includes('Looking at')) {
    events.push({
      type: 'phase_changed',
      timestamp,
      data: { phase: 'analyzing', thought: 'Analyzing the request...' },
    });
  }

  if (content.includes('Reading') || content.includes('reading') || content.includes('Checking')) {
    events.push({
      type: 'phase_changed',
      timestamp,
      data: { phase: 'reading', thought: 'Reading relevant files...' },
    });
  }

  // Detect file operations with various patterns
  const filePatterns = [
    // Pattern: file path mentions
    /(?:Reading|Writing|Creating|Editing|Updating|Modified|Created|Deleted|Viewing)\s+[`"]?([a-zA-Z0-9_\-\/\.]+\.[a-zA-Z]+)[`"]?/gi,
    // Pattern: code blocks with file paths
    /```(?:typescript|javascript|tsx|jsx|ts|js|css|html|json)?\s*\n?\/\/\s*([a-zA-Z0-9_\-\/\.]+\.[a-zA-Z]+)/gi,
    // Pattern: src/ or supabase/ paths
    /(?:src|supabase|components|hooks|pages|lib|utils)\/[a-zA-Z0-9_\-\/]+\.[a-zA-Z]+/gi,
  ];

  const detectedFiles = new Set<string>();
  
  for (const pattern of filePatterns) {
    let match;
    while ((match = pattern.exec(content)) !== null) {
      const filePath = match[1] || match[0];
      if (filePath && !detectedFiles.has(filePath)) {
        detectedFiles.add(filePath);
        
        // Determine action based on context
        const lowerContent = content.toLowerCase();
        let action: 'read' | 'write' | 'create' | 'delete' = 'read';
        if (lowerContent.includes('creating') || lowerContent.includes('created') || lowerContent.includes('new file')) {
          action = 'create';
        } else if (lowerContent.includes('editing') || lowerContent.includes('writing') || lowerContent.includes('updating') || lowerContent.includes('modified')) {
          action = 'write';
        } else if (lowerContent.includes('deleting') || lowerContent.includes('removed')) {
          action = 'delete';
        }
        
        events.push({
          type: 'file_activity',
          timestamp,
          data: {
            file: {
              id: `file-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
              path: filePath,
              action,
              status: 'active',
            },
          },
        });
      }
    }
  }

  // Detect code blocks as writing phase
  const codeBlockCount = (content.match(/```/g) || []).length / 2;
  if (codeBlockCount > 0) {
    events.push({
      type: 'phase_changed',
      timestamp,
      data: { phase: 'writing', thought: `Writing code changes...` },
    });
    
    // Estimate lines changed
    const codeContent = content.match(/```[\s\S]*?```/g) || [];
    const totalLines = codeContent.reduce((acc, block) => {
      return acc + (block.split('\n').length - 2); // Subtract opening and closing ```
    }, 0);
    
    if (totalLines > 0) {
      events.push({
        type: 'stats_updated',
        timestamp,
        data: { 
          linesChanged: totalLines,
          totalEdits: detectedFiles.size,
        },
      });
    }
  }

  // Detect completion indicators
  if (content.includes('Done') || content.includes('Completed') || content.includes('finished') || 
      content.includes('Successfully') || content.includes('All changes')) {
    events.push({
      type: 'activity_completed',
      timestamp,
      data: { message: 'Changes completed' },
    });
  }

  // Add thought update with content summary
  if (content.length > 0 && events.length > 0) {
    const summary = content.slice(0, 100).replace(/\n/g, ' ').trim();
    events.unshift({
      type: 'thought_updated',
      timestamp,
      data: { thought: summary + (content.length > 100 ? '...' : '') },
    });
  }

  return events;
}
