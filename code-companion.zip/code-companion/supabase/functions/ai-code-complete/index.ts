import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface CompletionRequest {
  prefix: string;
  suffix: string;
  language: string;
  fileName: string;
  maxTokens?: number;
  // Multi-file context
  imports?: string[];
  relatedFiles?: Array<{
    fileName: string;
    content: string;
    relevance: 'high' | 'medium' | 'low';
  }>;
  projectStructure?: string[];
  recentEdits?: Array<{
    fileName: string;
    snippet: string;
  }>;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { 
      prefix, 
      suffix, 
      language, 
      fileName, 
      maxTokens = 150,
      imports = [],
      relatedFiles = [],
      projectStructure = [],
      recentEdits = []
    } = await req.json() as CompletionRequest;

    if (!prefix) {
      return new Response(
        JSON.stringify({ error: 'Prefix is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    // Build context-aware prompts
    const systemPrompt = buildSystemPrompt(language, fileName, imports, projectStructure);
    const userPrompt = buildUserPrompt(prefix, suffix, language, relatedFiles, recentEdits);

    console.log(`[ai-code-complete] Generating completion for ${language} file: ${fileName} with ${relatedFiles.length} related files`);

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
        max_tokens: maxTokens,
        temperature: 0.2,
        stop: ['\n\n\n', '```', '// END', '/* END'],
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: 'Rate limit exceeded. Please try again later.' }),
          { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: 'Usage limit reached. Please add credits.' }),
          { status: 402, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      const errorText = await response.text();
      console.error('[ai-code-complete] API error:', response.status, errorText);
      throw new Error(`AI API error: ${response.status}`);
    }

    const data = await response.json();
    const completion = data.choices?.[0]?.message?.content || '';

    // Clean up the completion
    const cleanedCompletion = cleanCompletion(completion, prefix);

    console.log(`[ai-code-complete] Generated ${cleanedCompletion.length} chars`);

    return new Response(
      JSON.stringify({ 
        completion: cleanedCompletion,
        language,
        fileName 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('[ai-code-complete] Error:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

function buildSystemPrompt(
  language: string, 
  fileName: string,
  imports: string[],
  projectStructure: string[]
): string {
  let prompt = `You are NAVI, an expert code completion engine integrated into VS Code.

Your task is to complete code naturally and intelligently based on context.

RULES:
1. Output ONLY the code completion - no explanations, no markdown, no backticks
2. Continue naturally from where the code left off
3. Match the coding style, indentation, and patterns in the existing code
4. Be concise - complete the immediate logical unit (function, statement, block)
5. Consider the file type (${language}) and file name (${fileName}) for context
6. If completing a function, include proper return statements
7. If completing an import, suggest commonly used imports for the detected framework
8. Respect TypeScript types if present
9. Add appropriate semicolons/formatting based on detected style

LANGUAGE-SPECIFIC HINTS:
${getLanguageHints(language)}`;

  // Add import context
  if (imports.length > 0) {
    prompt += `

AVAILABLE IMPORTS IN THIS FILE:
${imports.slice(0, 20).join('\n')}`;
  }

  // Add project structure context
  if (projectStructure.length > 0) {
    prompt += `

PROJECT STRUCTURE (relevant files):
${projectStructure.slice(0, 30).join('\n')}`;
  }

  prompt += `

Remember: Output ONLY the completion text, nothing else.`;

  return prompt;
}

function buildUserPrompt(
  prefix: string, 
  suffix: string, 
  language: string,
  relatedFiles: Array<{ fileName: string; content: string; relevance: string }>,
  recentEdits: Array<{ fileName: string; snippet: string }>
): string {
  let prompt = '';

  // Add related files context (high relevance first)
  const highRelevance = relatedFiles.filter(f => f.relevance === 'high').slice(0, 3);
  if (highRelevance.length > 0) {
    prompt += `RELATED CODE CONTEXT:\n`;
    for (const file of highRelevance) {
      prompt += `--- ${file.fileName} ---\n${file.content.slice(0, 500)}\n\n`;
    }
  }

  // Add recent edits for consistency
  if (recentEdits.length > 0) {
    prompt += `RECENT EDITS (for style consistency):\n`;
    for (const edit of recentEdits.slice(0, 2)) {
      prompt += `${edit.fileName}: ${edit.snippet.slice(0, 200)}\n`;
    }
    prompt += '\n';
  }

  prompt += `Complete the following ${language} code. Output ONLY the completion.

CODE BEFORE CURSOR:
\`\`\`${language}
${prefix}
\`\`\``;

  if (suffix && suffix.trim()) {
    prompt += `

CODE AFTER CURSOR:
\`\`\`${language}
${suffix}
\`\`\``;
  }

  prompt += `

Complete the code naturally. Output ONLY the completion text:`;

  return prompt;
}

function getLanguageHints(language: string): string {
  const hints: Record<string, string> = {
    typescript: `- Use TypeScript types and interfaces
- Import from common libraries like React, lodash, date-fns
- Use async/await for promises
- Prefer const and arrow functions`,
    
    typescriptreact: `- Use React hooks (useState, useEffect, useMemo, useCallback)
- Import from shadcn/ui components when appropriate
- Use Tailwind CSS classes for styling
- Follow React component patterns`,
    
    javascript: `- Use modern ES6+ syntax
- Prefer const/let over var
- Use template literals for strings
- Use destructuring when appropriate`,
    
    javascriptreact: `- Use React hooks and functional components
- Import PropTypes if needed
- Use JSX best practices`,
    
    python: `- Use type hints when appropriate
- Follow PEP 8 style guidelines
- Use f-strings for formatting
- Import commonly used libraries (os, sys, json, requests)`,
    
    rust: `- Use proper ownership and borrowing
- Handle Results and Options appropriately
- Use pattern matching
- Follow Rust naming conventions`,
    
    go: `- Use proper error handling patterns
- Follow Go naming conventions
- Use goroutines and channels appropriately`,
    
    sql: `- Use proper SQL formatting
- Include table aliases for joins
- Use parameterized queries patterns`,
  };

  return hints[language] || '- Follow standard conventions for this language';
}

function cleanCompletion(completion: string, prefix: string): string {
  let cleaned = completion.trim();
  
  // Remove markdown code blocks if present
  cleaned = cleaned.replace(/^```[\w]*\n?/g, '');
  cleaned = cleaned.replace(/\n?```$/g, '');
  
  // Remove any leading/trailing backticks
  cleaned = cleaned.replace(/^`+|`+$/g, '');
  
  // Remove "Here's the completion:" type prefixes
  cleaned = cleaned.replace(/^(Here'?s?\s*(the\s*)?(code\s*)?(completion|suggestion)[:\s]*)/i, '');
  
  // If the completion starts with the same text as the end of prefix, remove the overlap
  const prefixEnd = prefix.slice(-50);
  const overlapIndex = cleaned.indexOf(prefixEnd);
  if (overlapIndex === 0) {
    cleaned = cleaned.slice(prefixEnd.length);
  }
  
  // Trim any leading newlines but preserve indentation
  cleaned = cleaned.replace(/^\n+/, '');
  
  return cleaned;
}
