import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface CodeGenerationRequest {
  taskKey: string;
  taskTitle: string;
  taskDescription: string;
  acceptanceCriteria?: string;
  existingCode?: string;
  fileContext?: string[];
  action: 'generate' | 'refactor' | 'fix' | 'test';
  userInstructions?: string;
  includeDocumentation?: boolean;
}

interface IntegrationContext {
  confluencePages?: any[];
  slackMessages?: any[];
  jiraComments?: any[];
  meetingNotes?: any[];
  relatedPRs?: any[];
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const supabase = createClient(supabaseUrl, supabaseServiceKey);

  try {
    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    // Get user from auth header
    const authHeader = req.headers.get('Authorization');
    let userId: string | null = null;
    
    if (authHeader) {
      const token = authHeader.replace('Bearer ', '');
      const { data: { user } } = await supabase.auth.getUser(token);
      userId = user?.id || null;
    }

    const { 
      taskKey, 
      taskTitle, 
      taskDescription, 
      acceptanceCriteria, 
      existingCode, 
      fileContext, 
      action,
      userInstructions,
      includeDocumentation = true 
    }: CodeGenerationRequest = await req.json();
    
    console.log(`[ai-code-generator] Processing ${action} request for task ${taskKey}`);

    // Gather context from connected integrations if user is authenticated
    let integrationContext: IntegrationContext = {};
    
    if (userId && includeDocumentation) {
      integrationContext = await gatherIntegrationContext(supabase, userId, taskKey, taskTitle);
      console.log(`[ai-code-generator] Gathered context: ${Object.keys(integrationContext).filter(k => (integrationContext as any)[k]?.length > 0).join(', ')}`);
    }

    const systemPrompt = buildSystemPrompt(action);
    const userPrompt = buildUserPrompt({
      action,
      taskKey,
      taskTitle,
      taskDescription,
      acceptanceCriteria,
      existingCode,
      fileContext,
      userInstructions,
      integrationContext,
    });

    console.log(`[ai-code-generator] Sending request to Lovable AI...`);

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('[ai-code-generator] API error:', response.status, errorText);
      
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: 'Rate limit exceeded. Please try again later.' }), {
          status: 429,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: 'Usage limit reached. Please add credits.' }), {
          status: 402,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      throw new Error(`AI API error: ${response.status}`);
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;

    if (!content) {
      throw new Error('No content in AI response');
    }

    // Try to parse JSON from the response
    let parsedResponse;
    try {
      // Extract JSON from markdown code blocks if present
      const jsonMatch = content.match(/```(?:json)?\s*([\s\S]*?)```/);
      const jsonStr = jsonMatch ? jsonMatch[1] : content;
      parsedResponse = JSON.parse(jsonStr.trim());
    } catch {
      // If not valid JSON, wrap the content as a single file
      parsedResponse = {
        files: [{
          path: 'generated-code.tsx',
          content: content,
          action: 'create',
          description: 'AI-generated code'
        }],
        summary: 'Code generated based on task requirements',
        estimatedImpact: 'medium',
        testSuggestions: [],
        contextUsed: Object.keys(integrationContext).filter(k => (integrationContext as any)[k]?.length > 0),
      };
    }

    // Add context information to the response
    parsedResponse.contextUsed = Object.keys(integrationContext).filter(k => (integrationContext as any)[k]?.length > 0);

    console.log(`[ai-code-generator] Generated ${parsedResponse.files?.length || 0} file suggestions`);

    return new Response(JSON.stringify({
      success: true,
      taskKey,
      ...parsedResponse
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('[ai-code-generator] Error:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Unknown error' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

function buildSystemPrompt(action: string): string {
  return `You are an expert software engineer and AI coding assistant. Your task is to generate high-quality, production-ready code based on Jira task requirements and available documentation context.

## Your Capabilities:
- Generate clean, maintainable TypeScript/React code
- Follow best practices and modern design patterns
- Consider architectural implications and code organization
- Include proper error handling and edge cases
- Write comprehensive unit tests when requested
- Understand and incorporate context from Confluence docs, Slack discussions, meeting notes, and PR comments

## Response Format:
ALWAYS respond with a valid JSON object containing:
{
  "files": [
    {
      "path": "src/components/Example.tsx",
      "content": "// full file content here",
      "action": "create" | "modify" | "delete",
      "description": "Brief description of changes"
    }
  ],
  "summary": "Overall summary of changes (2-3 sentences)",
  "estimatedImpact": "low" | "medium" | "high",
  "testSuggestions": ["List of test cases to add"],
  "architecturalNotes": "Any important architectural decisions or considerations",
  "dependenciesNeeded": ["list of npm packages if any new ones needed"]
}

## Code Quality Requirements:
- Use semantic and descriptive variable/function names
- Add JSDoc comments for complex functions and exported components
- Follow React best practices (hooks, proper state management)
- Use TypeScript types properly (no 'any' unless absolutely necessary)
- Implement proper error boundaries and error handling
- Consider accessibility (a11y) in UI components
- Write code that is easy to test

## Action-Specific Guidelines:
${action === 'generate' ? '- Focus on implementing the feature from scratch with clean architecture' : ''}
${action === 'refactor' ? '- Improve code quality while maintaining existing functionality' : ''}
${action === 'fix' ? '- Identify the root cause and fix the bug with minimal changes' : ''}
${action === 'test' ? '- Generate comprehensive unit tests covering happy paths and edge cases' : ''}
`;
}

function buildUserPrompt(params: {
  action: string;
  taskKey: string;
  taskTitle: string;
  taskDescription: string;
  acceptanceCriteria?: string;
  existingCode?: string;
  fileContext?: string[];
  userInstructions?: string;
  integrationContext: IntegrationContext;
}): string {
  const {
    action,
    taskKey,
    taskTitle,
    taskDescription,
    acceptanceCriteria,
    existingCode,
    fileContext,
    userInstructions,
    integrationContext,
  } = params;

  const actionPrompts = {
    generate: 'Generate new code to implement this feature:',
    refactor: 'Refactor the existing code to improve quality while implementing:',
    fix: 'Fix the bug described in this task:',
    test: 'Generate comprehensive unit tests for this feature:',
  };

  let prompt = `${actionPrompts[action as keyof typeof actionPrompts] || actionPrompts.generate}

## Task: ${taskKey} - ${taskTitle}

### Description:
${taskDescription}

`;

  if (acceptanceCriteria) {
    prompt += `### Acceptance Criteria:
${acceptanceCriteria}

`;
  }

  if (userInstructions) {
    prompt += `### Additional Instructions from User:
${userInstructions}

`;
  }

  // Add integration context
  if (integrationContext.confluencePages?.length) {
    prompt += `### Related Documentation (from Confluence):
${integrationContext.confluencePages.map(p => `- **${p.title}**: ${p.excerpt || 'No excerpt available'}`).join('\n')}

`;
  }

  if (integrationContext.slackMessages?.length) {
    prompt += `### Relevant Slack Discussions:
${integrationContext.slackMessages.map(m => `- ${m.user}: "${m.text?.substring(0, 200)}${m.text?.length > 200 ? '...' : ''}"`).join('\n')}

`;
  }

  if (integrationContext.meetingNotes?.length) {
    prompt += `### Meeting Notes & Decisions:
${integrationContext.meetingNotes.map(n => `- ${n.topic}: ${n.notes?.substring(0, 300)}${n.notes?.length > 300 ? '...' : ''}`).join('\n')}

`;
  }

  if (integrationContext.relatedPRs?.length) {
    prompt += `### Related Pull Requests:
${integrationContext.relatedPRs.map(pr => `- **${pr.title}** (#${pr.number}): ${pr.state}`).join('\n')}

`;
  }

  if (existingCode) {
    prompt += `### Existing Code to Modify:
\`\`\`typescript
${existingCode}
\`\`\`

`;
  }

  if (fileContext?.length) {
    prompt += `### Related Files in Codebase:
${fileContext.join('\n')}

`;
  }

  prompt += `
Generate the code implementation now. Remember to respond with valid JSON in the specified format.`;

  return prompt;
}

async function gatherIntegrationContext(
  supabase: any,
  userId: string,
  taskKey: string,
  taskTitle: string
): Promise<IntegrationContext> {
  const context: IntegrationContext = {};

  try {
    // Get user's connected integrations
    const { data: connections } = await supabase
      .from('integration_connections')
      .select('provider, access_token, provider_metadata')
      .eq('user_id', userId)
      .eq('status', 'connected');

    if (!connections || connections.length === 0) {
      return context;
    }

    // Search keywords from task
    const searchTerms = [taskKey, ...taskTitle.split(' ').filter(w => w.length > 3)].slice(0, 5);

    // Gather Confluence documentation
    const confluenceConn = connections.find((c: any) => c.provider === 'confluence');
    if (confluenceConn) {
      try {
        const resources = confluenceConn.provider_metadata?.resources;
        if (resources?.length) {
          const cloudId = resources[0].id;
          // Search for related pages
          const searchQuery = searchTerms.join(' OR ');
          const searchRes = await fetch(
            `https://api.atlassian.com/ex/confluence/${cloudId}/wiki/rest/api/content/search?cql=text~"${encodeURIComponent(searchQuery)}"&limit=5`,
            { headers: { Authorization: `Bearer ${confluenceConn.access_token}` } }
          );
          if (searchRes.ok) {
            const searchData = await searchRes.json();
            context.confluencePages = (searchData.results || []).map((p: any) => ({
              id: p.id,
              title: p.title,
              excerpt: p.excerpt,
              url: p._links?.webui,
            }));
          }
        }
      } catch (e) {
        console.error('[ai-code-generator] Confluence search error:', e);
      }
    }

    // Gather relevant Slack messages
    const slackConn = connections.find((c: any) => c.provider === 'slack');
    if (slackConn) {
      try {
        const searchQuery = searchTerms.slice(0, 3).join(' ');
        const searchRes = await fetch(
          `https://slack.com/api/search.messages?query=${encodeURIComponent(searchQuery)}&count=10`,
          { headers: { Authorization: `Bearer ${slackConn.access_token}` } }
        );
        if (searchRes.ok) {
          const searchData = await searchRes.json();
          if (searchData.ok && searchData.messages?.matches) {
            context.slackMessages = searchData.messages.matches.slice(0, 5).map((m: any) => ({
              text: m.text,
              user: m.username || m.user,
              channel: m.channel?.name,
              ts: m.ts,
            }));
          }
        }
      } catch (e) {
        console.error('[ai-code-generator] Slack search error:', e);
      }
    }

    // Gather related GitHub PRs
    const githubConn = connections.find((c: any) => c.provider === 'github');
    if (githubConn) {
      try {
        // Search for PRs mentioning the task key
        const searchRes = await fetch(
          `https://api.github.com/search/issues?q=${encodeURIComponent(taskKey)}+type:pr&per_page=5`,
          { 
            headers: { 
              Authorization: `Bearer ${githubConn.access_token}`,
              Accept: 'application/vnd.github.v3+json',
            } 
          }
        );
        if (searchRes.ok) {
          const searchData = await searchRes.json();
          context.relatedPRs = (searchData.items || []).map((pr: any) => ({
            number: pr.number,
            title: pr.title,
            state: pr.state,
            url: pr.html_url,
          }));
        }
      } catch (e) {
        console.error('[ai-code-generator] GitHub search error:', e);
      }
    }

    // Check workspace memories for meeting notes
    try {
      const { data: memories } = await supabase
        .from('workspace_memories')
        .select('title, content, source, metadata')
        .eq('user_id', userId)
        .eq('memory_type', 'meeting_note')
        .order('created_at', { ascending: false })
        .limit(5);

      if (memories?.length) {
        context.meetingNotes = memories.map((m: any) => ({
          topic: m.title,
          notes: m.content,
          source: m.source,
        }));
      }
    } catch (e) {
      console.error('[ai-code-generator] Memory fetch error:', e);
    }

  } catch (error) {
    console.error('[ai-code-generator] Context gathering error:', error);
  }

  return context;
}
