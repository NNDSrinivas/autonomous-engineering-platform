import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface DocumentationRequest {
  code: string;
  language: string;
  fileName: string;
  docType: 'jsdoc' | 'readme' | 'api' | 'inline' | 'all';
  projectName?: string;
  existingDocs?: string;
  additionalContext?: string;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { 
      code, 
      language, 
      fileName, 
      docType = 'jsdoc',
      projectName,
      existingDocs,
      additionalContext 
    } = await req.json() as DocumentationRequest;

    if (!code) {
      return new Response(
        JSON.stringify({ error: 'Code is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    const systemPrompt = buildSystemPrompt(language, docType);
    const userPrompt = buildUserPrompt(code, language, fileName, docType, projectName, existingDocs, additionalContext);

    console.log(`[ai-documentation] Generating ${docType} docs for ${language} file: ${fileName}`);

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
        max_tokens: 3000,
        temperature: 0.3,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: 'Rate limit exceeded. Please try again later.' }),
          { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: 'Usage limit reached. Please add credits.' }),
          { status: 402, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      const errorText = await response.text();
      console.error('[ai-documentation] API error:', response.status, errorText);
      throw new Error(`AI API error: ${response.status}`);
    }

    const data = await response.json();
    const generatedDocs = data.choices?.[0]?.message?.content || '';

    // Parse based on doc type
    const parsed = parseDocumentation(generatedDocs, docType);

    console.log(`[ai-documentation] Generated ${docType} documentation`);

    return new Response(
      JSON.stringify({
        documentation: parsed.main,
        sections: parsed.sections,
        docType,
        language,
        fileName,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('[ai-documentation] Error:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

function buildSystemPrompt(language: string, docType: string): string {
  const basePrompt = `You are NAVI, an expert technical writer and documentation specialist.

LANGUAGE: ${language}
DOCUMENTATION TYPE: ${docType}

Your documentation should be:
- Clear and concise
- Accurate and complete
- Following best practices for the language
- Easy to understand for developers of all levels`;

  const typeSpecificPrompts: Record<string, string> = {
    jsdoc: `
JSDOC RULES:
- Use proper JSDoc/TSDoc syntax
- Include @param with types and descriptions
- Include @returns with type and description
- Include @throws for error conditions
- Include @example with usage examples
- Include @deprecated if applicable
- Use @template for generics
- Add @see for related functions

FORMAT:
\`\`\`typescript
/**
 * Brief description of what the function does.
 * 
 * @param {Type} paramName - Description of the parameter
 * @returns {ReturnType} Description of the return value
 * @throws {ErrorType} When this error occurs
 * @example
 * const result = functionName(arg);
 */
\`\`\``,

    readme: `
README RULES:
- Start with a clear project title and description
- Include installation instructions
- Provide usage examples with code
- Document configuration options
- Include API reference for public functions
- Add contributing guidelines if appropriate
- Include license information

STRUCTURE:
# Project Name
## Description
## Installation
## Usage
## API Reference
## Configuration
## Examples
## Contributing
## License`,

    api: `
API DOCUMENTATION RULES:
- Document all public exports
- Include type signatures
- Provide detailed parameter descriptions
- Show return types and values
- Include usage examples
- Document error responses
- Group related functions/methods

FORMAT for each function:
### functionName
Description of the function.
**Signature:** \`functionName(param1: Type1, param2: Type2): ReturnType\`
**Parameters:**
- \`param1\` (Type1): Description
**Returns:** ReturnType - Description
**Example:**
\`\`\`typescript
const result = functionName(value1, value2);
\`\`\``,

    inline: `
INLINE COMMENT RULES:
- Add comments above complex logic
- Explain WHY, not WHAT
- Keep comments concise
- Use TODO/FIXME/NOTE appropriately
- Don't over-comment obvious code
- Comment edge cases and workarounds`,
  };

  return basePrompt + (typeSpecificPrompts[docType] || typeSpecificPrompts.jsdoc);
}

function buildUserPrompt(
  code: string,
  language: string,
  fileName: string,
  docType: string,
  projectName?: string,
  existingDocs?: string,
  additionalContext?: string
): string {
  let prompt = `Generate ${docType} documentation for the following ${language} code from ${fileName}:

\`\`\`${language}
${code}
\`\`\``;

  if (projectName) {
    prompt += `\n\nPROJECT NAME: ${projectName}`;
  }

  if (existingDocs) {
    prompt += `\n\nEXISTING DOCUMENTATION (maintain consistency):
${existingDocs}`;
  }

  if (additionalContext) {
    prompt += `\n\nADDITIONAL CONTEXT:
${additionalContext}`;
  }

  const typeInstructions: Record<string, string> = {
    jsdoc: '\n\nGenerate JSDoc/TSDoc comments for all functions, classes, and interfaces.',
    readme: '\n\nGenerate a comprehensive README.md for this code/project.',
    api: '\n\nGenerate API documentation for all public exports.',
    inline: '\n\nAdd helpful inline comments explaining complex logic.',
    all: '\n\nGenerate comprehensive documentation including JSDoc, README section, and API reference.',
  };

  prompt += typeInstructions[docType] || typeInstructions.jsdoc;

  return prompt;
}

function parseDocumentation(content: string, docType: string): { main: string; sections: Record<string, string> } {
  const sections: Record<string, string> = {};
  
  if (docType === 'readme' || docType === 'all') {
    // Extract markdown sections
    const sectionRegex = /^##\s+(.+)$/gm;
    let match;
    let lastIndex = 0;
    let lastSection = 'intro';
    
    while ((match = sectionRegex.exec(content)) !== null) {
      if (lastIndex > 0) {
        sections[lastSection] = content.slice(lastIndex, match.index).trim();
      }
      lastSection = match[1].toLowerCase().replace(/\s+/g, '_');
      lastIndex = match.index + match[0].length;
    }
    
    if (lastIndex > 0) {
      sections[lastSection] = content.slice(lastIndex).trim();
    }
  }

  if (docType === 'jsdoc' || docType === 'api') {
    // Extract code blocks
    const codeBlockRegex = /```[\w]*\n([\s\S]*?)```/g;
    let match;
    let index = 0;
    
    while ((match = codeBlockRegex.exec(content)) !== null) {
      sections[`code_block_${index}`] = match[1].trim();
      index++;
    }
  }

  return {
    main: content,
    sections,
  };
}
