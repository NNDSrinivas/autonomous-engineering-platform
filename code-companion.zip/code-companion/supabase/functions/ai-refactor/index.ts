import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface RefactorRequest {
  code: string;
  language: string;
  fileName: string;
  refactorType?: 'all' | 'extract' | 'types' | 'performance' | 'readability' | 'security';
  additionalContext?: string;
}

interface RefactorSuggestion {
  title: string;
  description: string;
  priority: 'high' | 'medium' | 'low';
  category: string;
  originalCode: string;
  suggestedCode: string;
  lineRange?: { start: number; end: number };
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { 
      code, 
      language, 
      fileName, 
      refactorType = 'all',
      additionalContext 
    } = await req.json() as RefactorRequest;

    if (!code) {
      return new Response(
        JSON.stringify({ error: 'Code is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    const systemPrompt = buildSystemPrompt(language, refactorType);
    const userPrompt = buildUserPrompt(code, language, fileName, refactorType, additionalContext);

    console.log(`[ai-refactor] Analyzing ${language} code for ${refactorType} improvements`);

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
        tools: [{
          type: 'function',
          function: {
            name: 'provide_refactor_suggestions',
            description: 'Provide structured refactoring suggestions for the code',
            parameters: {
              type: 'object',
              properties: {
                suggestions: {
                  type: 'array',
                  items: {
                    type: 'object',
                    properties: {
                      title: { type: 'string', description: 'Brief title of the refactoring' },
                      description: { type: 'string', description: 'Detailed explanation of why this refactoring improves the code' },
                      priority: { type: 'string', enum: ['high', 'medium', 'low'] },
                      category: { type: 'string', enum: ['extract', 'types', 'performance', 'readability', 'security', 'naming', 'structure'] },
                      originalCode: { type: 'string', description: 'The code snippet to be refactored' },
                      suggestedCode: { type: 'string', description: 'The refactored code' },
                      lineStart: { type: 'number', description: 'Approximate starting line' },
                      lineEnd: { type: 'number', description: 'Approximate ending line' }
                    },
                    required: ['title', 'description', 'priority', 'category', 'originalCode', 'suggestedCode']
                  }
                },
                overallScore: {
                  type: 'number',
                  description: 'Overall code quality score from 1-10'
                },
                summary: {
                  type: 'string',
                  description: 'Brief summary of the main issues and improvements'
                }
              },
              required: ['suggestions', 'overallScore', 'summary']
            }
          }
        }],
        tool_choice: { type: 'function', function: { name: 'provide_refactor_suggestions' } },
        max_tokens: 3000,
        temperature: 0.3,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: 'Rate limit exceeded. Please try again later.' }),
          { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: 'Usage limit reached. Please add credits.' }),
          { status: 402, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      const errorText = await response.text();
      console.error('[ai-refactor] API error:', response.status, errorText);
      throw new Error(`AI API error: ${response.status}`);
    }

    const data = await response.json();
    
    // Parse tool call response
    const toolCall = data.choices?.[0]?.message?.tool_calls?.[0];
    if (!toolCall) {
      throw new Error('No refactoring suggestions generated');
    }

    const result = JSON.parse(toolCall.function.arguments);

    console.log(`[ai-refactor] Found ${result.suggestions?.length || 0} suggestions, score: ${result.overallScore}/10`);

    return new Response(
      JSON.stringify({
        suggestions: result.suggestions || [],
        overallScore: result.overallScore || 0,
        summary: result.summary || '',
        language,
        fileName,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('[ai-refactor] Error:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

function buildSystemPrompt(language: string, refactorType: string): string {
  return `You are NAVI, an expert code reviewer and refactoring specialist.

LANGUAGE: ${language}
FOCUS: ${refactorType === 'all' ? 'All improvement types' : refactorType}

Your role is to analyze code and provide actionable refactoring suggestions.

ANALYSIS CATEGORIES:
${getRefactorCategories(refactorType)}

PRIORITY GUIDELINES:
- HIGH: Security issues, bugs, significant performance problems, or major code smells
- MEDIUM: Readability improvements, minor performance gains, better patterns
- LOW: Style preferences, minor naming improvements, optional enhancements

RULES:
1. Be specific - show exact code changes
2. Explain WHY each change improves the code
3. Consider the language's idioms and best practices
4. Don't suggest changes that would alter behavior
5. Focus on practical, impactful improvements
6. Consider maintainability and readability

${getLanguageSpecificGuidelines(language)}`;
}

function getRefactorCategories(type: string): string {
  const categories: Record<string, string> = {
    all: `- Extract: Functions/methods that should be extracted
- Types: Missing or improvable type annotations
- Performance: Inefficient patterns, unnecessary computations
- Readability: Complex logic, poor naming, missing docs
- Security: Potential vulnerabilities
- Structure: Better organization, SOLID principles`,
    
    extract: `- Long functions that should be split
- Repeated code that should be extracted
- Complex conditionals that should be functions
- Magic values that should be constants`,
    
    types: `- Missing type annotations
- Use of 'any' that could be typed
- Generic types that could be more specific
- Union types that could be narrowed`,
    
    performance: `- Unnecessary re-renders in React
- Inefficient loops or iterations
- Memory leaks or poor memory usage
- Redundant computations
- Missing memoization opportunities`,
    
    readability: `- Complex nested logic
- Poor variable/function names
- Missing or outdated comments
- Inconsistent formatting
- Long parameter lists`,
    
    security: `- SQL injection vulnerabilities
- XSS vulnerabilities
- Exposed secrets or sensitive data
- Unsafe user input handling
- Missing input validation`,
  };
  return categories[type] || categories.all;
}

function getLanguageSpecificGuidelines(language: string): string {
  const guidelines: Record<string, string> = {
    typescript: `TYPESCRIPT BEST PRACTICES:
- Use strict types, avoid 'any'
- Prefer interfaces for object shapes
- Use type guards for narrowing
- Leverage utility types (Partial, Pick, Omit)
- Use const assertions where applicable
- Prefer readonly arrays/tuples when data shouldn't mutate`,

    typescriptreact: `REACT + TYPESCRIPT BEST PRACTICES:
- Use proper component typing
- Prefer hooks over class components
- Use useMemo/useCallback for expensive operations
- Avoid inline function definitions in JSX
- Extract complex logic into custom hooks
- Use proper event handler types`,

    python: `PYTHON BEST PRACTICES:
- Use type hints (PEP 484)
- Follow PEP 8 style guidelines
- Use list/dict comprehensions appropriately
- Prefer generators for large data
- Use context managers for resources
- Avoid mutable default arguments`,

    javascript: `JAVASCRIPT BEST PRACTICES:
- Use const/let, never var
- Use optional chaining and nullish coalescing
- Prefer async/await over callbacks
- Use destructuring appropriately
- Avoid global variables
- Use strict equality (===)`,
  };
  return guidelines[language] || '';
}

function buildUserPrompt(
  code: string, 
  language: string, 
  fileName: string, 
  refactorType: string,
  context?: string
): string {
  let prompt = `Analyze the following ${language} code from ${fileName} and provide refactoring suggestions:

\`\`\`${language}
${code}
\`\`\`

Focus on: ${refactorType === 'all' ? 'all improvement types' : refactorType}`;

  if (context) {
    prompt += `

ADDITIONAL CONTEXT:
${context}`;
  }

  prompt += `

Provide specific, actionable refactoring suggestions with before/after code examples.`;

  return prompt;
}
