import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface TranscriptSummarizeRequest {
  transcript: string;
  meetingTopic?: string;
  participants?: string[];
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    const { transcript, meetingTopic, participants }: TranscriptSummarizeRequest = await req.json();
    
    console.log('[ai-summarize-transcript] Processing meeting transcript');

    const systemPrompt = `You are an expert at analyzing meeting transcripts for engineering teams.
Your task is to extract structured information from meeting transcripts.

You MUST respond with a valid JSON object containing:
{
  "summary": "A comprehensive 3-5 sentence summary of the meeting",
  "actionItems": [
    {
      "item": "Description of the action item",
      "owner": "Person responsible (if mentioned)",
      "deadline": "Deadline if mentioned",
      "priority": "high" | "medium" | "low"
    }
  ],
  "keyDecisions": [
    {
      "decision": "The decision made",
      "context": "Brief context",
      "stakeholders": ["Person 1", "Person 2"]
    }
  ],
  "technicalDiscussions": [
    {
      "topic": "Technical topic discussed",
      "summary": "Brief summary of the discussion",
      "outcome": "What was concluded"
    }
  ],
  "followUps": [
    {
      "item": "Follow-up item",
      "assignee": "Person responsible",
      "dueDate": "When it's due"
    }
  ],
  "blockers": ["Any blockers mentioned"],
  "questionsRaised": ["Unanswered questions from the meeting"],
  "participants": ["List of participants who spoke"],
  "sentiment": "positive" | "neutral" | "concerned",
  "nextMeeting": "Details about next meeting if mentioned"
}

Focus on:
- Extracting clear, actionable items with owners
- Identifying decisions that affect the project
- Noting technical discussions and their outcomes
- Capturing follow-up items and deadlines
- Identifying blockers and concerns`;

    let userPrompt = `Analyze this meeting transcript and extract structured information:\n\n${transcript}`;
    
    if (meetingTopic) {
      userPrompt += `\n\nMeeting Topic: ${meetingTopic}`;
    }
    if (participants?.length) {
      userPrompt += `\n\nKnown Participants: ${participants.join(', ')}`;
    }

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('[ai-summarize-transcript] API error:', response.status, errorText);
      
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: 'Rate limit exceeded' }), {
          status: 429,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      throw new Error(`AI API error: ${response.status}`);
    }

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content;

    // Parse the JSON response
    let parsedResult;
    try {
      const jsonMatch = content.match(/```(?:json)?\s*([\s\S]*?)```/);
      const jsonStr = jsonMatch ? jsonMatch[1] : content;
      parsedResult = JSON.parse(jsonStr.trim());
    } catch {
      // If parsing fails, create a structured response from raw text
      parsedResult = {
        summary: content,
        actionItems: [],
        keyDecisions: [],
        technicalDiscussions: [],
        followUps: [],
        blockers: [],
        questionsRaised: [],
        participants: participants || [],
        sentiment: 'neutral',
        raw: true
      };
    }

    console.log('[ai-summarize-transcript] Successfully processed transcript');

    return new Response(JSON.stringify({
      success: true,
      ...parsedResult
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('[ai-summarize-transcript] Error:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Unknown error' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
