import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface SummarizeRequest {
  type: 'slack' | 'meeting' | 'pr_comments' | 'confluence';
  content: string;
  context?: {
    taskKey?: string;
    channelName?: string;
    participants?: string[];
  };
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    const { type, content, context }: SummarizeRequest = await req.json();
    
    console.log(`[ai-summarize] Processing ${type} summarization request`);

    const systemPrompts: Record<string, string> = {
      slack: `You are an expert at summarizing Slack conversations for engineering teams.
Extract:
- Key decisions made
- Action items with owners
- Important announcements
- Technical discussions and conclusions
- Questions that need answers
- Blockers mentioned

Format as JSON:
{
  "summary": "Brief 2-3 sentence overview",
  "decisions": ["Decision 1", "Decision 2"],
  "actionItems": [{"item": "Task", "owner": "Person", "deadline": "Date if mentioned"}],
  "keyPoints": ["Point 1", "Point 2"],
  "questions": ["Unanswered question 1"],
  "blockers": ["Blocker 1"],
  "sentiment": "positive" | "neutral" | "concerned"
}`,

      meeting: `You are an expert at summarizing engineering meeting notes.
Extract:
- Meeting purpose and outcomes
- Decisions made
- Action items with owners and deadlines
- Technical discussions
- Follow-up items
- Architecture or design decisions

Format as JSON:
{
  "summary": "Meeting overview in 2-3 sentences",
  "agenda": ["Topic 1", "Topic 2"],
  "decisions": ["Decision 1"],
  "actionItems": [{"item": "Task", "owner": "Person", "deadline": "Date"}],
  "technicalNotes": ["Important technical point"],
  "followUps": ["Follow-up item"],
  "nextSteps": "What happens next"
}`,

      pr_comments: `You are an expert at summarizing PR review discussions.
Extract:
- Main feedback themes
- Required changes
- Suggestions for improvement
- Approved aspects
- Outstanding concerns

Format as JSON:
{
  "summary": "Overall PR feedback summary",
  "requiredChanges": ["Change 1"],
  "suggestions": ["Suggestion 1"],
  "approvedAspects": ["Good thing 1"],
  "concerns": ["Concern 1"],
  "overallSentiment": "approved" | "changes_requested" | "needs_discussion"
}`,

      confluence: `You are an expert at summarizing technical documentation.
Extract:
- Document purpose
- Key requirements or specifications
- Technical constraints
- Important diagrams or flows described
- Related systems or dependencies

Format as JSON:
{
  "summary": "Document overview",
  "purpose": "Why this document exists",
  "keyRequirements": ["Requirement 1"],
  "technicalDetails": ["Detail 1"],
  "constraints": ["Constraint 1"],
  "dependencies": ["Dependency 1"],
  "relatedDocs": ["Related doc if mentioned"]
}`
    };

    const systemPrompt = systemPrompts[type] || systemPrompts.slack;
    
    let userPrompt = `Summarize the following ${type} content:\n\n${content}`;
    
    if (context?.taskKey) {
      userPrompt += `\n\nThis is related to Jira task: ${context.taskKey}`;
    }
    if (context?.channelName) {
      userPrompt += `\n\nChannel: ${context.channelName}`;
    }
    if (context?.participants?.length) {
      userPrompt += `\n\nParticipants: ${context.participants.join(', ')}`;
    }

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('[ai-summarize] API error:', response.status, errorText);
      
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: 'Rate limit exceeded' }), {
          status: 429,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      throw new Error(`AI API error: ${response.status}`);
    }

    const data = await response.json();
    const content_response = data.choices?.[0]?.message?.content;

    // Parse the JSON response
    let parsedSummary;
    try {
      const jsonMatch = content_response.match(/```(?:json)?\s*([\s\S]*?)```/);
      const jsonStr = jsonMatch ? jsonMatch[1] : content_response;
      parsedSummary = JSON.parse(jsonStr.trim());
    } catch {
      parsedSummary = { summary: content_response, raw: true };
    }

    console.log(`[ai-summarize] Successfully summarized ${type} content`);

    return new Response(JSON.stringify({
      success: true,
      type,
      ...parsedSummary
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('[ai-summarize] Error:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Unknown error' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
