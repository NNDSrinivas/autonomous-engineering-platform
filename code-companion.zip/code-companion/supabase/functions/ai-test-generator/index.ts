import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface TestGeneratorRequest {
  code: string;
  language: string;
  fileName: string;
  framework?: string; // jest, vitest, mocha, pytest, etc.
  testType?: 'unit' | 'integration' | 'e2e';
  additionalContext?: string;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { 
      code, 
      language, 
      fileName, 
      framework,
      testType = 'unit',
      additionalContext 
    } = await req.json() as TestGeneratorRequest;

    if (!code) {
      return new Response(
        JSON.stringify({ error: 'Code is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    const detectedFramework = framework || detectTestFramework(language, fileName);
    const systemPrompt = buildSystemPrompt(language, detectedFramework, testType);
    const userPrompt = buildUserPrompt(code, language, fileName, additionalContext);

    console.log(`[ai-test-generator] Generating ${testType} tests for ${language} using ${detectedFramework}`);

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
        max_tokens: 2000,
        temperature: 0.3,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: 'Rate limit exceeded. Please try again later.' }),
          { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: 'Usage limit reached. Please add credits.' }),
          { status: 402, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      const errorText = await response.text();
      console.error('[ai-test-generator] API error:', response.status, errorText);
      throw new Error(`AI API error: ${response.status}`);
    }

    const data = await response.json();
    const generatedTests = data.choices?.[0]?.message?.content || '';

    // Parse the response to extract test code and explanation
    const parsed = parseTestResponse(generatedTests);

    console.log(`[ai-test-generator] Generated ${parsed.testCount} test cases`);

    return new Response(
      JSON.stringify({
        tests: parsed.testCode,
        explanation: parsed.explanation,
        testCount: parsed.testCount,
        framework: detectedFramework,
        suggestedFileName: generateTestFileName(fileName, language),
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('[ai-test-generator] Error:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

function detectTestFramework(language: string, fileName: string): string {
  const frameworks: Record<string, string> = {
    typescript: 'vitest',
    typescriptreact: 'vitest',
    javascript: 'jest',
    javascriptreact: 'jest',
    python: 'pytest',
    rust: 'cargo-test',
    go: 'go-test',
    java: 'junit',
    csharp: 'xunit',
    ruby: 'rspec',
  };
  return frameworks[language] || 'jest';
}

function buildSystemPrompt(language: string, framework: string, testType: string): string {
  return `You are NAVI, an expert test engineer. Generate comprehensive ${testType} tests.

FRAMEWORK: ${framework}
LANGUAGE: ${language}
TEST TYPE: ${testType}

RULES:
1. Generate complete, runnable test code
2. Include all necessary imports
3. Cover edge cases and error scenarios
4. Use descriptive test names that explain the behavior
5. Follow ${framework} best practices and conventions
6. Include setup/teardown if needed
7. Mock external dependencies appropriately
8. Test both happy paths and error cases

OUTPUT FORMAT:
First output the complete test code in a code block.
Then provide a brief explanation of what each test covers.

${getFrameworkSpecificGuidelines(framework)}`;
}

function getFrameworkSpecificGuidelines(framework: string): string {
  const guidelines: Record<string, string> = {
    vitest: `VITEST GUIDELINES:
- Use describe/it/expect syntax
- Import from 'vitest': describe, it, expect, vi, beforeEach, afterEach
- Use vi.fn() for mocks
- Use vi.spyOn() for spying on methods
- Support async tests with async/await`,

    jest: `JEST GUIDELINES:
- Use describe/it/expect syntax
- Use jest.fn() for mocks
- Use jest.spyOn() for spying
- Support async tests with async/await or done callback`,

    pytest: `PYTEST GUIDELINES:
- Use def test_* function naming
- Use assert statements
- Use @pytest.fixture for fixtures
- Use @pytest.mark.parametrize for parameterized tests
- Use monkeypatch for mocking`,

    'cargo-test': `RUST TEST GUIDELINES:
- Use #[test] attribute
- Use assert!, assert_eq!, assert_ne! macros
- Use #[should_panic] for expected panics
- Organize with mod tests { }`,

    'go-test': `GO TEST GUIDELINES:
- Use func Test*(t *testing.T) naming
- Use t.Error, t.Fatal, t.Run
- Use table-driven tests
- Import testing package`,
  };
  return guidelines[framework] || '';
}

function buildUserPrompt(code: string, language: string, fileName: string, context?: string): string {
  let prompt = `Generate comprehensive tests for the following ${language} code from ${fileName}:

\`\`\`${language}
${code}
\`\`\``;

  if (context) {
    prompt += `

ADDITIONAL CONTEXT:
${context}`;
  }

  prompt += `

Generate tests that:
1. Test all public functions/methods
2. Cover edge cases (null, undefined, empty values)
3. Test error handling
4. Mock external dependencies
5. Use descriptive test names`;

  return prompt;
}

function parseTestResponse(response: string): { testCode: string; explanation: string; testCount: number } {
  // Extract code blocks
  const codeBlockMatch = response.match(/```[\w]*\n([\s\S]*?)```/);
  const testCode = codeBlockMatch ? codeBlockMatch[1].trim() : response;
  
  // Extract explanation (text after the code block)
  const explanation = codeBlockMatch 
    ? response.slice(response.indexOf('```', codeBlockMatch.index! + 3) + 3).trim()
    : '';

  // Count test cases (approximate)
  const testCount = (testCode.match(/(?:it|test|def test_|func Test|#\[test\])\s*[\(\{]/g) || []).length;

  return { testCode, explanation, testCount };
}

function generateTestFileName(fileName: string, language: string): string {
  const baseName = fileName.replace(/\.[^.]+$/, '');
  const ext = language.includes('typescript') ? '.test.ts' : 
              language.includes('javascript') ? '.test.js' :
              language === 'python' ? '_test.py' :
              language === 'rust' ? '.rs' :
              language === 'go' ? '_test.go' :
              '.test.js';
  return `${baseName}${ext}`;
}
