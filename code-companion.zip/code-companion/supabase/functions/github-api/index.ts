import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const GITHUB_API_BASE = 'https://api.github.com';

async function getGitHubToken(supabase: any, userId: string): Promise<string | null> {
  const { data: connection, error } = await supabase
    .from('integration_connections')
    .select('access_token')
    .eq('user_id', userId)
    .eq('provider', 'github')
    .eq('status', 'connected')
    .single();

  if (error || !connection) {
    console.log('[GitHub API] No connection found for user:', userId);
    return null;
  }

  return connection.access_token;
}

async function githubRequest(
  token: string,
  endpoint: string,
  method: string = 'GET',
  body?: Record<string, unknown>
): Promise<any> {
  const url = `${GITHUB_API_BASE}${endpoint}`;
  console.log(`[GitHub API] ${method} ${endpoint}`);

  const response = await fetch(url, {
    method,
    headers: {
      'Authorization': `Bearer ${token}`,
      'Accept': 'application/vnd.github+json',
      'X-GitHub-Api-Version': '2022-11-28',
      ...(body && { 'Content-Type': 'application/json' }),
    },
    ...(body && { body: JSON.stringify(body) }),
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error(`[GitHub API] Error ${response.status}:`, errorText);
    throw new Error(`GitHub API error: ${response.status} - ${errorText}`);
  }

  // Handle 204 No Content
  if (response.status === 204) {
    return { success: true };
  }

  return response.json();
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const supabase = createClient(supabaseUrl, supabaseServiceKey);

  try {
    // Authenticate user
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(JSON.stringify({ error: 'Authorization required' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);

    if (userError || !user) {
      return new Response(JSON.stringify({ error: 'Invalid token' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { action, ...params } = await req.json();
    console.log(`[GitHub API] Action: ${action}, User: ${user.id}`);

    // Get GitHub token
    const githubToken = await getGitHubToken(supabase, user.id);

    // Handle check_connection without requiring token
    if (action === 'check_connection') {
      if (!githubToken) {
        return new Response(JSON.stringify({ connected: false }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      try {
        const userData = await githubRequest(githubToken, '/user');
        return new Response(JSON.stringify({
          connected: true,
          user: {
            login: userData.login,
            name: userData.name,
            avatar_url: userData.avatar_url,
            email: userData.email,
          },
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      } catch {
        return new Response(JSON.stringify({ connected: false }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
    }

    // All other actions require a valid token
    if (!githubToken) {
      return new Response(JSON.stringify({ error: 'GitHub not connected' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    let result: any;

    switch (action) {
      case 'list_repos': {
        const repos = await githubRequest(githubToken, '/user/repos?sort=updated&per_page=50');
        result = { repos };
        break;
      }

      case 'list_branches': {
        const { owner, repo } = params;
        if (!owner || !repo) throw new Error('owner and repo are required');
        const branches = await githubRequest(githubToken, `/repos/${owner}/${repo}/branches`);
        result = { branches };
        break;
      }

      case 'list_pull_requests': {
        const { owner, repo, state = 'open' } = params;
        if (!owner || !repo) throw new Error('owner and repo are required');
        const pull_requests = await githubRequest(
          githubToken,
          `/repos/${owner}/${repo}/pulls?state=${state}&per_page=30`
        );
        result = { pull_requests };
        break;
      }

      case 'get_pull_request': {
        const { owner, repo, pull_number } = params;
        if (!owner || !repo || !pull_number) throw new Error('owner, repo, and pull_number are required');
        const pull_request = await githubRequest(
          githubToken,
          `/repos/${owner}/${repo}/pulls/${pull_number}`
        );
        result = { pull_request };
        break;
      }

      case 'list_workflow_runs': {
        const { owner, repo, per_page = 20 } = params;
        if (!owner || !repo) throw new Error('owner and repo are required');
        const data = await githubRequest(
          githubToken,
          `/repos/${owner}/${repo}/actions/runs?per_page=${per_page}`
        );
        result = { workflow_runs: data.workflow_runs };
        break;
      }

      case 'get_workflow_run': {
        const { owner, repo, run_id } = params;
        if (!owner || !repo || !run_id) throw new Error('owner, repo, and run_id are required');
        const workflow_run = await githubRequest(
          githubToken,
          `/repos/${owner}/${repo}/actions/runs/${run_id}`
        );
        result = { workflow_run };
        break;
      }

      case 'rerun_workflow': {
        const { owner, repo, run_id } = params;
        if (!owner || !repo || !run_id) throw new Error('owner, repo, and run_id are required');
        await githubRequest(
          githubToken,
          `/repos/${owner}/${repo}/actions/runs/${run_id}/rerun`,
          'POST'
        );
        result = { success: true };
        break;
      }

      case 'create_pull_request': {
        const { owner, repo, title, body, head, base } = params;
        if (!owner || !repo || !title || !head || !base) {
          throw new Error('owner, repo, title, head, and base are required');
        }
        const pull_request = await githubRequest(
          githubToken,
          `/repos/${owner}/${repo}/pulls`,
          'POST',
          { title, body: body || '', head, base }
        );
        result = { pull_request };
        break;
      }

      case 'create_branch': {
        const { owner, repo, branch_name, from_branch } = params;
        if (!owner || !repo || !branch_name || !from_branch) {
          throw new Error('owner, repo, branch_name, and from_branch are required');
        }
        
        // Get the SHA of the source branch
        const refData = await githubRequest(
          githubToken,
          `/repos/${owner}/${repo}/git/refs/heads/${from_branch}`
        );
        
        // Create new branch
        const branch = await githubRequest(
          githubToken,
          `/repos/${owner}/${repo}/git/refs`,
          'POST',
          {
            ref: `refs/heads/${branch_name}`,
            sha: refData.object.sha,
          }
        );
        result = { branch };
        break;
      }

      case 'get_file_content': {
        const { owner, repo, path, ref } = params;
        if (!owner || !repo || !path) throw new Error('owner, repo, and path are required');
        
        let endpoint = `/repos/${owner}/${repo}/contents/${path}`;
        if (ref) endpoint += `?ref=${ref}`;
        
        const fileData = await githubRequest(githubToken, endpoint);
        
        // Decode base64 content
        const content = fileData.encoding === 'base64' 
          ? atob(fileData.content.replace(/\n/g, ''))
          : fileData.content;
        
        result = { 
          content, 
          sha: fileData.sha,
          path: fileData.path,
          size: fileData.size,
        };
        break;
      }

      case 'update_file': {
        const { owner, repo, path, content, message, branch, sha } = params;
        if (!owner || !repo || !path || !content || !message || !branch) {
          throw new Error('owner, repo, path, content, message, and branch are required');
        }
        
        // Encode content to base64
        const encodedContent = btoa(content);
        
        const commitData: Record<string, unknown> = {
          message,
          content: encodedContent,
          branch,
        };
        
        if (sha) {
          commitData.sha = sha;
        }
        
        const commit = await githubRequest(
          githubToken,
          `/repos/${owner}/${repo}/contents/${path}`,
          'PUT',
          commitData
        );
        result = { commit };
        break;
      }

      case 'get_commits': {
        const { owner, repo, sha, per_page = 30 } = params;
        if (!owner || !repo) throw new Error('owner and repo are required');
        
        let endpoint = `/repos/${owner}/${repo}/commits?per_page=${per_page}`;
        if (sha) endpoint += `&sha=${sha}`;
        
        const commits = await githubRequest(githubToken, endpoint);
        result = { commits };
        break;
      }

      case 'merge_pull_request': {
        const { owner, repo, pull_number, commit_title, commit_message, merge_method = 'merge' } = params;
        if (!owner || !repo || !pull_number) {
          throw new Error('owner, repo, and pull_number are required');
        }
        const mergeResult = await githubRequest(
          githubToken,
          `/repos/${owner}/${repo}/pulls/${pull_number}/merge`,
          'PUT',
          { 
            commit_title: commit_title || undefined,
            commit_message: commit_message || undefined,
            merge_method // 'merge', 'squash', or 'rebase'
          }
        );
        result = { merged: true, sha: mergeResult.sha, message: mergeResult.message };
        break;
      }

      case 'get_workflow_logs': {
        const { owner, repo, run_id } = params;
        if (!owner || !repo || !run_id) throw new Error('owner, repo, and run_id are required');
        
        // Get workflow jobs which contain logs
        const jobs = await githubRequest(
          githubToken,
          `/repos/${owner}/${repo}/actions/runs/${run_id}/jobs`
        );
        result = { jobs: jobs.jobs };
        break;
      }

      case 'cancel_workflow': {
        const { owner, repo, run_id } = params;
        if (!owner || !repo || !run_id) throw new Error('owner, repo, and run_id are required');
        await githubRequest(
          githubToken,
          `/repos/${owner}/${repo}/actions/runs/${run_id}/cancel`,
          'POST'
        );
        result = { cancelled: true };
        break;
      }

      // Repo indexing actions
      case 'list_repo_tree': {
        const { owner, repo, ref = 'main' } = params;
        if (!owner || !repo) throw new Error('owner and repo are required');
        const tree = await githubRequest(
          githubToken,
          `/repos/${owner}/${repo}/git/trees/${ref}?recursive=1`
        );
        result = { tree: tree.tree, sha: tree.sha, truncated: tree.truncated };
        break;
      }

      case 'list_contents': {
        const { owner, repo, path = '', ref } = params;
        if (!owner || !repo) throw new Error('owner and repo are required');
        let endpoint = `/repos/${owner}/${repo}/contents/${path}`;
        if (ref) endpoint += `?ref=${ref}`;
        const contents = await githubRequest(githubToken, endpoint);
        result = { contents };
        break;
      }

      case 'get_repo': {
        const { owner, repo } = params;
        if (!owner || !repo) throw new Error('owner and repo are required');
        const repoData = await githubRequest(githubToken, `/repos/${owner}/${repo}`);
        result = { repo: repoData };
        break;
      }

      case 'search_code': {
        const { owner, repo, query } = params;
        if (!owner || !repo || !query) throw new Error('owner, repo, and query are required');
        const searchResult = await githubRequest(
          githubToken,
          `/search/code?q=${encodeURIComponent(query)}+repo:${owner}/${repo}`
        );
        result = { items: searchResult.items, total_count: searchResult.total_count };
        break;
      }

      default:
        throw new Error(`Unknown action: ${action}`);
    }

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('[GitHub API] Error:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Unknown error' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
