import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface GitHubWriteRequest {
  action: 'create_branch' | 'commit_files' | 'create_pr' | 'merge_pr';
  owner: string;
  repo: string;
  // For create_branch
  branchName?: string;
  baseBranch?: string;
  // For commit_files
  branch?: string;
  files?: Array<{ path: string; content: string }>;
  commitMessage?: string;
  // For create_pr
  title?: string;
  body?: string;
  head?: string;
  base?: string;
  // For merge_pr
  prNumber?: number;
}

async function getGitHubToken(supabase: any, userId: string): Promise<string | null> {
  const { data, error } = await supabase
    .from('integration_connections')
    .select('access_token')
    .eq('user_id', userId)
    .eq('provider', 'github')
    .eq('status', 'connected')
    .single();
  
  if (error || !data) {
    console.error('[github-write] No GitHub token found:', error);
    return null;
  }
  
  return data.access_token;
}

async function githubRequest(token: string, endpoint: string, method: string = 'GET', body?: any) {
  const response = await fetch(`https://api.github.com${endpoint}`, {
    method,
    headers: {
      'Authorization': `Bearer ${token}`,
      'Accept': 'application/vnd.github.v3+json',
      'Content-Type': 'application/json',
      'X-GitHub-Api-Version': '2022-11-28'
    },
    body: body ? JSON.stringify(body) : undefined
  });

  if (!response.ok) {
    const errorData = await response.text();
    console.error(`[github-write] GitHub API error: ${response.status}`, errorData);
    throw new Error(`GitHub API error: ${response.status} - ${errorData}`);
  }

  return response.json();
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get('authorization');
    if (!authHeader) {
      throw new Error('Missing authorization header');
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Get user from JWT
    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    
    if (authError || !user) {
      throw new Error('Invalid authentication');
    }

    const githubToken = await getGitHubToken(supabase, user.id);
    if (!githubToken) {
      return new Response(JSON.stringify({ 
        error: 'GitHub not connected. Please connect your GitHub account first.' 
      }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const request: GitHubWriteRequest = await req.json();
    const { action, owner, repo } = request;

    console.log(`[github-write] Processing ${action} for ${owner}/${repo}`);

    let result;

    switch (action) {
      case 'create_branch': {
        const { branchName, baseBranch = 'main' } = request;
        if (!branchName) throw new Error('branchName is required');

        // Get the SHA of the base branch
        const baseRef = await githubRequest(githubToken, `/repos/${owner}/${repo}/git/refs/heads/${baseBranch}`);
        const baseSha = baseRef.object.sha;

        // Create the new branch
        result = await githubRequest(githubToken, `/repos/${owner}/${repo}/git/refs`, 'POST', {
          ref: `refs/heads/${branchName}`,
          sha: baseSha
        });

        console.log(`[github-write] Created branch ${branchName} from ${baseBranch}`);
        break;
      }

      case 'commit_files': {
        const { branch, files, commitMessage } = request;
        if (!branch || !files || !commitMessage) {
          throw new Error('branch, files, and commitMessage are required');
        }

        // Get the current commit SHA
        const ref = await githubRequest(githubToken, `/repos/${owner}/${repo}/git/refs/heads/${branch}`);
        const currentCommitSha = ref.object.sha;

        // Get the tree SHA
        const commit = await githubRequest(githubToken, `/repos/${owner}/${repo}/git/commits/${currentCommitSha}`);
        const baseTreeSha = commit.tree.sha;

        // Create blobs for each file
        const treeItems = await Promise.all(files.map(async (file) => {
          const blob = await githubRequest(githubToken, `/repos/${owner}/${repo}/git/blobs`, 'POST', {
            content: file.content,
            encoding: 'utf-8'
          });
          return {
            path: file.path,
            mode: '100644',
            type: 'blob',
            sha: blob.sha
          };
        }));

        // Create a new tree
        const newTree = await githubRequest(githubToken, `/repos/${owner}/${repo}/git/trees`, 'POST', {
          base_tree: baseTreeSha,
          tree: treeItems
        });

        // Create a new commit
        const newCommit = await githubRequest(githubToken, `/repos/${owner}/${repo}/git/commits`, 'POST', {
          message: commitMessage,
          tree: newTree.sha,
          parents: [currentCommitSha]
        });

        // Update the branch reference
        result = await githubRequest(githubToken, `/repos/${owner}/${repo}/git/refs/heads/${branch}`, 'PATCH', {
          sha: newCommit.sha
        });

        console.log(`[github-write] Committed ${files.length} files to ${branch}`);
        result = { ...result, commitSha: newCommit.sha, filesCommitted: files.length };
        break;
      }

      case 'create_pr': {
        const { title, body, head, base = 'main' } = request;
        if (!title || !head) {
          throw new Error('title and head are required');
        }

        result = await githubRequest(githubToken, `/repos/${owner}/${repo}/pulls`, 'POST', {
          title,
          body: body || '',
          head,
          base
        });

        console.log(`[github-write] Created PR #${result.number}: ${title}`);
        break;
      }

      case 'merge_pr': {
        const { prNumber } = request;
        if (!prNumber) throw new Error('prNumber is required');

        result = await githubRequest(githubToken, `/repos/${owner}/${repo}/pulls/${prNumber}/merge`, 'PUT', {
          merge_method: 'squash'
        });

        console.log(`[github-write] Merged PR #${prNumber}`);
        break;
      }

      default:
        throw new Error(`Unknown action: ${action}`);
    }

    return new Response(JSON.stringify({
      success: true,
      action,
      result
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('[github-write] Error:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Unknown error' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
