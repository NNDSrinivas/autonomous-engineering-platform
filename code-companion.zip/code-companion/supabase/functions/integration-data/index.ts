import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const supabase = createClient(supabaseUrl, supabaseServiceKey);

  try {
    // Get user from auth header
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(JSON.stringify({ error: 'Authorization required' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);
    
    if (userError || !user) {
      return new Response(JSON.stringify({ error: 'Invalid token' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { provider, action } = await req.json();
    console.log(`[IntegrationData] Provider: ${provider}, Action: ${action}`);

    // Handle calendar specially - it can pull from multiple providers
    if (provider === 'calendar') {
      const calendarEvents = await fetchCalendarEvents(supabase, user.id, action);
      return new Response(JSON.stringify({ data: calendarEvents }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Get the user's connection for this provider
    const { data: connection, error: connError } = await supabase
      .from('integration_connections')
      .select('*')
      .eq('user_id', user.id)
      .eq('provider', provider)
      .eq('status', 'connected')
      .single();

    if (connError || !connection) {
      return new Response(JSON.stringify({ 
        error: `${provider} not connected`,
        requiresAuth: true 
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const accessToken = connection.access_token;
    let data: unknown = null;

    // Record sync start
    const { data: syncRecord } = await supabase
      .from('sync_history')
      .insert({
        user_id: user.id,
        provider,
        sync_type: 'manual',
        status: 'running',
      })
      .select()
      .single();

    try {
      switch (provider) {
        case 'github':
          data = await fetchGitHubData(accessToken, action);
          break;
        case 'jira':
          data = await fetchJiraData(accessToken, connection.provider_metadata, action);
          break;
        case 'slack':
          data = await fetchSlackData(accessToken, action);
          break;
        case 'confluence':
          data = await fetchConfluenceData(accessToken, connection.provider_metadata, action);
          break;
        case 'google_calendar':
          data = await fetchGoogleCalendarData(accessToken, action);
          break;
        case 'microsoft_calendar':
          data = await fetchMicrosoftCalendarData(accessToken, action);
          break;
        case 'zoom':
          data = await fetchZoomData(accessToken, action);
          break;
        case 'teams':
          data = await fetchTeamsData(accessToken, action);
          break;
        default:
          return new Response(JSON.stringify({ error: 'Unsupported provider' }), {
            status: 400,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
      }

      // Update sync record
      const itemCount = Array.isArray(data) ? data.length : (data ? 1 : 0);
      await supabase
        .from('sync_history')
        .update({
          status: 'completed',
          items_synced: itemCount,
          completed_at: new Date().toISOString(),
        })
        .eq('id', syncRecord?.id);

      return new Response(JSON.stringify({ data }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });

    } catch (fetchError) {
      console.error(`[IntegrationData] Fetch error:`, fetchError);
      
      // Update sync record with error
      await supabase
        .from('sync_history')
        .update({
          status: 'failed',
          error_message: fetchError instanceof Error ? fetchError.message : 'Unknown error',
          completed_at: new Date().toISOString(),
        })
        .eq('id', syncRecord?.id);

      throw fetchError;
    }

  } catch (error) {
    console.error('[IntegrationData] Error:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Unknown error' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

async function fetchGitHubData(accessToken: string, action: string) {
  const headers = {
    Authorization: `Bearer ${accessToken}`,
    Accept: 'application/vnd.github.v3+json',
  };

  switch (action) {
    case 'repos':
      const reposRes = await fetch('https://api.github.com/user/repos?sort=updated&per_page=20', { headers });
      if (!reposRes.ok) throw new Error('Failed to fetch repos');
      return await reposRes.json();

    case 'prs':
      const prsRes = await fetch('https://api.github.com/user/repos?sort=updated&per_page=10', { headers });
      if (!prsRes.ok) throw new Error('Failed to fetch repos for PRs');
      const repos = await prsRes.json();
      
      const allPRs = [];
      for (const repo of repos.slice(0, 5)) {
        const prRes = await fetch(`https://api.github.com/repos/${repo.full_name}/pulls?state=open`, { headers });
        if (prRes.ok) {
          const prs = await prRes.json();
          allPRs.push(...prs.map((pr: Record<string, unknown>) => ({
            ...pr,
            repo: repo.full_name,
          })));
        }
      }
      return allPRs;

    case 'issues':
      const issuesRes = await fetch('https://api.github.com/issues?filter=assigned&state=open&per_page=20', { headers });
      if (!issuesRes.ok) throw new Error('Failed to fetch issues');
      return await issuesRes.json();

    case 'notifications':
      const notifRes = await fetch('https://api.github.com/notifications?per_page=20', { headers });
      if (!notifRes.ok) throw new Error('Failed to fetch notifications');
      return await notifRes.json();

    case 'workflow_runs':
      // Get workflow runs from user's repos
      const workflowReposRes = await fetch('https://api.github.com/user/repos?sort=updated&per_page=5', { headers });
      if (!workflowReposRes.ok) throw new Error('Failed to fetch repos for workflows');
      const workflowRepos = await workflowReposRes.json();
      
      const allRuns = [];
      for (const repo of workflowRepos) {
        try {
          const runsRes = await fetch(`https://api.github.com/repos/${repo.full_name}/actions/runs?per_page=5`, { headers });
          if (runsRes.ok) {
            const runsData = await runsRes.json();
            allRuns.push(...(runsData.workflow_runs || []).map((run: any) => ({
              ...run,
              repo: repo.full_name,
            })));
          }
        } catch (e) {
          console.error(`[GitHub] Failed to fetch runs for ${repo.full_name}:`, e);
        }
      }
      return allRuns.sort((a: any, b: any) => 
        new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
      ).slice(0, 20);

    default:
      throw new Error('Unknown GitHub action');
  }
}

async function fetchJiraData(accessToken: string, metadata: Record<string, unknown>, action: string) {
  const resources = metadata?.resources as Array<{ id: string; name: string; url: string }> | undefined;
  if (!resources || resources.length === 0) {
    throw new Error('No Jira sites available');
  }

  const cloudId = resources[0].id;
  const siteName = resources[0].name;
  const baseUrl = `https://api.atlassian.com/ex/jira/${cloudId}/rest/api/3`;
  
  const headers = {
    Authorization: `Bearer ${accessToken}`,
    Accept: 'application/json',
  };

  switch (action) {
    case 'issues':
      const jql = 'assignee = currentUser() AND statusCategory != Done ORDER BY updated DESC';
      const issuesRes = await fetch(
        `${baseUrl}/search?jql=${encodeURIComponent(jql)}&maxResults=50&expand=names,renderedFields`,
        { headers }
      );
      if (!issuesRes.ok) {
        const errorText = await issuesRes.text();
        console.error('[Jira] Issues error:', errorText);
        throw new Error('Failed to fetch Jira issues');
      }
      const issuesData = await issuesRes.json();
      
      return (issuesData.issues || []).map((issue: any) => ({
        id: issue.id,
        key: issue.key,
        self: issue.self,
        site: siteName,
        fields: {
          summary: issue.fields.summary,
          description: issue.renderedFields?.description || extractTextFromADF(issue.fields.description),
          status: { name: issue.fields.status?.name || 'Unknown' },
          priority: { name: issue.fields.priority?.name || 'None' },
          assignee: issue.fields.assignee ? { 
            displayName: issue.fields.assignee.displayName,
            avatarUrl: issue.fields.assignee.avatarUrls?.['48x48'],
            accountId: issue.fields.assignee.accountId,
          } : null,
          reporter: issue.fields.reporter ? {
            displayName: issue.fields.reporter.displayName,
            avatarUrl: issue.fields.reporter.avatarUrls?.['48x48'],
          } : null,
          updated: issue.fields.updated,
          created: issue.fields.created,
          duedate: issue.fields.duedate,
          issuetype: { 
            name: issue.fields.issuetype?.name || 'Task',
            iconUrl: issue.fields.issuetype?.iconUrl,
          },
          project: { 
            key: issue.fields.project?.key, 
            name: issue.fields.project?.name,
          },
          labels: issue.fields.labels || [],
          components: (issue.fields.components || []).map((c: any) => c.name),
          storyPoints: issue.fields.customfield_10016 || null,
          sprint: issue.fields.customfield_10020?.[0]?.name || null,
          acceptanceCriteria: issue.fields.customfield_10034 || null,
        },
      }));

    case 'projects':
      const projectsRes = await fetch(`${baseUrl}/project/search?maxResults=50`, { headers });
      if (!projectsRes.ok) throw new Error('Failed to fetch projects');
      const projectsData = await projectsRes.json();
      return projectsData.values || [];

    case 'sprints':
      const boardsRes = await fetch(
        `https://api.atlassian.com/ex/jira/${cloudId}/rest/agile/1.0/board?maxResults=10`,
        { headers }
      );
      if (!boardsRes.ok) throw new Error('Failed to fetch boards');
      const boardsData = await boardsRes.json();
      
      const sprints: any[] = [];
      for (const board of (boardsData.values || []).slice(0, 5)) {
        const sprintRes = await fetch(
          `https://api.atlassian.com/ex/jira/${cloudId}/rest/agile/1.0/board/${board.id}/sprint?state=active,future&maxResults=10`,
          { headers }
        );
        if (sprintRes.ok) {
          const sprintData = await sprintRes.json();
          sprints.push(...(sprintData.values || []).map((s: any) => ({
            ...s,
            boardName: board.name,
            boardId: board.id,
          })));
        }
      }
      return sprints;

    default:
      throw new Error('Unknown Jira action');
  }
}

function extractTextFromADF(adf: any): string {
  if (!adf || typeof adf !== 'object') return '';
  if (adf.type === 'text') return adf.text || '';
  if (adf.content && Array.isArray(adf.content)) {
    return adf.content.map(extractTextFromADF).join(' ');
  }
  return '';
}

async function fetchSlackData(accessToken: string, action: string) {
  const headers = {
    Authorization: `Bearer ${accessToken}`,
  };

  switch (action) {
    case 'channels':
      const channelsRes = await fetch('https://slack.com/api/conversations.list?types=public_channel,private_channel&limit=50', { headers });
      if (!channelsRes.ok) throw new Error('Failed to fetch channels');
      const channelsData = await channelsRes.json();
      if (!channelsData.ok) throw new Error(channelsData.error || 'Slack API error');
      return channelsData.channels || [];

    case 'messages':
      const chRes = await fetch('https://slack.com/api/conversations.list?types=public_channel&limit=10', { headers });
      const chData = await chRes.json();
      
      if (!chData.ok || !chData.channels?.length) return [];
      
      const messages: any[] = [];
      for (const channel of chData.channels.slice(0, 5)) {
        try {
          const msgRes = await fetch(
            `https://slack.com/api/conversations.history?channel=${channel.id}&limit=15`,
            { headers }
          );
          const msgData = await msgRes.json();
          if (msgData.ok) {
            messages.push(...(msgData.messages || []).map((m: Record<string, unknown>) => ({
              ...m,
              channel_name: channel.name,
              channel_id: channel.id,
            })));
          }
        } catch (err) {
          console.error(`[Slack] Failed to fetch messages from #${channel.name}:`, err);
        }
      }
      messages.sort((a, b) => parseFloat(b.ts) - parseFloat(a.ts));
      return messages.slice(0, 50);

    case 'users':
      const usersRes = await fetch('https://slack.com/api/users.list?limit=100', { headers });
      const usersData = await usersRes.json();
      if (!usersData.ok) throw new Error(usersData.error || 'Slack API error');
      return (usersData.members || []).filter((u: any) => !u.is_bot && !u.deleted);

    case 'search':
      const searchRes = await fetch('https://slack.com/api/search.messages?query=*&count=30&sort=timestamp', { headers });
      const searchData = await searchRes.json();
      if (!searchData.ok) throw new Error(searchData.error || 'Slack API error');
      return searchData.messages?.matches || [];

    case 'team':
      const teamRes = await fetch('https://slack.com/api/team.info', { headers });
      const teamData = await teamRes.json();
      if (!teamData.ok) throw new Error(teamData.error || 'Slack API error');
      return teamData.team;

    case 'post':
      // This would need channel and text in the request
      throw new Error('Use dedicated post endpoint');

    default:
      throw new Error('Unknown Slack action');
  }
}

async function fetchConfluenceData(accessToken: string, metadata: Record<string, unknown>, action: string) {
  const resources = metadata?.resources as Array<{ id: string; name: string; url: string }> | undefined;
  if (!resources || resources.length === 0) {
    throw new Error('No Confluence sites available');
  }

  const cloudId = resources[0].id;
  const baseUrl = `https://api.atlassian.com/ex/confluence/${cloudId}/wiki/api/v2`;
  
  const headers = {
    Authorization: `Bearer ${accessToken}`,
    Accept: 'application/json',
  };

  switch (action) {
    case 'spaces':
      const spacesRes = await fetch(`${baseUrl}/spaces?limit=20`, { headers });
      if (!spacesRes.ok) throw new Error('Failed to fetch spaces');
      const spacesData = await spacesRes.json();
      return spacesData.results || [];

    case 'pages':
      const pagesRes = await fetch(`${baseUrl}/pages?limit=20&sort=-modified-date`, { headers });
      if (!pagesRes.ok) throw new Error('Failed to fetch pages');
      const pagesData = await pagesRes.json();
      return pagesData.results || [];

    case 'search':
      const searchRes = await fetch(
        `https://api.atlassian.com/ex/confluence/${cloudId}/wiki/rest/api/content/search?cql=type=page ORDER BY lastmodified DESC&limit=20`,
        { headers }
      );
      if (!searchRes.ok) throw new Error('Failed to search content');
      const searchData = await searchRes.json();
      return searchData.results || [];

    default:
      throw new Error('Unknown Confluence action');
  }
}

// Zoom integration functions
async function fetchZoomData(accessToken: string, action: string) {
  const headers = {
    Authorization: `Bearer ${accessToken}`,
    'Content-Type': 'application/json',
  };

  switch (action) {
    case 'meetings':
      // Get upcoming and past meetings
      const meetingsRes = await fetch('https://api.zoom.us/v2/users/me/meetings?type=scheduled&page_size=30', { headers });
      if (!meetingsRes.ok) {
        const errorText = await meetingsRes.text();
        console.error('[Zoom] Meetings error:', errorText);
        throw new Error('Failed to fetch Zoom meetings');
      }
      const meetingsData = await meetingsRes.json();
      return (meetingsData.meetings || []).map((m: any) => ({
        id: m.id,
        uuid: m.uuid,
        topic: m.topic,
        type: m.type,
        start_time: m.start_time,
        duration: m.duration,
        timezone: m.timezone,
        join_url: m.join_url,
        agenda: m.agenda,
      }));

    case 'recordings':
      // Get cloud recordings from the past month
      const fromDate = new Date();
      fromDate.setMonth(fromDate.getMonth() - 1);
      const toDate = new Date();
      
      const recordingsRes = await fetch(
        `https://api.zoom.us/v2/users/me/recordings?from=${fromDate.toISOString().split('T')[0]}&to=${toDate.toISOString().split('T')[0]}&page_size=30`,
        { headers }
      );
      if (!recordingsRes.ok) {
        const errorText = await recordingsRes.text();
        console.error('[Zoom] Recordings error:', errorText);
        throw new Error('Failed to fetch Zoom recordings');
      }
      const recordingsData = await recordingsRes.json();
      
      return (recordingsData.meetings || []).map((meeting: any) => ({
        meeting_id: meeting.id,
        uuid: meeting.uuid,
        topic: meeting.topic,
        start_time: meeting.start_time,
        duration: meeting.duration,
        total_size: meeting.total_size,
        recording_count: meeting.recording_count,
        recording_files: (meeting.recording_files || []).map((f: any) => ({
          id: f.id,
          meeting_id: f.meeting_id,
          recording_type: f.recording_type,
          file_type: f.file_type,
          file_size: f.file_size,
          download_url: f.download_url,
          play_url: f.play_url,
          status: f.status,
        })),
      }));

    case 'transcripts':
      // Get recordings with transcripts
      const transcriptFromDate = new Date();
      transcriptFromDate.setMonth(transcriptFromDate.getMonth() - 1);
      
      const transcriptRecordingsRes = await fetch(
        `https://api.zoom.us/v2/users/me/recordings?from=${transcriptFromDate.toISOString().split('T')[0]}&to=${new Date().toISOString().split('T')[0]}&page_size=20`,
        { headers }
      );
      if (!transcriptRecordingsRes.ok) throw new Error('Failed to fetch recordings for transcripts');
      const transcriptRecordingsData = await transcriptRecordingsRes.json();
      
      const meetingsWithTranscripts = [];
      for (const meeting of (transcriptRecordingsData.meetings || [])) {
        const transcriptFiles = (meeting.recording_files || []).filter(
          (f: any) => f.recording_type === 'audio_transcript' || f.file_type === 'VTT' || f.file_type === 'TXT'
        );
        if (transcriptFiles.length > 0) {
          meetingsWithTranscripts.push({
            meeting_id: meeting.id,
            uuid: meeting.uuid,
            topic: meeting.topic,
            start_time: meeting.start_time,
            duration: meeting.duration,
            transcripts: transcriptFiles.map((f: any) => ({
              id: f.id,
              file_type: f.file_type,
              download_url: f.download_url,
              recording_type: f.recording_type,
            })),
          });
        }
      }
      return meetingsWithTranscripts;

    case 'user':
      const userRes = await fetch('https://api.zoom.us/v2/users/me', { headers });
      if (!userRes.ok) throw new Error('Failed to fetch Zoom user');
      return await userRes.json();

    default:
      throw new Error('Unknown Zoom action');
  }
}

// Microsoft Teams integration functions
async function fetchTeamsData(accessToken: string, action: string) {
  const headers = {
    Authorization: `Bearer ${accessToken}`,
    'Content-Type': 'application/json',
  };

  switch (action) {
    case 'teams':
      // Get joined teams
      const teamsRes = await fetch('https://graph.microsoft.com/v1.0/me/joinedTeams', { headers });
      if (!teamsRes.ok) {
        const errorText = await teamsRes.text();
        console.error('[Teams] Teams error:', errorText);
        throw new Error('Failed to fetch Teams');
      }
      const teamsData = await teamsRes.json();
      return (teamsData.value || []).map((team: any) => ({
        id: team.id,
        displayName: team.displayName,
        description: team.description,
        isArchived: team.isArchived,
      }));

    case 'channels':
      // Get channels from all joined teams
      const teamsList = await fetch('https://graph.microsoft.com/v1.0/me/joinedTeams', { headers });
      if (!teamsList.ok) throw new Error('Failed to fetch teams for channels');
      const teamsListData = await teamsList.json();
      
      const allChannels = [];
      for (const team of (teamsListData.value || []).slice(0, 5)) {
        try {
          const channelsRes = await fetch(
            `https://graph.microsoft.com/v1.0/teams/${team.id}/channels`,
            { headers }
          );
          if (channelsRes.ok) {
            const channelsData = await channelsRes.json();
            allChannels.push(...(channelsData.value || []).map((channel: any) => ({
              ...channel,
              teamId: team.id,
              teamName: team.displayName,
            })));
          }
        } catch (e) {
          console.error(`[Teams] Failed to fetch channels for team ${team.displayName}:`, e);
        }
      }
      return allChannels;

    case 'messages':
      // Get recent chat messages
      const chatsRes = await fetch('https://graph.microsoft.com/v1.0/me/chats?$expand=lastMessagePreview&$top=20', { headers });
      if (!chatsRes.ok) {
        const errorText = await chatsRes.text();
        console.error('[Teams] Chats error:', errorText);
        throw new Error('Failed to fetch chats');
      }
      const chatsData = await chatsRes.json();
      
      const allMessages = [];
      for (const chat of (chatsData.value || []).slice(0, 10)) {
        try {
          const messagesRes = await fetch(
            `https://graph.microsoft.com/v1.0/me/chats/${chat.id}/messages?$top=10`,
            { headers }
          );
          if (messagesRes.ok) {
            const messagesData = await messagesRes.json();
            allMessages.push(...(messagesData.value || []).map((msg: any) => ({
              id: msg.id,
              chatId: chat.id,
              chatTopic: chat.topic,
              from: msg.from?.user?.displayName || 'Unknown',
              body: msg.body?.content,
              createdDateTime: msg.createdDateTime,
              messageType: msg.messageType,
            })));
          }
        } catch (e) {
          console.error(`[Teams] Failed to fetch messages for chat ${chat.id}:`, e);
        }
      }
      
      return allMessages.sort((a, b) => 
        new Date(b.createdDateTime).getTime() - new Date(a.createdDateTime).getTime()
      ).slice(0, 50);

    case 'channel_messages':
      // Get messages from team channels
      const teamsForChannels = await fetch('https://graph.microsoft.com/v1.0/me/joinedTeams', { headers });
      if (!teamsForChannels.ok) throw new Error('Failed to fetch teams');
      const teamsForChannelsData = await teamsForChannels.json();
      
      const channelMessages = [];
      for (const team of (teamsForChannelsData.value || []).slice(0, 3)) {
        try {
          const channelsRes = await fetch(
            `https://graph.microsoft.com/v1.0/teams/${team.id}/channels`,
            { headers }
          );
          if (channelsRes.ok) {
            const channelsData = await channelsRes.json();
            for (const channel of (channelsData.value || []).slice(0, 3)) {
              try {
                const msgsRes = await fetch(
                  `https://graph.microsoft.com/v1.0/teams/${team.id}/channels/${channel.id}/messages?$top=10`,
                  { headers }
                );
                if (msgsRes.ok) {
                  const msgsData = await msgsRes.json();
                  channelMessages.push(...(msgsData.value || []).map((msg: any) => ({
                    id: msg.id,
                    teamId: team.id,
                    teamName: team.displayName,
                    channelId: channel.id,
                    channelName: channel.displayName,
                    from: msg.from?.user?.displayName || 'Unknown',
                    body: msg.body?.content,
                    createdDateTime: msg.createdDateTime,
                  })));
                }
              } catch (e) {
                // Skip channels we can't access
              }
            }
          }
        } catch (e) {
          console.error(`[Teams] Failed to fetch channels for team ${team.displayName}:`, e);
        }
      }
      
      return channelMessages.sort((a, b) => 
        new Date(b.createdDateTime).getTime() - new Date(a.createdDateTime).getTime()
      ).slice(0, 50);

    case 'user':
      const userRes = await fetch('https://graph.microsoft.com/v1.0/me', { headers });
      if (!userRes.ok) throw new Error('Failed to fetch Teams user');
      return await userRes.json();

    default:
      throw new Error('Unknown Teams action');
  }
}

// Fetch calendar events from all connected calendar providers
async function fetchCalendarEvents(supabase: any, userId: string, action: string) {
  const allEvents: any[] = [];

  // Get all calendar connections
  const { data: connections } = await supabase
    .from('integration_connections')
    .select('*')
    .eq('user_id', userId)
    .in('provider', ['google_calendar', 'microsoft_calendar'])
    .eq('status', 'connected');

  if (!connections || connections.length === 0) {
    return [];
  }

  for (const connection of connections) {
    try {
      let events: any[] = [];
      if (connection.provider === 'google_calendar') {
        events = await fetchGoogleCalendarData(connection.access_token, action);
      } else if (connection.provider === 'microsoft_calendar') {
        events = await fetchMicrosoftCalendarData(connection.access_token, action);
      }
      allEvents.push(...events.map(e => ({ ...e, provider: connection.provider })));
    } catch (err) {
      console.error(`[Calendar] Failed to fetch from ${connection.provider}:`, err);
    }
  }

  // Sort by start time
  allEvents.sort((a, b) => {
    const aStart = new Date(a.start?.dateTime || a.start?.date || a.start).getTime();
    const bStart = new Date(b.start?.dateTime || b.start?.date || b.start).getTime();
    return aStart - bStart;
  });

  return allEvents;
}

async function fetchGoogleCalendarData(accessToken: string, action: string) {
  const headers = {
    Authorization: `Bearer ${accessToken}`,
    Accept: 'application/json',
  };

  switch (action) {
    case 'today-events':
    case 'events': {
      const now = new Date();
      const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const endOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
      
      const params = new URLSearchParams({
        timeMin: startOfDay.toISOString(),
        timeMax: endOfDay.toISOString(),
        singleEvents: 'true',
        orderBy: 'startTime',
        maxResults: '50',
      });
      
      const res = await fetch(
        `https://www.googleapis.com/calendar/v3/calendars/primary/events?${params}`,
        { headers }
      );
      
      if (!res.ok) {
        const errorText = await res.text();
        console.error('[Google Calendar] Error:', errorText);
        throw new Error('Failed to fetch Google Calendar events');
      }
      
      const data = await res.json();
      return data.items || [];
    }
    
    case 'upcoming': {
      const now = new Date();
      const endDate = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
      
      const params = new URLSearchParams({
        timeMin: now.toISOString(),
        timeMax: endDate.toISOString(),
        singleEvents: 'true',
        orderBy: 'startTime',
        maxResults: '20',
      });
      
      const res = await fetch(
        `https://www.googleapis.com/calendar/v3/calendars/primary/events?${params}`,
        { headers }
      );
      
      if (!res.ok) throw new Error('Failed to fetch upcoming events');
      const data = await res.json();
      return data.items || [];
    }

    default:
      throw new Error('Unknown Google Calendar action');
  }
}

async function fetchMicrosoftCalendarData(accessToken: string, action: string) {
  const headers = {
    Authorization: `Bearer ${accessToken}`,
    Accept: 'application/json',
  };

  switch (action) {
    case 'today-events':
    case 'events': {
      const now = new Date();
      const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const endOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
      
      const res = await fetch(
        `https://graph.microsoft.com/v1.0/me/calendarview?startDateTime=${startOfDay.toISOString()}&endDateTime=${endOfDay.toISOString()}&$orderby=start/dateTime&$top=50`,
        { headers }
      );
      
      if (!res.ok) {
        const errorText = await res.text();
        console.error('[Microsoft Calendar] Error:', errorText);
        throw new Error('Failed to fetch Microsoft Calendar events');
      }
      
      const data = await res.json();
      return (data.value || []).map((event: any) => ({
        id: event.id,
        summary: event.subject,
        description: event.bodyPreview,
        start: { dateTime: event.start?.dateTime, timeZone: event.start?.timeZone },
        end: { dateTime: event.end?.dateTime, timeZone: event.end?.timeZone },
        location: { displayName: event.location?.displayName },
        attendees: (event.attendees || []).map((a: any) => ({
          email: a.emailAddress?.address,
          name: a.emailAddress?.name,
        })),
        onlineMeeting: event.onlineMeeting,
        isAllDay: event.isAllDay,
      }));
    }
    
    case 'upcoming': {
      const now = new Date();
      const endDate = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
      
      const res = await fetch(
        `https://graph.microsoft.com/v1.0/me/calendarview?startDateTime=${now.toISOString()}&endDateTime=${endDate.toISOString()}&$orderby=start/dateTime&$top=20`,
        { headers }
      );
      
      if (!res.ok) throw new Error('Failed to fetch upcoming events');
      const data = await res.json();
      return data.value || [];
    }

    default:
      throw new Error('Unknown Microsoft Calendar action');
  }
}
