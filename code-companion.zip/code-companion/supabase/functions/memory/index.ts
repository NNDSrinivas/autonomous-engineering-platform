import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

// Generate embeddings using Lovable AI Gateway
async function generateEmbedding(text: string): Promise<number[]> {
  const response = await fetch('https://ai.gateway.lovable.dev/v1/embeddings', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${LOVABLE_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: 'text-embedding-3-small',
      input: text,
    }),
  });

  if (!response.ok) {
    console.error('Embedding API error:', await response.text());
    throw new Error('Failed to generate embedding');
  }

  const data = await response.json();
  return data.data[0].embedding;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(JSON.stringify({ error: 'No authorization header' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Create Supabase client with user's token for RLS
    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
      global: { headers: { Authorization: authHeader } },
    });

    // Also create a client to get the user ID
    const userClient = createClient(
      SUPABASE_URL,
      Deno.env.get('SUPABASE_ANON_KEY')!,
      { global: { headers: { Authorization: authHeader } } }
    );

    const { data: { user }, error: userError } = await userClient.auth.getUser();
    if (userError || !user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { action, ...params } = await req.json();
    console.log(`[Memory] Action: ${action}, User: ${user.id}`);

    switch (action) {
      case 'store': {
        // Store a new memory with embedding
        const { memory_type, source, title, content, metadata, source_url, source_id, organization_id } = params;
        
        let embedding = null;
        if (content && content.length > 0) {
          try {
            embedding = await generateEmbedding(content.slice(0, 8000)); // Limit for embedding
          } catch (err) {
            console.error('Failed to generate embedding:', err);
          }
        }

        const { data, error } = await supabase
          .from('workspace_memories')
          .insert({
            user_id: user.id,
            organization_id,
            memory_type,
            source,
            title,
            content,
            embedding,
            metadata: metadata || {},
            source_url,
            source_id,
          })
          .select()
          .single();

        if (error) throw error;
        
        return new Response(JSON.stringify({ success: true, memory: data }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      case 'search': {
        // Search memories by semantic similarity
        const { query, match_count = 5, memory_type } = params;
        
        const queryEmbedding = await generateEmbedding(query);
        
        const { data, error } = await supabase.rpc('search_memories', {
          query_embedding: queryEmbedding,
          match_count,
          filter_user_id: user.id,
          filter_type: memory_type || null,
        });

        if (error) throw error;

        return new Response(JSON.stringify({ results: data }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      case 'get_preferences': {
        // Get user preferences
        const { data, error } = await supabase
          .from('user_preferences')
          .select('*')
          .eq('user_id', user.id);

        if (error) throw error;

        // Convert to key-value object
        const preferences: Record<string, any> = {};
        data?.forEach(pref => {
          preferences[pref.preference_key] = pref.preference_value;
        });

        return new Response(JSON.stringify({ preferences }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      case 'set_preference': {
        // Set a user preference
        const { key, value } = params;
        
        const { data, error } = await supabase
          .from('user_preferences')
          .upsert({
            user_id: user.id,
            preference_key: key,
            preference_value: value,
          }, {
            onConflict: 'user_id,preference_key',
          })
          .select()
          .single();

        if (error) throw error;

        return new Response(JSON.stringify({ success: true, preference: data }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      case 'save_conversation': {
        // Save conversation summary
        const { conversation_id, summary, message_count, key_topics, metadata } = params;
        
        let embedding = null;
        if (summary) {
          try {
            embedding = await generateEmbedding(summary);
          } catch (err) {
            console.error('Failed to generate conversation embedding:', err);
          }
        }

        const { data, error } = await supabase
          .from('conversation_memories')
          .upsert({
            user_id: user.id,
            conversation_id,
            summary,
            message_count,
            key_topics,
            embedding,
            metadata: metadata || {},
            last_message_at: new Date().toISOString(),
          }, {
            onConflict: 'user_id,conversation_id',
            ignoreDuplicates: false,
          })
          .select()
          .single();

        if (error) throw error;

        return new Response(JSON.stringify({ success: true, conversation: data }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      case 'get_recent_conversations': {
        // Get recent conversation summaries
        const { limit = 10 } = params;
        
        const { data, error } = await supabase
          .from('conversation_memories')
          .select('*')
          .eq('user_id', user.id)
          .order('last_message_at', { ascending: false })
          .limit(limit);

        if (error) throw error;

        return new Response(JSON.stringify({ conversations: data }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      case 'store_task': {
        // Store task memory
        const { task_id, task_key, title, description, related_content, status, priority, assignee } = params;
        
        let embedding = null;
        const textToEmbed = `${title || ''} ${description || ''}`.trim();
        if (textToEmbed) {
          try {
            embedding = await generateEmbedding(textToEmbed);
          } catch (err) {
            console.error('Failed to generate task embedding:', err);
          }
        }

        const { data, error } = await supabase
          .from('task_memories')
          .upsert({
            user_id: user.id,
            task_id,
            task_key,
            title,
            description,
            related_content: related_content || [],
            embedding,
            status,
            priority,
            assignee,
          }, {
            onConflict: 'user_id,task_id',
          })
          .select()
          .single();

        if (error) throw error;

        return new Response(JSON.stringify({ success: true, task: data }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      case 'get_tasks': {
        // Get user's task memories
        const { status, limit = 20 } = params;
        
        let query = supabase
          .from('task_memories')
          .select('*')
          .eq('user_id', user.id)
          .order('updated_at', { ascending: false })
          .limit(limit);

        if (status) {
          query = query.eq('status', status);
        }

        const { data, error } = await query;

        if (error) throw error;

        return new Response(JSON.stringify({ tasks: data }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      case 'get_memories': {
        // Get user's memories with optional filtering
        const { memory_type, source, limit = 20 } = params;
        
        let query = supabase
          .from('workspace_memories')
          .select('*')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false })
          .limit(limit);

        if (memory_type) {
          query = query.eq('memory_type', memory_type);
        }
        if (source) {
          query = query.eq('source', source);
        }

        const { data, error } = await query;

        if (error) throw error;

        return new Response(JSON.stringify({ memories: data }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      case 'delete_memory': {
        const { memory_id } = params;
        
        const { error } = await supabase
          .from('workspace_memories')
          .delete()
          .eq('id', memory_id)
          .eq('user_id', user.id);

        if (error) throw error;

        return new Response(JSON.stringify({ success: true }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      default:
        return new Response(JSON.stringify({ error: 'Unknown action' }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
    }
  } catch (error) {
    console.error('[Memory] Error:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Unknown error' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
