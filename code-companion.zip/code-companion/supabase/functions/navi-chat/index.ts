import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Model mapping for different providers
const modelMapping: Record<string, string> = {
  // Lovable AI (default)
  'lovable/gemini-flash': 'google/gemini-2.5-flash',
  'lovable/gemini-pro': 'google/gemini-2.5-pro',
  'lovable/gpt-5': 'openai/gpt-5',
  'lovable/gpt-5-mini': 'openai/gpt-5-mini',
  // Placeholders for other providers (would need their own API keys)
  'openai/gpt-4': 'openai/gpt-5',
  'anthropic/claude-3': 'google/gemini-2.5-pro',
  'meta/llama-3': 'google/gemini-2.5-flash',
  'google/gemini': 'google/gemini-2.5-flash',
};

const NAVI_SYSTEM_PROMPT = `You are NAVI, an Autonomous Engineering Intelligence (AEI) assistant. When users greet you, introduce yourself as "Hello! I'm NAVI, your Autonomous Engineering Intelligence."

Your capabilities include:
1. Understanding engineering context from Jira tasks, Slack/Teams conversations, Confluence docs, GitHub PRs, and meeting notes
2. Providing intelligent code suggestions and implementations
3. Explaining complex engineering concepts clearly
4. Helping debug issues and suggesting fixes
5. Generating code based on requirements
6. Always asking for approval before making any changes

Key behaviors:
- Be concise but thorough
- Provide code examples when helpful
- Reference relevant sources when available
- Ask clarifying questions when requirements are unclear
- Format responses with markdown for readability
- When suggesting code changes, explain the reasoning
- When greeting users, always say "I'm NAVI" not "Hello NAVI"

Remember: You always ask for user approval before executing any actions like implementing code, creating PRs, or making commits.`;

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { messages, model = 'lovable/gemini-flash', taskContext, stream = true } = await req.json();
    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    // Map the requested model to actual model
    const actualModel = modelMapping[model] || 'google/gemini-2.5-flash';
    
    console.log(`[NAVI] Request received - Model: ${model} -> ${actualModel}`);
    console.log(`[NAVI] Messages count: ${messages?.length || 0}`);

    // Build system prompt with optional task context
    let systemPrompt = NAVI_SYSTEM_PROMPT;
    if (taskContext) {
      systemPrompt += `\n\nCurrent Task Context:\n${JSON.stringify(taskContext, null, 2)}`;
    }

    const requestBody = {
      model: actualModel,
      messages: [
        { role: 'system', content: systemPrompt },
        ...messages,
      ],
      stream,
    };

    console.log('[NAVI] Calling Lovable AI Gateway...');

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(requestBody),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('[NAVI] AI Gateway error:', response.status, errorText);
      
      if (response.status === 429) {
        return new Response(JSON.stringify({ 
          error: 'Rate limit exceeded. Please wait a moment and try again.' 
        }), {
          status: 429,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }
      
      if (response.status === 402) {
        return new Response(JSON.stringify({ 
          error: 'AI usage limit reached. Please add credits to continue.' 
        }), {
          status: 402,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      return new Response(JSON.stringify({ error: 'AI service unavailable' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log('[NAVI] Streaming response...');

    // Return the stream directly
    return new Response(response.body, {
      headers: { 
        ...corsHeaders, 
        'Content-Type': stream ? 'text/event-stream' : 'application/json' 
      },
    });

  } catch (error) {
    console.error('[NAVI] Error:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Unknown error' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
