import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface OAuthProviderConfig {
  authUrl: string;
  tokenUrl: string;
  scopes: string[];
  audience?: string;
}

// OAuth provider configurations
const oauthConfig: Record<string, OAuthProviderConfig> = {
  github: {
    authUrl: 'https://github.com/login/oauth/authorize',
    tokenUrl: 'https://github.com/login/oauth/access_token',
    scopes: ['repo', 'read:user', 'user:email', 'workflow'],
  },
  slack: {
    authUrl: 'https://slack.com/oauth/v2/authorize',
    tokenUrl: 'https://slack.com/api/oauth.v2.access',
    scopes: [
      'channels:read',
      'channels:history',
      'chat:write',
      'groups:read',
      'groups:history',
      'im:read',
      'im:history',
      'mpim:read',
      'mpim:history',
      'users:read',
      'users:read.email',
      'team:read',
      'search:read',
    ],
  },
  jira: {
    authUrl: 'https://auth.atlassian.com/authorize',
    tokenUrl: 'https://auth.atlassian.com/oauth/token',
    scopes: ['read:jira-user', 'read:jira-work', 'write:jira-work', 'offline_access'],
    audience: 'api.atlassian.com',
  },
  confluence: {
    authUrl: 'https://auth.atlassian.com/authorize',
    tokenUrl: 'https://auth.atlassian.com/oauth/token',
    scopes: ['read:confluence-content.all', 'read:confluence-space.summary', 'offline_access'],
    audience: 'api.atlassian.com',
  },
  google_calendar: {
    authUrl: 'https://accounts.google.com/o/oauth2/v2/auth',
    tokenUrl: 'https://oauth2.googleapis.com/token',
    scopes: [
      'https://www.googleapis.com/auth/calendar.readonly',
      'https://www.googleapis.com/auth/calendar.events.readonly',
      'openid',
      'email',
      'profile',
    ],
  },
  microsoft_calendar: {
    authUrl: 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize',
    tokenUrl: 'https://login.microsoftonline.com/common/oauth2/v2.0/token',
    scopes: [
      'Calendars.Read',
      'User.Read',
      'offline_access',
    ],
  },
  zoom: {
    authUrl: 'https://zoom.us/oauth/authorize',
    tokenUrl: 'https://zoom.us/oauth/token',
    scopes: [
      'meeting:read',
      'recording:read',
      'user:read',
      'cloud_recording:read',
    ],
  },
  teams: {
    authUrl: 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize',
    tokenUrl: 'https://login.microsoftonline.com/common/oauth2/v2.0/token',
    scopes: [
      'User.Read',
      'Chat.Read',
      'Chat.ReadWrite',
      'ChannelMessage.Read.All',
      'Team.ReadBasic.All',
      'Channel.ReadBasic.All',
      'offline_access',
    ],
  },
};

type Provider = string;

function generateState(): string {
  const array = new Uint8Array(32);
  crypto.getRandomValues(array);
  return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
}

// Helper to get OAuth credentials - checks org config first, then env vars
async function getOAuthCredentials(
  supabase: any,
  userId: string,
  provider: string
): Promise<{ clientId: string; clientSecret: string } | null> {
  // First, get user's current organization
  const { data: profile } = await supabase
    .from('profiles')
    .select('current_organization_id')
    .eq('user_id', userId)
    .single();

  if (profile?.current_organization_id) {
    // Check org-level OAuth config
    const { data: orgConfig } = await supabase
      .from('organization_oauth_configs')
      .select('client_id, client_secret')
      .eq('organization_id', profile.current_organization_id)
      .eq('provider', provider)
      .single();

    if (orgConfig) {
      console.log(`[OAuth] Using org-level credentials for ${provider}`);
      return {
        clientId: orgConfig.client_id,
        clientSecret: orgConfig.client_secret,
      };
    }
  }

  // Fallback to environment variables (for backwards compatibility)
  const clientId = Deno.env.get(`${provider.toUpperCase()}_CLIENT_ID`);
  const clientSecret = Deno.env.get(`${provider.toUpperCase()}_CLIENT_SECRET`);

  if (clientId && clientSecret) {
    console.log(`[OAuth] Using env var credentials for ${provider}`);
    return { clientId, clientSecret };
  }

  return null;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  
  const supabase = createClient(supabaseUrl, supabaseServiceKey);

  try {
    const url = new URL(req.url);
    const action = url.searchParams.get('action');
    
    console.log(`[OAuth] Action: ${action}`);

    // For initiate, we need user auth
    if (action === 'initiate') {
      const authHeader = req.headers.get('Authorization');
      if (!authHeader) {
        return new Response(JSON.stringify({ error: 'Authorization required' }), {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const token = authHeader.replace('Bearer ', '');
      const { data: { user }, error: userError } = await supabase.auth.getUser(token);
      
      if (userError || !user) {
        return new Response(JSON.stringify({ error: 'Invalid token' }), {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const { provider, redirectUri } = await req.json();
      
      if (!provider || !oauthConfig[provider as Provider]) {
        return new Response(JSON.stringify({ error: 'Invalid provider' }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const config = oauthConfig[provider as Provider];
      
      // Get OAuth credentials from org config or env vars
      const credentials = await getOAuthCredentials(supabase, user.id, provider);
      
      if (!credentials) {
        console.log(`[OAuth] No credentials configured for ${provider}`);
        return new Response(JSON.stringify({ 
          authUrl: null,
          message: `${provider} OAuth not configured. Your organization admin needs to add OAuth credentials in Settings > Connectors.`,
          provider,
          configRequired: true,
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const state = generateState();
      
      // Store state in database for CSRF protection
      const { error: stateError } = await supabase
        .from('oauth_states')
        .insert({
          user_id: user.id,
          provider,
          state,
          redirect_uri: redirectUri,
        });

      if (stateError) {
        console.error('[OAuth] State storage error:', stateError);
        return new Response(JSON.stringify({ error: 'Failed to initiate OAuth' }), {
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Build OAuth URL
      const callbackUrl = `${supabaseUrl}/functions/v1/oauth?action=callback`;
      const params = new URLSearchParams({
        client_id: credentials.clientId,
        redirect_uri: callbackUrl,
        response_type: 'code',
        scope: config.scopes.join(' '),
        state,
      });

      // Add Atlassian-specific params
      if (provider === 'jira' || provider === 'confluence') {
        params.set('audience', config.audience!);
        params.set('prompt', 'consent');
      }

      const authUrl = `${config.authUrl}?${params.toString()}`;
      
      console.log(`[OAuth] Generated auth URL for ${provider}`);

      return new Response(JSON.stringify({ authUrl, state }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Handle OAuth callback
    if (action === 'callback') {
      const code = url.searchParams.get('code');
      const state = url.searchParams.get('state');
      const error = url.searchParams.get('error');

      if (error) {
        console.error('[OAuth] Provider error:', error);
        return new Response(`<html><body><script>window.close();</script>OAuth error: ${error}</body></html>`, {
          headers: { 'Content-Type': 'text/html' },
        });
      }

      if (!code || !state) {
        return new Response('<html><body><script>window.close();</script>Missing code or state</body></html>', {
          headers: { 'Content-Type': 'text/html' },
        });
      }

      // Verify state and get user/provider info
      const { data: stateData, error: stateError } = await supabase
        .from('oauth_states')
        .select('*')
        .eq('state', state)
        .gt('expires_at', new Date().toISOString())
        .single();

      if (stateError || !stateData) {
        console.error('[OAuth] Invalid or expired state:', stateError);
        return new Response('<html><body><script>window.close();</script>Invalid or expired state</body></html>', {
          headers: { 'Content-Type': 'text/html' },
        });
      }

      const provider = stateData.provider as Provider;
      const config = oauthConfig[provider];
      
      // Get client credentials from org config or env vars
      const credentials = await getOAuthCredentials(supabase, stateData.user_id, provider);

      if (!credentials) {
        return new Response('<html><body><script>window.close();</script>OAuth not configured</body></html>', {
          headers: { 'Content-Type': 'text/html' },
        });
      }

      const { clientId, clientSecret } = credentials;
      const callbackUrl = `${supabaseUrl}/functions/v1/oauth?action=callback`;

      // Exchange code for tokens
      let tokenResponse;
      
      if (provider === 'github') {
        tokenResponse = await fetch(config.tokenUrl, {
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            client_id: clientId,
            client_secret: clientSecret,
            code,
            redirect_uri: callbackUrl,
          }),
        });
      } else if (provider === 'slack') {
        const params = new URLSearchParams({
          client_id: clientId,
          client_secret: clientSecret,
          code,
          redirect_uri: callbackUrl,
        });
        tokenResponse = await fetch(config.tokenUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: params.toString(),
        });
      } else if (provider === 'google_calendar') {
        const params = new URLSearchParams({
          client_id: clientId,
          client_secret: clientSecret,
          code,
          redirect_uri: callbackUrl,
          grant_type: 'authorization_code',
        });
        tokenResponse = await fetch(config.tokenUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: params.toString(),
        });
      } else if (provider === 'microsoft_calendar' || provider === 'teams') {
        const params = new URLSearchParams({
          client_id: clientId,
          client_secret: clientSecret,
          code,
          redirect_uri: callbackUrl,
          grant_type: 'authorization_code',
        });
        tokenResponse = await fetch(config.tokenUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: params.toString(),
        });
      } else if (provider === 'zoom') {
        // Zoom uses Basic Auth for token exchange
        const basicAuth = btoa(`${clientId}:${clientSecret}`);
        const params = new URLSearchParams({
          code,
          redirect_uri: callbackUrl,
          grant_type: 'authorization_code',
        });
        tokenResponse = await fetch(config.tokenUrl, {
          method: 'POST',
          headers: {
            'Authorization': `Basic ${basicAuth}`,
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: params.toString(),
        });
      } else {
        // Atlassian (Jira/Confluence)
        tokenResponse = await fetch(config.tokenUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            grant_type: 'authorization_code',
            client_id: clientId,
            client_secret: clientSecret,
            code,
            redirect_uri: callbackUrl,
          }),
        });
      }

      const tokenData = await tokenResponse.json();
      console.log(`[OAuth] Token exchange for ${provider}:`, tokenResponse.ok ? 'success' : 'failed');

      if (!tokenResponse.ok || tokenData.error) {
        console.error('[OAuth] Token error:', tokenData);
        return new Response(`<html><body><script>window.close();</script>Token exchange failed: ${tokenData.error || 'Unknown error'}</body></html>`, {
          headers: { 'Content-Type': 'text/html' },
        });
      }

      // Get access token (format varies by provider)
      const accessToken = tokenData.access_token || tokenData.authed_user?.access_token;
      const refreshToken = tokenData.refresh_token;
      const expiresIn = tokenData.expires_in;

      // Fetch user info
      let userInfo: Record<string, unknown> = {};
      
      try {
        if (provider === 'github') {
          const userRes = await fetch('https://api.github.com/user', {
            headers: { Authorization: `Bearer ${accessToken}` },
          });
          userInfo = await userRes.json();
        } else if (provider === 'slack') {
          userInfo = {
            team: tokenData.team,
            user_id: tokenData.authed_user?.id,
          };
        } else if (provider === 'jira' || provider === 'confluence') {
          const resourceRes = await fetch('https://api.atlassian.com/oauth/token/accessible-resources', {
            headers: { Authorization: `Bearer ${accessToken}` },
          });
          const resources = await resourceRes.json();
          userInfo = { resources };
        } else if (provider === 'google_calendar') {
          const userRes = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
            headers: { Authorization: `Bearer ${accessToken}` },
          });
          userInfo = await userRes.json();
        } else if (provider === 'microsoft_calendar' || provider === 'teams') {
          const userRes = await fetch('https://graph.microsoft.com/v1.0/me', {
            headers: { Authorization: `Bearer ${accessToken}` },
          });
          userInfo = await userRes.json();
        } else if (provider === 'zoom') {
          const userRes = await fetch('https://api.zoom.us/v2/users/me', {
            headers: { Authorization: `Bearer ${accessToken}` },
          });
          userInfo = await userRes.json();
        }
      } catch (e) {
        console.error('[OAuth] User info fetch error:', e);
      }

      // Store or update the connection
      const connectionData = {
        user_id: stateData.user_id,
        provider,
        access_token: accessToken,
        refresh_token: refreshToken || null,
        token_expires_at: expiresIn ? new Date(Date.now() + expiresIn * 1000).toISOString() : null,
        provider_user_id: String(userInfo.id || userInfo.user_id || ''),
        provider_email: String(userInfo.email || ''),
        provider_display_name: String(userInfo.name || userInfo.login || userInfo.first_name || tokenData.team?.name || ''),
        provider_metadata: userInfo,
        status: 'connected',
        last_sync_at: new Date().toISOString(),
      };

      const { error: upsertError } = await supabase
        .from('integration_connections')
        .upsert(connectionData, { onConflict: 'user_id,provider' });

      if (upsertError) {
        console.error('[OAuth] Connection storage error:', upsertError);
        return new Response('<html><body><script>window.close();</script>Failed to store connection</body></html>', {
          headers: { 'Content-Type': 'text/html' },
        });
      }

      // Delete the used state
      await supabase.from('oauth_states').delete().eq('state', state);

      console.log(`[OAuth] Successfully connected ${provider} for user ${stateData.user_id}`);

      // Close popup and notify parent
      const redirectTo = stateData.redirect_uri || '/';
      return new Response(`
        <html>
          <body>
            <script>
              if (window.opener) {
                window.opener.postMessage({ type: 'oauth-success', provider: '${provider}' }, '*');
                window.close();
              } else {
                window.location.href = '${redirectTo}';
              }
            </script>
            <p>Connection successful! This window should close automatically.</p>
          </body>
        </html>
      `, {
        headers: { 'Content-Type': 'text/html' },
      });
    }

    // Get user's connections
    if (action === 'connections') {
      const authHeader = req.headers.get('Authorization');
      if (!authHeader) {
        return new Response(JSON.stringify({ error: 'Authorization required' }), {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const token = authHeader.replace('Bearer ', '');
      const { data: { user }, error: userError } = await supabase.auth.getUser(token);
      
      if (userError || !user) {
        return new Response(JSON.stringify({ error: 'Invalid token' }), {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const { data: connections, error: connError } = await supabase
        .from('integration_connections')
        .select('provider, status, provider_display_name, last_sync_at, created_at')
        .eq('user_id', user.id);

      if (connError) {
        return new Response(JSON.stringify({ error: 'Failed to fetch connections' }), {
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      return new Response(JSON.stringify({ connections }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Disconnect integration
    if (action === 'disconnect') {
      const authHeader = req.headers.get('Authorization');
      if (!authHeader) {
        return new Response(JSON.stringify({ error: 'Authorization required' }), {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const token = authHeader.replace('Bearer ', '');
      const { data: { user }, error: userError } = await supabase.auth.getUser(token);
      
      if (userError || !user) {
        return new Response(JSON.stringify({ error: 'Invalid token' }), {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const { provider } = await req.json();

      const { error: deleteError } = await supabase
        .from('integration_connections')
        .delete()
        .eq('user_id', user.id)
        .eq('provider', provider);

      if (deleteError) {
        return new Response(JSON.stringify({ error: 'Failed to disconnect' }), {
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      console.log(`[OAuth] Disconnected ${provider} for user ${user.id}`);

      return new Response(JSON.stringify({ success: true }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Check configured providers for current org
    if (action === 'configured-providers') {
      const authHeader = req.headers.get('Authorization');
      if (!authHeader) {
        return new Response(JSON.stringify({ error: 'Authorization required' }), {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const token = authHeader.replace('Bearer ', '');
      const { data: { user }, error: userError } = await supabase.auth.getUser(token);
      
      if (userError || !user) {
        return new Response(JSON.stringify({ error: 'Invalid token' }), {
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Get user's current organization
      const { data: profile } = await supabase
        .from('profiles')
        .select('current_organization_id')
        .eq('user_id', user.id)
        .single();

      const configuredProviders: string[] = [];

      if (profile?.current_organization_id) {
        const { data: configs } = await supabase
          .from('organization_oauth_configs')
          .select('provider')
          .eq('organization_id', profile.current_organization_id);

        if (configs) {
          configuredProviders.push(...configs.map(c => c.provider));
        }
      }

      // Also check env vars for backwards compatibility
      const envProviders = ['github', 'slack', 'jira', 'confluence', 'zoom', 'teams'];
      for (const p of envProviders) {
        if (!configuredProviders.includes(p)) {
          const clientId = Deno.env.get(`${p.toUpperCase()}_CLIENT_ID`);
          if (clientId) {
            configuredProviders.push(p);
          }
        }
      }

      return new Response(JSON.stringify({ configuredProviders }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    return new Response(JSON.stringify({ error: 'Invalid action' }), {
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('[OAuth] Error:', error);
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
