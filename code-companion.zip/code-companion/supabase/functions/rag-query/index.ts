import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');

// Generate embedding for a query
async function generateEmbedding(text: string): Promise<number[]> {
  const response = await fetch('https://ai.gateway.lovable.dev/v1/embeddings', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${LOVABLE_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: 'text-embedding-3-small',
      input: text,
    }),
  });

  if (!response.ok) {
    throw new Error(`Embedding API error: ${response.status}`);
  }

  const data = await response.json();
  return data.data[0].embedding;
}

// Format memories for LLM context
function formatMemoriesForContext(memories: any[]): string {
  if (memories.length === 0) return '';
  
  return memories.map((mem, idx) => {
    const source = mem.source ? ` [Source: ${mem.source}]` : '';
    const title = mem.title ? `**${mem.title}**` : '';
    const relevance = mem.similarity ? ` (${Math.round(mem.similarity * 100)}% relevant)` : '';
    return `${idx + 1}. ${title}${source}${relevance}\n${mem.content}`;
  }).join('\n\n');
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const supabase = createClient(supabaseUrl, supabaseServiceKey);

  try {
    // Authenticate user
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(JSON.stringify({ error: 'Authorization required' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);
    
    if (userError || !user) {
      return new Response(JSON.stringify({ error: 'Invalid token' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { 
      query, 
      messages = [], 
      task_context,
      include_memories = true,
      memory_count = 5,
      stream = true,
      model = 'google/gemini-2.5-flash',
    } = await req.json();

    console.log(`[RAG] Query from user ${user.id}: "${query?.substring(0, 50)}..."`);

    // Step 1: Retrieve relevant memories if enabled
    let relevantMemories: any[] = [];
    let memoryContext = '';

    if (include_memories && query) {
      try {
        // Generate embedding for the query
        const queryEmbedding = await generateEmbedding(query);

        // Search for relevant memories
        const { data: memories, error: memError } = await supabase.rpc('search_memories', {
          query_embedding: JSON.stringify(queryEmbedding),
          match_count: memory_count,
          filter_user_id: user.id,
        });

        if (memError) {
          console.error('[RAG] Memory search error:', memError);
        } else if (memories && memories.length > 0) {
          relevantMemories = memories;
          memoryContext = formatMemoriesForContext(memories);
          console.log(`[RAG] Found ${memories.length} relevant memories`);
        }
      } catch (err) {
        console.error('[RAG] Memory retrieval error:', err);
        // Continue without memory context
      }
    }

    // Step 2: Get user preferences
    let userPreferences: Record<string, any> = {};
    try {
      const { data: prefs } = await supabase
        .from('user_preferences')
        .select('preference_key, preference_value')
        .eq('user_id', user.id);
      
      if (prefs) {
        prefs.forEach(p => {
          userPreferences[p.preference_key] = p.preference_value;
        });
      }
    } catch (err) {
      console.error('[RAG] Preferences fetch error:', err);
    }

    // Step 3: Build enhanced system prompt with RAG context
    let systemPrompt = `You are NAVI, an Autonomous Engineering Intelligence (AEI) assistant. When users greet you, introduce yourself as "Hello! I'm NAVI, your Autonomous Engineering Intelligence."

Your capabilities include:
1. Understanding engineering context from Jira tasks, Slack/Teams conversations, Confluence docs, GitHub PRs, and meeting notes
2. Providing intelligent code suggestions and implementations
3. Explaining complex engineering concepts clearly
4. Helping debug issues and suggesting fixes
5. Generating code based on requirements
6. Always asking for approval before making any changes

Key behaviors:
- Be concise but thorough
- Provide code examples when helpful
- Reference relevant sources when available
- Ask clarifying questions when requirements are unclear
- Format responses with markdown for readability
- When suggesting code changes, explain the reasoning`;

    // Add memory context if available
    if (memoryContext) {
      systemPrompt += `\n\n## Relevant Context from Memory
The following information from previous conversations, tasks, and documentation may be relevant to this query:

${memoryContext}

Use this context to provide more informed and personalized responses. Reference specific memories when relevant.`;
    }

    // Add user preferences if available
    if (Object.keys(userPreferences).length > 0) {
      systemPrompt += `\n\n## User Preferences
${JSON.stringify(userPreferences, null, 2)}`;
    }

    // Add task context if provided
    if (task_context) {
      systemPrompt += `\n\n## Current Task Context
${JSON.stringify(task_context, null, 2)}`;
    }

    // Step 4: Call LLM with enhanced context
    const llmMessages = [
      { role: 'system', content: systemPrompt },
      ...messages,
    ];

    // Add the current query if not already in messages
    if (query && (!messages.length || messages[messages.length - 1].content !== query)) {
      llmMessages.push({ role: 'user', content: query });
    }

    console.log(`[RAG] Calling LLM with ${llmMessages.length} messages, model: ${model}`);

    const llmResponse = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model,
        messages: llmMessages,
        stream,
      }),
    });

    if (!llmResponse.ok) {
      const errorText = await llmResponse.text();
      console.error('[RAG] LLM error:', llmResponse.status, errorText);
      throw new Error(`LLM API error: ${llmResponse.status}`);
    }

    // For non-streaming, add memory metadata to response
    if (!stream) {
      const data = await llmResponse.json();
      return new Response(JSON.stringify({
        ...data,
        memories_used: relevantMemories.map(m => ({
          id: m.id,
          title: m.title,
          source: m.source,
          similarity: m.similarity,
        })),
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // For streaming, pass through the response
    return new Response(llmResponse.body, {
      headers: { 
        ...corsHeaders, 
        'Content-Type': 'text/event-stream',
      },
    });

  } catch (error) {
    console.error('[RAG] Error:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Unknown error' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
