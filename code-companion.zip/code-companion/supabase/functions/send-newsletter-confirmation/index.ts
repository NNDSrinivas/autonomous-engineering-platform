import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { Resend } from "https://esm.sh/resend@4.0.0";

const resend = new Resend(Deno.env.get("RESEND_API_KEY"));

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface NewsletterConfirmationRequest {
  email: string;
  siteUrl?: string;
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { email, siteUrl = 'https://navi.dev' }: NewsletterConfirmationRequest = await req.json();
    
    // Generate unsubscribe token (base64 encoded email)
    const unsubscribeToken = btoa(email);
    const unsubscribeUrl = `${siteUrl}/newsletter/unsubscribe?token=${unsubscribeToken}`;

    if (!email) {
      console.error("Missing email in request");
      return new Response(
        JSON.stringify({ error: "Email is required" }),
        { status: 400, headers: { "Content-Type": "application/json", ...corsHeaders } }
      );
    }

    console.log(`Sending newsletter confirmation to: ${email}`);

    const emailResponse = await resend.emails.send({
      from: "NAVI <onboarding@resend.dev>",
      to: [email],
      subject: "Welcome to NAVI Newsletter! 🚀",
      html: `
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
          </head>
          <body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; background-color: #0a0a0a;">
            <div style="max-width: 600px; margin: 0 auto; padding: 40px 20px;">
              <!-- Header -->
              <div style="text-align: center; margin-bottom: 40px;">
                <h1 style="color: #ffffff; font-size: 32px; margin: 0; font-weight: bold;">
                  Welcome to <span style="background: linear-gradient(135deg, #6366f1, #8b5cf6); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">NAVI</span>
                </h1>
              </div>

              <!-- Main Content -->
              <div style="background-color: #1a1a1a; border-radius: 16px; padding: 32px; border: 1px solid #333;">
                <div style="text-align: center; margin-bottom: 24px;">
                  <div style="width: 64px; height: 64px; background-color: rgba(34, 197, 94, 0.1); border-radius: 50%; display: inline-flex; align-items: center; justify-content: center; border: 1px solid rgba(34, 197, 94, 0.3);">
                    <span style="font-size: 32px;">✓</span>
                  </div>
                </div>

                <h2 style="color: #ffffff; font-size: 24px; text-align: center; margin: 0 0 16px;">
                  You're officially subscribed!
                </h2>

                <p style="color: #a1a1aa; font-size: 16px; line-height: 1.6; text-align: center; margin: 0 0 24px;">
                  Thank you for joining 10,000+ engineers who receive weekly insights on AI-powered development.
                </p>

                <div style="background-color: #0a0a0a; border-radius: 12px; padding: 20px; margin-bottom: 24px;">
                  <h3 style="color: #ffffff; font-size: 16px; margin: 0 0 12px;">What to expect:</h3>
                  <ul style="color: #a1a1aa; font-size: 14px; line-height: 1.8; margin: 0; padding-left: 20px;">
                    <li>Weekly AI development tips & best practices</li>
                    <li>Early access to new NAVI features</li>
                    <li>Case studies from engineering teams</li>
                    <li>Exclusive content and resources</li>
                  </ul>
                </div>

                <div style="text-align: center;">
                  <a href="https://navi.dev" style="display: inline-block; background: linear-gradient(135deg, #6366f1, #8b5cf6); color: #ffffff; text-decoration: none; padding: 14px 32px; border-radius: 8px; font-weight: 600; font-size: 16px;">
                    Explore NAVI →
                  </a>
                </div>
              </div>

              <!-- Footer -->
              <div style="text-align: center; margin-top: 32px;">
                <p style="color: #71717a; font-size: 12px; margin: 0;">
                  You're receiving this because you subscribed to the NAVI newsletter.
                </p>
                <p style="color: #71717a; font-size: 12px; margin: 8px 0 0;">
                  <a href="${unsubscribeUrl}" style="color: #71717a; text-decoration: underline;">Unsubscribe</a> · © ${new Date().getFullYear()} NAVI. All rights reserved.
                </p>
              </div>
                </p>
              </div>
            </div>
          </body>
        </html>
      `,
    });

    console.log("Newsletter confirmation sent successfully:", emailResponse);

    return new Response(JSON.stringify({ success: true, data: emailResponse }), {
      status: 200,
      headers: { "Content-Type": "application/json", ...corsHeaders },
    });
  } catch (error: any) {
    console.error("Error sending newsletter confirmation:", error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { "Content-Type": "application/json", ...corsHeaders } }
    );
  }
};

serve(handler);
