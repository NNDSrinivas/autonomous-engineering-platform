import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
  const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
  const supabase = createClient(supabaseUrl, supabaseServiceKey);

  try {
    // Get user from auth header
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(JSON.stringify({ error: 'Authorization required' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);
    
    if (userError || !user) {
      return new Response(JSON.stringify({ error: 'Invalid token' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Get request body
    const { channel, message, blocks, thread_ts } = await req.json();
    console.log(`[SlackNotify] Sending notification to channel: ${channel || 'default'}`);

    // Get user's Slack connection
    const { data: connection, error: connError } = await supabase
      .from('integration_connections')
      .select('*')
      .eq('user_id', user.id)
      .eq('provider', 'slack')
      .eq('status', 'connected')
      .single();

    if (connError || !connection) {
      console.log('[SlackNotify] No Slack connection found');
      return new Response(JSON.stringify({ 
        success: false,
        error: 'Slack not connected',
        requiresAuth: true 
      }), {
        status: 200, // Return 200 so it doesn't throw, just indicates no connection
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const accessToken = connection.access_token;
    
    // Determine which channel to post to
    let targetChannel = channel;
    
    // If no channel specified, try to get the default channel from metadata or use #general
    if (!targetChannel) {
      const metadata = connection.provider_metadata as Record<string, unknown>;
      targetChannel = (metadata?.default_channel as string) || 'general';
    }

    // Try to find the channel ID if a name was provided
    let channelId = targetChannel;
    if (!targetChannel.startsWith('C') && !targetChannel.startsWith('D')) {
      // It's a channel name, need to look it up
      const channelsRes = await fetch(
        'https://slack.com/api/conversations.list?types=public_channel,private_channel&limit=200',
        {
          headers: { Authorization: `Bearer ${accessToken}` },
        }
      );
      const channelsData = await channelsRes.json();
      
      if (channelsData.ok && channelsData.channels) {
        const foundChannel = channelsData.channels.find(
          (ch: { name: string; id: string }) => 
            ch.name === targetChannel || ch.name === targetChannel.replace('#', '')
        );
        if (foundChannel) {
          channelId = foundChannel.id;
        } else {
          console.log(`[SlackNotify] Channel "${targetChannel}" not found, using first available`);
          // Use the first available channel
          channelId = channelsData.channels[0]?.id;
        }
      }
    }

    if (!channelId) {
      return new Response(JSON.stringify({ 
        success: false,
        error: 'No channel available to post to' 
      }), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Send the message
    const postBody: Record<string, unknown> = {
      channel: channelId,
      text: message,
    };

    if (blocks && blocks.length > 0) {
      postBody.blocks = blocks;
    }

    if (thread_ts) {
      postBody.thread_ts = thread_ts;
    }

    const response = await fetch('https://slack.com/api/chat.postMessage', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(postBody),
    });

    const result = await response.json();

    if (!result.ok) {
      console.error('[SlackNotify] Slack API error:', result.error);
      return new Response(JSON.stringify({ 
        success: false,
        error: result.error 
      }), {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log(`[SlackNotify] Message sent successfully to ${channelId}`);

    return new Response(JSON.stringify({ 
      success: true,
      ts: result.ts,
      channel: result.channel,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('[SlackNotify] Error:', error);
    return new Response(JSON.stringify({ 
      success: false,
      error: error instanceof Error ? error.message : 'Unknown error' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
