import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface CorrelationRequest {
  action: 'analyze' | 'link' | 'get_links';
  taskKey: string;
  taskTitle?: string;
  taskDescription?: string;
  // For linking
  linkedItems?: Array<{
    type: 'file' | 'pr' | 'commit' | 'branch' | 'slack_thread' | 'confluence_page';
    id: string;
    url?: string;
    title?: string;
  }>;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get('authorization');
    if (!authHeader) {
      throw new Error('Missing authorization header');
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);
    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    
    if (authError || !user) {
      throw new Error('Invalid authentication');
    }

    const { action, taskKey, taskTitle, taskDescription, linkedItems }: CorrelationRequest = await req.json();

    console.log(`[task-correlation] Processing ${action} for task ${taskKey}`);

    switch (action) {
      case 'analyze': {
        if (!LOVABLE_API_KEY) {
          throw new Error('LOVABLE_API_KEY is not configured');
        }

        // Use AI to suggest correlations based on task description
        const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${LOVABLE_API_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            model: 'google/gemini-2.5-flash',
            messages: [
              { 
                role: 'system', 
                content: `You are an expert at analyzing engineering tasks and identifying related code, files, and components.

Given a Jira task, analyze it and suggest:
1. Likely file paths that would need to be modified
2. Component names that might be affected
3. Potential dependencies
4. Related patterns in the codebase

Respond with JSON:
{
  "suggestedFiles": ["src/components/Example.tsx", "src/hooks/useExample.ts"],
  "suggestedComponents": ["ExampleComponent", "ExampleHook"],
  "keywords": ["authentication", "user", "login"],
  "dependencies": ["@supabase/supabase-js"],
  "complexity": "low" | "medium" | "high",
  "estimatedFiles": 3,
  "suggestedBranchName": "feature/task-key-short-description"
}`
              },
              { 
                role: 'user', 
                content: `Analyze this task and suggest related code:

Task: ${taskKey} - ${taskTitle}

Description:
${taskDescription}`
              }
            ],
          }),
        });

        if (!response.ok) {
          throw new Error('AI analysis failed');
        }

        const data = await response.json();
        const content = data.choices?.[0]?.message?.content;

        let analysis;
        try {
          const jsonMatch = content.match(/```(?:json)?\s*([\s\S]*?)```/);
          const jsonStr = jsonMatch ? jsonMatch[1] : content;
          analysis = JSON.parse(jsonStr.trim());
        } catch {
          analysis = { suggestedFiles: [], keywords: [], raw: content };
        }

        return new Response(JSON.stringify({
          success: true,
          taskKey,
          analysis
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      case 'link': {
        if (!linkedItems?.length) {
          throw new Error('linkedItems is required for link action');
        }

        // Get existing task memory or create new one
        const { data: existingMemory } = await supabase
          .from('task_memories')
          .select('*')
          .eq('task_key', taskKey)
          .eq('user_id', user.id)
          .single();

        const existingLinks = (existingMemory?.related_content as any)?.links || [];
        const newLinks = [...existingLinks, ...linkedItems.map(item => ({
          ...item,
          linkedAt: new Date().toISOString(),
          linkedBy: user.id
        }))];

        // Remove duplicates based on type + id
        const uniqueLinks = newLinks.filter((link, index, self) =>
          index === self.findIndex(l => l.type === link.type && l.id === link.id)
        );

        if (existingMemory) {
          await supabase
            .from('task_memories')
            .update({
              related_content: { links: uniqueLinks },
              updated_at: new Date().toISOString()
            })
            .eq('id', existingMemory.id);
        } else {
          await supabase
            .from('task_memories')
            .insert({
              task_key: taskKey,
              task_id: taskKey,
              user_id: user.id,
              title: taskTitle || taskKey,
              description: taskDescription,
              related_content: { links: uniqueLinks }
            });
        }

        console.log(`[task-correlation] Linked ${linkedItems.length} items to ${taskKey}`);

        return new Response(JSON.stringify({
          success: true,
          taskKey,
          totalLinks: uniqueLinks.length
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      case 'get_links': {
        const { data: taskMemory } = await supabase
          .from('task_memories')
          .select('related_content')
          .eq('task_key', taskKey)
          .eq('user_id', user.id)
          .single();

        const links = (taskMemory?.related_content as any)?.links || [];

        return new Response(JSON.stringify({
          success: true,
          taskKey,
          links
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      default:
        throw new Error(`Unknown action: ${action}`);
    }

  } catch (error) {
    console.error('[task-correlation] Error:', error);
    return new Response(JSON.stringify({ 
      error: error instanceof Error ? error.message : 'Unknown error' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
