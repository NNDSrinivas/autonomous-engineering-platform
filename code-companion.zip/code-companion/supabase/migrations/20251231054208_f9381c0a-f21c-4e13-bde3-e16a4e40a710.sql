-- Enable the pgvector extension for embedding storage
CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA extensions;

-- Memory Types Enum
CREATE TYPE public.memory_type AS ENUM (
  'user_preference',
  'task_context', 
  'code_snippet',
  'meeting_note',
  'conversation',
  'documentation',
  'slack_message',
  'jira_ticket'
);

-- Memory Source Enum
CREATE TYPE public.memory_source AS ENUM (
  'jira',
  'confluence', 
  'slack',
  'teams',
  'zoom',
  'github',
  'manual',
  'conversation'
);

-- User Preferences Table (Long-term memory per user)
CREATE TABLE public.user_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  preference_key text NOT NULL,
  preference_value jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, preference_key)
);

-- Workspace Memory Table (Mid-term memory across workspace)
CREATE TABLE public.workspace_memories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id uuid REFERENCES public.organizations(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  memory_type memory_type NOT NULL,
  source memory_source NOT NULL DEFAULT 'manual',
  title text,
  content text NOT NULL,
  embedding vector(1536),
  metadata jsonb DEFAULT '{}',
  source_url text,
  source_id text,
  relevance_score float DEFAULT 0.5,
  expires_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Conversation Memories Table (Short-term + summarized)
CREATE TABLE public.conversation_memories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  conversation_id text NOT NULL,
  summary text,
  message_count integer DEFAULT 0,
  key_topics text[],
  embedding vector(1536),
  metadata jsonb DEFAULT '{}',
  last_message_at timestamptz DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Task Context Memory (Per-task knowledge)
CREATE TABLE public.task_memories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  task_id text NOT NULL,
  task_key text,
  title text,
  description text,
  related_content jsonb DEFAULT '[]',
  embedding vector(1536),
  status text DEFAULT 'active',
  priority text,
  assignee text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, task_id)
);

-- Enable RLS
ALTER TABLE public.user_preferences ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.workspace_memories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.conversation_memories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.task_memories ENABLE ROW LEVEL SECURITY;

-- RLS Policies for user_preferences
CREATE POLICY "Users can manage their own preferences"
ON public.user_preferences FOR ALL
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- RLS Policies for workspace_memories (users see their own + org shared)
CREATE POLICY "Users can view their own workspace memories"
ON public.workspace_memories FOR SELECT
USING (
  auth.uid() = user_id OR 
  (organization_id IS NOT NULL AND is_org_member(auth.uid(), organization_id))
);

CREATE POLICY "Users can create their own workspace memories"
ON public.workspace_memories FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own workspace memories"
ON public.workspace_memories FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own workspace memories"
ON public.workspace_memories FOR DELETE
USING (auth.uid() = user_id);

-- RLS Policies for conversation_memories
CREATE POLICY "Users can manage their own conversation memories"
ON public.conversation_memories FOR ALL
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- RLS Policies for task_memories
CREATE POLICY "Users can manage their own task memories"
ON public.task_memories FOR ALL
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- Create indexes for vector similarity search
CREATE INDEX ON public.workspace_memories 
USING ivfflat (embedding vector_cosine_ops) 
WITH (lists = 100);

CREATE INDEX ON public.conversation_memories 
USING ivfflat (embedding vector_cosine_ops) 
WITH (lists = 100);

CREATE INDEX ON public.task_memories 
USING ivfflat (embedding vector_cosine_ops) 
WITH (lists = 100);

-- Additional indexes for fast lookups
CREATE INDEX idx_workspace_memories_user ON public.workspace_memories(user_id);
CREATE INDEX idx_workspace_memories_type ON public.workspace_memories(memory_type);
CREATE INDEX idx_workspace_memories_source ON public.workspace_memories(source);
CREATE INDEX idx_task_memories_task_id ON public.task_memories(task_id);
CREATE INDEX idx_conversation_memories_conv_id ON public.conversation_memories(conversation_id);

-- Function to search memories by similarity
CREATE OR REPLACE FUNCTION public.search_memories(
  query_embedding vector(1536),
  match_count int DEFAULT 5,
  filter_user_id uuid DEFAULT NULL,
  filter_type memory_type DEFAULT NULL
)
RETURNS TABLE (
  id uuid,
  content text,
  title text,
  memory_type memory_type,
  source memory_source,
  metadata jsonb,
  similarity float
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    wm.id,
    wm.content,
    wm.title,
    wm.memory_type,
    wm.source,
    wm.metadata,
    1 - (wm.embedding <=> query_embedding) as similarity
  FROM public.workspace_memories wm
  WHERE 
    (filter_user_id IS NULL OR wm.user_id = filter_user_id)
    AND (filter_type IS NULL OR wm.memory_type = filter_type)
    AND wm.embedding IS NOT NULL
  ORDER BY wm.embedding <=> query_embedding
  LIMIT match_count;
END;
$$;

-- Update timestamps trigger
CREATE TRIGGER update_user_preferences_updated_at
BEFORE UPDATE ON public.user_preferences
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_workspace_memories_updated_at
BEFORE UPDATE ON public.workspace_memories
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_conversation_memories_updated_at
BEFORE UPDATE ON public.conversation_memories
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_task_memories_updated_at
BEFORE UPDATE ON public.task_memories
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();