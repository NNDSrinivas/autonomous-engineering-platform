-- Create message_feedback table to store likes/dislikes for AI improvement
CREATE TABLE public.message_feedback (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  message_id TEXT NOT NULL,
  conversation_id TEXT NOT NULL,
  feedback_type TEXT NOT NULL CHECK (feedback_type IN ('like', 'dislike')),
  message_content TEXT,
  message_role TEXT NOT NULL CHECK (message_role IN ('user', 'assistant')),
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.message_feedback ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can create their own feedback"
ON public.message_feedback
FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view their own feedback"
ON public.message_feedback
FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own feedback"
ON public.message_feedback
FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own feedback"
ON public.message_feedback
FOR DELETE
USING (auth.uid() = user_id);

-- Add unique constraint to prevent duplicate feedback
CREATE UNIQUE INDEX idx_message_feedback_unique 
ON public.message_feedback (user_id, message_id, conversation_id);

-- Add index for analytics queries
CREATE INDEX idx_message_feedback_type 
ON public.message_feedback (feedback_type, created_at);

-- Add trigger for updated_at
CREATE TRIGGER update_message_feedback_updated_at
BEFORE UPDATE ON public.message_feedback
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();