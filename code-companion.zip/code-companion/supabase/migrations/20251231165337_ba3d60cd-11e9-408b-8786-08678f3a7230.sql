-- Create app_role enum for user roles
CREATE TYPE public.app_role AS ENUM ('admin', 'moderator', 'user');

-- Create user_roles table
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);

-- Enable RLS
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- Create security definer function to check roles (prevents RLS recursion)
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;

-- RLS policies for user_roles
CREATE POLICY "Users can view their own roles"
ON public.user_roles
FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Admins can view all roles"
ON public.user_roles
FOR SELECT
USING (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can manage roles"
ON public.user_roles
FOR ALL
USING (has_role(auth.uid(), 'admin'));

-- Add admin-only policy for viewing all feedback
CREATE POLICY "Admins can view all feedback"
ON public.message_feedback
FOR SELECT
USING (has_role(auth.uid(), 'admin'));

-- Create an aggregated view for feedback analytics (no RLS needed, accessed via function)
CREATE OR REPLACE FUNCTION public.get_feedback_analytics()
RETURNS TABLE (
  total_likes BIGINT,
  total_dislikes BIGINT,
  feedback_by_day JSONB,
  recent_dislikes JSONB
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Check if user is admin
  IF NOT has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Access denied: Admin role required';
  END IF;

  RETURN QUERY
  SELECT
    (SELECT COUNT(*) FROM message_feedback WHERE feedback_type = 'like')::BIGINT as total_likes,
    (SELECT COUNT(*) FROM message_feedback WHERE feedback_type = 'dislike')::BIGINT as total_dislikes,
    (
      SELECT COALESCE(jsonb_agg(daily_stats ORDER BY day DESC), '[]'::jsonb)
      FROM (
        SELECT 
          DATE(created_at) as day,
          COUNT(*) FILTER (WHERE feedback_type = 'like') as likes,
          COUNT(*) FILTER (WHERE feedback_type = 'dislike') as dislikes
        FROM message_feedback
        WHERE created_at > NOW() - INTERVAL '30 days'
        GROUP BY DATE(created_at)
        LIMIT 30
      ) daily_stats
    ) as feedback_by_day,
    (
      SELECT COALESCE(jsonb_agg(recent ORDER BY created_at DESC), '[]'::jsonb)
      FROM (
        SELECT 
          id,
          message_content,
          created_at,
          metadata
        FROM message_feedback
        WHERE feedback_type = 'dislike'
        ORDER BY created_at DESC
        LIMIT 20
      ) recent
    ) as recent_dislikes;
END;
$$;