-- Create workflow_templates table for saving custom templates
CREATE TABLE public.workflow_templates (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  icon TEXT DEFAULT 'Zap',
  phases TEXT[] NOT NULL,
  is_default BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create workflow_history table for tracking completed workflows
CREATE TABLE public.workflow_history (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  task_id TEXT NOT NULL,
  task_key TEXT NOT NULL,
  task_title TEXT,
  template_id TEXT,
  template_name TEXT,
  phases_completed TEXT[] NOT NULL DEFAULT '{}',
  phases_skipped TEXT[] DEFAULT '{}',
  status TEXT NOT NULL DEFAULT 'in_progress',
  started_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  completed_at TIMESTAMP WITH TIME ZONE,
  duration_ms INTEGER,
  results JSONB DEFAULT '[]'::jsonb,
  error_message TEXT,
  pr_url TEXT,
  pr_number INTEGER,
  branch_name TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.workflow_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.workflow_history ENABLE ROW LEVEL SECURITY;

-- RLS policies for workflow_templates
CREATE POLICY "Users can view their own templates"
  ON public.workflow_templates
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own templates"
  ON public.workflow_templates
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own templates"
  ON public.workflow_templates
  FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own templates"
  ON public.workflow_templates
  FOR DELETE
  USING (auth.uid() = user_id);

-- RLS policies for workflow_history
CREATE POLICY "Users can view their own workflow history"
  ON public.workflow_history
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own workflow history"
  ON public.workflow_history
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own workflow history"
  ON public.workflow_history
  FOR UPDATE
  USING (auth.uid() = user_id);

-- Create indexes for performance
CREATE INDEX idx_workflow_templates_user_id ON public.workflow_templates(user_id);
CREATE INDEX idx_workflow_history_user_id ON public.workflow_history(user_id);
CREATE INDEX idx_workflow_history_task_id ON public.workflow_history(task_id);
CREATE INDEX idx_workflow_history_status ON public.workflow_history(status);
CREATE INDEX idx_workflow_history_started_at ON public.workflow_history(started_at DESC);

-- Add trigger for updated_at
CREATE TRIGGER update_workflow_templates_updated_at
  BEFORE UPDATE ON public.workflow_templates
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();