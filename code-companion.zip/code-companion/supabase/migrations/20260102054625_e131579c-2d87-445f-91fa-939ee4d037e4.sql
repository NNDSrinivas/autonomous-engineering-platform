-- Create agent_activity_history table to persist completed agent activities
CREATE TABLE public.agent_activity_history (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  session_id TEXT NOT NULL,
  conversation_id TEXT,
  task_key TEXT,
  phase TEXT NOT NULL DEFAULT 'complete',
  duration_ms INTEGER,
  total_edits INTEGER DEFAULT 0,
  lines_changed INTEGER DEFAULT 0,
  tokens_processed INTEGER DEFAULT 0,
  files JSONB DEFAULT '[]'::jsonb,
  steps JSONB DEFAULT '[]'::jsonb,
  commands JSONB DEFAULT '[]'::jsonb,
  summary TEXT,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  completed_at TIMESTAMP WITH TIME ZONE
);

-- Enable Row Level Security
ALTER TABLE public.agent_activity_history ENABLE ROW LEVEL SECURITY;

-- Create policies for user access
CREATE POLICY "Users can view their own activity history" 
ON public.agent_activity_history 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own activity history" 
ON public.agent_activity_history 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own activity history" 
ON public.agent_activity_history 
FOR DELETE 
USING (auth.uid() = user_id);

-- Create index for efficient queries
CREATE INDEX idx_agent_activity_user_created ON public.agent_activity_history(user_id, created_at DESC);
CREATE INDEX idx_agent_activity_session ON public.agent_activity_history(session_id);

-- Enable realtime for activity updates
ALTER PUBLICATION supabase_realtime ADD TABLE public.agent_activity_history;