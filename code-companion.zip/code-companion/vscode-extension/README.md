# NAVI AI - VS Code Extension

**Autonomous Engineering Intelligence for your IDE**

NAVI brings the power of AI-driven engineering assistance directly into VS Code, connecting your Jira tasks, Slack conversations, GitHub PRs, and more into a unified intelligent workspace.

## Features

### 🤖 AI-Powered Chat Panel
- Natural language conversations with context awareness
- Streaming responses with code blocks and actions
- Morning briefing and daily standup summaries
- Search across all your integrated tools

### 💡 Inline Code Suggestions
- Real-time code completions as you type
- Context-aware suggestions based on your codebase
- Multi-language support

### 🔧 Code Actions
- Right-click to explain, refactor, or generate code
- Quick fixes for build errors
- AI-powered code review assistance

### 📋 Task Management
- View your assigned Jira tasks in the sidebar
- Start working on tasks with full context
- Link commits and PRs to Jira issues

### 🔄 CI/CD Integration
- Real-time build status notifications
- Auto-analyze and fix failing builds
- View workflow runs and logs

### 🔔 Unified Notifications
- Aggregated alerts from all integrations
- PR review requests, mentions, build failures
- Configurable notification preferences

## Installation

### From VSIX (Local Development)

1. Clone this repository
2. Install dependencies:
   ```bash
   cd vscode-extension
   npm install
   ```
3. Compile the extension:
   ```bash
   npm run compile
   ```
4. Package the extension:
   ```bash
   npm run package
   ```
5. Install the generated `.vsix` file:
   - Open VS Code
   - Go to Extensions (Cmd+Shift+X)
   - Click the `...` menu → Install from VSIX
   - Select the generated file

### Configuration

1. Open VS Code Settings (Cmd+,)
2. Search for "NAVI"
3. Configure:
   - **API Endpoint**: Your NAVI backend URL (e.g., `https://your-project.supabase.co/functions/v1`)
   - **API Key**: Your NAVI API key
   - **Default Model**: Choose your preferred AI model
   - **Jira Base URL**: Your Jira instance URL
   - **Slack Workspace**: Your Slack workspace ID

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Cmd+Shift+N` | Open NAVI Chat |
| `Cmd+Shift+G` | Generate Code |
| `Cmd+Shift+E` | Explain Selected Code |
| `Cmd+/` | Command Palette (NAVI commands) |

## Commands

| Command | Description |
|---------|-------------|
| `NAVI: Open Chat Panel` | Open the AI chat interface |
| `NAVI: Explain Selected Code` | Get an explanation of selected code |
| `NAVI: Refactor Selected Code` | Refactor with AI assistance |
| `NAVI: Generate Code from Description` | Generate code from natural language |
| `NAVI: Run Terminal Command` | Execute a terminal command with approval |
| `NAVI: Show My Jira Tasks` | View assigned tasks |
| `NAVI: Start Working on Task` | Begin a task with full context |
| `NAVI: Create Pull Request` | Generate a PR with description |
| `NAVI: Analyze and Fix Build Errors` | Auto-fix failing builds |
| `NAVI: Show Morning Briefing` | Get your daily briefing |
| `NAVI: Search Workspace Context` | Search across all integrations |

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    VS Code Extension                      │
├─────────────────────────────────────────────────────────┤
│  Providers                    │  Services                 │
│  ├─ NaviChatViewProvider     │  ├─ WorkspaceIndexer      │
│  ├─ NaviCompletionProvider   │  ├─ TerminalManager       │
│  ├─ NaviTasksProvider        │  └─ NotificationManager   │
│  ├─ NaviActivityProvider     │                           │
│  └─ NaviCodeActionProvider   │                           │
├─────────────────────────────────────────────────────────┤
│                    NaviAPIClient                          │
│  ├─ streamChat()            ├─ getJiraTasks()            │
│  ├─ getInlineCompletion()   ├─ getCICDStatus()           │
│  └─ generateCode()          └─ getNotifications()        │
├─────────────────────────────────────────────────────────┤
│               NAVI Backend (Supabase Edge Functions)      │
│  ├─ navi-chat              ├─ ai-code-generator          │
│  ├─ integration-data       ├─ github-api                 │
│  └─ rag-query              └─ task-correlation           │
└─────────────────────────────────────────────────────────┘
```

## Development

### Prerequisites
- Node.js 18+
- VS Code 1.85+
- TypeScript 5+

### Setup
```bash
# Install dependencies
npm install

# Watch for changes
npm run watch

# Press F5 in VS Code to launch Extension Development Host
```

### Testing
```bash
npm run test
```

### Publishing
```bash
# Package for distribution
npm run package

# Publish to VS Code Marketplace (requires access token)
npm run publish
```

## Connecting to NAVI Backend

The extension connects to your NAVI backend (Supabase Edge Functions) for:
- AI chat and code generation
- Integration data (Jira, Slack, GitHub)
- RAG-based context search
- Memory and preferences

Ensure your backend has the following functions deployed:
- `navi-chat`
- `ai-code-generator`
- `integration-data`
- `github-api`
- `rag-query`
- `task-correlation`

## Privacy & Security

- All API keys are stored securely in VS Code settings
- Code context is only sent when you explicitly request assistance
- Auto-approve mode is disabled by default
- All terminal commands require manual approval

## Roadmap

- [ ] Multi-cursor inline completions
- [ ] Git diff visualization
- [ ] Voice input support
- [ ] Team collaboration features
- [ ] Custom prompt templates
- [ ] Plugin system for custom integrations

## License

MIT

## Support

For issues and feature requests, please open an issue on GitHub.
