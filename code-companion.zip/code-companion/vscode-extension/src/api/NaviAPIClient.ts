import * as vscode from 'vscode';
import axios, { AxiosInstance } from 'axios';

export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export interface JiraTask {
  id: string;
  key: string;
  title: string;
  status: string;
  priority: string;
  assignee?: string;
  description?: string;
}

export interface StreamCallback {
  onDelta: (text: string) => void;
  onDone: () => void;
  onError: (error: Error) => void;
}

export class NaviAPIClient {
  private client: AxiosInstance;
  private context: vscode.ExtensionContext;

  constructor(context: vscode.ExtensionContext) {
    this.context = context;
    this.client = this.createClient();

    // Re-create client when configuration changes
    vscode.workspace.onDidChangeConfiguration(e => {
      if (e.affectsConfiguration('navi')) {
        this.client = this.createClient();
      }
    });
  }

  private createClient(): AxiosInstance {
    const config = vscode.workspace.getConfiguration('navi');
    const apiEndpoint = config.get<string>('apiEndpoint') || 'https://xzpgwblreapqwuyytdzj.supabase.co/functions/v1';
    const apiKey = config.get<string>('apiKey') || '';

    return axios.create({
      baseURL: apiEndpoint,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
    });
  }

  async streamChat(
    messages: ChatMessage[],
    callbacks: StreamCallback,
    taskContext?: any
  ): Promise<void> {
    const config = vscode.workspace.getConfiguration('navi');
    const model = config.get<string>('defaultModel') || 'google/gemini-2.5-flash';

    try {
      const response = await fetch(`${this.client.defaults.baseURL}/navi-chat`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': this.client.defaults.headers['Authorization'] as string,
        },
        body: JSON.stringify({
          messages,
          model,
          taskContext,
          stream: true,
        }),
      });

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      const reader = response.body?.getReader();
      if (!reader) {
        throw new Error('No response body');
      }

      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6).trim();
            if (data === '[DONE]') {
              callbacks.onDone();
              return;
            }

            try {
              const parsed = JSON.parse(data);
              const content = parsed.choices?.[0]?.delta?.content;
              if (content) {
                callbacks.onDelta(content);
              }
            } catch {
              // Ignore parse errors for partial JSON
            }
          }
        }
      }

      callbacks.onDone();
    } catch (error) {
      callbacks.onError(error instanceof Error ? error : new Error(String(error)));
    }
  }

  async getJiraTasks(): Promise<JiraTask[]> {
    try {
      const response = await this.client.post('/integration-data', {
        provider: 'jira',
        action: 'my-tasks',
      });
      return response.data.data || [];
    } catch (error) {
      console.error('Failed to fetch Jira tasks:', error);
      return [];
    }
  }

  async getTaskDetails(taskKey: string): Promise<any> {
    try {
      const response = await this.client.post('/integration-data', {
        provider: 'jira',
        action: 'get-issue',
        issueKey: taskKey,
      });
      return response.data.data;
    } catch (error) {
      console.error('Failed to fetch task details:', error);
      return null;
    }
  }

  async searchContext(query: string): Promise<any[]> {
    try {
      const response = await this.client.post('/rag-query', {
        query,
        topK: 10,
      });
      return response.data.results || [];
    } catch (error) {
      console.error('Failed to search context:', error);
      return [];
    }
  }

  async getInlineCompletion(
    prefix: string,
    suffix: string,
    language: string,
    filePath: string,
    maxTokens: number = 150
  ): Promise<string | null> {
    return this.getInlineCompletionWithContext(prefix, suffix, language, filePath, null, maxTokens);
  }

  async getInlineCompletionWithContext(
    prefix: string,
    suffix: string,
    language: string,
    filePath: string,
    context: {
      imports?: string[];
      relatedFiles?: Array<{ fileName: string; content: string; relevance: string }>;
      projectStructure?: string[];
      recentEdits?: Array<{ fileName: string; snippet: string }>;
    } | null,
    maxTokens: number = 150
  ): Promise<string | null> {
    try {
      const response = await this.client.post('/ai-code-complete', {
        prefix,
        suffix,
        language,
        fileName: filePath,
        maxTokens,
        ...(context || {}),
      });
      
      if (response.status === 429) {
        vscode.window.showWarningMessage('NAVI: Rate limit exceeded.');
        return null;
      }
      
      return response.data.completion || null;
    } catch (error: any) {
      if (error?.response?.status === 429 || error?.response?.status === 402) {
        vscode.window.showWarningMessage('NAVI: API limit reached.');
      }
      return null;
    }
  }

  async generateCode(
    description: string,
    language: string,
    context?: string
  ): Promise<{ code: string; explanation: string } | null> {
    try {
      const response = await this.client.post('/ai-code-generator', {
        action: 'generate',
        taskDescription: description,
        language,
        context,
      });
      return response.data;
    } catch (error) {
      console.error('Failed to generate code:', error);
      return null;
    }
  }

  async getGitHubPRs(): Promise<any[]> {
    try {
      const response = await this.client.post('/github-api', {
        action: 'list-prs',
        state: 'open',
      });
      return response.data.data || [];
    } catch (error) {
      console.error('Failed to fetch PRs:', error);
      return [];
    }
  }

  async getCICDStatus(): Promise<any[]> {
    try {
      const response = await this.client.post('/integration-data', {
        provider: 'github',
        action: 'workflow-runs',
      });
      return response.data.data || [];
    } catch (error) {
      console.error('Failed to fetch CI/CD status:', error);
      return [];
    }
  }

  async getNotifications(): Promise<any[]> {
    try {
      const response = await this.client.post('/integration-data', {
        provider: 'all',
        action: 'notifications',
      });
      return response.data.data || [];
    } catch (error) {
      console.error('Failed to fetch notifications:', error);
      return [];
    }
  }
}
