import * as vscode from 'vscode';
import { NaviChatViewProvider } from './providers/NaviChatViewProvider';
import { NaviTasksProvider } from './providers/NaviTasksProvider';
import { NaviActivityProvider } from './providers/NaviActivityProvider';
import { NaviCompletionProvider } from './providers/NaviCompletionProvider';
import { NaviCodeActionProvider } from './providers/NaviCodeActionProvider';
import { NaviAPIClient } from './api/NaviAPIClient';
import { WorkspaceIndexer } from './services/WorkspaceIndexer';
import { TerminalManager } from './services/TerminalManager';
import { NotificationManager } from './services/NotificationManager';

let outputChannel: vscode.OutputChannel;

export function activate(context: vscode.ExtensionContext) {
  outputChannel = vscode.window.createOutputChannel('NAVI AI');
  outputChannel.appendLine('🚀 NAVI AI Extension activating...');

  // Initialize API client
  const apiClient = new NaviAPIClient(context);
  
  // Initialize services
  const workspaceIndexer = new WorkspaceIndexer(context, apiClient);
  const terminalManager = new TerminalManager();
  const notificationManager = new NotificationManager(context);

  // Register Chat Panel Provider
  const chatProvider = new NaviChatViewProvider(context.extensionUri, apiClient, terminalManager);
  context.subscriptions.push(
    vscode.window.registerWebviewViewProvider('navi.chatPanel', chatProvider)
  );

  // Register Tasks Tree View
  const tasksProvider = new NaviTasksProvider(apiClient);
  vscode.window.registerTreeDataProvider('navi.tasksView', tasksProvider);

  // Register Activity Tree View
  const activityProvider = new NaviActivityProvider(apiClient);
  vscode.window.registerTreeDataProvider('navi.activityView', activityProvider);

  // Register Inline Completion Provider (for code suggestions)
  const completionProvider = new NaviCompletionProvider(apiClient);
  context.subscriptions.push(
    vscode.languages.registerInlineCompletionItemProvider(
      { pattern: '**' },
      completionProvider
    )
  );

  // Register Code Action Provider (for quick fixes and refactoring)
  const codeActionProvider = new NaviCodeActionProvider(apiClient);
  context.subscriptions.push(
    vscode.languages.registerCodeActionsProvider(
      { pattern: '**' },
      codeActionProvider,
      { providedCodeActionKinds: [vscode.CodeActionKind.QuickFix, vscode.CodeActionKind.Refactor] }
    )
  );

  // Register Commands
  registerCommands(context, apiClient, chatProvider, tasksProvider, workspaceIndexer, terminalManager);

  // Start workspace indexing
  workspaceIndexer.indexWorkspace();

  // Show morning briefing on startup (if enabled)
  showMorningBriefingOnStartup(apiClient);

  // Start polling for notifications
  notificationManager.startPolling(apiClient);

  outputChannel.appendLine('✅ NAVI AI Extension activated successfully');
  
  // Show welcome message
  vscode.window.showInformationMessage(
    'Hello! NAVI is ready. Press Cmd+Shift+N to open the chat panel.',
    'Open NAVI'
  ).then(selection => {
    if (selection === 'Open NAVI') {
      vscode.commands.executeCommand('navi.openChat');
    }
  });
}

function registerCommands(
  context: vscode.ExtensionContext,
  apiClient: NaviAPIClient,
  chatProvider: NaviChatViewProvider,
  tasksProvider: NaviTasksProvider,
  workspaceIndexer: WorkspaceIndexer,
  terminalManager: TerminalManager
) {
  // Open Chat Panel
  context.subscriptions.push(
    vscode.commands.registerCommand('navi.openChat', () => {
      vscode.commands.executeCommand('navi.chatPanel.focus');
    })
  );

  // Explain Selected Code
  context.subscriptions.push(
    vscode.commands.registerCommand('navi.explainCode', async () => {
      const editor = vscode.window.activeTextEditor;
      if (!editor) return;

      const selection = editor.selection;
      const selectedText = editor.document.getText(selection);
      
      if (!selectedText) {
        vscode.window.showWarningMessage('Please select some code first');
        return;
      }

      chatProvider.sendMessage(`Explain this code:\n\`\`\`${editor.document.languageId}\n${selectedText}\n\`\`\``);
    })
  );

  // Refactor Selected Code (Enhanced with Quick Pick)
  context.subscriptions.push(
    vscode.commands.registerCommand('navi.refactorCode', async () => {
      const editor = vscode.window.activeTextEditor;
      if (!editor) return;

      const selection = editor.selection;
      const selectedText = editor.document.getText(selection);
      
      if (!selectedText) {
        vscode.window.showWarningMessage('Please select some code first');
        return;
      }

      const refactorOptions = [
        { label: '$(lightbulb) All Improvements', description: 'Analyze all aspects', value: 'all' },
        { label: '$(symbol-function) Extract Functions', description: 'Extract reusable functions', value: 'extract' },
        { label: '$(symbol-interface) Improve Types', description: 'Add/improve TypeScript types', value: 'types' },
        { label: '$(rocket) Optimize Performance', description: 'Performance improvements', value: 'performance' },
        { label: '$(book) Improve Readability', description: 'Cleaner, more readable code', value: 'readability' },
        { label: '$(shield) Security Review', description: 'Find security issues', value: 'security' },
        { label: '$(edit) Custom...', description: 'Describe your own refactoring', value: 'custom' },
      ];

      const selected = await vscode.window.showQuickPick(refactorOptions, {
        placeHolder: 'Select refactoring type',
        title: 'NAVI: Refactor Code'
      });

      if (!selected) return;

      let refactorType = selected.value;
      if (refactorType === 'custom') {
        const customInstruction = await vscode.window.showInputBox({
          prompt: 'Describe how you want to refactor this code'
        });
        if (!customInstruction) return;
        
        chatProvider.sendMessage(
          `Refactor this code (${customInstruction}):\n\`\`\`${editor.document.languageId}\n${selectedText}\n\`\`\`\n\nFile: ${editor.document.fileName}`
        );
        return;
      }

      // Call the ai-refactor edge function
      vscode.window.withProgress({
        location: vscode.ProgressLocation.Notification,
        title: 'NAVI: Analyzing code...',
        cancellable: false
      }, async () => {
        try {
          const response = await fetch(`${getApiEndpoint()}/ai-refactor`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              code: selectedText,
              language: editor.document.languageId,
              fileName: editor.document.fileName,
              refactorType,
            }),
          });

          if (!response.ok) {
            throw new Error(`API error: ${response.status}`);
          }

          const data = (await response.json()) as any;
          
          if (data.suggestions && data.suggestions.length > 0) {
            // Show suggestions in quick pick
            const suggestionItems: Array<{ label: string; description?: string; detail?: string; suggestion: any }> = data.suggestions.map((s: any) => ({
              label: `${getPriorityIcon(s.priority)} ${s.title}`,
              description: s.category,
              detail: s.description,
              suggestion: s,
            }));

            const selectedSuggestion = await vscode.window.showQuickPick<typeof suggestionItems[number]>(suggestionItems, {
              placeHolder: `Found ${data.suggestions.length} suggestions (Score: ${data.overallScore}/10)`,
              title: 'NAVI: Refactoring Suggestions'
            });

            if (selectedSuggestion) {
              // Show diff and offer to apply
              const apply = await vscode.window.showInformationMessage(
                `Apply: ${selectedSuggestion.suggestion.title}?`,
                { modal: true, detail: selectedSuggestion.suggestion.description },
                'Apply',
                'Show in Chat'
              );

              if (apply === 'Apply') {
                // Replace selected text with suggested code
                await editor.edit(editBuilder => {
                  editBuilder.replace(selection, selectedSuggestion.suggestion.suggestedCode);
                });
                vscode.window.showInformationMessage('Refactoring applied!');
              } else if (apply === 'Show in Chat') {
                chatProvider.sendMessage(
                  `Show me more details about this refactoring suggestion:\n\n**${selectedSuggestion.suggestion.title}**\n\n${selectedSuggestion.suggestion.description}\n\nOriginal:\n\`\`\`\n${selectedSuggestion.suggestion.originalCode}\n\`\`\`\n\nSuggested:\n\`\`\`\n${selectedSuggestion.suggestion.suggestedCode}\n\`\`\``
                );
              }
            }
          } else {
            vscode.window.showInformationMessage('No refactoring suggestions found for this code.');
          }
        } catch (error) {
          vscode.window.showErrorMessage(`Refactoring failed: ${error}`);
        }
      });
    })
  );

  // Generate Tests Command
  context.subscriptions.push(
    vscode.commands.registerCommand('navi.generateTests', async () => {
      const editor = vscode.window.activeTextEditor;
      if (!editor) return;

      const selection = editor.selection;
      let codeToTest = editor.document.getText(selection);
      
      // If no selection, use entire file
      if (!codeToTest) {
        codeToTest = editor.document.getText();
      }

      const testOptions = [
        { label: '$(beaker) Unit Tests', description: 'Isolated component/function tests', value: 'unit' },
        { label: '$(server) Integration Tests', description: 'Test component interactions', value: 'integration' },
        { label: '$(globe) E2E Tests', description: 'End-to-end user flow tests', value: 'e2e' },
      ];

      const testType = await vscode.window.showQuickPick(testOptions, {
        placeHolder: 'Select test type',
        title: 'NAVI: Generate Tests'
      });

      if (!testType) return;

      const frameworkOptions = getTestFrameworkOptions(editor.document.languageId);
      let framework = frameworkOptions[0]?.value;

      if (frameworkOptions.length > 1) {
        const selectedFramework = await vscode.window.showQuickPick(frameworkOptions, {
          placeHolder: 'Select test framework',
          title: 'NAVI: Test Framework'
        });
        if (!selectedFramework) return;
        framework = selectedFramework.value;
      }

      vscode.window.withProgress({
        location: vscode.ProgressLocation.Notification,
        title: 'NAVI: Generating tests...',
        cancellable: false
      }, async () => {
        try {
          const response = await fetch(`${getApiEndpoint()}/ai-test-generator`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              code: codeToTest,
              language: editor.document.languageId,
              fileName: editor.document.fileName,
              framework,
              testType: testType.value,
            }),
          });

          if (!response.ok) {
            throw new Error(`API error: ${response.status}`);
          }

          const data = (await response.json()) as any;
          
          if (data.tests) {
            // Create new test file
            const testFileName = data.suggestedFileName || 
              editor.document.fileName.replace(/\.(ts|tsx|js|jsx)$/, '.test.$1');
            
            const action = await vscode.window.showInformationMessage(
              `Generated ${data.testCount} test cases using ${data.framework}`,
              'Create Test File',
              'Copy to Clipboard',
              'Show in Chat'
            );

            if (action === 'Create Test File') {
              const testUri = vscode.Uri.file(testFileName);
              await vscode.workspace.fs.writeFile(testUri, Buffer.from(data.tests));
              await vscode.window.showTextDocument(testUri);
            } else if (action === 'Copy to Clipboard') {
              await vscode.env.clipboard.writeText(data.tests);
              vscode.window.showInformationMessage('Tests copied to clipboard!');
            } else if (action === 'Show in Chat') {
              chatProvider.sendMessage(
                `Here are the generated tests:\n\n\`\`\`${editor.document.languageId}\n${data.tests}\n\`\`\`\n\n${data.explanation || ''}`
              );
            }
          }
        } catch (error) {
          vscode.window.showErrorMessage(`Test generation failed: ${error}`);
        }
      });
    })
  );

  // Generate Documentation Command
  context.subscriptions.push(
    vscode.commands.registerCommand('navi.generateDocs', async () => {
      const editor = vscode.window.activeTextEditor;
      if (!editor) return;

      const selection = editor.selection;
      let codeToDocument = editor.document.getText(selection);
      
      if (!codeToDocument) {
        codeToDocument = editor.document.getText();
      }

      const docOptions = [
        { label: '$(comment) JSDoc/TSDoc', description: 'Function and class documentation', value: 'jsdoc' },
        { label: '$(book) README Section', description: 'Generate README content', value: 'readme' },
        { label: '$(list-unordered) API Reference', description: 'API documentation', value: 'api' },
        { label: '$(note) Inline Comments', description: 'Add explanatory comments', value: 'inline' },
        { label: '$(files) All Documentation', description: 'Generate all doc types', value: 'all' },
      ];

      const docType = await vscode.window.showQuickPick(docOptions, {
        placeHolder: 'Select documentation type',
        title: 'NAVI: Generate Documentation'
      });

      if (!docType) return;

      vscode.window.withProgress({
        location: vscode.ProgressLocation.Notification,
        title: 'NAVI: Generating documentation...',
        cancellable: false
      }, async () => {
        try {
          const response = await fetch(`${getApiEndpoint()}/ai-documentation`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              code: codeToDocument,
              language: editor.document.languageId,
              fileName: editor.document.fileName,
              docType: docType.value,
            }),
          });

          if (!response.ok) {
            throw new Error(`API error: ${response.status}`);
          }

          const data = (await response.json()) as any;
          
          if (data.documentation) {
            const action = await vscode.window.showInformationMessage(
              `Generated ${docType.label} documentation`,
              'Insert at Cursor',
              'Copy to Clipboard',
              'Show in Chat'
            );

            if (action === 'Insert at Cursor') {
              await editor.edit(editBuilder => {
                editBuilder.insert(selection.start, data.documentation + '\n');
              });
            } else if (action === 'Copy to Clipboard') {
              await vscode.env.clipboard.writeText(data.documentation);
              vscode.window.showInformationMessage('Documentation copied to clipboard!');
            } else if (action === 'Show in Chat') {
              chatProvider.sendMessage(
                `Here's the generated documentation:\n\n${data.documentation}`
              );
            }
          }
        } catch (error) {
          vscode.window.showErrorMessage(`Documentation generation failed: ${error}`);
        }
      });
    })
  );

  // Generate Code
  context.subscriptions.push(
    vscode.commands.registerCommand('navi.generateCode', async () => {
      const description = await vscode.window.showInputBox({
        prompt: 'Describe what code you want to generate',
        placeHolder: 'e.g., Create a React component for a login form with validation'
      });

      if (!description) return;

      const editor = vscode.window.activeTextEditor;
      const fileContext = editor ? `Current file: ${editor.document.fileName}\nLanguage: ${editor.document.languageId}` : '';

      chatProvider.sendMessage(`Generate code: ${description}\n\n${fileContext}`);
    })
  );

  // Run Terminal Command
  context.subscriptions.push(
    vscode.commands.registerCommand('navi.runTerminalCommand', async () => {
      const command = await vscode.window.showInputBox({
        prompt: 'Enter a terminal command to run',
        placeHolder: 'e.g., npm install axios'
      });

      if (!command) return;

      const approved = await vscode.window.showWarningMessage(
        `Run command: ${command}?`,
        { modal: true },
        'Run'
      );

      if (approved === 'Run') {
        terminalManager.runCommand(command);
      }
    })
  );

  // Show Tasks
  context.subscriptions.push(
    vscode.commands.registerCommand('navi.showTasks', () => {
      tasksProvider.refresh();
      vscode.commands.executeCommand('navi.tasksView.focus');
    })
  );

  // Start Task
  context.subscriptions.push(
    vscode.commands.registerCommand('navi.startTask', async (taskItem?: any) => {
      let taskKey: string | undefined;

      if (taskItem?.taskKey) {
        taskKey = taskItem.taskKey;
      } else {
        taskKey = await vscode.window.showInputBox({
          prompt: 'Enter Jira task key',
          placeHolder: 'e.g., PROJ-123'
        });
      }

      if (!taskKey) return;

      chatProvider.sendMessage(`Start working on task ${taskKey}. Show me the task details, related documentation, and suggest implementation steps.`);
    })
  );

  // Create PR
  context.subscriptions.push(
    vscode.commands.registerCommand('navi.createPR', async () => {
      const title = await vscode.window.showInputBox({
        prompt: 'PR Title',
        placeHolder: 'e.g., feat: Add user authentication'
      });

      if (!title) return;

      chatProvider.sendMessage(`Create a pull request with title: "${title}". Generate the PR description based on the recent commits and changes.`);
    })
  );

  // Fix Build Errors
  context.subscriptions.push(
    vscode.commands.registerCommand('navi.fixBuild', async () => {
      const diagnostics = vscode.languages.getDiagnostics();
      const errors: string[] = [];

      diagnostics.forEach(([uri, diags]) => {
        diags.forEach(diag => {
          if (diag.severity === vscode.DiagnosticSeverity.Error) {
            errors.push(`${uri.fsPath}:${diag.range.start.line + 1}: ${diag.message}`);
          }
        });
      });

      if (errors.length === 0) {
        vscode.window.showInformationMessage('No build errors found!');
        return;
      }

      chatProvider.sendMessage(
        `Analyze and fix these build errors:\n\`\`\`\n${errors.slice(0, 10).join('\n')}\n\`\`\`\n\n${errors.length > 10 ? `(and ${errors.length - 10} more errors)` : ''}`
      );
    })
  );

  // Morning Briefing
  context.subscriptions.push(
    vscode.commands.registerCommand('navi.morningBriefing', async () => {
      chatProvider.sendMessage('Good morning! Give me my daily briefing including my assigned tasks, recent activity, and any blockers.');
    })
  );

  // Search Context
  context.subscriptions.push(
    vscode.commands.registerCommand('navi.searchContext', async () => {
      const query = await vscode.window.showInputBox({
        prompt: 'Search across workspace, docs, and integrations',
        placeHolder: 'e.g., authentication flow, API endpoints'
      });

      if (!query) return;

      chatProvider.sendMessage(`Search for: ${query}`);
    })
  );
}

function getApiEndpoint(): string {
  const config = vscode.workspace.getConfiguration('navi');
  return config.get<string>('apiEndpoint') || 'https://xzpgwblreapqwuyytdzj.supabase.co/functions/v1';
}

function getPriorityIcon(priority: string): string {
  switch (priority) {
    case 'high': return '$(error)';
    case 'medium': return '$(warning)';
    case 'low': return '$(info)';
    default: return '$(circle)';
  }
}

function getTestFrameworkOptions(language: string): Array<{ label: string; value: string }> {
  const frameworks: Record<string, Array<{ label: string; value: string }>> = {
    typescript: [
      { label: 'Vitest', value: 'vitest' },
      { label: 'Jest', value: 'jest' },
    ],
    typescriptreact: [
      { label: 'Vitest + React Testing Library', value: 'vitest' },
      { label: 'Jest + React Testing Library', value: 'jest' },
    ],
    javascript: [
      { label: 'Jest', value: 'jest' },
      { label: 'Mocha', value: 'mocha' },
    ],
    javascriptreact: [
      { label: 'Jest + React Testing Library', value: 'jest' },
    ],
    python: [
      { label: 'pytest', value: 'pytest' },
      { label: 'unittest', value: 'unittest' },
    ],
    go: [
      { label: 'Go Test', value: 'go-test' },
    ],
    rust: [
      { label: 'Cargo Test', value: 'cargo-test' },
    ],
  };
  return frameworks[language] || [{ label: 'Default', value: 'default' }];
}

async function showMorningBriefingOnStartup(apiClient: NaviAPIClient) {
  const config = vscode.workspace.getConfiguration('navi');
  const hour = new Date().getHours();
  
  // Only show between 6 AM and 11 AM
  if (hour >= 6 && hour < 11) {
    const showBriefing = await vscode.window.showInformationMessage(
      '☀️ Good morning! Would you like your daily briefing?',
      'Show Briefing',
      'Not Now'
    );

    if (showBriefing === 'Show Briefing') {
      vscode.commands.executeCommand('navi.morningBriefing');
    }
  }
}

export function deactivate() {
  outputChannel.appendLine('NAVI AI Extension deactivated');
}
