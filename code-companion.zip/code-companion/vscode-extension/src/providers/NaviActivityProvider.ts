import * as vscode from 'vscode';
import { NaviAPIClient } from '../api/NaviAPIClient';

interface ActivityItem {
  id: string;
  type: 'pr' | 'build' | 'message' | 'task';
  title: string;
  description: string;
  timestamp: Date;
  url?: string;
}

export class NaviActivityTreeItem extends vscode.TreeItem {
  constructor(
    public readonly activity: ActivityItem,
    public readonly collapsibleState: vscode.TreeItemCollapsibleState
  ) {
    super(activity.title, collapsibleState);
    
    this.tooltip = `${activity.title}\n${activity.description}`;
    this.description = this.getTimeAgo(activity.timestamp);
    
    // Set icon based on type
    const typeIcons: Record<string, vscode.ThemeIcon> = {
      'pr': new vscode.ThemeIcon('git-pull-request'),
      'build': new vscode.ThemeIcon('play'),
      'message': new vscode.ThemeIcon('comment'),
      'task': new vscode.ThemeIcon('checklist'),
    };
    this.iconPath = typeIcons[activity.type] || new vscode.ThemeIcon('bell');

    if (activity.url) {
      this.command = {
        command: 'vscode.open',
        title: 'Open',
        arguments: [vscode.Uri.parse(activity.url)],
      };
    }
  }

  private getTimeAgo(date: Date): string {
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffMins < 1) return 'just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    return `${diffDays}d ago`;
  }
}

export class NaviActivityProvider implements vscode.TreeDataProvider<NaviActivityTreeItem> {
  private _onDidChangeTreeData: vscode.EventEmitter<NaviActivityTreeItem | undefined | null | void> = 
    new vscode.EventEmitter<NaviActivityTreeItem | undefined | null | void>();
  readonly onDidChangeTreeData: vscode.Event<NaviActivityTreeItem | undefined | null | void> = 
    this._onDidChangeTreeData.event;

  private activities: ActivityItem[] = [];
  private pollingInterval: NodeJS.Timeout | null = null;

  constructor(private readonly apiClient: NaviAPIClient) {
    this.startPolling();
  }

  private startPolling() {
    this.refresh();
    this.pollingInterval = setInterval(() => this.refresh(), 60000); // Poll every minute
  }

  refresh(): void {
    this.fetchActivities();
  }

  private async fetchActivities() {
    try {
      // Fetch from multiple sources
      const [prs, builds, notifications] = await Promise.all([
        this.apiClient.getGitHubPRs(),
        this.apiClient.getCICDStatus(),
        this.apiClient.getNotifications(),
      ]);

      const activities: ActivityItem[] = [];

      // Map PRs
      prs.forEach((pr: any) => {
        activities.push({
          id: `pr-${pr.number}`,
          type: 'pr',
          title: `PR #${pr.number}: ${pr.title}`,
          description: pr.user?.login || 'Unknown',
          timestamp: new Date(pr.updated_at),
          url: pr.html_url,
        });
      });

      // Map builds
      builds.forEach((build: any) => {
        activities.push({
          id: `build-${build.id}`,
          type: 'build',
          title: `${build.name}`,
          description: build.conclusion || build.status,
          timestamp: new Date(build.updated_at || build.created_at),
          url: build.html_url,
        });
      });

      // Sort by timestamp
      activities.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());

      this.activities = activities.slice(0, 20); // Keep last 20
      this._onDidChangeTreeData.fire();
    } catch (error) {
      console.error('Failed to fetch activities:', error);
    }
  }

  getTreeItem(element: NaviActivityTreeItem): vscode.TreeItem {
    return element;
  }

  getChildren(element?: NaviActivityTreeItem): Thenable<NaviActivityTreeItem[]> {
    if (element) {
      return Promise.resolve([]);
    }

    if (this.activities.length === 0) {
      return Promise.resolve([]);
    }

    return Promise.resolve(
      this.activities.map(activity => 
        new NaviActivityTreeItem(activity, vscode.TreeItemCollapsibleState.None)
      )
    );
  }

  dispose() {
    if (this.pollingInterval) {
      clearInterval(this.pollingInterval);
    }
  }
}
