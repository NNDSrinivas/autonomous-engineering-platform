import * as vscode from 'vscode';
import { NaviAPIClient, ChatMessage } from '../api/NaviAPIClient';
import { TerminalManager } from '../services/TerminalManager';

export class NaviChatViewProvider implements vscode.WebviewViewProvider {
  private view?: vscode.WebviewView;
  private messages: ChatMessage[] = [];

  constructor(
    private readonly extensionUri: vscode.Uri,
    private readonly apiClient: NaviAPIClient,
    private readonly terminalManager: TerminalManager
  ) {}

  public resolveWebviewView(
    webviewView: vscode.WebviewView,
    context: vscode.WebviewViewResolveContext,
    _token: vscode.CancellationToken
  ) {
    this.view = webviewView;

    webviewView.webview.options = {
      enableScripts: true,
      localResourceRoots: [this.extensionUri],
    };

    webviewView.webview.html = this.getHtmlContent();

    webviewView.webview.onDidReceiveMessage(async (message) => {
      switch (message.type) {
        case 'sendMessage':
          await this.handleUserMessage(message.content);
          break;
        case 'approveAction':
          await this.handleApproval(message.actionId, true);
          break;
        case 'rejectAction':
          await this.handleApproval(message.actionId, false);
          break;
        case 'runCommand':
          this.terminalManager.runCommand(message.command);
          break;
        case 'applyCode':
          await this.applyCodeToEditor(message.code, message.filePath);
          break;
      }
    });
  }

  public async sendMessage(content: string) {
    if (!this.view) {
      vscode.commands.executeCommand('navi.chatPanel.focus');
      // Wait for view to be ready
      await new Promise(resolve => setTimeout(resolve, 500));
    }

    await this.handleUserMessage(content);
  }

  private async handleUserMessage(content: string) {
    // Add user message
    this.messages.push({ role: 'user', content });
    this.postMessage({ type: 'addMessage', role: 'user', content });

    // Get workspace context
    const workspaceContext = await this.gatherWorkspaceContext();

    // Add context to the message if relevant
    const contextualMessages = [...this.messages];
    if (workspaceContext) {
      contextualMessages.unshift({
        role: 'system',
        content: `Current workspace context:\n${workspaceContext}`,
      });
    }

    // Start streaming response
    this.postMessage({ type: 'startResponse' });

    let fullResponse = '';
    await this.apiClient.streamChat(contextualMessages, {
      onDelta: (text) => {
        fullResponse += text;
        this.postMessage({ type: 'appendResponse', content: text });
      },
      onDone: () => {
        this.messages.push({ role: 'assistant', content: fullResponse });
        this.postMessage({ type: 'endResponse' });
        
        // Parse for action items
        this.parseAndShowActions(fullResponse);
      },
      onError: (error) => {
        this.postMessage({ 
          type: 'error', 
          message: `Error: ${error.message}` 
        });
      },
    });
  }

  private async gatherWorkspaceContext(): Promise<string> {
    const parts: string[] = [];

    // Current file
    const editor = vscode.window.activeTextEditor;
    if (editor) {
      parts.push(`Current file: ${editor.document.fileName}`);
      parts.push(`Language: ${editor.document.languageId}`);
      
      // Include selected text if any
      const selection = editor.selection;
      if (!selection.isEmpty) {
        const selectedText = editor.document.getText(selection);
        parts.push(`Selected code:\n\`\`\`${editor.document.languageId}\n${selectedText}\n\`\`\``);
      }
    }

    // Workspace folders
    const workspaceFolders = vscode.workspace.workspaceFolders;
    if (workspaceFolders) {
      parts.push(`Workspace: ${workspaceFolders.map(f => f.name).join(', ')}`);
    }

    // Recent diagnostics (errors)
    const diagnostics = vscode.languages.getDiagnostics();
    const errors: string[] = [];
    diagnostics.forEach(([uri, diags]) => {
      diags.forEach(diag => {
        if (diag.severity === vscode.DiagnosticSeverity.Error) {
          errors.push(`${uri.fsPath}:${diag.range.start.line + 1}: ${diag.message}`);
        }
      });
    });
    if (errors.length > 0) {
      parts.push(`Current errors (${errors.length}):\n${errors.slice(0, 5).join('\n')}`);
    }

    return parts.join('\n');
  }

  private parseAndShowActions(response: string) {
    // Parse code blocks for apply action
    const codeBlockRegex = /```(\w+)?\n([\s\S]*?)```/g;
    let match;
    while ((match = codeBlockRegex.exec(response)) !== null) {
      const language = match[1] || 'text';
      const code = match[2];
      
      if (code.trim().length > 0) {
        this.postMessage({
          type: 'showAction',
          actionType: 'code',
          language,
          code,
        });
      }
    }

    // Parse terminal commands
    const terminalRegex = /```(?:bash|sh|shell|terminal)\n([\s\S]*?)```/g;
    while ((match = terminalRegex.exec(response)) !== null) {
      const command = match[1].trim();
      if (command) {
        this.postMessage({
          type: 'showAction',
          actionType: 'terminal',
          command,
        });
      }
    }
  }

  private async handleApproval(actionId: string, approved: boolean) {
    if (approved) {
      vscode.window.showInformationMessage('Action approved');
      // Execute the approved action
    } else {
      vscode.window.showInformationMessage('Action rejected');
    }
  }

  private async applyCodeToEditor(code: string, filePath?: string) {
    const editor = vscode.window.activeTextEditor;
    
    if (!editor) {
      // Create new file
      const doc = await vscode.workspace.openTextDocument({ content: code });
      await vscode.window.showTextDocument(doc);
      return;
    }

    // Apply to current editor
    const edit = new vscode.WorkspaceEdit();
    const selection = editor.selection;
    
    if (selection.isEmpty) {
      // Insert at cursor
      edit.insert(editor.document.uri, selection.active, code);
    } else {
      // Replace selection
      edit.replace(editor.document.uri, selection, code);
    }

    await vscode.workspace.applyEdit(edit);
    vscode.window.showInformationMessage('Code applied successfully');
  }

  private postMessage(message: any) {
    this.view?.webview.postMessage(message);
  }

  private getHtmlContent(): string {
    return `<!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>NAVI Chat</title>
      <style>
        * {
          box-sizing: border-box;
          margin: 0;
          padding: 0;
        }
        body {
          font-family: var(--vscode-font-family);
          font-size: var(--vscode-font-size);
          color: var(--vscode-foreground);
          background: var(--vscode-sideBar-background);
          height: 100vh;
          display: flex;
          flex-direction: column;
        }
        .header {
          padding: 12px;
          border-bottom: 1px solid var(--vscode-panel-border);
          display: flex;
          align-items: center;
          gap: 8px;
        }
        .header-icon {
          width: 24px;
          height: 24px;
          background: linear-gradient(135deg, #6366f1, #8b5cf6);
          border-radius: 6px;
        }
        .header-title {
          font-weight: 600;
          font-size: 14px;
        }
        .messages {
          flex: 1;
          overflow-y: auto;
          padding: 12px;
        }
        .message {
          margin-bottom: 16px;
          animation: fadeIn 0.2s ease;
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(8px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .message-user {
          text-align: right;
        }
        .message-user .bubble {
          background: var(--vscode-button-background);
          color: var(--vscode-button-foreground);
          display: inline-block;
          max-width: 85%;
          text-align: left;
        }
        .message-assistant .bubble {
          background: var(--vscode-editor-background);
          border: 1px solid var(--vscode-panel-border);
          max-width: 100%;
        }
        .bubble {
          padding: 10px 14px;
          border-radius: 12px;
          line-height: 1.5;
        }
        .bubble pre {
          background: var(--vscode-textCodeBlock-background);
          padding: 12px;
          border-radius: 6px;
          overflow-x: auto;
          margin: 8px 0;
          font-family: var(--vscode-editor-font-family);
          font-size: 12px;
        }
        .bubble code {
          font-family: var(--vscode-editor-font-family);
          background: var(--vscode-textCodeBlock-background);
          padding: 2px 6px;
          border-radius: 4px;
        }
        .action-buttons {
          display: flex;
          gap: 8px;
          margin-top: 8px;
        }
        .action-btn {
          padding: 6px 12px;
          border-radius: 6px;
          border: none;
          cursor: pointer;
          font-size: 12px;
          display: flex;
          align-items: center;
          gap: 4px;
        }
        .action-btn-primary {
          background: var(--vscode-button-background);
          color: var(--vscode-button-foreground);
        }
        .action-btn-secondary {
          background: var(--vscode-button-secondaryBackground);
          color: var(--vscode-button-secondaryForeground);
        }
        .input-container {
          padding: 12px;
          border-top: 1px solid var(--vscode-panel-border);
        }
        .input-wrapper {
          display: flex;
          gap: 8px;
        }
        #messageInput {
          flex: 1;
          padding: 10px 14px;
          border: 1px solid var(--vscode-input-border);
          background: var(--vscode-input-background);
          color: var(--vscode-input-foreground);
          border-radius: 8px;
          font-size: 13px;
          outline: none;
        }
        #messageInput:focus {
          border-color: var(--vscode-focusBorder);
        }
        #sendBtn {
          padding: 10px 16px;
          background: var(--vscode-button-background);
          color: var(--vscode-button-foreground);
          border: none;
          border-radius: 8px;
          cursor: pointer;
          font-weight: 500;
        }
        #sendBtn:hover {
          background: var(--vscode-button-hoverBackground);
        }
        #sendBtn:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }
        .typing-indicator {
          display: flex;
          gap: 4px;
          padding: 8px 0;
        }
        .typing-dot {
          width: 6px;
          height: 6px;
          background: var(--vscode-foreground);
          border-radius: 50%;
          opacity: 0.5;
          animation: typing 1.4s infinite;
        }
        .typing-dot:nth-child(2) { animation-delay: 0.2s; }
        .typing-dot:nth-child(3) { animation-delay: 0.4s; }
        @keyframes typing {
          0%, 100% { opacity: 0.3; transform: scale(0.8); }
          50% { opacity: 1; transform: scale(1); }
        }
        .welcome {
          text-align: center;
          padding: 40px 20px;
          color: var(--vscode-descriptionForeground);
        }
        .welcome h2 {
          color: var(--vscode-foreground);
          margin-bottom: 8px;
        }
        .quick-actions {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
          justify-content: center;
          margin-top: 16px;
        }
        .quick-action {
          padding: 8px 14px;
          background: var(--vscode-button-secondaryBackground);
          color: var(--vscode-button-secondaryForeground);
          border: none;
          border-radius: 20px;
          cursor: pointer;
          font-size: 12px;
        }
        .quick-action:hover {
          background: var(--vscode-button-secondaryHoverBackground);
        }
      </style>
    </head>
    <body>
      <div class="header">
        <div class="header-icon"></div>
        <span class="header-title">NAVI AI</span>
      </div>
      
      <div class="messages" id="messages">
        <div class="welcome" id="welcome">
          <h2>👋 Hello! I'm NAVI</h2>
          <p>Your Autonomous Engineering Intelligence</p>
          <div class="quick-actions">
            <button class="quick-action" onclick="sendQuick('Show my Jira tasks')">My Tasks</button>
            <button class="quick-action" onclick="sendQuick('Give me my morning briefing')">Briefing</button>
            <button class="quick-action" onclick="sendQuick('Help me with this code')">Help with Code</button>
            <button class="quick-action" onclick="sendQuick('Search for documentation')">Search Docs</button>
          </div>
        </div>
      </div>
      
      <div class="input-container">
        <div class="input-wrapper">
          <input 
            type="text" 
            id="messageInput" 
            placeholder="Ask NAVI anything..."
            onkeydown="if(event.key === 'Enter') sendMessage()"
          />
          <button id="sendBtn" onclick="sendMessage()">Send</button>
        </div>
      </div>

      <script>
        const vscode = acquireVsCodeApi();
        const messagesContainer = document.getElementById('messages');
        const welcomeEl = document.getElementById('welcome');
        const input = document.getElementById('messageInput');
        const sendBtn = document.getElementById('sendBtn');
        let currentResponseEl = null;

        function sendMessage() {
          const content = input.value.trim();
          if (!content) return;
          
          welcomeEl.style.display = 'none';
          vscode.postMessage({ type: 'sendMessage', content });
          input.value = '';
        }

        function sendQuick(content) {
          welcomeEl.style.display = 'none';
          vscode.postMessage({ type: 'sendMessage', content });
        }

        function addMessage(role, content) {
          const div = document.createElement('div');
          div.className = 'message message-' + role;
          div.innerHTML = '<div class="bubble">' + formatContent(content) + '</div>';
          messagesContainer.appendChild(div);
          messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }

        function formatContent(content) {
          // Basic markdown formatting
          return content
            .replace(/\`\`\`(\\w+)?\\n([\\s\\S]*?)\`\`\`/g, '<pre><code>$2</code></pre>')
            .replace(/\`([^\`]+)\`/g, '<code>$1</code>')
            .replace(/\\*\\*([^*]+)\\*\\*/g, '<strong>$1</strong>')
            .replace(/\\n/g, '<br>');
        }

        function startResponse() {
          const div = document.createElement('div');
          div.className = 'message message-assistant';
          div.innerHTML = '<div class="bubble"><div class="typing-indicator"><div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div></div></div>';
          messagesContainer.appendChild(div);
          currentResponseEl = div.querySelector('.bubble');
          messagesContainer.scrollTop = messagesContainer.scrollHeight;
          sendBtn.disabled = true;
        }

        function appendResponse(content) {
          if (currentResponseEl) {
            const typing = currentResponseEl.querySelector('.typing-indicator');
            if (typing) typing.remove();
            currentResponseEl.innerHTML += content;
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
          }
        }

        function endResponse() {
          if (currentResponseEl) {
            currentResponseEl.innerHTML = formatContent(currentResponseEl.textContent);
          }
          currentResponseEl = null;
          sendBtn.disabled = false;
        }

        function showAction(data) {
          const actionsDiv = document.createElement('div');
          actionsDiv.className = 'action-buttons';
          
          if (data.actionType === 'code') {
            actionsDiv.innerHTML = \`
              <button class="action-btn action-btn-primary" onclick="applyCode()">
                ✓ Apply Code
              </button>
              <button class="action-btn action-btn-secondary" onclick="copyCode()">
                Copy
              </button>
            \`;
          } else if (data.actionType === 'terminal') {
            actionsDiv.innerHTML = \`
              <button class="action-btn action-btn-primary" onclick="runCommand('\${data.command}')">
                ▶ Run Command
              </button>
            \`;
          }
          
          if (currentResponseEl) {
            currentResponseEl.appendChild(actionsDiv);
          }
        }

        function applyCode() {
          const codeEl = currentResponseEl?.querySelector('code');
          if (codeEl) {
            vscode.postMessage({ type: 'applyCode', code: codeEl.textContent });
          }
        }

        function copyCode() {
          const codeEl = currentResponseEl?.querySelector('code');
          if (codeEl) {
            navigator.clipboard.writeText(codeEl.textContent);
          }
        }

        function runCommand(cmd) {
          vscode.postMessage({ type: 'runCommand', command: cmd });
        }

        window.addEventListener('message', event => {
          const message = event.data;
          switch (message.type) {
            case 'addMessage':
              addMessage(message.role, message.content);
              break;
            case 'startResponse':
              startResponse();
              break;
            case 'appendResponse':
              appendResponse(message.content);
              break;
            case 'endResponse':
              endResponse();
              break;
            case 'showAction':
              showAction(message);
              break;
            case 'error':
              alert(message.message);
              sendBtn.disabled = false;
              break;
          }
        });
      </script>
    </body>
    </html>`;
  }
}
