import * as vscode from 'vscode';
import { NaviAPIClient } from '../api/NaviAPIClient';

export class NaviCodeActionProvider implements vscode.CodeActionProvider {
  constructor(private readonly apiClient: NaviAPIClient) {}

  provideCodeActions(
    document: vscode.TextDocument,
    range: vscode.Range,
    context: vscode.CodeActionContext,
    token: vscode.CancellationToken
  ): vscode.ProviderResult<vscode.CodeAction[]> {
    const actions: vscode.CodeAction[] = [];

    // If there are diagnostics (errors), offer to fix them
    if (context.diagnostics.length > 0) {
      const fixAction = new vscode.CodeAction(
        '🔧 NAVI: Fix this error',
        vscode.CodeActionKind.QuickFix
      );
      fixAction.command = {
        command: 'navi.fixBuild',
        title: 'Fix with NAVI',
      };
      actions.push(fixAction);
    }

    // If there's a selection, offer refactoring options
    if (!range.isEmpty) {
      const explainAction = new vscode.CodeAction(
        '💡 NAVI: Explain this code',
        vscode.CodeActionKind.Source
      );
      explainAction.command = {
        command: 'navi.explainCode',
        title: 'Explain with NAVI',
      };
      actions.push(explainAction);

      const refactorAction = new vscode.CodeAction(
        '✨ NAVI: Refactor this code',
        vscode.CodeActionKind.Refactor
      );
      refactorAction.command = {
        command: 'navi.refactorCode',
        title: 'Refactor with NAVI',
      };
      actions.push(refactorAction);
    }

    // Always offer to generate code
    const generateAction = new vscode.CodeAction(
      '🚀 NAVI: Generate code here',
      vscode.CodeActionKind.Source
    );
    generateAction.command = {
      command: 'navi.generateCode',
      title: 'Generate with NAVI',
    };
    actions.push(generateAction);

    return actions;
  }
}
