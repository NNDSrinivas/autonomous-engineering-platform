import * as vscode from 'vscode';
import { NaviAPIClient } from '../api/NaviAPIClient';
import { WorkspaceIndexer } from '../services/WorkspaceIndexer';

export class NaviCompletionProvider implements vscode.InlineCompletionItemProvider {
  private debounceTimer: NodeJS.Timeout | null = null;
  private workspaceIndexer: WorkspaceIndexer | null = null;

  constructor(private readonly apiClient: NaviAPIClient) {}

  setWorkspaceIndexer(indexer: WorkspaceIndexer): void {
    this.workspaceIndexer = indexer;
  }

  async provideInlineCompletionItems(
    document: vscode.TextDocument,
    position: vscode.Position,
    context: vscode.InlineCompletionContext,
    token: vscode.CancellationToken
  ): Promise<vscode.InlineCompletionItem[] | null> {
    // Check if inline suggestions are enabled
    const config = vscode.workspace.getConfiguration('navi');
    if (!config.get<boolean>('enableInlineSuggestions')) {
      return null;
    }

    // Get surrounding code context
    const prefix = this.getPrefix(document, position);
    const suffix = this.getSuffix(document, position);

    // Skip if too short
    if (prefix.length < 10) {
      return null;
    }

    // Debounce to avoid too many requests
    if (this.debounceTimer) {
      clearTimeout(this.debounceTimer);
    }

    return new Promise((resolve) => {
      this.debounceTimer = setTimeout(async () => {
        if (token.isCancellationRequested) {
          resolve(null);
          return;
        }

        try {
          // Get multi-file context from workspace indexer
          let completionContext = null;
          if (this.workspaceIndexer) {
            completionContext = await this.workspaceIndexer.getCompletionContext(document);
          }

          const completion = await this.apiClient.getInlineCompletionWithContext(
            prefix,
            suffix,
            document.languageId,
            document.fileName,
            completionContext
          );

          if (!completion || token.isCancellationRequested) {
            resolve(null);
            return;
          }

          const item = new vscode.InlineCompletionItem(
            completion,
            new vscode.Range(position, position)
          );

          resolve([item]);
        } catch (error) {
          console.error('Inline completion error:', error);
          resolve(null);
        }
      }, 500); // 500ms debounce
    });
  }

  private getPrefix(document: vscode.TextDocument, position: vscode.Position): string {
    // Get up to 50 lines before cursor
    const startLine = Math.max(0, position.line - 50);
    const range = new vscode.Range(
      new vscode.Position(startLine, 0),
      position
    );
    return document.getText(range);
  }

  private getSuffix(document: vscode.TextDocument, position: vscode.Position): string {
    // Get up to 10 lines after cursor
    const endLine = Math.min(document.lineCount - 1, position.line + 10);
    const range = new vscode.Range(
      position,
      new vscode.Position(endLine, document.lineAt(endLine).text.length)
    );
    return document.getText(range);
  }
}
