import * as vscode from 'vscode';
import { NaviAPIClient, JiraTask } from '../api/NaviAPIClient';

export class NaviTaskItem extends vscode.TreeItem {
  constructor(
    public readonly task: JiraTask,
    public readonly collapsibleState: vscode.TreeItemCollapsibleState
  ) {
    super(`${task.key}: ${task.title}`, collapsibleState);
    
    this.taskKey = task.key;
    this.tooltip = `${task.key}\n${task.title}\nStatus: ${task.status}\nPriority: ${task.priority}`;
    this.description = task.status;
    
    // Set icon based on priority
    const priorityIcons: Record<string, string> = {
      'Highest': '🔴',
      'High': '🟠',
      'Medium': '🟡',
      'Low': '🟢',
      'Lowest': '⚪',
    };
    this.iconPath = new vscode.ThemeIcon(
      task.priority === 'Highest' || task.priority === 'High' 
        ? 'flame' 
        : 'circle-outline'
    );

    this.contextValue = 'naviTask';
    this.command = {
      command: 'navi.startTask',
      title: 'Start Task',
      arguments: [this],
    };
  }

  taskKey: string;
}

export class NaviTasksProvider implements vscode.TreeDataProvider<NaviTaskItem> {
  private _onDidChangeTreeData: vscode.EventEmitter<NaviTaskItem | undefined | null | void> = 
    new vscode.EventEmitter<NaviTaskItem | undefined | null | void>();
  readonly onDidChangeTreeData: vscode.Event<NaviTaskItem | undefined | null | void> = 
    this._onDidChangeTreeData.event;

  private tasks: JiraTask[] = [];

  constructor(private readonly apiClient: NaviAPIClient) {
    this.refresh();
  }

  refresh(): void {
    this.fetchTasks();
  }

  private async fetchTasks() {
    try {
      this.tasks = await this.apiClient.getJiraTasks();
      this._onDidChangeTreeData.fire();
    } catch (error) {
      console.error('Failed to fetch tasks:', error);
    }
  }

  getTreeItem(element: NaviTaskItem): vscode.TreeItem {
    return element;
  }

  getChildren(element?: NaviTaskItem): Thenable<NaviTaskItem[]> {
    if (element) {
      return Promise.resolve([]);
    }

    if (this.tasks.length === 0) {
      return Promise.resolve([]);
    }

    return Promise.resolve(
      this.tasks.map(task => new NaviTaskItem(task, vscode.TreeItemCollapsibleState.None))
    );
  }
}
