import * as vscode from 'vscode';
import { NaviAPIClient } from '../api/NaviAPIClient';

interface NaviNotification {
  id: string;
  type: 'info' | 'warning' | 'error' | 'success';
  title: string;
  description: string;
  source: string;
  actions?: Array<{ label: string; action: string }>;
}

export class NotificationManager {
  private pollingInterval: NodeJS.Timeout | null = null;
  private seenNotifications: Set<string> = new Set();
  private statusBarItem: vscode.StatusBarItem;

  constructor(private readonly context: vscode.ExtensionContext) {
    // Create status bar item
    this.statusBarItem = vscode.window.createStatusBarItem(
      vscode.StatusBarAlignment.Right,
      100
    );
    this.statusBarItem.text = '$(bell) NAVI';
    this.statusBarItem.tooltip = 'NAVI Notifications';
    this.statusBarItem.command = 'navi.openChat';
    this.statusBarItem.show();
    context.subscriptions.push(this.statusBarItem);

    // Load seen notifications from storage
    const seen = context.globalState.get<string[]>('naviSeenNotifications');
    if (seen) {
      this.seenNotifications = new Set(seen);
    }
  }

  startPolling(apiClient: NaviAPIClient, intervalMs: number = 60000): void {
    this.stopPolling();

    const poll = async () => {
      try {
        const notifications = await apiClient.getNotifications();
        this.processNotifications(notifications);
      } catch (error) {
        console.error('Failed to fetch notifications:', error);
      }
    };

    // Initial poll
    poll();

    // Set up interval
    this.pollingInterval = setInterval(poll, intervalMs);
  }

  stopPolling(): void {
    if (this.pollingInterval) {
      clearInterval(this.pollingInterval);
      this.pollingInterval = null;
    }
  }

  private processNotifications(notifications: NaviNotification[]): void {
    const newNotifications = notifications.filter(n => !this.seenNotifications.has(n.id));

    if (newNotifications.length === 0) {
      return;
    }

    // Update status bar
    this.statusBarItem.text = `$(bell-dot) NAVI (${newNotifications.length})`;

    // Show high-priority notifications
    for (const notification of newNotifications) {
      this.showNotification(notification);
      this.seenNotifications.add(notification.id);
    }

    // Save seen notifications
    this.context.globalState.update(
      'naviSeenNotifications',
      Array.from(this.seenNotifications)
    );
  }

  private async showNotification(notification: NaviNotification): Promise<void> {
    const actions = notification.actions?.map(a => a.label) || [];
    let result: string | undefined;

    switch (notification.type) {
      case 'error':
        result = await vscode.window.showErrorMessage(
          `[${notification.source}] ${notification.title}`,
          ...actions
        );
        break;
      case 'warning':
        result = await vscode.window.showWarningMessage(
          `[${notification.source}] ${notification.title}`,
          ...actions
        );
        break;
      default:
        result = await vscode.window.showInformationMessage(
          `[${notification.source}] ${notification.title}`,
          ...actions
        );
    }

    // Handle action clicks
    if (result && notification.actions) {
      const action = notification.actions.find(a => a.label === result);
      if (action?.action.startsWith('http')) {
        vscode.env.openExternal(vscode.Uri.parse(action.action));
      }
    }
  }

  updateStatusBar(unreadCount: number): void {
    if (unreadCount > 0) {
      this.statusBarItem.text = `$(bell-dot) NAVI (${unreadCount})`;
    } else {
      this.statusBarItem.text = '$(bell) NAVI';
    }
  }

  dispose(): void {
    this.stopPolling();
    this.statusBarItem.dispose();
  }
}
