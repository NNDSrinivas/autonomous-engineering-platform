import * as vscode from 'vscode';

export class TerminalManager {
  private naviTerminal: vscode.Terminal | null = null;

  constructor() {
    // Clean up terminal when it's closed
    vscode.window.onDidCloseTerminal(terminal => {
      if (terminal === this.naviTerminal) {
        this.naviTerminal = null;
      }
    });
  }

  private getOrCreateTerminal(): vscode.Terminal {
    if (!this.naviTerminal || !this.isTerminalAlive(this.naviTerminal)) {
      this.naviTerminal = vscode.window.createTerminal({
        name: 'NAVI Terminal',
        iconPath: new vscode.ThemeIcon('rocket'),
      });
    }
    return this.naviTerminal;
  }

  private isTerminalAlive(terminal: vscode.Terminal): boolean {
    // Check if terminal is in the active terminals list
    return vscode.window.terminals.includes(terminal);
  }

  runCommand(command: string, showTerminal: boolean = true): void {
    const terminal = this.getOrCreateTerminal();
    
    if (showTerminal) {
      terminal.show();
    }
    
    terminal.sendText(command);
  }

  runCommands(commands: string[], showTerminal: boolean = true): void {
    const terminal = this.getOrCreateTerminal();
    
    if (showTerminal) {
      terminal.show();
    }

    for (const command of commands) {
      terminal.sendText(command);
    }
  }

  async runCommandWithApproval(command: string): Promise<boolean> {
    const config = vscode.workspace.getConfiguration('navi');
    const autoApprove = config.get<boolean>('autoApprove');

    if (autoApprove) {
      this.runCommand(command);
      return true;
    }

    const result = await vscode.window.showWarningMessage(
      `NAVI wants to run: ${command}`,
      { modal: true, detail: 'This command will be executed in the terminal.' },
      'Run',
      'Cancel'
    );

    if (result === 'Run') {
      this.runCommand(command);
      return true;
    }

    return false;
  }

  async runGitCommand(command: string): Promise<boolean> {
    const fullCommand = `git ${command}`;
    return this.runCommandWithApproval(fullCommand);
  }

  async createBranch(branchName: string): Promise<boolean> {
    return this.runGitCommand(`checkout -b ${branchName}`);
  }

  async commit(message: string): Promise<boolean> {
    await this.runGitCommand('add .');
    return this.runGitCommand(`commit -m "${message}"`);
  }

  async push(branchName?: string): Promise<boolean> {
    const branch = branchName ? `-u origin ${branchName}` : '';
    return this.runGitCommand(`push ${branch}`);
  }

  dispose(): void {
    if (this.naviTerminal) {
      this.naviTerminal.dispose();
    }
  }
}
