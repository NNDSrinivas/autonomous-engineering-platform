import * as vscode from 'vscode';
import * as path from 'path';
import { NaviAPIClient } from '../api/NaviAPIClient';

interface FileIndex {
  path: string;
  language: string;
  size: number;
  lastModified: number;
  symbols: string[];
  imports: string[];
  exports: string[];
}

interface CompletionContext {
  imports: string[];
  relatedFiles: Array<{
    fileName: string;
    content: string;
    relevance: 'high' | 'medium' | 'low';
  }>;
  projectStructure: string[];
  recentEdits: Array<{
    fileName: string;
    snippet: string;
  }>;
}

export class WorkspaceIndexer {
  private fileIndex: Map<string, FileIndex> = new Map();
  private importGraph: Map<string, Set<string>> = new Map();
  private recentEdits: Array<{ fileName: string; snippet: string; timestamp: number }> = [];
  private isIndexing = false;
  private outputChannel: vscode.OutputChannel;

  constructor(
    private readonly context: vscode.ExtensionContext,
    private readonly apiClient: NaviAPIClient
  ) {
    this.outputChannel = vscode.window.createOutputChannel('NAVI Indexer');

    // Watch for file changes
    const watcher = vscode.workspace.createFileSystemWatcher('**/*');
    watcher.onDidCreate(uri => this.indexFile(uri));
    watcher.onDidChange(uri => this.indexFile(uri));
    watcher.onDidDelete(uri => this.removeFile(uri));
    context.subscriptions.push(watcher);

    // Track recent edits
    vscode.workspace.onDidChangeTextDocument(event => {
      this.trackEdit(event);
    });
  }

  async indexWorkspace(): Promise<void> {
    if (this.isIndexing) {
      return;
    }

    this.isIndexing = true;
    this.outputChannel.appendLine('Starting workspace indexing...');

    const workspaceFolders = vscode.workspace.workspaceFolders;
    if (!workspaceFolders) {
      this.isIndexing = false;
      return;
    }

    try {
      for (const folder of workspaceFolders) {
        await this.indexFolder(folder.uri);
      }

      // Build import graph after indexing
      this.buildImportGraph();

      this.outputChannel.appendLine(`Indexed ${this.fileIndex.size} files`);
      
      // Store index in context
      this.context.workspaceState.update('naviFileIndex', 
        Array.from(this.fileIndex.entries())
      );
    } catch (error) {
      this.outputChannel.appendLine(`Indexing error: ${error}`);
    } finally {
      this.isIndexing = false;
    }
  }

  private async indexFolder(folderUri: vscode.Uri): Promise<void> {
    const excludePatterns = [
      '**/node_modules/**',
      '**/.git/**',
      '**/dist/**',
      '**/build/**',
      '**/.next/**',
      '**/coverage/**',
    ];

    const pattern = new vscode.RelativePattern(folderUri, '**/*.{ts,tsx,js,jsx,py,java,go,rs,rb,php,cs,cpp,c,h}');
    const files = await vscode.workspace.findFiles(pattern, `{${excludePatterns.join(',')}}`);

    for (const file of files) {
      await this.indexFile(file);
    }
  }

  private async indexFile(uri: vscode.Uri): Promise<void> {
    try {
      const stat = await vscode.workspace.fs.stat(uri);
      
      // Skip large files
      if (stat.size > 500000) {
        return;
      }

      const document = await vscode.workspace.openTextDocument(uri);
      const content = document.getText();
      const symbols = await this.extractSymbols(document);
      const imports = this.extractImports(content, document.languageId);
      const exports = this.extractExports(content, document.languageId);

      this.fileIndex.set(uri.fsPath, {
        path: uri.fsPath,
        language: document.languageId,
        size: stat.size,
        lastModified: stat.mtime,
        symbols,
        imports,
        exports,
      });
    } catch (error) {
      // Ignore files we can't read
    }
  }

  private removeFile(uri: vscode.Uri): void {
    this.fileIndex.delete(uri.fsPath);
    this.importGraph.delete(uri.fsPath);
  }

  private extractImports(content: string, language: string): string[] {
    const imports: string[] = [];
    
    if (['typescript', 'typescriptreact', 'javascript', 'javascriptreact'].includes(language)) {
      // ES6 imports
      const importRegex = /import\s+(?:(?:[\w*\s{},]+)\s+from\s+)?['"]([^'"]+)['"]/g;
      let match;
      while ((match = importRegex.exec(content)) !== null) {
        imports.push(match[0]);
      }
      
      // Require statements
      const requireRegex = /require\s*\(\s*['"]([^'"]+)['"]\s*\)/g;
      while ((match = requireRegex.exec(content)) !== null) {
        imports.push(match[0]);
      }
    } else if (language === 'python') {
      const importRegex = /(?:from\s+[\w.]+\s+)?import\s+[\w.,\s]+/g;
      let match;
      while ((match = importRegex.exec(content)) !== null) {
        imports.push(match[0]);
      }
    } else if (language === 'go') {
      const importRegex = /import\s+(?:\(\s*([^)]+)\s*\)|"([^"]+)")/g;
      let match;
      while ((match = importRegex.exec(content)) !== null) {
        imports.push(match[0]);
      }
    }
    
    return imports;
  }

  private extractExports(content: string, language: string): string[] {
    const exports: string[] = [];
    
    if (['typescript', 'typescriptreact', 'javascript', 'javascriptreact'].includes(language)) {
      // Named exports
      const namedExportRegex = /export\s+(?:const|let|var|function|class|interface|type|enum)\s+(\w+)/g;
      let match;
      while ((match = namedExportRegex.exec(content)) !== null) {
        exports.push(match[1]);
      }
      
      // Default exports
      const defaultExportRegex = /export\s+default\s+(?:function\s+)?(\w+)?/g;
      while ((match = defaultExportRegex.exec(content)) !== null) {
        if (match[1]) exports.push(match[1]);
      }
    }
    
    return exports;
  }

  private buildImportGraph(): void {
    this.importGraph.clear();
    
    for (const [filePath, fileIndex] of this.fileIndex) {
      const deps = new Set<string>();
      
      for (const importStatement of fileIndex.imports) {
        // Extract import path
        const pathMatch = importStatement.match(/['"]([^'"]+)['"]/);
        if (pathMatch) {
          const importPath = pathMatch[1];
          
          // Resolve relative imports
          if (importPath.startsWith('.')) {
            const resolvedPath = this.resolveImportPath(filePath, importPath);
            if (resolvedPath && this.fileIndex.has(resolvedPath)) {
              deps.add(resolvedPath);
            }
          }
        }
      }
      
      this.importGraph.set(filePath, deps);
    }
  }

  private resolveImportPath(fromFile: string, importPath: string): string | null {
    const dir = path.dirname(fromFile);
    const extensions = ['.ts', '.tsx', '.js', '.jsx', ''];
    
    for (const ext of extensions) {
      const resolved = path.resolve(dir, importPath + ext);
      if (this.fileIndex.has(resolved)) {
        return resolved;
      }
      // Check for index files
      const indexResolved = path.resolve(dir, importPath, 'index' + ext);
      if (this.fileIndex.has(indexResolved)) {
        return indexResolved;
      }
    }
    
    return null;
  }

  private trackEdit(event: vscode.TextDocumentChangeEvent): void {
    if (event.contentChanges.length === 0) return;
    
    const fileName = event.document.fileName;
    const change = event.contentChanges[0];
    
    // Get surrounding context (up to 5 lines)
    const startLine = Math.max(0, change.range.start.line - 2);
    const endLine = Math.min(event.document.lineCount - 1, change.range.end.line + 2);
    
    let snippet = '';
    for (let i = startLine; i <= endLine; i++) {
      snippet += event.document.lineAt(i).text + '\n';
    }
    
    // Keep only last 10 edits
    this.recentEdits.unshift({
      fileName,
      snippet: snippet.slice(0, 500),
      timestamp: Date.now(),
    });
    
    if (this.recentEdits.length > 10) {
      this.recentEdits.pop();
    }
  }

  private async extractSymbols(document: vscode.TextDocument): Promise<string[]> {
    const symbols: string[] = [];

    try {
      const documentSymbols = await vscode.commands.executeCommand<vscode.DocumentSymbol[]>(
        'vscode.executeDocumentSymbolProvider',
        document.uri
      );

      if (documentSymbols) {
        this.flattenSymbols(documentSymbols, symbols);
      }
    } catch {
      // Symbol extraction not available for this file type
    }

    return symbols;
  }

  private flattenSymbols(symbols: vscode.DocumentSymbol[], result: string[]): void {
    for (const symbol of symbols) {
      result.push(symbol.name);
      if (symbol.children) {
        this.flattenSymbols(symbol.children, result);
      }
    }
  }

  searchFiles(query: string): FileIndex[] {
    const results: FileIndex[] = [];
    const lowerQuery = query.toLowerCase();

    for (const [, file] of this.fileIndex) {
      const fileName = path.basename(file.path).toLowerCase();
      const matchesPath = file.path.toLowerCase().includes(lowerQuery);
      const matchesSymbol = file.symbols.some(s => 
        s.toLowerCase().includes(lowerQuery)
      );

      if (matchesPath || matchesSymbol) {
        results.push(file);
      }
    }

    return results.slice(0, 20);
  }

  /**
   * Get context for AI code completion with multi-file awareness
   */
  async getCompletionContext(document: vscode.TextDocument): Promise<CompletionContext> {
    const filePath = document.uri.fsPath;
    const fileIndex = this.fileIndex.get(filePath);
    
    // Get imports from current file
    const imports = fileIndex?.imports || this.extractImports(document.getText(), document.languageId);
    
    // Get related files (files that import this file or are imported by this file)
    const relatedFiles: CompletionContext['relatedFiles'] = [];
    
    // Files imported by current file (high relevance)
    const dependencies = this.importGraph.get(filePath) || new Set();
    for (const depPath of Array.from(dependencies).slice(0, 3)) {
      try {
        const depDoc = await vscode.workspace.openTextDocument(depPath);
        relatedFiles.push({
          fileName: path.basename(depPath),
          content: depDoc.getText().slice(0, 1000),
          relevance: 'high',
        });
      } catch {
        // Skip files we can't read
      }
    }
    
    // Files that import current file (medium relevance)
    for (const [otherPath, deps] of this.importGraph) {
      if (deps.has(filePath) && relatedFiles.length < 5) {
        try {
          const otherDoc = await vscode.workspace.openTextDocument(otherPath);
          relatedFiles.push({
            fileName: path.basename(otherPath),
            content: otherDoc.getText().slice(0, 500),
            relevance: 'medium',
          });
        } catch {
          // Skip files we can't read
        }
      }
    }
    
    // Get project structure
    const projectStructure = this.getProjectStructure(filePath);
    
    // Get recent edits (filter old ones)
    const fiveMinutesAgo = Date.now() - 5 * 60 * 1000;
    const recentEdits = this.recentEdits
      .filter(e => e.timestamp > fiveMinutesAgo && e.fileName !== filePath)
      .slice(0, 3)
      .map(({ fileName, snippet }) => ({ fileName: path.basename(fileName), snippet }));
    
    return {
      imports,
      relatedFiles,
      projectStructure,
      recentEdits,
    };
  }

  private getProjectStructure(currentFile: string): string[] {
    const structure: string[] = [];
    const currentDir = path.dirname(currentFile);
    
    // Get files in same directory and parent directories
    for (const [filePath] of this.fileIndex) {
      const fileDir = path.dirname(filePath);
      const relativePath = path.relative(currentDir, filePath);
      
      // Include files in same directory or 1-2 levels up/down
      const levels = relativePath.split(path.sep).filter(p => p !== '..').length;
      if (levels <= 3 && !relativePath.includes('node_modules')) {
        structure.push(relativePath);
      }
    }
    
    return structure.sort().slice(0, 50);
  }

  getFileIndex(): Map<string, FileIndex> {
    return this.fileIndex;
  }

  getImportGraph(): Map<string, Set<string>> {
    return this.importGraph;
  }
}
